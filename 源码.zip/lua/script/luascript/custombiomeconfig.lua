local BiomeConfigList = {}
local BiomeSpecialSubOrderBiomeConfigList = {}
local biomeDef = {
	highInterpolationType = 0,
	interval = 3,
	startpos = 1000,
	step = 4,
	shapemap = "",
	probGen = 1000,
	rangeZ = 16,
	rangeX = 16,
	seed = 2021
}

table.insert(BiomeConfigList, {
	genmode = 1,
	active = true,
	highInterpolationType = 1,
	mountainDropHeightIceAltar = 0,
	iceAltarRange = 2,
	step = 4,
	shapemap = "BiomeRegionShapeMapIceBreg",
	rangeZ = 32,
	rangeX = 32,
	seed = 2048,
	iceAltarGenPro = 100,
	mountainPeakHeighNeedNoisy = -1.975,
	mountainPeakAxiesAccuracy = 3,
	mountainHalfPeriodMaxFactor = 2,
	mountainHalfPeriodMinFactor = 0.6,
	mountainCurveAmplitude = 15,
	mainPeakNoiceHigh = 0.25,
	mountainPeakNoiseOverLayTime = 4,
	mountainPeakNoisePersistence = 0.5,
	mountainPeakNoiseLacunarity = 0.5,
	mountainPeakNoiseAmplitude = 2,
	mountainPeakNoiseFrequency = 0.5,
	mountainNoiceHigh = 0.18,
	mountainNoiseOverLayTime = 4,
	mountainNoisePersistence = 0.8,
	mountainNoiseLacunarity = 2,
	mountainNoiseAmplitude = 1,
	mountainNoiseFrequency = 0.1,
	mountainCoverHeight = 0.6,
	mountainStartHeight = 0,
	mountainSecondPeakLenRandMax = 4,
	mountainPeakLenRandMax = 8,
	mountainNearestHalfWidthMax = 9,
	mountainNearestHalfWidthMin = 9,
	mountainFarestHalfWidthMax = 8,
	mountainFarestHalfWidthMin = 5,
	mountainDropHeight = -0.9,
	mountainLenMax = 100,
	mountainLenMin = 80,
	mountainSmallContinous = 1,
	mountainSecondMiddleRange = 8,
	mountainMiddleRange = 12,
	secondDaryPeakAway = 4,
	secondDaryPeakNoiceHigh = 0.075,
	secondDaryPeakRadius = 2,
	secondDaryPeakMaxNum = 2,
	secondDaryPeakMinNum = 1,
	peakParaBolaFactor = 0.1,
	mainPeakAwayFromMainPeakRangeMin = 3,
	mainPeakAwayFromMainPeakRangeMax = 4,
	mainPeakRadius = 1,
	mountainRangeZ = 32,
	mountainRangeX = 32,
	iceGenProb = 3,
	biomeid = BIOME_ICE_PLAINS,
	mountainAnglesLarge = {
		60,
		70
	},
	mountainAnglesSmall = {
		60,
		70
	},
	mountainBezierControlPoints = {
		{
			196,
			200,
			65,
			149,
			60,
			211,
			0,
			0,
			187,
			252,
			65,
			35,
			84,
			119
		},
		{
			260,
			200,
			27,
			179,
			63,
			193,
			0,
			22,
			75,
			297,
			119,
			175,
			5,
			0
		},
		{
			300,
			200,
			28,
			118,
			210,
			195,
			0,
			48,
			166,
			0,
			273,
			137,
			19,
			82
		},
		{
			247,
			200,
			30,
			178,
			2,
			264,
			125,
			0,
			30,
			0,
			300,
			224,
			3,
			66
		},
		{
			283,
			200,
			37,
			182,
			89,
			55,
			154,
			94,
			178,
			156,
			179,
			65,
			200,
			0
		},
		{
			249,
			200,
			109,
			136,
			0,
			132,
			68,
			0,
			262,
			151,
			74,
			47,
			222,
			16
		},
		{
			300,
			200,
			98,
			145,
			31,
			69,
			108,
			204,
			78,
			1,
			202,
			220,
			210,
			24
		}
	},
	mountainHighBezierControlPoints = {
		{
			300,
			0,
			64,
			0,
			83,
			66,
			154,
			52,
			57,
			0,
			200,
			51
		},
		{
			300,
			0,
			106,
			0,
			162,
			50,
			204,
			68,
			224,
			0
		}
	},
	mountainExtendBezierControlPoints = {
		{
			300,
			179,
			151,
			140,
			0,
			0,
			300,
			217,
			0,
			49
		}
	},
	mountainPeakAngles = {
		30,
		50
	},
	antreCreateParam = {
		cavernFillStartPercentage = 1.05,
		cavernIrregularityFactor = 0.15,
		passageData = {
			passageRandomProbability = 200,
			Bottom = {
				{
					31,
					0,
					750
				},
				{
					32,
					750,
					1500
				},
				{
					150009,
					1500,
					2500
				},
				{
					110,
					2500,
					3500
				},
				{
					763,
					3500,
					4500
				},
				{
					150012,
					4500,
					5500
				}
			},
			Top = {
				{
					31,
					0,
					3500
				},
				{
					32,
					3500,
					8000
				}
			}
		},
		stoneCavernData = {
			cavernWallProbability = 1000,
			cavernRandomProbability = 1000,
			Bottom = {
				{
					31,
					0,
					750
				},
				{
					32,
					750,
					1500
				},
				{
					150009,
					1500,
					2500
				},
				{
					110,
					2500,
					3500
				},
				{
					763,
					3500,
					4500
				},
				{
					150012,
					4500,
					5500
				}
			},
			Top = {
				{
					31,
					0,
					3500
				},
				{
					32,
					3500,
					8000
				}
			},
			Wall = {
				{
					34,
					0,
					6000
				},
				{
					402,
					6000,
					6500
				}
			}
		},
		spaceCavernData = {
			cavernWallProbability = 1000,
			cavernRandomProbability = 1000,
			Bottom = {
				{
					31,
					0,
					1500
				},
				{
					32,
					1500,
					3000
				},
				{
					110,
					3000,
					4000
				},
				{
					763,
					4000,
					5000
				},
				{
					150012,
					5000,
					6500
				}
			},
			Top = {
				{
					31,
					0,
					3500
				},
				{
					32,
					3500,
					8000
				}
			},
			Wall = {
				{
					34,
					0,
					3000
				},
				{
					402,
					3000,
					4500
				}
			}
		},
		hotspringCavernData = {
			cavernWallProbability = 1000,
			cavernRandomProbability = 1000,
			Bottom = {
				{
					31,
					0,
					2000
				},
				{
					32,
					2000,
					4000
				}
			},
			Top = {
				{
					31,
					0,
					3500
				},
				{
					32,
					3500,
					8000
				}
			},
			Wall = {
				{
					34,
					0,
					0
				}
			}
		},
		MainBigCavernData = {
			cavernWallProbability = 1000,
			cavernRandomProbability = 1000,
			Bottom = {
				{
					31,
					0,
					550
				},
				{
					32,
					550,
					1000
				},
				{
					150009,
					1000,
					1250
				},
				{
					110,
					1250,
					2500
				},
				{
					763,
					2500,
					3500
				},
				{
					150012,
					3500,
					8000
				}
			},
			Top = {
				{
					31,
					0,
					2500
				},
				{
					32,
					2500,
					8000
				}
			},
			Wall = {
				{
					34,
					0,
					2000
				},
				{
					402,
					2000,
					3500
				}
			}
		}
	}
})
table.insert(BiomeConfigList, {
	mountainFarestHalfWidthMax = 8,
	active = true,
	mountainOffsetByCenter = 5,
	interval = 2,
	startpos = 30,
	ventCoreActiveHigh = 0.8,
	shapemap = "BiomeRegionShapeMapVolcano",
	probGen = 10,
	rangeZ = 32,
	rangeX = 32,
	seed = 2048,
	magmaTrailGenPreb_Mountain = 0,
	mountainSpaceSize = 4,
	mountainNearestHalfWidthMin = 12,
	riverMapComplexity = 100,
	mountainFarestHalfWidthMin = 4,
	ventNoiceHigh = 0.075,
	magmaTrailGenCount_Mountain = 1,
	magmaTrailLimitMinY_Mountain = 0,
	magmaTrailGenPreb_Volcano = 3,
	mountainNoiceHigh = 0.08,
	magmaTrailGenCount_Volcano = 8,
	magmaTrailLimitMinY_Volcano = 50,
	MOB3881_SpawnHeightLimit = 40,
	VolcanoAltarBlockDig = 206,
	VolcanoAltarBlockKey = 0,
	VolcanoAltarProb = 0,
	riverBreakageProc2 = 20,
	riverBreakageProc1 = 10,
	riverContinuous = 50,
	mountainNearestHalfWidthMax = 18,
	riverMapSize = 12,
	ventMountainBlentHigh = 0.3,
	ventMountainBlendFactor = 0.25,
	mountainDropHeight = -0.9,
	mountainLenMax = 80,
	mountainLenMin = 50,
	ventFlatness = 1,
	mountainSmallContinous = 1,
	ventParabolaCurvature = 0.7,
	ventParabolaNum = 12,
	ventR = 38,
	ventCoreR = 8,
	biomeid = BIOME_VOLCANO,
	mountainAnglesLarge = {
		75,
		270
	},
	mountainAnglesSmall = {
		15,
		30
	},
	VolcanoAltarOffset = {
		-3,
		-20,
		-3
	},
	MOB3881_SpawnUndergroundDepth = {
		3,
		10
	},
	magmaTrailLen = {
		18,
		22
	},
	magmaTrailInitialWidth = {
		1.5,
		2.5
	},
	magmaTrailWidthIncrement = {
		0.1,
		0.5
	},
	magmaTrailWidthLimit = {
		1,
		5
	}
})
table.insert(BiomeConfigList, {
	highCloudProb = 60,
	cloudProbability = 90,
	shrineRange = 320,
	loopTimes = 3,
	generatePercent = 65,
	active = true,
	waterProb = 10,
	rosyCloudProb = 5,
	lowCloudProb = 60,
	biomeid = BIOME_AIR_PLAINS_H,
	highCloudHeight = {
		1,
		8
	},
	lowCloudHeight = {
		1,
		8
	}
})
table.insert(BiomeConfigList, {
	highCloudProb = 60,
	active = true,
	cloudProbability = 90,
	generatePercent = 100,
	shapemap = "_",
	generateSpace = 80,
	groundPeak = 120,
	mainShipRange = 100,
	rosyCloudProb = 5,
	lowCloudProb = 60,
	biomeid = BIOME_AIRSHIP_H,
	highCloudHeight = {
		1,
		8
	},
	lowCloudHeight = {
		1,
		8
	},
	absoluteHeightRange = {
		180,
		200
	},
	bOSSGenerationSpace = {
		20,
		50,
		80
	},
	blockIdListDelay = {
		150734,
		150735
	},
	sightDistanceAdjustment = {
		0.5,
		0.6,
		0.8,
		1,
		1
	},
	airshipConfig = {
		eliteVBP = {
			weights = {
				{
					vbp = "IronFleet_Elite_1",
					weight = 100
				},
				{
					vbp = "IronFleet_Elite_2",
					weight = 100
				}
			},
			replaceRules = {
				{
					count = 1,
					creatureID = 3938,
					replaceType = 1,
					targetBlockID = 919
				},
				{
					count = 1,
					creatureID = 3939,
					replaceType = 1,
					targetBlockID = 920
				},
				{
					count = 1,
					creatureID = 3940,
					replaceType = 1,
					targetBlockID = 921
				},
				{
					count = 1,
					creatureID = 3941,
					replaceType = 1,
					targetBlockID = 922
				},
				{
					lootIndex = 200501,
					creatureID = 200370,
					replaceType = 2,
					targetBlockID = 450
				},
				{
					lootIndex = 200500,
					creatureID = 200370,
					replaceType = 2,
					targetBlockID = 449
				},
				{
					blockdata = 8,
					creatureID = 150912,
					replaceType = 4,
					targetBlockID = 150912
				}
			}
		},
		commonVBPs = {
			{
				spawnProbability = 100,
				xOffset = -78,
				jitterRadius = 5,
				zOffset = -68,
				generateSpace = 30,
				weights = {
					{
						vbp = "IronFleet_Normal_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_3",
						weight = 100
					}
				},
				heightRange = {
					-30,
					-20
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					},
					{
						lootIndex = 200501,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 450
					},
					{
						lootIndex = 200500,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 449
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = 78,
				jitterRadius = 5,
				zOffset = 68,
				generateSpace = 30,
				weights = {
					{
						vbp = "IronFleet_Normal_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_3",
						weight = 100
					}
				},
				heightRange = {
					-30,
					-20
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					},
					{
						lootIndex = 200501,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 450
					},
					{
						lootIndex = 200500,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 449
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = -78,
				jitterRadius = 5,
				zOffset = 68,
				generateSpace = 30,
				weights = {
					{
						vbp = "IronFleet_Normal_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_3",
						weight = 100
					}
				},
				heightRange = {
					-30,
					-20
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					},
					{
						lootIndex = 200501,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 450
					},
					{
						lootIndex = 200500,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 449
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = 78,
				jitterRadius = 5,
				zOffset = -68,
				generateSpace = 30,
				weights = {
					{
						vbp = "IronFleet_Normal_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Normal_3",
						weight = 100
					}
				},
				heightRange = {
					-30,
					-20
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					},
					{
						lootIndex = 200501,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 450
					},
					{
						lootIndex = 200500,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 449
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = 40,
				jitterRadius = 5,
				zOffset = -60,
				generateSpace = 1,
				weights = {
					{
						vbp = "IronFleet_Small_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_3",
						weight = 100
					}
				},
				heightRange = {
					0,
					10
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = 80,
				jitterRadius = 5,
				zOffset = 0,
				generateSpace = 1,
				weights = {
					{
						vbp = "IronFleet_Small_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_3",
						weight = 100
					}
				},
				heightRange = {
					0,
					10
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = 50,
				jitterRadius = 5,
				zOffset = 50,
				generateSpace = 1,
				weights = {
					{
						vbp = "IronFleet_Small_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_3",
						weight = 100
					}
				},
				heightRange = {
					0,
					10
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = -40,
				jitterRadius = 5,
				zOffset = -60,
				generateSpace = 1,
				weights = {
					{
						vbp = "IronFleet_Small_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_3",
						weight = 100
					}
				},
				heightRange = {
					0,
					10
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = -80,
				jitterRadius = 5,
				zOffset = 0,
				generateSpace = 1,
				weights = {
					{
						vbp = "IronFleet_Small_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_3",
						weight = 100
					}
				},
				heightRange = {
					0,
					10
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					}
				}
			},
			{
				spawnProbability = 100,
				xOffset = -50,
				jitterRadius = 5,
				zOffset = 50,
				generateSpace = 1,
				weights = {
					{
						vbp = "IronFleet_Small_1",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_2",
						weight = 100
					},
					{
						vbp = "IronFleet_Small_3",
						weight = 100
					}
				},
				heightRange = {
					0,
					10
				},
				replaceRules = {
					{
						count = 1,
						creatureID = 3938,
						replaceType = 1,
						targetBlockID = 919
					},
					{
						count = 1,
						creatureID = 3939,
						replaceType = 1,
						targetBlockID = 920
					},
					{
						lootIndex = 200502,
						creatureID = 200370,
						replaceType = 2,
						targetBlockID = 685
					}
				}
			}
		}
	}
})
table.insert(BiomeConfigList, {
	interval = 4,
	active = true,
	rate = 0.6,
	biomeid = BIOME_DESERT_OASIS
})
table.insert(BiomeConfigList, {
	edgeThickness = 4,
	active = true,
	biomeid = BIOME_DESERT_LAKE
})
table.insert(BiomeConfigList, {
	rate = 0.7,
	island_interval = 10,
	active = true,
	island_thickness = 3,
	island_rate = 0.5,
	island_shore_thickness = 2,
	edgeThickness = 1,
	biomeid = BIOME_DEEPOCEAN
})
table.insert(BiomeConfigList, {
	random = 1,
	active = true,
	biomeid = BIOME_ICE_PLAINS_FRIZEB_LAKE
})
table.insert(BiomeConfigList, {
	maxFactor = 2,
	active = true,
	minFactor = 1,
	biomeid = BIOME_ICE_PLAINS_CONIFEROUS_FOREST
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.3,
	sub_edgeThickness = 3,
	main_biomeid = BIOME_PLAINS,
	biomeid = BIOME_PLAINS_ARID
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.3,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_PLAINS,
	biomeid = BIOME_PLAINS_DANDELION
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.3,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_PLAINS,
	biomeid = BIOME_PLAINS_RAPESEED
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.3,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_FOREST,
	biomeid = BIOME_FOREST_LAVENDER
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.5,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_FOREST,
	biomeid = BIOME_FOREST_FOXTAIL
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.3,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_FOREST,
	biomeid = BIOME_FOREST_CHRYSANTH
})
table.insert(BiomeConfigList, {
	sub_interval = 8,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_BASIN,
	biomeid = BIOME_BASIN_RICE
})
table.insert(BiomeConfigList, {
	sub_interval = 8,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_SWAMPLAND,
	biomeid = BIOME_SWAMPLAND_RIVERSIDE
})
table.insert(BiomeConfigList, {
	sub_interval = 6,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_AIR_PLAINS,
	biomeid = BIOME_AIRISLAND_SHINE
})
table.insert(BiomeConfigList, {
	sub_interval = 8,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 1,
	main_biomeid = BIOME_EXTREMEHILLS,
	biomeid = BIOME_EXTREMEHILLS_PLUM
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 2,
	main_biomeid = BIOME_DESERT,
	biomeid = BIOME_DESERT_HUYANG
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 3,
	main_biomeid = BIOME_JUNGLE,
	biomeid = BIOME_JUNGLE_LANHUAYING
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 2,
	main_biomeid = BIOME_EXTREMEHILLS,
	biomeid = BIOME_EXTREMEHILLS_FENGYE
})
table.insert(BiomeConfigList, {
	sub_interval = 4,
	active = true,
	sub_rate = 0.7,
	sub_edgeThickness = 2,
	main_biomeid = BIOME_EXTREMEHILLS,
	biomeid = BIOME_EXTREMEHILLS_YINXING
})

function GetCustomBiomeCount()
	return #BiomeConfigList
end

function GetCustomBiomeConfig(idx)
	local cfg = BiomeConfigList[idx]

	if not cfg or not cfg.active then
		return ""
	end

	local data = copy_table(cfg)

	for k, v in pairs(biomeDef) do
		if data[k] == nil then
			data[k] = v
		end
	end

	local ok, json = pcall(JSON.encode, JSON, data)

	if not ok then
		return ""
	end

	if string.len(json) >= 8192 then
		print("ERROR! Custom Biome Config -> json is too long!")

		return ""
	end

	return json
end

BiomeSpecialSubOrderBiomeConfigList = {
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 29,
		topBlock = 29,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_DESERT,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 100,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_PLAINS,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 100,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_FOREST,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 100,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_SWAMPLAND,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 100,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_TAIGA,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 123,
		topBlock = 120,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_ICE_PLAINS,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 233,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_REDSOIL,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 100,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_JUNGLE,
		biomeid = BIOME_DESERT_CITY
	},
	{
		random = 10000,
		rangeZ = 3,
		rangeX = 3,
		fillBlock = 101,
		topBlock = 100,
		distanceZ = 6,
		distanceX = 6,
		replaceBiomeid = BIOME_BASIN,
		biomeid = BIOME_DESERT_CITY
	}
}

function GetBiomeSpecialCount()
	return #BiomeSpecialSubOrderBiomeConfigList
end

function GetBiomeSpecialConfig(idx)
	local cfg = BiomeSpecialSubOrderBiomeConfigList[idx]

	if not cfg then
		return ""
	end

	local data = copy_table(cfg)

	for k, v in pairs(biomeDef) do
		if data[k] == nil then
			data[k] = v
		end
	end

	local ok, json = pcall(JSON.encode, JSON, data)

	if not ok then
		return ""
	end

	if string.len(json) > 4095 then
		print("ERROR! Custom Biome Config -> json is too long!")

		return ""
	end

	return json
end

local DebugBiomeCmdBiomeColor = {
	[0] = {
		128,
		255,
		255
	},
	{
		38,
		255,
		0
	},
	{
		255,
		215,
		0
	},
	{
		0,
		128,
		0
	},
	[5] = {
		110,
		135,
		2
	},
	[6] = {
		0,
		128,
		64
	},
	[7] = {
		167,
		213,
		1
	},
	[8] = {
		200,
		255,
		255
	},
	[19] = {
		255,
		255,
		128
	},
	[49] = {
		0,
		0,
		255
	},
	[63] = {
		215,
		255,
		254
	},
	[83] = {
		215,
		255,
		229
	},
	[84] = {
		201,
		251,
		193
	},
	[85] = {
		156,
		250,
		142
	},
	[86] = {
		233,
		250,
		142
	},
	[87] = {
		100,
		142,
		0
	},
	[18] = {
		219,
		0,
		27
	}
}

function GetDebugBiomeCmdConfig(i)
	if DebugBiomeCmdBiomeColor[i] then
		return DebugBiomeCmdBiomeColor[i][1], DebugBiomeCmdBiomeColor[i][2], DebugBiomeCmdBiomeColor[i][3]
	end

	return 0, 0, 0
end
