_G.client_M = {}
local class = _G.class

if not class then
	return
end

local container = _G.container
client_M.msgpack = loadwwwcache("MessagePack")

loadwwwcache("accountcs")
loadwwwcache("errorcodetostring")

local ItemUseSkinDef = loadwwwcache("res.ItemUseSkinDef")
_G.ItemUseSkinDef = ItemUseSkinDef
local ItemSpecial = loadwwwcache("res.ItemSpecial")
client_M.DevConfig = loadwwwcache("res.Developer")
client_M.policyAgeControlConfig = loadwwwcache("res.policyAgeControl")
client_M.DefCache = {}
client_M.http_authkey = "2ddb7619717147439c83ab022e9d4d38"
client_M.account_def = loadwwwcache("account_def")
client_M.antiaddiction = loadwwwcache("res.antiaddiction")
client_M.online_def = loadwwwcache("online_def")
client_M.__INT32__ = 2147483648.0
client_M.__UINT32__ = 4294967296.0

function client_M:qqinfo2vipinfo(qqinfo)
	qqinfo = qqinfo or {}
	local gender = qqinfo.gender or 0
	local nickname = qqinfo.nickname or ""
	local is_blue_vip = qqinfo.is_blue_vip or 0
	local is_blue_year_vip = qqinfo.is_blue_year_vip or 0
	local blue_vip_level = qqinfo.blue_vip_level or 0
	local is_super_blue_vip = qqinfo.is_super_blue_vip or 0
	local is_yellow_vip = qqinfo.is_yellow_vip or 0
	local is_yellow_year_vip = qqinfo.is_yellow_year_vip or 0
	local yellow_vip_level = qqinfo.yellow_vip_level or 0
	local is_super_yellow_vip = qqinfo.is_super_yellow_vip or 0
	local info = {
		vipType = VIP_NONE,
		vipLevel = 0
	}
	local apiId = GetClientInfo():GetAppId()

	if isQQGame() then
		if is_super_blue_vip ~= 0 then
			if is_blue_year_vip ~= 0 then
				info.vipType = VIP_QQ_BLUEDELUXE_YEARLY
			else
				info.vipType = VIP_QQ_BLUEDELUXE
			end
		elseif is_blue_vip ~= 0 then
			if is_blue_year_vip ~= 0 then
				info.vipType = VIP_QQ_BLUE_YEARLY
			else
				info.vipType = VIP_QQ_BLUE
			end
		end

		info.vipLevel = blue_vip_level
	elseif apiId == 109 then
		if is_super_yellow_vip ~= 0 then
			if is_yellow_year_vip ~= 0 then
				info.vipType = VIP_QQ_YELLOWDELUXE_YEARLY
			else
				info.vipType = VIP_QQ_YELLOWDELUXE
			end
		elseif is_yellow_vip ~= 0 then
			if is_yellow_year_vip ~= 0 then
				info.vipType = VIP_QQ_YELLOW_YEARLY
			else
				info.vipType = VIP_QQ_YELLOW
			end
		end

		info.vipLevel = yellow_vip_level
	end

	info.vipExp = 0

	if info.vipLevel and info.vipLevel > 7 then
		info.vipLevel = 7
	end

	return info
end

client_M.ad_init_flag = false
client_M.already_init_ad_platform_map = {}
client_M.ad_platform_id = nil
client_M.recharge_event_id = "recharge.event"
client_M.StdioRoot = LuaInterface:getStdioRoot()
client_M.clientcfg = {}
cpp_const.ITEM_ID_MINI_COIN = cpp_const.ITEM_ID_MINI_COIN or 10002

require("luascript.clientEx.Account")

client_M.eventcache = {}
client_M.do_not_showloadloop = {
	"share_info",
	"chat_query",
	"not_ok",
	"friend_list",
	"friend_check_newchat",
	"ad_info",
	"ad_show",
	"other_baseinfo_check",
	"ad_platform_id",
	"other_baseinfo",
	"steam_order_new",
	"steam_order_finish",
	"order_check",
	"order_notify",
	"avatar_seat_init",
	"online_report",
	"get_online_report",
	"set_guest",
	"set_noviceGuideFlag",
	"set_noviceGuideFlagEx",
	"clicall",
	"ad_info_update",
	"update",
	"set_name",
	"login_v2",
	"login_v3",
	"get_rider_frequently_use_status",
	"login_limit",
	"get_cmcc_pushid"
}

for i, v in ipairs(client_M.do_not_showloadloop) do
	client_M.do_not_showloadloop[v] = true
end

client_M.do_not_show_errrocode = {}

for i, v in ipairs({
	ErrorCode.DEV_MAPSTORE_NEED_REFRESH,
	ErrorCode.DEV_MAPBAG_NEED_REFRESH,
	ErrorCode.QUESTION_NOT_SET,
	ErrorCode.DEV_MAPSTORE_CHEST_LEVEL_NOT_ENOUGH,
	ErrorCode.IDCARD_NOT_VALID,
	ErrorCode.IDCARD_AUTH_FAILED,
	ErrorCode.PRECHECK_ACCOUNT_BIND_ALREADY,
	ErrorCode.PRECHECK_SMS_PHONENUM_UIN_NOTRIGHT,
	ErrorCode.PRECHECK_SMS_PHONENUM_TYPE_ERROR,
	ErrorCode.PRECHECK_SMS_EMAIL_TYPE_ERROR,
	ErrorCode.PRECHECK_SMS_EMAIL_UIN_NOTRIGHT,
	ErrorCode.PRECHECK_SMS_PHONENUM_BINDED_DIFF,
	ErrorCode.PRECHECK_SMS_EMAIL_BINDED_DIFF,
	ErrorCode.PRECHECK_SLOWDOWN_PLEASE,
	ErrorCode.PRECHECK_SMS_CLOSE_WINDOWS,
	ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW,
	ErrorCode.CDKEY_REACH_LIMIT_PERDAY_PERUIN,
	ErrorCode.CDKEY_USE_REACH_LIMIT,
	ErrorCode.CDKEY_REACH_LIMIT_GROUP,
	ErrorCode.CDKEY_REACH_LIMIT_TOTAL_PERUIN,
	ErrorCode.CDKEY_REACH_LIMIT_TOTAL,
	ErrorCode.CDKEY_REACH_LIMIT_PERDAY,
	ErrorCode.PRECHECK_IDCARD_AUTHED_OK,
	ErrorCode.LOGIN_LIMIT_HIT_LOGIN,
	ErrorCode.LOGIN_LIMIT_CHANNEL_AUTH_ERROR,
	ErrorCode.LOGIN_LIMIT_NO_IDCARD,
	ErrorCode.IDCARD_AUTH_UIN_EXCEED
}) do
	client_M.do_not_show_errrocode[v] = true
end

client_M.check_iteminfo_full = {
	"homesvr.chest_lot_one",
	"homesvr.chest_lot_ten",
	"homesvr.chest_bonus",
	"homesvr.chest_lingqu_baoxiang",
	"homesvr.chest_trader_buy",
	"shopsvr.item_buy",
	"shopsvr.item_use",
	"shopsvr.item_reclaim_onestep",
	"shopsvr.group_unlock_award",
	"shopsvr.cdkey",
	"shopsvr.ad_finish"
}

for i, v in ipairs(client_M.check_iteminfo_full) do
	client_M.check_iteminfo_full[v] = true
end

require("luascript.clientEx.AccountManager")
require("luascript.clientEx.HomeChestMgr")
require("luascript.clientEx.BuddyInfo")
require("luascript.clientEx.BuddyDetail")
require("luascript.clientEx.FansData")
require("luascript.clientEx.BuddyManager")
require("luascript.clientEx.ClientMgr")
require("luascript.clientEx.SdkManager")
require("luascript.clientEx.CSMgr")
require("luascript.clientEx.UIActorBodyManager")
require("luascript.clientEx.GM")

return require("luascript.clientEx.ServiceAtClientSide")
