MCodeUploadMgr = {
	downUrl = "",
	msgKey = "",
	seq = 0,
	baseSeq = 5000000,
	isCancelPushlish = true,
	screenShotSeq = 0,
	errMsg = "",
	curMode = 0
}

function MCodeUploadMgr:uploadMcode(mode)
	MiniCodeUtils:Log("MCodeUploadMgr uploadMcode, mode:", mode)

	if mode == 1 then
		self.curMode = 1

		MCodeUploadMgr:uploadMcodeToMinicode()
	elseif mode == 2 then
		self.curMode = 2

		MCodeUploadMgr:uploadMcodeToMiniWorld()
	elseif self.curMode == 1 then
		MiniCodeUtils:Log("MCodeUploadMgr retry_btnClick uploadMcodeToMinicode")
		MCodeUploadMgr:uploadMcodeToMinicode()
	elseif self.curMode == 2 then
		MiniCodeUtils:Log("MCodeUploadMgr retry_btnClick uploadMcodeToMiniWorld")
		MCodeUploadMgr:uploadMcodeToMiniWorld()
	end
end

function MCodeUploadMgr:ShowPublicException()
	local data = {
		mbuttonName = "确定",
		modal = false,
		showContext = "作品数据异常，发布失败"
	}

	GetInst("ConfirmInterface"):ShowPopView(1, data)
end

function MCodeUploadMgr:getPublishParams(keyWords)
	local params = {
		toolVersion = 2,
		fromType = "lua",
		mapId = MCodeManager:getMapData().mapId,
		keyWords = keyWords,
		sceneInfo = MCodeManager:getSceneInfo()
	}
	local errInfo = nil
	local isOk = true
	local jmiString = MCodeMgr:getJmiJson()
	local ok, json_data = pcall(JSON.decode, JSON, jmiString)

	if ok and type(json_data) == "table" then
		MiniCodeUtils:Log("MCodeUploadMgr ", json_data)

		if json_data.toolVersion == nil or json_data.mapSource == nil or json_data.originType == nil then
			errInfo = "toolVersion mapSource originType nil"
			isOk = false
		end

		if json_data.mapSource == 3 and (json_data.last_info == nil or json_data.last_info.last_work_id == nil) then
			errInfo = "last info is null"
			isOk = false
		end

		if (json_data.mapSource == 5 or json_data.mapSource == 4 or json_data.mapSource == 6) and json_data.templateId == nil then
			errInfo = "templateId is null"
			isOk = false
		end

		if json_data.thumbPath then
			params.screenShot = json_data.thumbPath
		end

		if json_data.toolVersion then
			params.toolVersion = json_data.toolVersion
		end

		if json_data.mapSource then
			params.mapSource = json_data.mapSource
		else
			params.mapSource = -1
			isOk = false
		end

		if json_data.name then
			params.name = json_data.name
		end

		if json_data.templateId then
			params.templateId = json_data.templateId
		end

		if json_data.stageId then
			params.stageId = json_data.stageId
		end

		if json_data.courseId then
			params.courseId = json_data.courseId
		end

		if json_data.ori_info then
			params.ori_info = json_data.ori_info
		else
			MiniCodeUtils:Log("MCodeUploadMgr getPublishParams exception ori_info null")
		end

		if json_data.last_info then
			params.last_info = json_data.last_info
		else
			MiniCodeUtils:Log("MCodeUploadMgr getPublishParams exception last_info null")
		end

		if json_data.themeId then
			params.themeId = json_data.themeId
		end

		if WorldMgr and WorldMgr.getWorldTime then
			params.totalCodeTime = tostring(math.floor(WorldMgr:getWorldTime() / 20))
		else
			MiniCodeUtils:Log("MCodeUploadMgr getPublishParams exception TotalCodeTime null")
		end

		local nEventCount, nBlockCount = MiniCodeBlockStatistic()
		params.curBlockCount = tostring(nBlockCount)

		if json_data.CurBlockTypeCount then
			params.curBlockTypeCount = json_data.CurBlockTypeCount
		else
			MiniCodeUtils:Log("MCodeUploadMgr getPublishParams exception curBlockTypeCount null")

			params.curBlockTypeCount = "0"
		end

		params.originType = MiniCodeUtils:getMapOriginType()

		if json_data.originType and params.originType ~= json_data.originType then
			MiniCodeUtils:Log("MCodeUploadMgr getPublishParams originType is exception")

			errInfo = "originType != jmi originType"
			isOk = false
		end

		if params.originType == 1 then
			params.last_info = nil
		end
	else
		return false, "jmi is null", params
	end

	MiniCodeUtils:Log("MCodeUploadMgr getPublishParams: ", params)

	return isOk, errInfo, params
end

function MCodeUploadMgr:handleExitScreenShot(message)
	if self.screenShotSeq == -1000 then
		MCodeUploadMgr:handleEnterPublic(self.fromType, message.thumbPath)
	elseif MsgApi and message then
		MsgApi.changeScreenShotResp({
			code = 0,
			screenShot = message.thumbPath
		}, self.screenShotSeq)
	else
		MsgApi.changeScreenShotResp({
			code = 0,
			message = "screen shot fail"
		}, self.screenShotSeq)
	end
end

function MCodeUploadMgr:handleEnterScreenShotUI(message)
	self.screenShotSeq = message.seq or 0

	if MsgApi then
		threadpool:work(function ()
			GetInst("ScreenShotInterface"):OpenView("shot")

			if message.seq == -1000 then
				GetInst("ScreenShotInterface"):ScreenShot()
			end
		end)
	end
end

function MCodeUploadMgr:handleExitPublicUI(message)
	local data = {}

	if message.type == MCMessageType.native_publish_complete then
		data.isPublish = true
	end

	if message.type == MCMessageType.native_publish_complete or message.data and message.data.fromType and message.data.fromType == "native" then
		MiniCodeApi:quitWorld(true, nil, false, false, data)
	end
end

function MCodeUploadMgr:handleClosePublicUI()
	if self.havePublished == false and self.screenShotSeq == -1000 then
		if self.fromType == "native" then
			local data = {}

			MiniCodeApi:quitWorld(true, nil, false, false, data)

			return true
		end
	else
		MCodeUploadMgr:handleEnterPublic(self.fromType)
	end

	return false
end

function MCodeUploadMgr:fetchMCodeCheckWords()
	local mapId = AccountManager:getCurWorldId()
	local result = MCodeMgr:doAction(1, JSON:encode({
		"fetchMCodeCheckWords",
		tostring(mapId)
	}), 1)
	local retArray = {}
	local ok, json_data = pcall(JSON.decode, JSON, result)

	if ok and type(json_data) == "table" then
		table.remove(json_data, 1)

		for index, fruit in ipairs(json_data) do
			local obj = {}
			local fields = {}

			for part in string.gmatch(fruit, "[^_]+") do
				table.insert(fields, part)
			end

			if #fields >= 2 then
				obj.position = fields[1]
				obj.text = fields[2]
				retArray[#retArray + 1] = obj
			end
		end
	end

	return retArray
end

function MCodeUploadMgr:handleEnterPublic(fromType, thumbPath)
	local havePubliced = self.havePublished

	if MsgApi then
		threadpool:work(function ()
			local keyWorks = MCodeUploadMgr:fetchMCodeCheckWords()

			MiniCodeUtils:Log("zuoyou******Publish, keyWorks: ", TableToStr and TableToStr(keyWorks) or "")

			local ok, errInfo, params = MCodeUploadMgr:getPublishParams(keyWorks)

			if ok == false then
				local jmiString = MCodeMgr:getJmiJson()
				local ok, json_data = pcall(JSON.decode, JSON, jmiString)

				if ok and type(json_data) == "table" then
					SlsLog:logReport("map_publish", "get_publish_param_err_jmi", {
						jmi = json_data
					}, 4)
				end

				SlsLog:logReport("map_publish", "get_publish_param_err", {
					err = errInfo,
					param = params
				}, 4)
			else
				SlsLog:logReport("map_publish", "get_publish_param", params, 4)
			end

			if thumbPath and #thumbPath > 1 then
				params.screenShot = thumbPath
			end

			if havePubliced ~= nil then
				params.havePubliced = havePubliced
			end

			params.fromType = fromType

			MsgApi.publishWorkV2(params)
		end)
	end
end

function MCodeUploadMgr:handleEnterPublicUI(fromType)
	self.fromType = fromType
	local sceneInfo = MCodeManager:getSceneInfo()
	self.havePublished = false

	if sceneInfo and sceneInfo.data and sceneInfo.data.havePubliced then
		self.havePublished = sceneInfo.data.havePubliced
	end

	if self.havePublished == false then
		MCodeUploadMgr:handleEnterScreenShotUI({
			seq = -1000
		})
	elseif MsgApi then
		MCodeUploadMgr:handleEnterPublic(fromType)
	end
end

function MCodeUploadMgr:handeCancelUploadMcode(mesage)
	self.isCancelPushlish = true

	threadpool:notify(self.msgKey, ErrorCode.NONE, "")
	MCodeMgr:doAction(1, JSON:encode({
		"cancelUploadMCode"
	}), 1)
end

function MCodeUploadMgr:handleStartUploadMcode(message)
	self.isCancelPushlish = false

	threadpool:work(function ()
		if self.isCancelPushlish == false then
			MsgApi.uploadProgress({
				code = 0,
				progress = 5,
				message = "start save map"
			})
		end

		if message.data == nil or message.data.name == nil or message.data.openCode == nil then
			if self.isCancelPushlish == false then
				MsgApi.uploadMcodeResp({
					code = -1,
					message = "param err[name or openCode null]"
				}, message.seq)
			end

			return
		else
			local saveInfo = {}

			MiniCodeApi:saveMap(message.data.name, saveInfo.tempType, saveInfo.homework, false, false, message.data.openCode)
		end

		if self.isCancelPushlish == false then
			MsgApi.uploadProgress({
				code = 0,
				progress = 10,
				message = "start save map success"
			})
		end

		local needUploadCover = true

		if message and message.data and message.data.uploadCover then
			needUploadCover = message.data.uploadCover
		end

		local data = MCodeUploadMgr:backgroundUploadMcodeToMinicode(function (progress)
			if self.isCancelPushlish == false then
				MsgApi.uploadProgress({
					code = 0,
					progress = progress,
					message = message
				})
			end
		end, needUploadCover)

		if data and self.isCancelPushlish == false then
			MiniCodeUtils:Log("MCodeUploadMgr ", data)
			MsgApi.uploadMcodeResp(data, message.seq)
		elseif self.isCancelPushlish == true then
			MiniCodeUtils:Log("MCodeUploadMgr publish cancel")
		else
			MiniCodeUtils:Log("MCodeUploadMgr publish exception")
		end
	end)
end

function MCodeUploadMgr:uploadMcodeExit(isSuccess)
	local saveInfo = {}

	if isSuccess == true then
		MiniCodeApi:quitWorld(true, saveInfo, false, false, {
			toast = "上传作品成功"
		})
	else
		MiniCodeApi:quitWorld(true, saveInfo, false, false, {})
	end
end

function MCodeUploadMgr:uploadMcodeToMinicode()
	MiniCodeUtils:Log("MCodeUploadMgr uploadMcodeToMinicode: 开始上传")
	threadpool:work(function ()
		if GetInst("UploadProgressInterface") then
			GetInst("UploadProgressInterface"):OpenView()
		else
			return
		end

		local ret, coverUrl = MCodeUploadMgr:uploadMinicodeCloud("image", "png", "uploadCover")

		if ret < 0 then
			GetInst("UploadProgressInterface"):ShowUploadStatus(0)

			return
		end

		local ret1, mcodeUrl = MCodeUploadMgr:uploadMinicodeCloud("mcode", "mcode", "uploadMcode")

		if ret1 < 0 then
			GetInst("UploadProgressInterface"):ShowUploadStatus(0)

			return
		end

		local suffix = string.sub(mcodeUrl, -6)

		if suffix ~= ".mcode" then
			GetInst("UploadProgressInterface"):ShowUploadStatus(0)

			return
		end

		local mapId = tostring(MCodeManager:getMapData().mapId)
		local toolVersion = 0
		local liteVersion = ""
		local title = ""
		local jmiString = MCodeMgr:getJmiJson()
		local ok, json_data = pcall(JSON.decode, JSON, jmiString)

		if ok and type(json_data) == "table" then
			MiniCodeUtils:Log("MCodeUploadMgr getJmiJson: ", json_data)

			toolVersion = json_data.toolVersion
			liteVersion = json_data.liteVesion
			title = json_data.name
		else
			return
		end

		MCNetworkApi:saveMcodeInfoToCloud(title, mapId, coverUrl, mcodeUrl, toolVersion, liteVersion, function (str)
			local resInfo = JSON:decode(str)

			if resInfo and resInfo.code == 0 then
				GetInst("UploadProgressInterface"):ShowUploadStatus(1)
				threadpool:delay(1, function ()
					MCodeUploadMgr:uploadMcodeExit(true)
				end)
			else
				GetInst("UploadProgressInterface"):ShowUploadStatus(0)
			end

			MiniCodeUtils:Log("MCodeUploadMgr saveMcodeInfoToCloud: ", str)
		end)
	end)
end

function MCodeUploadMgr:backgroundUploadMcodeToMinicode(progressCallBack, needUploadCover)
	MiniCodeUtils:Log("MCodeUploadMgr backgroundUploadMcodeToMinicode: 开始上传")

	if progressCallBack and type(progressCallBack) == "function" then
		progressCallBack(20, "start upload")
	end

	local ret, coverUrl = nil

	if needUploadCover == true then
		ret, coverUrl = MCodeUploadMgr:uploadMinicodeCloud("image", "png", "uploadCover")

		if ret < 0 then
			return {
				code = -1,
				message = "upload cover fail"
			}
		end
	end

	if progressCallBack and type(progressCallBack) == "function" then
		progressCallBack(40, "upload cover")
	end

	local ret1, mcodeUrl = MCodeUploadMgr:uploadMinicodeCloud("mcode", "mcode", "uploadMcode")

	if ret1 < 0 then
		return {
			code = -2,
			message = "upload mcode fail"
		}
	end

	local suffix = string.sub(mcodeUrl, -6)

	if suffix ~= ".mcode" then
		MiniCodeUtils:Log("MCodeUploadMgr url error: ", mcodeUrl)

		return {
			code = -2,
			message = "upload mcode fail URL error"
		}
	end

	if progressCallBack and type(progressCallBack) == "function" then
		progressCallBack(80, "upload mcode")
	end

	return {
		message = "success",
		code = 0,
		coverUrl = coverUrl,
		mcodeUrl = mcodeUrl
	}
end

function MCodeUploadMgr:uploadMcodeToMiniWorld()
	MiniCodeUtils:Log("MCodeUploadMgr uploadMcodeToMiniWorld: 开始上传")

	local worldDesc = AccountManager:findWorldDesc(WorldMgr:getWorldId())

	if worldDesc == nil then
		GetInst("UploadProgressInterface"):ShowUploadStatus(0)

		return
	end

	local toolVesion = worldDesc.editorSceneSwitch and 2 or 0

	if toolVesion < 2 then
		MiniCodeApi:quitWorld(true, nil, false, false, {})

		return
	end

	if worldDesc.tempType ~= 0 then
		MCodeMgr:setWDescKeyValue(JSON:encode({
			key = "TempType",
			Value = 0
		}))
	end

	threadpool:work(function ()
		local ret = MCodeUploadMgr:uploadMiniWorldCloud()

		if ret < 0 then
			if ret == -2 then
				GetInst("UploadProgressInterface"):CloseView()
				GetInst("ArchivesPopInterface"):OpenView()

				return
			end

			GetInst("UploadProgressInterface"):ShowUploadStatus(0)

			return
		end

		GetInst("UploadProgressInterface"):ShowUploadStatus(1)
		threadpool:delay(1, function ()
			MCodeUploadMgr:uploadMcodeExit(true)
		end)
	end)
end

function MCodeUploadMgr:asyncUploadResultCallBack(errMsg)
	local result = JSON:decode(errMsg)

	if result.seq and result.msg then
		if result.seq == -4000 then
			threadpool:notify(self.msgKey, ErrorCode.OK, result.msg)
		else
			local seq = result.seq - self.baseSeq
			local msgKey = "upload" .. tostring(seq)

			threadpool:notify(msgKey, ErrorCode.OK, result.msg)
		end
	end
end

function MCodeUploadMgr:uploadMinicodeCloud(dataType, ext, uplaodType, filePath)
	self.errMsg = ""
	self.seq = self.seq + 1
	local msgKey = "upload" .. tostring(self.seq)
	self.msgKey = msgKey

	MiniCodeUtils:Log("zuoyou MCodeUploadMgr getObsUploadUrl: ", filePath or "filePath Null")
	MCNetworkApi:getObsUploadUrl(dataType, ext, function (str)
		MiniCodeUtils:Log("MCodeUploadMgr getObsUploadUrl: ", dataType, " ext", ext, str)

		local resInfo = JSON:decode(str)

		if resInfo and resInfo.code == 0 and resInfo.data and resInfo.data.uploadUrl then
			local obsUrl = resInfo.data.uploadUrl
			self.downUrl = resInfo.data.downloadUrl
			local mapId = MCodeManager:getMapData().mapId
			local seq = self.seq + self.baseSeq
			local respdata = nil

			if uplaodType == "uploadMcode" then
				respdata = MCodeMgr:doAction(1, JSON:encode({
					"reqUploadMCode",
					seq,
					obsUrl,
					mapId,
					5
				}), 1)
			else
				MiniCodeUtils:Log("zuoyou MCodeUploadMgr getObsUploadUrl2: ", filePath or "filePath Null")

				if filePath == nil then
					respdata = MCodeMgr:doAction(1, JSON:encode({
						"reqUploadCover",
						seq,
						obsUrl
					}), 1)
				else
					respdata = MCodeMgr:doAction(1, JSON:encode({
						"reqUploadCover",
						seq,
						obsUrl,
						"1",
						filePath
					}), 1)
				end
			end

			if respdata then
				local retInfo = JSON:decode(respdata)

				if retInfo and type(retInfo) == "table" and retInfo[1] ~= 0 then
					threadpool:notify(msgKey, ErrorCode.NONE, respdata)
				end
			end
		else
			threadpool:notify(msgKey, ErrorCode.NONE, "")
		end
	end)

	local code, respdata = threadpool:wait(msgKey, 300)

	if code and respdata and code == ErrorCode.OK then
		local retInfo = JSON:decode(respdata)

		if retInfo and type(retInfo) == "table" then
			if retInfo[1] == 0 and retInfo[4] and #retInfo[4] > 1 then
				MiniCodeUtils:Log("MCodeUploadMgr uploadMcodeToMiniWorld 上传成功: ", retInfo)

				local strlist = utils.split(retInfo[4], "?")

				return 0, strlist[1]
			else
				MiniCodeUtils:Log("MCodeUploadMgr uploadMcodeToMiniWorld 上传失败: ", retInfo)

				return -1, ""
			end
		else
			return -1, ""
		end
	elseif code == ErrorCode.NONE then
		MiniCodeUtils:Log("MCodeUploadMgr uploadMcodeToMiniWorld 上传取消: ", msgKey, retInfo)
	end

	return -1, ""
end

function MCodeUploadMgr:uploadMiniWorldCloud()
	self.seq = self.seq + 1
	local msgKey = "upload" .. tostring(self.seq)
	self.msgKey = msgKey

	MiniCodeUtils:Log("MCodeUploadMgr uploadMiniWorldCloud: 开始上传")

	if GetInst("UploadProgressInterface") then
		GetInst("UploadProgressInterface"):OpenView()
	end

	local mapId = MCodeManager:getMapData().mapId

	MCodeMgr:doAction(1, JSON:encode({
		"reqPreUpload",
		tostring(mapId),
		0,
		20001
	}), 1)

	local code, respdata = threadpool:wait(msgKey, 60)

	if code and respdata and code == ErrorCode.OK then
		local retInfo = JSON:decode(respdata)

		if retInfo and type(retInfo) == "table" then
			if retInfo[1] == 0 then
				MiniCodeUtils:Log("MCodeUploadMgr uploadMiniWorldCloud 上传成功: ", retInfo)

				return 0
			else
				MiniCodeUtils:Log("MCodeUploadMgr uploadMiniWorldCloud 上传失败: ", retInfo)

				if retInfo[2] and (string.find(retInfo[2], "map_list_limi") or string.find(retInfo[2], "set_map_da") or string.find(retInfo[2], "overCount")) then
					self.errMsg = "云端档位不足, 你需要前往【迷你世界】管理现有档位"

					return -2
				else
					return -1
				end
			end
		else
			return -1
		end
	end

	return -1
end
