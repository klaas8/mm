MsgCenter = {
	_seq = 0,
	_replyMap = {}
}

MiniCodeUtils:Log("zuoyou*********MsgCenter*********")

function MsgCenter:sendMsg(to, type, data, needAnswer, isAnswer, id)
	local message = {
		from = MCModuleType.lua,
		to = to,
		type = type,
		needAnswer = needAnswer or false,
		isAnswer = isAnswer or false,
		data = data or {},
		seq = id or 0
	}

	MCodeMgr:newMsgFrame_handleLuaMsg(to, JSON:encode(message))
end

function MsgCenter:sendAsync(to, type, data, callback, timeout)
	local id = gen_gid()
	local message = {
		isAnswer = false,
		needAnswer = true,
		from = MCModuleType.lua,
		to = to,
		type = type,
		data = data or {},
		seq = id
	}

	MCodeMgr:newMsgFrame_handleLuaMsg(to, JSON:encode(message))

	local code, msg = threadpool:wait(id, timeout or 5)

	MiniCodeUtils:Log("zuoyou, ***** LUA sendAsync code", code, "msg", msg, JSON:encode(msg))

	return msg
end

function MsgCenter:onReceive(message)
	MiniCodeUtils:Log("zuoyou, ***** LUA onReceive message: " .. type(message) .. "; " .. (TableToStr and TableToStr(message) or ""))

	if message.isAnswer then
		threadpool:notify(message.seq, ErrorCode.OK, message.data)
	else
		MiniCodeUtils:Log("zuoyou, ***** LUA onReceive message to handle")
		MsgHandler:handleMessage(message)
	end
end

function MsgCenter:onReceiveCppMsg(message)
	MiniCodeUtils:Log("zuoyou*****---onReceiveCppMsg", MCodeManager.liteVersion, message.type, message)
end

function _G.onReceiveMessage(param)
	MiniCodeUtils:Log("zuoyou, ***** LUA onReceiveMessage0")

	local ok, json_data = pcall(JSON.decode, JSON, param)

	MiniCodeUtils:Log("zuoyou, ***** LUA onReceiveMessage1: " .. (TableToStr and TableToStr(json_data)))

	if ok and type(json_data) == "table" then
		if json_data.to == "lua" then
			MsgCenter:onReceive(json_data)
		else
			MiniCodeUtils:Log("zuoyou, ***** LUA onReceiveMessage, drop " .. json_data.type)
		end
	else
		MiniCodeUtils:Log("zuoyou, ***** LUA onReceiveMessage error" .. param)
	end
end

if SlsLog then
	SlsLog:logReport("course_enter_map", "lite_init_lua")
end

MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_loading_process, {
	msg = "初始化程序",
	process = 85
})
