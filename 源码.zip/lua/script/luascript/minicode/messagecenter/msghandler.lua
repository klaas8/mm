LuaInterface:log("zuoyou*********MsgHandler*********")

MsgHandler = {
	loginUserInfo = {
		s2t = "",
		s2 = "",
		mtoken = "",
		uid = ""
	},
	handleEnterLite = function (self, message)
		MiniCodeUtils:Log("zuoyou*****---handleEnterLite 1", message)
		MCodeMgr:showFullScreenLoading(false)
		MCodeManager:reset()

		local userInfo = message.data.userInfo
		local sceneInfo = message.data.sceneInfo

		MCodeManager:setSceneInfo(sceneInfo)
		MCodeManager:setUserInfo(userInfo)
		MCodeManager:setDeviceInfo(message.data.deviceInfo)
		MCodeManager:setEnv(message.data.env)
		MCNetworkApi:init(message.data.deviceInfo, message.data.env, userInfo)
		MiniCodeUtils:Log("zuoyou*****---", userInfo)
		MiniCodeUtils:Log("zuoyou*****---", sceneInfo)
		MiniCodeUtils:Log("zuoyou*****----", sceneInfo.type, userInfo.uin, MCodeManager.loginSuccessed)

		if MCodeManager.loginSuccessed then
			MiniCodeUtils:Log("zuoyou*****---login successed, loadMap", message)
			MCLoadMapHandler:loadMap(message.data)
		else
			MCodeManager:waitForLogin(function ()
				MiniCodeUtils:Log("zuoyou*****---onPlayerLogin, loadMap")
				MCLoadMapHandler:loadMap(message.data)
			end)
		end
	end,
	handleMapLoadedMessage = function (self, message)
		MCodeManager:closeLoading()
	end
}

function MsgHandler:handleMessage(message)
	MiniCodeUtils:Log("zuoyou, ***** MsgHandler.handleMessage: ", message.type, message)

	if message.type == MCMessageType.native_enterLite then
		MiniCodeUtils:Log("zuoyou, ***** MsgHandler:handleEnterLite: ")
		SlsLog:logStart("course_enter_map", "handle_enter_lite", {
			message.data.sceneInfo
		})
		MsgHandler:handleEnterLite(message)
	elseif message.type == MCMessageType.native_changeScreenShot_v2 then
		MCodeUploadMgr:handleEnterScreenShotUI(message)
	elseif message.type == MCMessageType.native_publish_back then
		-- Nothing
	elseif message.type == MCMessageType.native_publish_success then
		MiniCodeApi:quitWorld(true, nil, true, false, {
			isPublish = true
		})
	elseif message.type == MCMessageType.native_exit_lite then
		MiniCodeApi:quitWorld(true, nil, false, false, {})
	elseif message.type == MCMessageType.cpp_endGameResult then
		-- Nothing
	elseif message.type == MCMessageType.cpp_mapLoaded then
		MiniCodeUtils:Log("zuoyou, ***** MsgHandler:handleMapLoadedMessage: ")
		MsgHandler:handleMapLoadedMessage(message)

		if MCodeWorldStatus then
			if message.data then
				MCodeWorldStatus:onMapLoaded(message.data)
			else
				MCodeWorldStatus:onMapLoaded()
			end
		end
	elseif message.type == MCMessageType.cpp_unzipFail then
		MsgApi.mapLoadedFail({
			msg = "地图资源解压失败，请重试",
			type = 1,
			sceneInfo = MCodeManager:getSceneInfo()
		})
	elseif message.type == MCMessageType.cpp_mapLoadFail then
		MsgApi.mapLoadedFail({
			type = 2,
			msg = message.data,
			sceneInfo = MCodeManager:getSceneInfo()
		})
	elseif message.type == MCMessageType.native_saveAndExitLite then
		local sceneInfo = MCodeManager:getSceneInfo()
		local data = message.data

		MiniCodeUtils:Log("zuoyouStatus******MsgHandler.handleMessage:native_saveAndExitLite, data&sceneInfo:", data, sceneInfo)

		local saveInfo = nil
		local needDelLocalBackup = false
		local exitLiteData = {}

		if sceneInfo.type == MCEnterMapType.enterLocalBackup or sceneInfo.type == MCEnterMapType.templateEnterExampleMCode or sceneInfo.type == MCEnterMapType.programGameMap or sceneInfo.type == MCEnterMapType.createTerrain or sceneInfo.type == MCEnterMapType.adaptTemplate or sceneInfo.type == MCEnterMapType.challengeLevel or sceneInfo.newType == MCEnterMapType.play2EditInlite or sceneInfo.type == MCEnterMapType.createLiteRoom then
			saveInfo = {}
			needDelLocalBackup = false
			exitLiteData = {}
		elseif sceneInfo.type == MCEnterMapType.workshopEnterMap and sceneInfo.newType ~= MCEnterMapType.play2EditInlite then
			needDelLocalBackup = true
		elseif sceneInfo.type == MCEnterMapType.optionQuestion then
			saveInfo = {
				homework = true,
				tempType = 0
			}
		end

		if data and data.reason then
			exitLiteData.reason = data.reason
		else
			exitLiteData.reason = 1
		end

		MiniCodeApi:quitWorld(true, saveInfo, true, needDelLocalBackup, exitLiteData)
	elseif message.type == MCMessageType.native_publish_back_v2 or message.type == MCMessageType.native_publish_complete then
		MCodeUploadMgr:handleExitPublicUI(message)
	elseif message.type == MCMessageType.native_upload_mcode then
		MCodeUploadMgr:handleStartUploadMcode(message)
	elseif message.type == MCMessageType.native_upload_cancel then
		MCodeUploadMgr:handeCancelUploadMcode(message)
	elseif message.type == MCMessageType.native_webview_back then
		if GetInst("MinicodeAvatarPicEditMgr") then
			GetInst("MinicodeAvatarPicEditMgr"):refreshBGPic()
		end
	elseif message.type == MCMessageType.cpp_verionCheckFail then
		MsgApi.mapLoadedFail({
			msg = "这是新版本地图，当前版本过低，请更新后再打开",
			type = 2,
			sceneInfo = MCodeManager:getSceneInfo()
		})
	else
		MiniCodeUtils:Log("unsupport msg", message.type)
	end
end
