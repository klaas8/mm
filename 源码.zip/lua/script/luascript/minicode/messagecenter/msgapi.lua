MsgApi = {
	exitLite = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_liteExited, data or {})
	end,
	saveMap = function (data)
		local result = MsgCenter:sendAsync(MCModuleType.cpp, MCMessageType.lua_saveMap, data or {})

		return result
	end,
	publishWork = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_publishWork, data or {})
	end,
	screenShot = function (data)
		local result = MsgCenter:sendAsync(MCModuleType.cpp, MCMessageType.lua_screenShot, data or {})

		return result
	end,
	changeScreenShotFinished = function (data)
		MiniCodeUtils:Log("zuoyou******---------lua_changeScreenShotFinished: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_changeScreenShotFinished, data or {})
	end,
	deleteLocalBackup = function (data)
		local result = MsgCenter:sendAsync(MCModuleType.cpp, MCMessageType.lua_delete_local_backup, data or {})

		return result
	end,
	miniwLoadedOK = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_miniwLoadedOK, data or {})
	end,
	loadingStart = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_loading_start, data or {})
	end,
	loadingProcess = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_loading_process, data or {})
	end,
	loadingClose = function (data)
		MiniCodeUtils:Log("zuoyou******---------lua_loading_close: ")
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_loading_close, data or {})
	end,
	fetchMCodeCheckWords = function (data)
		MsgCenter:sendMsg(MCModuleType.lite, MCMessageType.lua_fetchMCodeCheckWords, data or {})
	end,
	mapLoadedFail = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_mapLoadedFail, data or {})
	end,
	sensorsTrack = function (data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_sensorsTrack, data or {})
	end,
	downloadCache = function (data)
		MiniCodeUtils:Log("zuoyou******---------lua_downloadCache: ", TableToStr and TableToStr(data))

		local result = MsgCenter:sendAsync(MCModuleType.cpp, MCMessageType.lua_downloadCache, data or {}, nil, 180000)

		return result
	end,
	sendcreateLiteRoomRet = function (nRet, roomThumbUrl)
		roomThumbUrl = roomThumbUrl or ""
		local tData = {
			nRet = nRet
		}

		if nRet == 0 then
			tData.roomThumbUrl = roomThumbUrl
			tData.roomUin = ClientCurGame:getHostUin()
			local miniCodeRoomName = MiniCodeUtils:getPlayTogetherRoomName()

			if miniCodeRoomName and miniCodeRoomName ~= "" then
				tData.roomName = miniCodeRoomName
			else
				tData.roomName = RoomInteractiveData.curRoomName
			end

			local worldInfo = AccountManager:getCurWorldDesc()

			if worldInfo then
				tData.mapId = worldInfo.worldid
				tData.mapName = worldInfo.worldname
			end
		end

		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_createLiteRoomRet, tData)
	end,
	sendjoinLiteRoomRet = function (nRet)
		local tData = {
			nRet = nRet
		}

		if nRet == 0 then
			tData.roomUin = ClientCurGame:getHostUin()
			local miniCodeRoomName = MiniCodeUtils:getPlayTogetherRoomName()

			if miniCodeRoomName and miniCodeRoomName ~= "" then
				tData.roomName = miniCodeRoomName
			else
				tData.roomName = RoomInteractiveData.curRoomName
			end

			tData.mapId = t_autojump_service.play_together.worldId
		end

		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_joinLiteRoomRet, tData)
	end,
	nativeShowUpFriendList = function (tUinList)
		local tData = {
			roomUin = ClientCurGame:getHostUin()
		}
		local miniCodeRoomName = MiniCodeUtils:getPlayTogetherRoomName()

		if miniCodeRoomName and miniCodeRoomName ~= "" then
			tData.roomName = miniCodeRoomName
		else
			tData.roomName = RoomInteractiveData.curRoomName
		end

		local worldInfo = AccountManager:getCurWorldDesc()

		if worldInfo then
			tData.mapId = worldInfo.worldid
		elseif t_autojump_service.play_together.worldId then
			tData.mapId = t_autojump_service.play_together.worldId
		end

		if tUinList then
			tData.userList = tUinList
		end

		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_showUpFriendList, tData)
	end,
	nativeShowUpShare = function ()
		threadpool:work(function ()
			local sceneInfo = MCodeManager:getSceneInfo()

			if not sceneInfo then
				return
			end

			if sceneInfo.type ~= MCEnterMapType.createLiteRoom and sceneInfo.type ~= MCEnterMapType.joinLiteRoom then
				return
			end

			if not ClientCurGame then
				return
			end

			local tData = {}
			local roomVer = ""
			local mapId = 0
			local roomName = ""
			local mapName = ""

			if sceneInfo.type == MCEnterMapType.createLiteRoom then
				roomVer = GetClientInfo():clientVersionStr()
			else
				roomVer = sceneInfo.data.roomVer
			end

			local worldInfo = AccountManager:getCurWorldDesc()

			if worldInfo then
				mapId = worldInfo.worldid
				mapName = worldInfo.worldname
			elseif t_autojump_service.play_together.worldId then
				mapId = t_autojump_service.play_together.worldId
			end

			local miniCodeRoomName = MiniCodeUtils:getPlayTogetherRoomName()

			if miniCodeRoomName and miniCodeRoomName ~= "" then
				roomName = miniCodeRoomName
			else
				roomName = RoomInteractiveData.curRoomName
			end

			tData.title = "分享给朋友，邀请TA一起来创作"

			if sceneInfo.type == MCEnterMapType.joinLiteRoom then
				local seq = gen_gid()

				local function callBack(str)
					MiniCodeUtils:Log("pyf test getRoomCover str = ", str)

					local resInfo = JSON:decode(str)

					if resInfo and resInfo.code == 0 and resInfo.data.url then
						MCodeWorldStatus.roomHostScreenShotUrl = resInfo.data.url

						threadpool:notify(seq, ErrorCode.OK)
					end
				end

				MCNetworkApi:getRoomCover(tostring(ClientCurGame:getHostUin()), callBack)
				threadpool:wait(seq, 5)
			end

			tData.source = {
				title = "好友联机创作，就等你了！",
				path = "joinLiteRoom",
				url = "https://www.miniaixue.com/open-app",
				senceParams = {
					title = "加入联机创作",
					imageUrl = MCodeWorldStatus.roomHostScreenShotUrl and MCodeWorldStatus.roomHostScreenShotUrl or "https://minioss.miniaixue.com/images/50*50.png",
					roomUin = ClientCurGame:getHostUin(),
					roomVer = roomVer,
					mapId = mapId,
					roomName = roomName,
					mapName = mapName
				},
				text = "我们这次创作的主题是：\"" .. roomName .. "\"，快来和我一起创作吧！",
				imageUrl = MCodeWorldStatus.roomHostScreenShotUrl and MCodeWorldStatus.roomHostScreenShotUrl or "https://minioss.miniaixue.com/images/279*157.png"
			}

			MiniCodeUtils:Log("pyf test nativeShowUpShare ", TableToStr(tData))
			MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_showShare, tData)
		end)
	end,
	quitRoomSensorsTrack = function ()
		if MCodeManager and not GetClientInfo():isPC() then
			local sensorsType = SensorsConst.LiteExitRoom
			local startTime = MiniCodeUtils:getPlayTogetherStartTime()

			if startTime <= 0 then
				return
			end

			local playTogetherInGameErrorOccur = MiniCodeUtils:getPlayTogetherInGameErrorOccur()

			MiniCodeUtils:setPlayTogetherStartInfo(0)

			local sensorsData = MCodeManager:getSensorsParams() or {}
			local sceneInfo = MCodeManager:getSceneInfo()

			if sceneInfo then
				sensorsData.ext_string2 = MiniCodeUtils:getPlayTogetherRoomName()

				if playTogetherInGameErrorOccur then
					sensorsData.ext_string3 = "被动"
				else
					sensorsData.ext_string3 = "主动"
				end

				local work_length = os.time() - startTime
				sensorsData.work_length = work_length * 1000

				if sceneInfo.type == MCEnterMapType.createLiteRoom then
					local worldInfo = AccountManager:getCurWorldDesc()

					if worldInfo then
						if worldInfo.gwid == 0 then
							sensorsData.content_type = "原创"
						else
							sensorsData.content_type = "改编"
						end

						sensorsData.content_name = worldInfo.worldname
						sensorsData.content_num = tostring(worldInfo.worldid)
						local uin = AccountManager:getUin()
						sensorsData.ext_string4 = tostring(uin)
					end
				elseif sceneInfo.type == MCEnterMapType.joinLiteRoom then
					local roomDesc = AccountManager:getCurHostRoom()

					if roomDesc then
						sensorsData.content_num = tostring(roomDesc.map_type)
						sensorsData.content_name = roomDesc.roomname
						sensorsData.ext_string4 = tostring(roomDesc.owneruin)
					end
				end

				MsgApi.sensorsTrack({
					sensorsType = sensorsType,
					sensorsData = sensorsData
				})
			end
		end
	end,
	publishWorkV2 = function (data)
		MiniCodeUtils:Log("zuoyou******---------publishWorkV2: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_publish_work_v2, data or {})
	end,
	changeScreenShotResp = function (data, seq)
		MiniCodeUtils:Log("zuoyou******---------changeScreenShotResp: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.native_changeScreenShot_v2, data or {}, false, true, seq)
	end,
	uploadMcodeResp = function (data, seq)
		MiniCodeUtils:Log("zuoyou******---------uploadMcodeResp: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.native_upload_mcode, data or {}, false, true, seq)
	end,
	uploadProgress = function (data)
		MiniCodeUtils:Log("zuoyou******---------uploadProgress: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_upload_progress, data or {}, false, false)
	end,
	loadUrl = function (data)
		MiniCodeUtils:Log("zuoyou******---------loadUrl: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_load_url, data or {})
	end,
	loadMiniWorld = function (data)
		MiniCodeUtils:Log("zuoyou******---------loadMiniWorld: ", data)
		MsgCenter:sendMsg(MCModuleType.native, MCMessageType.lua_load_miniworld, data or {})
	end,
	loginFailed = function (data)
		MsgCenter:sendMsg(MCModuleType.cpp, MCMessageType.lua_login_failed, data or {})
	end
}
