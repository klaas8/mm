MiniCodeApi = {
	createWorld = function (self, name, long, height, terrain, mapSeed, landforms, monster)
		HideMiniLobby()

		if HideLobby then
			HideLobby()
		else
			getglobal("LobbyFrame"):Hide()
		end

		MiniCodeUtils:Log("zuoyou*****---MiniCodeApi.createWorld;")

		local Model = 1
		local SkinID = 4

		if MCodeManager._roleInfoWhenOnAccountDirty and next(MCodeManager._roleInfoWhenOnAccountDirty) then
			Model = MCodeManager._roleInfoWhenOnAccountDirty.Model
			SkinID = MCodeManager._roleInfoWhenOnAccountDirty.RoleSkinID
		end

		LuaInterface:setRoleInfoForEducationMap(Model, MCodeManager:getUserInfo().nickName, SkinID, tostring(MCodeManager:getUserInfo().uin), 0)
		SlsLog:logStart("course_enter_map", "enter_map", {
			name = name,
			terrain = terrain,
			mapSeed = mapSeed,
			long = long,
			height = height,
			landforms = landforms,
			monster = monster
		})

		if MCodeWorldStatus then
			MCodeWorldStatus:beginEnterWorld(0, 2)
		end

		if AccountManager:requestCreateWorld(4, name, terrain, mapSeed, AccountManager:getRoleModel(), long, height, landforms, monster, false, 0, 1) then
			MiniCodeUtils:Log("zuoyou*****---MiniCodeApi.createWorld; sucess")
			SlsLog:logReport("course_enter_map", "enter_map", {
				msg = "AccountManager:requestCreateWorld true",
				name = name,
				terrain = terrain,
				mapSeed = mapSeed,
				long = long,
				height = height,
				landforms = landforms,
				monster = monster
			})
			CloseCreateWorldFrame()
			CloseCreateWorldRuleFrame()
			ShowLoadingFrame()
			HideLoginPanel()
		else
			SlsLog:logFail("course_enter_map", "enter_map", {
				msg = "AccountManager:requestCreateWorld false",
				name = name,
				terrain = terrain,
				mapSeed = mapSeed,
				long = long,
				height = height,
				landforms = landforms,
				monster = monster
			})
		end

		MiniCodeUtils:Log("zuoyou*****---MiniCodeApi.createWorld; finished")
	end
}

function MiniCodeApi:createWorldByMCode(mcodeUrl, liteMode, isPlay, mapSource)
	MiniCodeUtils:Log("zuoyou***** MiniCodeApi.createWorldByMCode: " .. mcodeUrl)

	if ResourceCache then
		MiniCodeUtils:Log("zuoyou***** MiniCodeApi.createWorldByMCode: ResourceCache  " .. (TableToStr and TableToStr(ResourceCache) or ""))
		SlsLog:logStart("course_enter_map", "enter_map_download", {
			mcode = mcodeUrl
		})

		if MCodeManager then
			MCodeManager:processLoading({
				type = "download",
				process = 0
			})
		end

		ResourceCache:getUrlRes(mcodeUrl, function (ret)
			if ret and ret.path then
				SlsLog:logSuccess("course_enter_map", "enter_map_download", {
					mcode = mcodeUrl
				})

				local uin = AccountManager:getUin()

				MiniCodeUtils:Log("zuoyou*** uin: " .. AccountManager:getUin() .. "; " .. (MCodeManager:getUserInfo() and MCodeManager:getUserInfo().uin or ""))

				if not uin or uin < 2 then
					uin = MCodeManager:getUserInfo().uin
				end

				MiniCodeUtils:Log("zuoyou*** uin: " .. uin .. "; path: " .. (TableToStr and TableToStr(ret)))

				local name = MCodeManager:getUserInfo() and MCodeManager:getUserInfo().nickName or ""

				SlsLog:logStart("course_enter_map", "enter_map", {
					mcode = mcodeUrl
				})

				if MCodeManager then
					MCodeManager:processLoading({
						type = "download",
						process = 100
					})
				end

				MCodeMgr:doAction(-1, JSON:encode({
					"createWorldByMCode",
					tostring(uin),
					ret.path,
					"./minicode/minicode.sb3",
					liteMode,
					isPlay,
					name .. "的作品",
					mapSource
				}), 1)
			else
				SlsLog:logFail("course_enter_map", "enter_map_download", ret)
				MsgApi.mapLoadedFail({
					msg = "地图下载失败，请重试",
					type = 1,
					sceneInfo = MCodeManager:getSceneInfo()
				})
				MiniCodeApi:quitWorld(false, nil, false, false, nil)
			end
		end)
	end
end

function MiniCodeApi:createWorldByLocalPath(localPath, liteMode, isPlay, mapSource)
	MiniCodeUtils:Log("zuoyou***** MiniCodeApi.createWorldByMCode: " .. localPath)

	if MCodeManager then
		MCodeManager:processLoading({
			type = "download",
			process = 0
		})
		MCodeManager:processLoading({
			type = "download",
			process = 100
		})
	end

	if localPath ~= nil then
		local uin = AccountManager:getUin()

		MiniCodeUtils:Log("zuoyou*** uin: " .. AccountManager:getUin() .. "; " .. (MCodeManager:getUserInfo() and MCodeManager:getUserInfo().uin or ""))

		if not uin or uin < 2 then
			uin = MCodeManager:getUserInfo().uin
		end

		MiniCodeUtils:Log("zuoyou*** uin: " .. uin .. "; path: " .. (TableToStr and TableToStr(ret)))

		local name = MCodeManager:getUserInfo() and MCodeManager:getUserInfo().nickName or ""

		SlsLog:logStart("course_enter_map", "enter_map", {
			localPath = localPath
		})
		MCodeMgr:doAction(-1, JSON:encode({
			"createWorldByMCode",
			tostring(uin),
			localPath,
			"./minicode/minicode.sb3",
			liteMode,
			isPlay,
			name .. "的作品",
			mapSource
		}), 1)
	else
		SlsLog:logFail("course_enter_map", "enter_map_download", ret)
		MsgApi.mapLoadedFail({
			msg = "地图路径错误，请重试",
			type = 1,
			sceneInfo = MCodeManager:getSceneInfo()
		})
		MiniCodeApi:quitWorld(false, nil, false, false, nil)
	end
end

function MiniCodeApi:enterWorldByMcodeUrl(mcodeUrl)
	if ResourceCache then
		ResourceCache:getUrlRes(mcodeUrl, function (ret)
			if ret and ret.path then
				local uin = AccountManager:getUin()

				MiniCodeUtils:Log("zuoyou*** uin: " .. AccountManager:getUin() .. "; " .. (MCodeManager:getUserInfo() and MCodeManager:getUserInfo().uin or ""))

				if not uin or uin < 2 then
					uin = MCodeManager:getUserInfo().uin
				end

				MiniCodeUtils:Log("zuoyou*** uin: " .. uin .. "; path: " .. (TableToStr and TableToStr(ret)))
				MCodeMgr:doAction(-1, JSON:encode({
					"enterWorldByMcode",
					tostring(uin),
					ret.path,
					3,
					4
				}), 1)
			else
				ShowGameTips("下载地图失败：" .. mcodeUrl)
				SlsLog:logFail("course_enter_map", "enter_map_download", ret)
				MsgApi.mapLoadedFail({
					msg = "地图下载失败，请重试",
					type = 1,
					sceneInfo = MCodeManager:getSceneInfo()
				})
				MiniCodeApi:quitWorld(false, nil, false, false, nil)
			end
		end)
	end
end

function MiniCodeApi:changeToCreateModelEnterWorld(mapId)
	local result = MCodeMgr:changeToCreateMode(mapId)

	MiniCodeUtils:Log("zuoyou*****---changeToCreateModelEnterWorld! ", mapId, result)

	if result ~= 0 then
		MsgApi.mapLoadedFail({
			msg = "地图不符合条件，转换失败",
			type = 2,
			sceneInfo = sceneInfo
		})
	end
end

function MiniCodeApi:quitWorld(needLoadingUI, saveInfo, needSensors, needDelLocalBackup, exitLiteData)
	GetInst("MainInterface"):CloseView()

	if MsgApi then
		MiniCodeUtils:Log("zuoyou****quitWorld")

		if needLoadingUI then
			MCodeMgr:showFullScreenLoading(true)
			GetInst("LoadingInterface"):OpenView()
		end

		if WorldMgr and GetClientInfo():isPC() then
			WorldMgr:SetAutoSaveFlag(false, 700)
		end

		threadpool:work(function ()
			if saveInfo then
				MCodeWorldStatus:updateWorkerCodeTime(false)
			end

			if MCodeWorldStatus then
				MCodeWorldStatus:exitWorld()
			end

			local sceneInfo = MCodeManager:getSceneInfo()

			MiniCodeUtils:Log("zuoyou****quitWorld sceneInfo", sceneInfo)

			local mapData = MCodeManager:getMapData()

			MiniCodeUtils:Log("zuoyou****quitWorld mapData", mapData)

			if saveInfo then
				MiniCodeUtils:Log("zuoyou****quitWorld ", saveInfo)

				if GetClientInfo():isPC() and not saveInfo.mvToRecyclebin then
					threadpool:wait(31.1)
				end

				MiniCodeApi:saveMap(saveInfo.name, saveInfo.tempType, saveInfo.homework, saveInfo.mvToRecyclebin, true)

				if not saveInfo.mvToRecyclebin and exitLiteData and (sceneInfo.type == MCEnterMapType.adaptTemplate or sceneInfo.type == MCEnterMapType.templateEnterExampleMCode) then
					exitLiteData.toastText = "作品已保存至我的创作"
				end
			end

			if sceneInfo.type == MCEnterMapType.createLiteRoom or sceneInfo.type == MCEnterMapType.joinLiteRoom then
				MsgApi.quitRoomSensorsTrack()
			end

			if needSensors and MCodeManager and not GetClientInfo():isPC() then
				local sensorsType = MCodeManager:getExitMapSensorsType()

				if sensorsType then
					local sensorsData = MCodeManager:getSensorsParams()
					sensorsData.work_length = MCodeManager:getEditMapTime()

					if saveInfo and saveInfo.mvToRecyclebin ~= true then
						sensorsData.is_save = "保存"
					else
						sensorsData.is_save = "不保存"
					end

					MsgApi.sensorsTrack({
						sensorsType = sensorsType,
						sensorsData = sensorsData
					})
				end

				MCodeManager:setSceneInfo({})
			end

			if sceneInfo.type == MCEnterMapType.createLiteRoom then
				AccountManager:sendToClientKickInfo(2)
			end

			MCodeMgr:clearWorkJmi()
			GoToMainMenu()

			if needDelLocalBackup and not GetClientInfo():isPC() then
				local userInfo = MCodeManager:getUserInfo()
				local mapData = MCodeManager:getMapData()

				MiniCodeUtils:Log("zuoyou*** userInfo: ", userInfo)
				MiniCodeUtils:Log("zuoyou*** mapData: ", mapData)
				MiniCodeApi:delLocalBackup(userInfo.uin, mapData.mapId)
			end

			threadpool:wait(1.1)
			MCodeMgr:gcResource()
			collectgarbage("collect")

			if exitLiteData and not GetClientInfo():isPC() then
				exitLiteData.type = sceneInfo.type

				if sceneInfo.data and sceneInfo.data.enterSource then
					exitLiteData.enterSource = sceneInfo.data.enterSource
				end

				MsgApi.exitLite(exitLiteData)
			end

			if needLoadingUI then
				GetInst("LoadingInterface"):CloseView()
			end
		end)
	end
end

function MiniCodeApi:saveMap(name, tempType, homework, mvToRecyclebin, isScreen, openCode)
	SlsLog:logStart("course_save_work", "save_map")
	MiniCodeUtils:Log("zuoyou*** MiniCodeApi.saveMap: ", name, tempType, homework)

	local worldName = name
	local type = tempType
	type = type or 0

	if openCode and openCode > 0 then
		type = 1
	end

	local path = MsgApi.saveMap({
		name = worldName,
		tempType = type,
		homework = homework,
		openCode = openCode or 0,
		mvToRecyclebin = mvToRecyclebin,
		isScreen = isScreen
	})

	SlsLog:logSuccess("course_save_work", "save_map", {
		mapPath = path
	})

	return path
end

function MiniCodeApi:enterMapWithId(mapId)
	local uin = AccountManager:getUin()

	MiniCodeUtils:Log("zuoyou*** uin: " .. AccountManager:getUin() .. "; " .. MCodeManager:getUserInfo().uin)

	if not uin or uin < 2 then
		uin = MCodeManager:getUserInfo().uin
	end

	MiniCodeUtils:Log("zuoyou*** uin: ", uin, mapId)
	MCodeMgr:doAction(-1, JSON:encode({
		"enterLocalBackup",
		tostring(uin),
		tostring(mapId),
		"./minicode/minicode.sb3",
		0
	}), 1)
end

function MiniCodeApi:enterMapWithStageId(stageId)
	local uin = AccountManager:getUin()

	MiniCodeUtils:Log("zuoyou*** uin: " .. AccountManager:getUin() .. "; " .. MCodeManager:getUserInfo().uin)

	if not uin or uin < 2 then
		uin = MCodeManager:getUserInfo().uin
	end

	MiniCodeUtils:Log("zuoyou*** uin: ", uin, mapId)
	MCodeMgr:doAction(-1, JSON:encode({
		"enterCourseHomeWork",
		tostring(uin),
		"",
		tostring(stageId),
		"./minicode/minicode.sb3",
		false,
		4
	}), 1)
end

function MiniCodeApi:onDisconnectToApp()
	MiniCodeUtils:Log("zuoyou****网络异常掉线通知")
	MCodeMgr:showFullScreenLoading(true)
	MsgApi.loginFailed()
	MsgApi.mapLoadedFail({
		msg = "无法联网，请检查网络！",
		type = 2,
		sceneInfo = MCodeManager:getSceneInfo()
	})

	local sceneInfo = MCodeManager:getSceneInfo()

	if sceneInfo and (sceneInfo.type == MCEnterMapType.createLiteRoom or sceneInfo.type == MCEnterMapType.joinLiteRoom) then
		MsgApi.quitRoomSensorsTrack()
	end
end

function MiniCodeApi:delLocalBackup(uin, mapId)
	MiniCodeUtils:Log("zuoyou****delLocalBackup: ", uin, mapId)
	MCodeMgr:doAction(-1, JSON:encode({
		"delLocalBackup",
		tostring(uin),
		tostring(mapId)
	}), 1)
end

function MiniCodeApi:play2Edit(mapId)
	MiniCodeUtils:Log("zuoyou****play2Edit: ", uin, mapId)
	threadpool:work(function ()
		MsgApi.loadingStart({
			mapId = mapId
		})

		local sceneInfo = MCodeManager:getSceneInfo()
		sceneInfo.newType = MCEnterMapType.play2EditInlite

		MCodeManager:setSceneInfo(sceneInfo)
		GoToMainMenu()
		threadpool:wait(1.1)
		MCodeMgr:gcResource()
		collectgarbage("collect")
		MCodeMgr:doAction(-1, JSON:encode({
			"play2Edit",
			tostring(mapId)
		}), 1)
	end)
end

function MiniCodeApi.loadReward()
	local url = MCNetworkConst.env.h5Host .. "/app-reward-center?module_id=10&from_page_id=99999"

	MiniCodeApi.loadUrl(url, 2)
end

function MiniCodeApi.loadUrl(url, ori)
	local origin = 2

	if ori == 1 then
		origin = 1
	end

	MsgApi.loadUrl({
		url = url,
		ori = origin
	})
end

function MiniCodeApi.loadMiniWorld()
	MsgApi.loadMiniWorld()
end

function MiniCodeApi.quitAvatar()
	if MsgApi then
		MiniCodeUtils:Log("zuoyou****quitAvatar")
		threadpool:work(function ()
			MCodeMgr:showFullScreenLoading(true)
			MsgApi.exitLite({
				reason = 3
			})
			GetInst("LoadingInterface"):CloseView()
		end)
	end
end
