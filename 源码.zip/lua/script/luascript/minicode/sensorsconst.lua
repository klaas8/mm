SensorsConst = {
	LiteJoinRoom = "room_join",
	LiteRoomCreate = "room_create",
	ExitCheckpoint = "ExitCheckpoint",
	EnterCheckpoint = "EnterCheckpoint",
	LiteStudyPageExit = "LiteStudyPageExit",
	LiteStudyPageEnter = "LiteStudyPageEnter",
	LitePlayPageExit = "LitePlayPageExit",
	LitePlayPageEnter = "LitePlayPageEnter",
	LiteCreatePageExit = "LiteCreatePageExit",
	LiteCreatePageEnter = "LiteCreatePageEnter",
	LiteExitRoom = "room_exit"
}
