MCLoadMapHandler = {
	loadMap = function (self, data)
		if SlsLog then
			SlsLog:logReport("lite_loading", "lite_enterMap_begin")
		end

		HideLoginPanel()

		local userInfo = data.userInfo
		local sceneInfo = data.sceneInfo

		if not userInfo or not sceneInfo then
			MsgApi.mapLoadedFail({
				type = 2,
				msg = "进入地图失败【参数错误】"
			})
		end

		MiniCodeUtils:Log("zuoyou*****---MCLoadMapHandler.loadMap, type: ", sceneInfo.type)
		MiniCodeUtils:Log("zuoyou*****---MCLoadMapHandler.loadMap, data: ", sceneInfo.data)
		MCodeMgr:checkWorkDir(userInfo.uin)

		if sceneInfo.data.templateId then
			MCodeMgr:addJmiJson(JSON:encode({
				templateId = sceneInfo.data.templateId
			}))
		end

		IsCreatingColloborationModeRoom = false

		if sceneInfo.type == MCEnterMapType.createTerrain then
			local name = MCodeManager:getUserInfo().nickName .. "的作品"

			if not IsEmptyString(sceneInfo.data.name) then
				name = sceneInfo.data.name
			end

			local long = 0

			if not IsEmptyString(sceneInfo.data.long) then
				long = sceneInfo.data.long
			end

			local height = 0

			if not IsEmptyString(sceneInfo.data.height) then
				height = sceneInfo.data.height
			end

			local terrain = 1

			if sceneInfo.data.terrain then
				terrain = sceneInfo.data.terrain
			end

			local mapSeed = ""

			if sceneInfo.data.mapSeed then
				mapSeed = sceneInfo.data.mapSeed
			end

			local landforms = 0

			if sceneInfo.data.landforms then
				landforms = sceneInfo.data.landforms
			end

			local monster = 0

			if sceneInfo.data.monster then
				monster = sceneInfo.data.monster
			end

			MiniCodeUtils:Log("zuoyou*****---createWorld", name, long, height, terrain, mapSeed, landforms, monster)
			MiniCodeApi:createWorld(name, long, height, terrain, mapSeed, landforms, monster)
		elseif sceneInfo.type == MCEnterMapType.programGameMap then
			for key, value in pairs(sceneInfo.data) do
				MiniCodeUtils:Log("zuoyou*****---enterMap by template; ", key, value)
			end

			local liteMode = 4
			local isPlay = false
			local mcodeUrl = sceneInfo.data.mcodeUrl

			if mcodeUrl and type(mcodeUrl) == "string" and #mcodeUrl > 0 then
				MiniCodeUtils:Log("zuoyou*****---enterMap mcodeUrl; ", mcodeUrl)

				local mapSource = 5

				if sceneInfo.data.templateId == nil then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【模板ID缺少】",
						sceneInfo = sceneInfo
					})

					return
				end

				MiniCodeApi:createWorldByMCode(mcodeUrl, liteMode, isPlay, mapSource)

				return
			end

			local createParam = sceneInfo.data.createParam

			if not createParam or type(createParam) ~= "table" then
				MsgApi.mapLoadedFail({
					type = 2,
					msg = "进入地图失败【URL参数错误】",
					sceneInfo = sceneInfo
				})

				return
			end

			local name = MCodeManager:getUserInfo().nickName .. "的作品"

			if not IsEmptyString(sceneInfo.data.name) then
				name = sceneInfo.data.name
			end

			local long = 0

			if not IsEmptyString(createParam.long) then
				long = createParam.long
			end

			local height = 0

			if not IsEmptyString(createParam.height) then
				height = createParam.height
			end

			local terrain = 1

			if createParam.terrain then
				if createParam.terrain == 2 then
					terrain = 10
				end

				if createParam.terrain == 3 then
					terrain = 11
				end

				if createParam.terrain == 4 then
					terrain = 0
				end

				if createParam.terrain == 5 then
					terrain = 12
				end

				if createParam.terrain == 6 then
					terrain = 4
				end
			end

			local mapSeed = ""

			if createParam.mapSeed then
				mapSeed = createParam.mapSeed
			end

			local landforms = 0

			if createParam.landforms then
				landforms = createParam.landforms
			end

			local monster = 0

			if createParam.monster then
				monster = createParam.monster
			end

			MCodeMgr:addJmiJson(JSON:encode({
				mapSource = 5
			}))
			MiniCodeUtils:Log("zuoyou*****---createWorld", name, long, height, terrain, mapSeed, landforms, monster)
			MiniCodeApi:createWorld(name, long, height, terrain, mapSeed, landforms, monster)
		elseif sceneInfo.type == MCEnterMapType.changeToCreateModel then
			local mapIdStr = sceneInfo.data.mapId

			if not mapIdStr or type(mapIdStr) ~= "string" or #mapIdStr <= 0 then
				MsgApi.mapLoadedFail({
					type = 2,
					msg = "进入地图失败【Id参数错误】",
					sceneInfo = sceneInfo
				})
			end

			MiniCodeUtils:Log("zuoyou*****---changeToCreateModel: ", sceneInfo.data)
			MiniCodeApi:changeToCreateModelEnterWorld(sceneInfo.data.mapId)
		elseif sceneInfo.type == MCEnterMapType.publishWorks or sceneInfo.type == MCEnterMapType.uploadToMiniworld or sceneInfo.type == MCEnterMapType.uploadToMiniCode or sceneInfo.type == MCEnterMapType.enterLocalBackup then
			MiniCodeApi:enterMapWithId(sceneInfo.data.mapId)
		elseif sceneInfo.type == MCEnterMapType.workshopEnterMap or sceneInfo.type == MCEnterMapType.adaptTemplate or sceneInfo.type == MCEnterMapType.templateEnterExampleMCode then
			local liteMode = 4
			local isPlay = false
			local localPath = nil

			if sceneInfo.type == MCEnterMapType.workshopEnterMap then
				liteMode = 5
				isPlay = true
				localPath = sceneInfo.data.localPath
			elseif sceneInfo.type == MCEnterMapType.adaptTemplate then
				localPath = sceneInfo.data.localPath
			end

			local mcodeUrl = sceneInfo.data.mcodeUrl

			if sceneInfo.type == MCEnterMapType.adaptTemplate then
				if localPath == nil or type(localPath) ~= "string" or #localPath <= 0 then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【PATH错误】",
						sceneInfo = sceneInfo
					})

					return
				end
			else
				if not mcodeUrl or type(mcodeUrl) ~= "string" or #mcodeUrl <= 0 then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【URL参数错误】",
						sceneInfo = sceneInfo
					})

					return
				end

				if liteMode ~= 4 and liteMode ~= 5 then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【Mode参数错误】",
						sceneInfo = sceneInfo
					})

					return
				end
			end

			local mapSource = -1

			if sceneInfo.type == MCEnterMapType.adaptTemplate then
				mapSource = 3
			elseif sceneInfo.type == MCEnterMapType.templateEnterExampleMCode then
				mapSource = 4

				if sceneInfo.data.templateId == nil then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【模板ID缺少】",
						sceneInfo = sceneInfo
					})

					return
				end
			elseif sceneInfo.type == MCEnterMapType.workshopEnterMap then
				mapSource = -2
			end

			if sceneInfo.type == MCEnterMapType.workshopEnterMap and localPath ~= nil or sceneInfo.type == MCEnterMapType.adaptTemplate then
				MiniCodeUtils:Log("zuoyou*****---enterMap localPath: ", localPath)
				MiniCodeApi:createWorldByLocalPath(localPath, liteMode, isPlay, mapSource)
			else
				MiniCodeUtils:Log("zuoyou*****---enterMap mcodeUrl2; ", mcodeUrl)
				MiniCodeApi:createWorldByMCode(mcodeUrl, liteMode, isPlay, mapSource)
			end
		elseif sceneInfo.type == MCEnterMapType.challengeLevel then
			MiniCodeUtils:Log("zuoyou*****---challengeLevel: ", sceneInfo.data)

			if sceneInfo.data.courseId then
				MCodeMgr:addJmiJson(JSON:encode({
					courseId = sceneInfo.data.courseId
				}))
			end

			if sceneInfo.data.mapId and #sceneInfo.data.mapId > 1 then
				MiniCodeUtils:Log("zuoyou*****---challengeLevel mapId: ", sceneInfo.data.mapId)
				MiniCodeApi:enterMapWithId(sceneInfo.data.mapId)
			else
				local mcodeUrl = sceneInfo.data.mcodeUrl

				if not mcodeUrl or type(mcodeUrl) ~= "string" or #mcodeUrl <= 0 then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【URL参数错误】",
						sceneInfo = sceneInfo
					})

					return
				end

				local mapSource = 6

				if sceneInfo.data.templateId == nil then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【模板ID缺少】",
						sceneInfo = sceneInfo
					})

					return
				end

				MiniCodeApi:createWorldByMCode(mcodeUrl, 4, false, mapSource)
			end
		elseif sceneInfo.type == MCEnterMapType.optionQuestion then
			MiniCodeUtils:Log("zuoyou*****---optionQuestion: ", sceneInfo.data, "maplen:", #sceneInfo.data.mapId)

			if sceneInfo.data.mapId and #sceneInfo.data.mapId > 1 and sceneInfo.data.stageId then
				MiniCodeUtils:Log("zuoyou*****---optionQuestion mapId: ", sceneInfo.data.mapId)
				MiniCodeApi:enterMapWithStageId(sceneInfo.data.stageId)
			else
				local mcodeUrl = sceneInfo.data.mcodeUrl

				if not mcodeUrl or type(mcodeUrl) ~= "string" or #mcodeUrl <= 0 then
					MsgApi.mapLoadedFail({
						type = 2,
						msg = "进入地图失败【URL参数错误】",
						sceneInfo = sceneInfo
					})

					return
				end

				local mapSource = -1

				MiniCodeApi:createWorldByMCode(mcodeUrl, 4, false, mapSource)
			end
		elseif sceneInfo.type == MCEnterMapType.createLiteRoom then
			MiniCodeUtils:playTogetherHookShowGameTipsStart()
			MiniCodeUtils:Log("pyf test MCEnterMapType.createLiteRoom: ", "roomName:", sceneInfo.data.roomName, "maxPeople", sceneInfo.data.maxPeople, "mapId", sceneInfo.data.mapId, "nickname", MCodeManager:getUserInfo().nickName)

			local param = {
				RoomDescTex = "",
				maxPeople = 6,
				backUp = false,
				authority = 6,
				connectMode = 1,
				password = "",
				name = sceneInfo.data.roomName
			}
			local uin = AccountManager:getUin()
			local respdata = MCodeMgr:doAction(-1, JSON:encode({
				"unarchiveMcode",
				tonumber(sceneInfo.data.mapId),
				tonumber(uin)
			}), 1)

			if respdata then
				local retInfo = JSON:decode(respdata)

				if retInfo and type(retInfo) == "table" and retInfo[1] ~= 0 then
					ShowGameTips("不存在mcode文件", 3)

					return
				end
			end

			MiniCodeUtils:setPlayTogetherRoomName(sceneInfo.data.roomName)
			MiniCodeUtils:setPlayTogetherStartInfo(0)

			local Model = 1
			local SkinID = 4

			if MCodeManager._roleInfoWhenOnAccountDirty and next(MCodeManager._roleInfoWhenOnAccountDirty) then
				Model = MCodeManager._roleInfoWhenOnAccountDirty.Model
				SkinID = MCodeManager._roleInfoWhenOnAccountDirty.RoleSkinID
			end

			LuaInterface:setRoleInfoForEducationMap(Model, MCodeManager:getUserInfo().nickName, SkinID, uin, sceneInfo.data.mapId, 4)
			MiniCodeUtils:Log("zuoyou****, uin = ", uin)

			if AccountManager:loginRoomServer(false) then
				IsLanRoom = false
				IsCreatingColloborationModeRoom = true

				MCLoadMapHandler:beginEnterWorld()
				OpenRoom(tonumber(sceneInfo.data.mapId, 10), param)
			else
				ShowGameTips("登录房间服失败", 3)
			end
		elseif sceneInfo.type == MCEnterMapType.joinLiteRoom then
			MiniCodeUtils:Log("pyf test MCEnterMapType.joinLiteRoom: ", "roomUin:", sceneInfo.data.roomUin, "roomVer", sceneInfo.data.roomVer, "mapId", sceneInfo.data.mapId, "nickname", MCodeManager:getUserInfo().nickName)
			MiniCodeUtils:playTogetherHookShowGameTipsStart()

			local Model = 1
			local SkinID = 4

			if MCodeManager._roleInfoWhenOnAccountDirty and next(MCodeManager._roleInfoWhenOnAccountDirty) then
				Model = MCodeManager._roleInfoWhenOnAccountDirty.Model
				SkinID = MCodeManager._roleInfoWhenOnAccountDirty.RoleSkinID
			end

			local uin = AccountManager:getUin()

			LuaInterface:setRoleInfoForEducationMap(Model, MCodeManager:getUserInfo().nickName, SkinID, uin, 0)
			MiniCodeUtils:setPlayTogetherRoomName(sceneInfo.data.roomName)
			MiniCodeUtils:setPlayTogetherStartInfo(0)
			MCLoadMapHandler:beginEnterWorld()

			t_autojump_service.play_together.worldId = tonumber(sceneInfo.data.mapId)
			t_autojump_service.play_together.GuestInCollaborationModeArr[t_autojump_service.play_together.worldId] = true
			t_autojump_service.play_together.anchorUin = tonumber(sceneInfo.data.roomUin)
			t_autojump_service.play_together.password = ""
			t_autojump_service.play_together.type = "inviteroom"

			t_autojump_service.play_together.LoginRoomServer()
		elseif sceneInfo.type == MCEnterMapType.editAvatar then
			if MCodeManager then
				MCodeManager:processLoading({
					type = "loadAvatar",
					process = 50
				})
			end

			threadpool:work(function ()
				if self.curLoginUin and userInfo.uin ~= self.curLoginUin then
					ShopReset()
				else
					ShopInit()
				end

				self.curLoginUin = userInfo.uin

				GetInst("PlayerCenterManager"):OrganizeSkinSeatInfo()
				threadpool:wait(2)
				GetInst("MinicodeAvatarPicEditMgr"):OpenUI()
			end)
		else
			MiniCodeUtils:Log("zuoyou*****---MsgHandler.enterMap 未知场景！", sceneInfo.type)
			ShowGameTips("没有" .. sceneInfo.type)
		end
	end,
	checkException = function (self, data)
		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.checkException: ", data)
		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.checkException: ", MCodeManager:getSceneInfo().type, MCodeManager:getSceneInfo())

		if ClientMgr and GetClientInfo():isPC() then
			return false
		end

		local sceneInfo = MCodeManager:getSceneInfo()

		if data and data.toolVersion and data.toolVersion < 2 then
			if sceneInfo.type == MCEnterMapType.adaptTemplate then
				MCodeMgr:showFullScreenLoading(true)
				MsgApi.mapLoadedFail({
					type = 2,
					msg = "基础版地图不能改编",
					sceneInfo = MCodeManager:getSceneInfo()
				})

				return true
			end

			if sceneInfo.type == MCEnterMapType.templateEnterExampleMCode then
				MCodeMgr:showFullScreenLoading(true)
				MsgApi.mapLoadedFail({
					type = 2,
					msg = "基础版教程已下架",
					sceneInfo = MCodeManager:getSceneInfo()
				})

				return true
			end
		end

		if sceneInfo.type == MCEnterMapType.adaptTemplate and data.tempType < 1 then
			MCodeMgr:showFullScreenLoading(true)
			MsgApi.mapLoadedFail({
				type = 2,
				msg = "原地图非开源模板，不能改编",
				sceneInfo = MCodeManager:getSceneInfo()
			})

			return true
		end

		return false
	end,
	beginEnterWorld = function (self, data)
		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.beginEnterWorld开始加载地图: ", data)
		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.beginEnterWorld开始加载地图: ", MCodeManager:getSceneInfo())

		if MCodeManager and MCodeManager:getSceneInfo() then
			MCodeManager:setSensorsParams(MCodeManager:getSceneInfo().sensorsParam)
		end
	end,
	onMapLoaded = function (self, data)
		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.onMapLoaded: 地图加载完成data: ", data)
		MCodeManager:setEnterMapTime()
		MCodeManager:setMapData(data)

		local sceneInfo = MCodeManager:getSceneInfo()

		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.onMapLoaded: 地图加载完成sceneInfo:", sceneInfo)

		local sensorsData = MCodeManager:getSensorsParams()
		sensorsData.work_id = data.mapId
		sensorsData.work_name = data.name

		MCodeManager:setSensorsParams(sensorsData)

		if data and data.toolVersion == 2 and data.liteMode == 4 then
			GetInst("UGCCommon"):RefreshEditUI()
		end

		if sceneInfo.type == MCEnterMapType.workshopEnterMap then
			GetInst("MainInterface"):OpenView(data)
		elseif sceneInfo.type == MCEnterMapType.publishWorks then
			MCodeUploadMgr:handleEnterPublicUI("native")
		elseif sceneInfo.type == MCEnterMapType.uploadToMiniCode then
			MiniCodeUtils:Log("MCodeUploadMgr onMapLoaded uploadToMiniCode")
			MCodeUploadMgr:uploadMcode(1)
			MiniCodeUtils:Log("MCodeUploadMgr onMapLoaded uploadToMiniCode2")
		elseif sceneInfo.type == MCEnterMapType.uploadToMiniworld then
			MiniCodeUtils:Log("MCodeUploadMgr onMapLoaded uploadToMiniworld")
			MCodeUploadMgr:uploadMcode(2)
			MiniCodeUtils:Log("MCodeUploadMgr onMapLoaded uploadToMiniworld2")
		elseif sceneInfo.type == MCEnterMapType.adaptTemplate then
			-- Nothing
		elseif sceneInfo.type == MCEnterMapType.programGameMap then
			-- Nothing
		elseif sceneInfo.type == MCEnterMapType.enterLocalBackup then
			if data and data.toolVersion < 2 then
				GetInst("MainInterface"):Reset()
				GetInst("MainInterface"):OpenView(data)
				MCodeMgr:doAction(-1, JSON:encode({
					"setUndoOperationSwitch",
					true
				}), 1)
			end
		elseif sceneInfo.type == MCEnterMapType.createLiteRoom then
			MsgApi.sendcreateLiteRoomRet(0)
			MiniCodeUtils:setPlayTogetherStartInfo(os.time())
			MiniCodeUtils:playTogetherHookShowGameTipsEnd()
			MCodeWorldStatus:RoomHostScreenShotStart()
		elseif sceneInfo.type == MCEnterMapType.joinLiteRoom then
			MsgApi.sendjoinLiteRoomRet(0)
			MiniCodeUtils:setPlayTogetherStartInfo(os.time())
			MiniCodeUtils:playTogetherHookShowGameTipsEnd()
		end

		if MCodeManager and not GetClientInfo():isPC() then
			local sensorsType = MCodeManager:getEnterMapSensorsType()

			if sensorsType then
				if sensorsType == SensorsConst.LiteJoinRoom then
					local roomDesc = AccountManager:getCurHostRoom()

					if roomDesc then
						sensorsData.content_num = tostring(roomDesc.map_type)
						sensorsData.content_name = roomDesc.roomname
						sensorsData.ext_string2 = MiniCodeUtils:getPlayTogetherRoomName()
						sensorsData.ext_string4 = tostring(roomDesc.owneruin)
					end
				end

				MsgApi.sensorsTrack({
					sensorsType = sensorsType,
					sensorsData = sensorsData
				})
			end
		end
	end,
	onWorldModeChanged = function (self, data)
		MiniCodeUtils:Log("zuoyouStatus******MCLoadMapHandler.onWorldModeChanged: ", data, mapData)
	end
}
