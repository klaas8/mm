MCodeManager = {
	templateIndex = 1,
	baseUrl = "http://127.0.0.1:8080",
	loginSuccessed = false,
	_mapData = {},
	_sceneInfo = {},
	_userInfo = {},
	_env = {},
	_deviceInfo = {},
	_sensorsCommentData = {},
	liteVerCode = GetClientInfo():GetClientVersion(),
	liteVersion = GetClientInfo():GetClientVersionStr(),
	waitForLoginCallback = {},
	setMapData = function (self, data)
		self._mapData = data
	end,
	getMapData = function (self)
		return self._mapData
	end,
	setSceneInfo = function (self, info)
		self._sceneInfo = info
	end,
	getSceneInfo = function (self)
		return self._sceneInfo
	end,
	setUserInfo = function (self, info)
		self._userInfo = info
	end,
	getUserInfo = function (self)
		return self._userInfo
	end,
	setDeviceInfo = function (self, info)
		self._deviceInfo = info
	end,
	getDeviceInfo = function (self)
		return self._deviceInfo
	end,
	setEnv = function (self, env)
		self._env = env
	end,
	getEnv = function (self)
		return self._env
	end,
	setEnterMapTime = function (self)
		self._enterMapTime = os.time()
	end,
	getEnterMapTime = function (self)
		return self._enterMapTime
	end,
	getEditMapTime = function (self)
		if self._enterMapTime then
			return os.time() - self._enterMapTime
		else
			return nil
		end
	end,
	setSensorsParams = function (self)
		MiniCodeUtils:Log("zuoyou*****---setSensorsParams1", self._sceneInfo)

		if self._sceneInfo and self._sceneInfo.data and self._sceneInfo.data.sensorsParam then
			self._sensorsCommentData = self._sceneInfo.data.sensorsParam
		end

		MiniCodeUtils:Log("zuoyou*****---setSensorsParams2", self._sensorsCommentData)

		if self._userInfo then
			self._sensorsCommentData.work_author = self._userInfo.uin
		end

		if self._mapData then
			self._sensorsCommentData.work_id = tostring(self._mapData.mapId)
		end

		self._sensorsCommentData.tool_version = "增强版2.0"

		MiniCodeUtils:Log("zuoyou*****---setSensorsParams3", self._sensorsCommentData)
	end,
	getSensorsParams = function (self)
		return self._sensorsCommentData
	end,
	reset = function (self)
		self._mapData = {}
		self._sceneInfo = {}
		self._userInfo = {}
		self._deviceInfo = {}
		self._env = {}
		self._sensorsCommentData = {}
		self._enterMapTime = nil
	end,
	closeLoading = function (self)
		SlsLog:logSuccess("course_enter_map", "handle_enter_lite", {
			msg = "map load. closeLoading"
		})

		if MsgApi then
			MsgApi.loadingClose()
		end
	end,
	processLoading = function (self, data)
		local process = 0
		local msg = "初始化"

		if data.type == "loadSoAndLua" then
			process = 85
			msg = "初始化程序"

			if SlsLog then
				SlsLog:logReport("course_enter_map", "lite_init_lua")
			end
		elseif data.type == "initLite" then
			if data.process % 2 == 0 then
				process = math.floor(process + 85 + data.process * 0.05)
			end

			msg = "加载场景"

			if data.process >= 100 then
				SlsLog:logReport("course_enter_map", "lite_init_finished")
				MsgApi.miniwLoadedOK()
			end
		elseif data.type == "login" then
			process = 90
			msg = "初始化数据"
		elseif data.type == "download" then
			if data.process % 2 == 0 then
				process = process + 90 + data.process * 0.05
			end

			msg = "下载地图"

			if data.process >= 100 then
				SlsLog:logReport("course_enter_map", "map_download_finished")
			end
		elseif data.type == "unzip" then
			process = 95
			msg = "解压地图"
		elseif data.type == "loadMap" then
			if data.process % 2 == 0 then
				process = process + 95 + data.process * 0.05
			end

			msg = "加载地图"

			if data.process >= 100 then
				SlsLog:logReport("course_enter_map", "map_load_finished")
			end
		elseif data.type == "loadAvatar" then
			if data.process % 2 == 0 then
				process = process + 95 + data.process * 0.05
			end

			msg = "加载avatar"

			if data.process >= 100 then
				SlsLog:logReport("course_enter_map", "map_load_finished")
			end
		else
			process = 100
		end

		if process > 100 then
			process = 100
		elseif process < 84 then
			return
		end

		if MsgApi then
			MsgApi.loadingProcess({
				process = process,
				msg = msg
			})
		end
	end,
	getEnterMapSensorsType = function (self)
		if self:getSceneInfo().type == MCEnterMapType.createWorks then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.enterLocalBackup then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.adaptateEnterLocalBackup then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.selectTerrainCreateNew then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.selectTerrainTemplate then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.templateRepoMap then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.createTabSelectTerrainTemplate then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.programGameMap then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.createTerrain then
			return SensorsConst.LiteCreatePageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.workshopEnterMap then
			return SensorsConst.LitePlayPageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.optionQuestion then
			return SensorsConst.LiteStudyPageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.challengeLevel then
			return SensorsConst.LiteStudyPageEnter
		elseif self:getSceneInfo().type == MCEnterMapType.adaptTemplate then
			if self:getSceneInfo().data.toolVersion == 2 then
				return SensorsConst.LiteCreatePageEnter
			else
				return nil
			end
		elseif self:getSceneInfo().type == MCEnterMapType.createLiteRoom then
			return SensorsConst.LiteRoomCreate
		elseif self:getSceneInfo().type == MCEnterMapType.joinLiteRoom then
			return SensorsConst.LiteJoinRoom
		else
			return nil
		end
	end,
	getExitMapSensorsType = function (self)
		if self:getSceneInfo().type == MCEnterMapType.createWorks then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.enterLocalBackup then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.adaptateEnterLocalBackup then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.selectTerrainCreateNew then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.selectTerrainTemplate then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.templateRepoMap then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.createTabSelectTerrainTemplate then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.programGameMap then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.createTerrain then
			return SensorsConst.LiteCreatePageExit
		elseif self:getSceneInfo().type == MCEnterMapType.workshopEnterMap then
			return SensorsConst.LitePlayPageExit
		elseif self:getSceneInfo().type == MCEnterMapType.optionQuestion then
			return SensorsConst.ExitCheckpoint
		elseif self:getSceneInfo().type == MCEnterMapType.challengeLevel then
			return SensorsConst.ExitCheckpoint
		elseif self:getSceneInfo().type == MCEnterMapType.adaptTemplate then
			if self:getSceneInfo().data.toolVersion == 2 then
				return SensorsConst.LiteCreatePageExit
			else
				return nil
			end
		else
			return nil
		end
	end,
	waitForLogin = function (self, callback)
		MiniCodeUtils:Log("zuoyou********waitForLogin:", callback)
		table.insert(self.waitForLoginCallback, callback)
	end,
	notifyLoginSuccess = function (self)
		self.loginSuccessed = true

		MiniCodeUtils:Log("zuoyou********notifyLoginSuccess:", self.waitForLoginCallback)

		local functions = copy_table(self.waitForLoginCallback)
		self.waitForLoginCallback = {}

		for _, value in ipairs(functions) do
			MiniCodeUtils:Log("zuoyou********notifyLoginSuccess:", value)
			value()
		end
	end
}
