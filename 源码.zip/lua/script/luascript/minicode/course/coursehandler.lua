MCCourseHandler = {
	isHaveGuide = false,
	sendTeachingTips = function ()
	end,
	onMapLoaded = function (self, data)
		MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onMapLoaded: ")

		local sceneInfo = MCodeManager:getSceneInfo()

		MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onMapLoaded: ", sceneInfo)

		if sceneInfo.type == MCEnterMapType.optionQuestion or sceneInfo.type == MCEnterMapType.challengeLevel then
			MCCourseHandler.isHaveGuide = true
		end

		if sceneInfo.type == MCEnterMapType.programGameMap and sceneInfo.data.templateId then
			MCCourseHandler.isHaveGuide = true
		end

		if sceneInfo.type == MCEnterMapType.templateEnterExampleMCode then
			local jmiString = MCodeMgr:getJmiJson()

			MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onMapLoaded: ", jmiString)

			local ok, json_data = pcall(JSON.decode, JSON, jmiString)

			if ok and type(json_data) == "table" then
				MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onMapLoaded: ", json_data)

				if json_data.toolVersion == 2 then
					MCCourseHandler.isHaveGuide = true
				end
			end
		end

		if MCCourseHandler.isHaveGuide then
			MiniCodeUtils:Log("zuoyou*******onMapLoaded: ")
			GetInst("TeachingEventHandler"):dispatcher(TeachingDef.data_event.start_lessons)

			local sceneInfo = MCodeManager:getSceneInfo()

			MiniCodeUtils:Log("zuoyou******---------MCCourseHandler.onMapLoaded: ", data)
			MiniCodeUtils:Log("zuoyou******---------MCCourseHandler.onMapLoaded: ", sceneInfo)

			if sceneInfo.type == MCEnterMapType.optionQuestion then
				MCCourseHandler:handleQuestion(sceneInfo.data)
			end

			if sceneInfo.type == MCEnterMapType.challengeLevel then
				MCCourseHandler:handleChallenge(sceneInfo.data)
			end

			if sceneInfo.type == MCEnterMapType.templateEnterExampleMCode or sceneInfo.type == MCEnterMapType.programGameMap then
				MCCourseHandler:handleTemplate(sceneInfo.data)
			end
		end
	end,
	onPlayerRevive = function (self, data)
		local sceneInfo = MCodeManager:getSceneInfo()

		MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onPlayerRevive: ", sceneInfo.type)

		if sceneInfo.type == MCEnterMapType.optionQuestion then
			GetInst("TargetsPannelInterface"):OpenView("open", sceneInfo.judgement)
		end
	end,
	onQuitMap = function (self, data)
		local sceneInfo = MCodeManager:getSceneInfo()

		MiniCodeUtils:Log("zuoyou*******onQuitMap: ", MCCourseHandler.isHaveGuide, sceneInfo)

		if MCCourseHandler.isHaveGuide then
			MiniCodeUtils:Log("zuoyou*******onQuitMap: ")
			GetInst("TeachingEventHandler"):dispatcher(TeachingDef.data_event.end_lessons)
		end

		MCCourseHandler.isHaveGuide = false
	end,
	handleQuestion = function (self, info)
		MiniCodeUtils:Log("zuoyou*******handleQuestion: ", info)

		if info and info.stageId then
			local function callback(str)
				MiniCodeUtils:Log("zuoyou*******handleQuestion: ", str)

				local stage = JSON:decode(str)

				MiniCodeUtils:Log("zuoyou*******操作题数据: ", stage.data.guide)

				if not stage.data or stage.code and stage.code ~= 0 then
					MiniCodeUtils:Log("zuoyou*******操作题数据异常: ")
				else
					local data = {
						open = 1,
						label = "任务目标",
						content = stage.data.guide,
						id = 90100000 + stage.data.id
					}
					local stageInfo = stage.data.mTutorial
					local judgement = stage.data.goalJudgement
					local sceneInfo = MCodeManager:getSceneInfo()
					sceneInfo.judgement = judgement
					sceneInfo.startTime = os.time()

					MiniCodeUtils:Log("zuoyou*******操作题数据1: ", stageInfo)
					MiniCodeUtils:Log("zuoyou*******判定目标: ", judgement)
					MiniCodeUtils:Log("zuoyou*******判定目标: ", sceneInfo)

					local course = {}

					if stageInfo then
						MiniCodeUtils:Log("zuoyou*******操作题数据2: ", type(stageInfo), stageInfo)

						for key, value in pairs(stageInfo) do
							MiniCodeUtils:Log("zuoyou*******操作题数据key: ", key, value.media, value)

							local type = 1
							local i, j = string.find(value.media, "%.mp4")

							if i and i > 0 then
								type = 3
							end

							table.insert(course, {
								type = type,
								url = MiniCodeUtils:clearParam(value.media),
								tips = value.desc
							})
						end
					end

					data.course = course

					if data.content and #data.content > 0 then
						GetInst("TeachingEventHandler"):dispatcher(TeachingDef.ui_event.send_teaching_message, data)
					end
				end
			end

			MCNetworkApi:getOptionQuestionInfo(info.stageId, callback)
		end
	end,
	handleChallenge = function (self, info)
		MiniCodeUtils:Log("zuoyou*******handleChallenge: ", info)

		if info and info.stageId then
			local function callback(str)
				MiniCodeUtils:Log("zuoyou*******handleChallenge: ", str)

				local stage = JSON:decode(str)

				MiniCodeUtils:Log("zuoyou*******课程数据: ", stage)

				if not stage.data or stage.code and stage.code ~= 0 then
					MiniCodeUtils:Log("zuoyou*******课程数据异常: ")
				else
					local stageInfo = stage.data.templateMapDetail
					local data = {
						open = 1,
						label = "创作指引",
						content = stageInfo.tips,
						id = 90100000 + stage.data.id
					}

					MiniCodeUtils:Log("zuoyou*******课程数据1: ", stageInfo)
					MiniCodeUtils:Log("zuoyou*******课程数据1: ", stageInfo.tips)

					local course = {}

					if stageInfo and stageInfo.strategy then
						local strategy = stageInfo.strategy

						MiniCodeUtils:Log("zuoyou*******课程数据2: ", type(strategy), strategy)

						for key, value in pairs(strategy) do
							MiniCodeUtils:Log("zuoyou*******课程数据key: ", key, value)

							local type = 1
							local i, j = string.find(value.coverUrl, "%.mp4")

							if i and i > 0 then
								type = 3
							end

							table.insert(course, {
								type = type,
								url = MiniCodeUtils:clearParam(value.coverUrl),
								tips = value.content
							})
						end
					end

					data.course = course

					if data.content and #data.content > 0 then
						GetInst("TeachingEventHandler"):dispatcher(TeachingDef.ui_event.send_teaching_message, data)
					end
				end
			end

			MCNetworkApi:getChallengeLevelInfo(info.stageId, callback)
		end
	end,
	handleTemplate = function (self, data)
		MiniCodeUtils:Log("zuoyou*******handleTemplate: ", data)

		if data and data.templateId and #tostring(data.templateId) > 0 then
			local function callback(str)
				MiniCodeUtils:Log("zuoyou*******handleTemplate: ", str)

				local stage = JSON:decode(str)

				MiniCodeUtils:Log("zuoyou*******模板教程数据: ", stage)

				if not stage.data or stage.code and stage.code ~= 0 then
					MiniCodeUtils:Log("zuoyou*******模板教程异常: ")
				else
					local lable = "提示"

					if stage.data.tooltipsType == 0 then
						lable = "教学"
					elseif stage.data.tooltipsType == 1 then
						lable = "提示"
					elseif stage.data.tooltipsType == 2 then
						lable = "教程"
					end

					local data = {
						open = 1,
						content = stage.data.tips,
						id = 90110000 + MCodeManager.templateIndex,
						label = lable
					}
					local strategy = stage.data.strategy

					MiniCodeUtils:Log("zuoyou*******课程数据1: ", strategy)

					local course = {}

					if strategy then
						MiniCodeUtils:Log("zuoyou*******课程数据2: ", type(strategy), strategy)

						for key, value in pairs(strategy) do
							MiniCodeUtils:Log("zuoyou*******操作题数据key: ", key, value.coverUrl, value)

							local type = 1
							local i, j = string.find(value.coverUrl, "%.mp4")

							if i and i > 0 then
								type = 3
							end

							table.insert(course, {
								type = type,
								url = MiniCodeUtils:clearParam(value.coverUrl),
								tips = value.content
							})
						end
					end

					data.course = course

					if stage.data.tips and #stage.data.tips > 0 then
						MiniCodeUtils:Log("zuoyou*******MCCourseHandler:handleTemplate: ", data)
						GetInst("TeachingEventHandler"):dispatcher(TeachingDef.ui_event.send_teaching_message, data)

						MCodeManager.templateIndex = MCodeManager.templateIndex + 1
					end
				end
			end

			MCNetworkApi:getTemplateInfo(data.templateId, callback)
		end
	end,
	handleJudgment = function (self, data)
		MiniCodeUtils:Log("zuoyou*******handleJudgment: ", data)
		GetInst("TargetsPannelInterface"):handleJudgment({
			{
				index = data.index,
				result = data.result
			}
		})
	end,
	isInCourse = function (self)
		local sceneInfo = MCodeManager:getSceneInfo()

		if sceneInfo and (sceneInfo.type == MCEnterMapType.optionQuestion or sceneInfo.type == MCEnterMapType.challengeLevel) then
			return true
		end

		return false
	end,
	setTargetsVisible = function (self, visible)
		MiniCodeUtils:Log("zuoyou*******setTargetsVisible: ", visible)

		if visible then
			GetInst("TargetsPannelInterface"):CtrlPannelOpen(true)
		else
			GetInst("TargetsPannelInterface"):CtrlPannelOpen(false)
		end
	end,
	onModeChanged = function (self, mode)
		local sceneInfo = MCodeManager:getSceneInfo()

		MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onModeChanged: ", mode, sceneInfo.type)
		MiniCodeUtils:Log("zuoyou*******MCCourseHandler.onModeChanged: ", sceneInfo.judgement)

		if sceneInfo.type == MCEnterMapType.optionQuestion then
			if mode == 5 then
				GetInst("TargetsPannelInterface"):OpenView("open", copy_table(sceneInfo.judgement))
			elseif mode == 4 then
				GetInst("TargetsPannelInterface"):CloseView()
			end
		end
	end
}
