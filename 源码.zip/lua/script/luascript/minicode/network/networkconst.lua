MCNetworkConst = {
	getCourseStageInfo = function (self, id)
		return MCNetworkConst.env.serverUrl .. string.format("/v1/course/stages/%s/lite", id)
	end,
	getHttpsHeader = function (self)
		local Authorization = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2NzI3OTcxMzIsImV4cCI6MTY3NDAwNjczMn0.ANfmrt-Jan2aUbLI4369Lnhk6Y9B708unU9wQ3s6nHQ"

		if MCNetworkConst.userInfo and MCNetworkConst.userInfo.ctoken then
			Authorization = MCNetworkConst.userInfo.ctoken
		end

		local platform = "iOS"

		if GetClientInfo() and GetClientInfo():isAndroid() then
			platform = "Android"
		end

		local channel = 2001

		if MCNetworkConst.env and MCNetworkConst.env.CHANNE_ID then
			channel = MCNetworkConst.env.CHANNE_ID
		end

		local version = "4.0.100"

		if MCNetworkConst.env and MCNetworkConst.env.VERSION_NAME then
			version = MCNetworkConst.env.VERSION_NAME
		end

		local device_id = ""

		if MCNetworkConst.deviceInfo and MCNetworkConst.deviceInfo.deviceName then
			device_id = string.format("%s_%s", MCNetworkConst.deviceInfo.deviceName, MCNetworkConst.deviceInfo.systemVersion)
		end

		return string.format("Authorization: Bearer %s;x-minicode-platform: %s;x-minicode-channel: %s;x-minicode-version: %s;x-minicode-device-id: %s;content-type: application/json", Authorization, platform, channel, version, device_id)
	end,
	deviceInfo = {
		deviceName = "HUAWEI NOH-AN00",
		brand = "HUAWEI",
		systemVersion = "12",
		chromeVer = "92"
	},
	env = {
		VERSION_NAME = "4.0.999",
		VERSION_CODE = 20221201092721.0,
		CHANNE_ID = 1150,
		serverUrl = "https://test-api.miniaixue.com",
		uploadImgUrl = "http://119.3.85.124:18081",
		h5Host = "https://xigua-h5.miniaixue.com",
		serverSiriusUrl = "https://test-api.miniaixue.com/sirius"
	},
	userInfo = {
		isRreview = 0,
		ctoken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2NzI3OTcxMzIsImV4cCI6MTY3NDAwNjczMn0.ANfmrt-Jan2aUbLI4369Lnhk6Y9B708unU9wQ3s6nHQ",
		s2t = 1669800666,
		s2 = "52201f9b8b14a43b3a353b5fcdc5d437",
		uin = 1000036389,
		nickName = "佐佑",
		mtoken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzcmMiOiJsb2dpbnNlcnZpY2UucGhvbmVfbG9naW4iLCJVaW4iOjEwMDAwMzYzODksImVudiI6MSwiYXV0aCI6IndlYiIsInRzIjoxNjY5ODAwNjY2LCJpYXQiOjE2Njk4MDA2NjZ9.JkraaGuBEVOjIS6_CwDSqONh8uuYNRJHFqWuo87F0SY",
		vipInfo = {
			isVip = 0,
			vipType = 0
		}
	}
}
