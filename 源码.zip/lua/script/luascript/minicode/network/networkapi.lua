MCNetworkApi = {
	_httpsHeader = "",
	init = function (self, deviceIfo, env, userInfo)
		if deviceIfo then
			MCNetworkConst.deviceInfo = deviceIfo
		end

		if env then
			MCNetworkConst.env = env
		end

		if userInfo then
			MCNetworkConst.userInfo = userInfo
		end

		_httpsHeader = MCNetworkConst:getHttpsHeader()
	end,
	getChallengeLevelInfo = function (self, id, callback)
		local url = MCNetworkConst:getCourseStageInfo(id)

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", _httpsHeader)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())

		local function RespCb(retstr)
			MiniCodeUtils:Log("zuoyou******getChallengeLevelInfo", retstr)
			callback(retstr)
		end

		ns_http.func.rpc_string_raw_https(url, RespCb, nil, true, nil, MCNetworkConst:getHttpsHeader())
	end,
	getOptionQuestionInfo = function (self, id, callback)
		local url = MCNetworkConst:getCourseStageInfo(id)

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", _httpsHeader)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())

		local function RespCb(retstr)
			MiniCodeUtils:Log("zuoyou******getOptionQuestionInfo", retstr)
			callback(retstr)
		end

		ns_http.func.rpc_string_raw_https(url, RespCb, nil, true, nil, MCNetworkConst:getHttpsHeader())
	end,
	getTemplateInfo = function (self, id, callback)
		local url = MCNetworkConst.env.serverUrl .. "/v1/template/map/detail"

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())

		local usrInfo = MCodeManager:getUserInfo()

		MiniCodeUtils:Log("zuoyou***usrInfo = ", usrInfo)

		local body = {
			templateMapId = id
		}

		MiniCodeUtils:Log("zuoyou***body = ", body)
		ns_http.func.rpc_string_raw_https(url, callback, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	commiteTaskResult = function (self, stageId, duration, correctCount, callback)
		local url = MCNetworkConst.env.serverUrl .. "/v1/course/progresses"

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())

		local usrInfo = MCodeManager:getUserInfo()

		MiniCodeUtils:Log("zuoyou***usrInfo = ", usrInfo)

		local body = {
			uin = tostring(usrInfo.uin),
			stageId = stageId,
			duration = duration,
			correctCount = correctCount
		}

		MiniCodeUtils:Log("zuoyou***body = ", body)
		ns_http.func.rpc_string_raw_https(url, callback, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	getCToken = function (self)
		local url = MCNetworkConst.env.serverUrl .. "/v2/accounts/debug-token"
		local uin = AccountManager:getUin()

		MiniCodeUtils:Log("zuoyou***uin = ", AccountManager:getUin())

		local body = {
			uin = tostring(uin)
		}

		local function RespCb(retstr)
			MiniCodeUtils:Log("zuoyou***retstr = ", retstr)

			local rsp = JSON:decode(retstr)

			if rsp and rsp.data and rsp.data.ctoken then
				MCodeManager:setUserInfo({
					uin = AccountManager:getUin(),
					ctoken = rsp.data.ctoken,
					nickName = AccountManager:getNickName()
				})

				MCNetworkConst.userInfo.uin = AccountManager:getUin()
				MCNetworkConst.userInfo.nickName = AccountManager:getNickName()
				MCNetworkConst.userInfo.ctoken = rsp.data.ctoken
			end

			ShowGameTips("星工场登录成功： " .. MCNetworkConst.userInfo.uin)
			MiniCodeUtils:Log("zuoyou***usrInfo2 = ", MCodeManager:getUserInfo())
		end

		ns_http.func.rpc_string_raw_https(url, RespCb, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	getObsUploadUrl = function (self, datatype, ext, callback)
		local s2, _, s2tpure = get_login_sign()
		local uin_ = tostring(AccountManager:getUin() or get_default_uin())
		local now_ = os.time()
		local md5 = gFunc_getmd5(now_ .. s2 .. uin_)
		local apiUrl, body = nil

		if ext == "png" then
			apiUrl = "/v1/tokens/upload"
			body = {
				contentType = "image/png",
				path = "minicode",
				fileName = md5 .. "." .. ext
			}
		else
			apiUrl = "/v1/tokens/oss"
			body = {
				type = datatype,
				ext = ext,
				sign = md5,
				uin = uin_,
				time = now_,
				s2t = s2tpure
			}
		end

		local url = MCNetworkConst.env.serverUrl .. apiUrl

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())
		MiniCodeUtils:Log("zuoyou***body = ", body)
		ns_http.func.rpc_string_raw_https(url, callback, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	saveMcodeInfoToCloud = function (self, title, mapId, coverUrl, mcodeUrl, toolVersion, liteVersion, callback)
		local url = MCNetworkConst.env.serverUrl .. "/v1/works/save/works"
		local usrInfo = MCodeManager:getUserInfo()

		MiniCodeUtils:Log("zuoyou***usrInfo = ", usrInfo)

		local uin_ = tostring(AccountManager:getUin() or get_default_uin())
		local body = {
			uin = uin_,
			worksId = mapId,
			coverUrl = coverUrl,
			mcodeUrl = mcodeUrl,
			toolVersion = toolVersion,
			liteVersion = liteVersion,
			title = title
		}

		MiniCodeUtils:Log("MCodeUploadMgr saveMcodeInfoToCloud = ", body)
		ns_http.func.rpc_string_raw_https(url, callback, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	getUinHeadUrl = function (self, uins, callBack)
		local url = MCNetworkConst.env.serverUrl .. "/v2/accounts"
		local uinStr = ""

		for index = 1, #uins do
			uinStr = uinStr + tostring(uins[index])

			if index < #uins then
				uinStr = uinStr + ","
			end
		end

		url = url + "?uin=" + uinStr

		ns_http.func.rpc_string_raw_https(url, callBack, nil, true, nil, MCNetworkConst:getHttpsHeader())
	end,
	roomCoverUpdate = function (self, roomId, coverUrl, callBack)
		local url = MCNetworkConst.env.serverUrl .. "/v1/room/cover/update"
		local body = {
			roomId = tostring(roomId),
			url = coverUrl
		}

		ns_http.func.rpc_string_raw_https(url, callBack, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	getRoomCover = function (self, roomId, callBack)
		local url = MCNetworkConst.env.serverUrl .. "/v1/room/cover"
		url = url + "?roomId=" + tostring(roomId)

		ns_http.func.rpc_string_raw_https(url, callBack, nil, true, nil, MCNetworkConst:getHttpsHeader())
	end,
	dataReport = function (self, data, callBack)
		local url = MCNetworkConst.env.serverUrl .. "/v1/events/behavior"
		local body = data

		MiniCodeUtils:Log("zuoyou***body = ", body)

		local function RespCb(retstr)
			MiniCodeUtils:Log("zuoyou***retstr = ", retstr)

			if callBack then
				callBack(retstr)
			end
		end

		ns_http.func.rpc_string_raw_https(url, RespCb, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end,
	getAvatarBackground = function (self, callback)
		local usrInfo = MCodeManager:getUserInfo()
		local uin_ = tostring(usrInfo.uin)
		local url = MCNetworkConst.env.serverUrl .. string.format("/v2/accounts/%s/avatar-background-images", uin_)

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())

		local function RespCb(retstr)
			MiniCodeUtils:Log("zuoyou******getAvatarBackground", retstr)

			if callback then
				callback(retstr)
			end
		end

		ns_http.func.rpc_string_raw_https(url, RespCb, nil, true, nil, MCNetworkConst:getHttpsHeader())
	end,
	updateAvatarBackground = function (self, bannerImage, callback)
		local usrInfo = MCodeManager:getUserInfo()
		local uin_ = tostring(usrInfo.uin)
		local url = MCNetworkConst.env.serverUrl .. "/v2/accounts/lite/save-banner-image/"

		MiniCodeUtils:Log("zuoyou***url = ", url)
		MiniCodeUtils:Log("zuoyou***_httpsHeader = ", MCNetworkConst:getHttpsHeader())

		local body = {
			uin = uin_,
			bannerImage = bannerImage
		}

		local function RespCb(retstr)
			MiniCodeUtils:Log("zuoyou******updateAvatarBackground", retstr)

			if callback then
				callback(retstr)
			end
		end

		ns_http.func.rpc_string_raw_https(url, RespCb, nil, true, JSON:encode(body), MCNetworkConst:getHttpsHeader())
	end
}
