local tbMiniCodeLuas = {
	"luascript/minicode/utils/utils.lua",
	"luascript/minicode/Upload/McodeUpload.lua",
	"luascript/minicode/utils/slsLog.lua",
	"luascript/minicode/MCodeManager.lua",
	"luascript/minicode/api.lua",
	"luascript/minicode/utils/apiUtils.lua",
	"luascript/minicode/utils/resourceCache.lua",
	"luascript/minicode/SensorsConst.lua",
	"luascript/minicode/network/NetworkConst.lua",
	"luascript/minicode/network/NetworkApi.lua",
	"luascript/minicode/Course/CourseHandler.lua",
	"luascript/minicode/LoadMap/LoadMapHandler.lua",
	"luascript/minicode/MessageCenter/MsgConst.lua",
	"luascript/minicode/MessageCenter/MsgHandler.lua",
	"luascript/minicode/MessageCenter/MsgCenter.lua",
	"luascript/minicode/MessageCenter/MsgApi.lua",
	"luascript/minicode/MCodeWorldStatus.lua",
	"luascript/minicode/utils/dataReportUtils.lua",
	"luascript/minicode/utils/minicodeglobals.lua"
}

return tbMiniCodeLuas
