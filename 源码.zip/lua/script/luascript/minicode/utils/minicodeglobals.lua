function RefreshLobbyFrameForEdu()
	if not isEducationalVersion then
		return
	end

	VehicleMgr:loadPhysicsPartsConnectInfo()
	GetInst("MainInterfaceHelp"):SetNodeVisible("moreBtn", false)

	MiniCode = class.MiniCode.new()
	local mapOwnerUin = wdesc and wdesc.realowneruin or nil
	local uin = AccountManager:getUin()

	if CurWorld and CurWorld:isGameMakerMode() and ClientMgr and not GetClientInfo():isMobile() and mapOwnerUin and uin and uin == mapOwnerUin then
		if UIEditorDef:isMainUICanShow(UIEditorDef.TREE_ITEM_TYPE.SHOP) then
			GetInst("MainInterfaceHelp"):SetNodeVisible("shopBtn", true)
		end

		GongNengFrameUILibBtn_Show()
	else
		GetInst("MainInterfaceHelp"):SetNodeVisible("shopBtn", false)

		local ctrl = GetInst("MainInterfaceHelp"):GetMainInterfaceCtrl()

		if ctrl and ctrl.view and ctrl.view.widgets then
			if ctrl.view.widgets.pluginLibBtn then
				ctrl.view.widgets.pluginLibBtn:setVisible(false)
			end

			if ctrl.view.widgets.ruleSetGNBtn then
				ctrl.view.widgets.ruleSetGNBtn:setVisible(false)
			end
		end
	end

	GetInst("MainInterfaceHelp"):SetNodeVisible("gameModeBtn", false)

	if GetInst("MiniUIManager"):IsShown("RSConnectLostFrameAutoGen") then
		GetInst("MiniUIManager"):CloseUI("RSConnectLostFrameAutoGen")
	end

	local SettingMgr = ModuleMgr:GetMgr("Setting")

	SettingMgr:SetGraphicSetting("physxparam", 0)

	if AccountManager:getMultiPlayer() > 0 then
		GetInst("MainInterfaceHelp"):SetNodeVisible("shopBtn", false)
		InteractiveBtn_ShowOrHide(true)
	end

	if UGCModeMgr and UGCModeMgr:IsUGCMode() then
		GetInst("MainInterfaceHelp"):SetNodeVisible("settingBtn", true)
	elseif MCodeManager and MCodeManager:getSceneInfo() and MCodeManager:getSceneInfo().type == MCEnterMapType.workshopEnterMap then
		GetInst("MainInterfaceHelp"):SetNodeVisible("settingBtn", true)
	else
		getglobal("DevToolsTabTypeBoxDevEditTrigger"):Hide()
		getglobal("DevToolsTabTypeBoxScript"):Hide()
		getglobal("DevToolsRuleConverBtn"):Hide()
		GetInst("MainInterfaceHelp"):SetNodeVisible("settingBtn", false)
	end

	GetInst("UIManager"):Close("ToolModeFrame")

	if CurWorld and CurWorld:isGameMakerRunMode() or UGCModeMgr and UGCModeMgr:IsUGCMode() then
		if ClientCurGame and ClientCurGame:isInGame() then
			GetInst("UIManager"):Close("CoordSelectionFrame")
			getglobal("CoordSelectionFrameToolModeBtn"):Hide()
		end
	elseif ClientCurGame and ClientCurGame:isInGame() then
		local param = {
			disableOperateUI = true
		}

		GetInst("UIManager"):Open("CoordSelectionFrame", param)
		getglobal("CoordSelectionFrameToolModeBtn"):Show()
	end

	local sceneInfo = MCodeManager:getSceneInfo()

	if sceneInfo and (sceneInfo.type == MCEnterMapType.createLiteRoom or sceneInfo.type == MCEnterMapType.joinLiteRoom) then
		getglobal("MiniCodeRoomShareBtn"):Show()
	else
		getglobal("MiniCodeRoomShareBtn"):Hide()
	end
end

function IsTipTextForbiddenByEdu(text)
	if not isEducationalVersion then
		return false
	end

	if text == GetS(3752) or text == GetS(771) or text == GetS(100235) or text == GetS(3690) or text == GetS(3691) or text == GetS(3692) or text == GetS(3693) or text == GetS(21595) then
		return true
	else
		return false
	end
end

function OnLeaveMap()
	if not isEducationalVersion then
		return
	end

	local view = getglobal("BattleEndFrameView")

	if view and view.getActorBody and view.detachActorBody and view.detachUIModelView then
		for i = 1, 6 do
			local body = view:getActorBody(i - 1)

			if body then
				if MODELVIEW_DECOUPLE_FROM_ACTORBODY then
					view:detachActorBody(body, i - 1)
				else
					body:detachUIModelView(view, i - 1)
				end
			end
		end
	end

	if getglobal("BattleFrame") and getglobal("BattleFrame"):IsShown() then
		getglobal("BattleFrame"):Hide()
	end

	if getglobal("BattleEndFrameSpectatorModeBtn") and getglobal("BattleEndFrameSpectatorModeBtn"):IsShown() then
		getglobal("BattleEndFrameSpectatorModeBtn"):Hide()
	end

	HideUI2GoMainMenu()
	ModsLib_OnLeave()

	if getglobal("CreateBackpackFrame") and getglobal("CreateBackpackFrame"):IsShown() then
		getglobal("CreateBackpackFrame"):Hide()
	end

	ResourceCenterCloseFrame(true)
end

function enterWorldByMcodeUrl(url)
	ShowGameTips("打开地图url：" .. url)
	MiniCodeApi:enterWorldByMcodeUrl(url)
end

function quitWorld()
	MiniCodeApi:quitWorld()
end

function downloadProcess(pro)
	MCodeManager:processLoading({
		type = "download",
		process = pro
	})
end

function uploadProcess(retMsg)
	MCodeUploadMgr:asyncUploadResultCallBack(retMsg)
end

g_AvatarRes = {}
g_AvatarQueue = {}

function downloadOnceAvatarRes_MiniCode(url, avatarId, checkMD5, callback)
	local function removeItem(code)
		for i = 1, #g_AvatarQueue do
			if g_AvatarQueue[i].url == url and g_AvatarQueue[i].avatarId == avatarId and g_AvatarQueue[i].callback then
				g_AvatarQueue[i].callback(code, {
					url = url,
					avatarId = avatarId,
					checkMD5 = checkMD5
				})
			end
		end

		for i = #g_AvatarQueue, 1, -1 do
			if g_AvatarQueue[i].url == url and g_AvatarQueue[i].avatarId == avatarId then
				table.remove(g_AvatarQueue, i)
			end
		end
	end

	local function nextItem()
		if #g_AvatarQueue > 0 then
			local item = g_AvatarQueue[1]

			downloadOnceAvatarRes_MiniCode(item.url, item.avatarId, item.checkMD5, item.callback)
		end
	end

	local function addCache(code, url, avatarId, checkMD5)
		if code ~= ErrorCode.OK then
			return
		end

		if not g_AvatarRes[url] then
			local cache = {
				url = url,
				avatarId = avatarId,
				checkMD5 = checkMD5
			}
			g_AvatarRes[url] = cache
		end
	end

	local function downloadFinish(code)
		addCache(code, url, avatarId, checkMD5)
		removeItem(code)
		nextItem()
	end

	local errorCode = ErrorCode.OK

	if avatarId < 5 then
		downloadFinish(ErrorCode.OK)

		return
	end

	if g_AvatarRes[url] then
		downloadFinish(ErrorCode.OK)

		return
	end

	local filePath = string.format("entity/avatar/1000_%d/all.filelist", avatarId)

	if gFunc_isAssetFileListExist(filePath) then
		downloadFinish(ErrorCode.OK)

		return
	else
		ns_http.func.downloadFileList(url, filePath, function (userdata, code)
			downloadFinish(code)
		end)
	end
end

function downloadAvatarResLua_MiniCode(url, avatarId, checkMD5, callback)
	table.insert(g_AvatarQueue, {
		url = url,
		avatarId = avatarId,
		checkMD5 = checkMD5,
		callback = callback
	})

	if #g_AvatarQueue == 1 then
		downloadOnceAvatarRes_MiniCode(url, avatarId, checkMD5, callback)
	end
end

function downloadAvatarResCpp_MiniCode(seq, avatarId, url, checkMD5)
	local function callback(code, item)
	end

	table.insert(g_AvatarQueue, {
		url = url,
		avatarId = avatarId,
		checkMD5 = checkMD5,
		callback = callback,
		seq = seq
	})

	if #g_AvatarQueue == 1 then
		downloadOnceAvatarRes_MiniCode(url, avatarId, checkMD5, callback)
	end
end

function ClientGetRoleAvatarInfo_MiniCode(uin)
	print(">>>> ClientGetRoleAvatarInfo_MiniCode", uin)
	threadpool:work(function ()
		if not ClientCurGame then
			return
		end

		local count = 0

		while not ClientCurGame:isInGame() do
			count = count + 1

			threadpool:wait(1)

			if count >= 10 then
				return
			end
		end

		player = ClientCurGame:getPlayerByUin(uin)

		if player == nil then
			return
		end

		player:changePlayerModel(257, 0, "")
	end)
end

function ClientGetRoleAvatarInfoCallback_MiniCode(param)
	local ok, json_data = pcall(JSON.decode, JSON, param)

	print(">>>> ClientGetRoleAvatarInfoCallback_MiniCode", json_data)

	if ok and type(json_data) == "table" then
		if json_data.code ~= 0 then
			return
		end

		if not json_data.data then
			return
		end

		if not json_data.data.list then
			return
		end

		local players = json_data.data.list

		for _, player in ipairs(players) do
			setPlayerAvatar_MiniCode(player.uin, player)
		end
	end
end

function setPlayerAvatar_MiniCode(uin, avatarData)
	if avatarData.list and #avatarData.list > 0 then
		player = ClientCurGame:getPlayerByUin(uin)

		if player == nil then
			return
		end

		local usingAvatar = avatarData.list[1]
		local avatars = usingAvatar.list

		player:changePlayerModel(2, 0, "1")

		for _, avatar in ipairs(avatars) do
			downloadAvatarResLua_MiniCode(avatar.resUrl, avatar.modelId, avatar.resMd5, function ()
				AddAvatarPart_MiniCode(uin, avatar.modelId, avatar.positionId)
			end)
		end
	end
end

function AddAvatarPart_MiniCode(uin, modelID, partID)
	print(">>>> AddAvatarPart_MiniCode", uin, modelID)

	if uin and modelID then
		local player = nil

		if CurMainPlayer ~= nil and CurMainPlayer:getUin() == uin then
			player = CurMainPlayer
		else
			if ClientCurGame:isInGame() == false then
				return
			end

			player = ClientCurGame:getPlayerByUin(uin)

			if player == nil then
				return
			end
		end

		if partID then
			if player:getBody() ~= nil then
				player:getBody():setBodyType(3)
				SetAVTAvatarPartShield(player:getBody(), modelID)
				player:getBody():addAvatarPartModel(modelID, partID, true)
			end

			if player:getUIViewBody() ~= nil then
				player:getUIViewBody():setBodyType(3)
				SetAVTAvatarPartShield(player:getUIViewBody(), modelID)
				player:getUIViewBody():addAvatarPartModel(modelID, partID, true)
			end
		end
	end
end

function loadFinish_MiniCode()
	local root = GetInst("MiniUISceneMgr"):getCurrentSceneRootNode()

	if not root then
		GetInst("MiniUISceneMgr"):loadScene("MiniUICommonScene")
	end
end

function MiniCodeBlockStatistic()
	if not GetInst("VisualCodeInfoManager") or not GetInst("VisualCodeInfoManager").m_ActorInfo then
		return 0, 0
	end

	local actorInfos = GetInst("VisualCodeInfoManager").m_ActorInfo
	local nEventCount = 0
	local nBlockCount = 0

	for key, value in pairs(actorInfos) do
		nEventCount = nEventCount + (value.totalEventCount or 0)
		nBlockCount = nBlockCount + (value.totalBlockCount or 0)
	end

	return nEventCount, nBlockCount
end

function MiniCodeRoomShareBtn_OnClick()
	MsgApi.nativeShowUpShare()
end

function setRoleInfoForEducationMap(wid, uin, nOWType)
	local Model = 1
	local SkinID = 4

	if MCodeManager._roleInfoWhenOnAccountDirty and next(MCodeManager._roleInfoWhenOnAccountDirty) then
		Model = MCodeManager._roleInfoWhenOnAccountDirty.Model
		SkinID = MCodeManager._roleInfoWhenOnAccountDirty.RoleSkinID
	end

	LuaInterface:setRoleInfoForEducationMap(Model, MCodeManager:getUserInfo().nickName, SkinID, uin, wid, nOWType)
end

function miniCodeManagerTick()
	if GetInst("MinicodeAvatarPicEditMgr") then
		GetInst("MinicodeAvatarPicEditMgr"):tick()
	end
end
