ResourceCache = {}

function ResourceCache:getUrlRes(url, callback)
	LuaInterface:log("zuoyou*** getUrlRes 1 start:" .. url)

	if not url then
		if callback then
			callback({})
		end

		return
	end

	local urlString = url
	local paramIndex = string.find(url, "?")

	if paramIndex then
		urlString = string.sub(url, 0, paramIndex - 1)
	end

	LuaInterface:log("zuoyou*** getUrlRes 2 urlString:" .. urlString)

	if not urlString or #urlString == 0 then
		if callback then
			callback({})
		end

		return
	end

	threadpool:work(function ()
		local ret = ResourceCache:doDownloadTask(url, 1)

		LuaInterface:log("zuoyou*** getUrlRes 3 ret:" .. (TableToStr and TableToStr(ret)))

		if callback then
			callback(ret)
		end
	end)
end

function ResourceCache:downloadCleanAllTask()
end

function ResourceCache:doDownloadTask(url, prior)
	return MsgApi.downloadCache({
		url = url,
		prior = prior
	})
end
