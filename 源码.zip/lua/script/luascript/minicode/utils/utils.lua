LuaInterface:log("zuoyou*********MiniCodeUtils*********")

MiniCodeUtils = {
	Log = function (self, ...)
		local log = ""

		for i, v in ipairs(arg) do
			local str = ""

			if type(v) == "table" then
				if TableToStr then
					str = TableToStr(v)
				else
					str = "{a table value}"
				end
			else
				str = tostring(v)
			end

			log = log .. str .. "; "
		end

		if MiniLog then
			MiniLog(log)
		else
			LuaInterface:log(log)
		end
	end,
	fileType = function (self, fileName)
		local strLen = #fileName
		local po = string.find(fileName, "%.", -4)
		local substr = string.sub(fileName, po + 1, strLen)

		return substr
	end,
	clearParam = function (self, fileName)
		local strLen = #fileName
		local po = string.find(fileName, "%?")

		if po and po > 2 then
			return string.sub(fileName, 1, po - 1)
		else
			return fileName
		end
	end
}

function MiniCodeUtils:getMapOpenCode()
	local openCode = "0"
	local jmiString = MCodeMgr:getJmiJson()
	local ok, json_data = pcall(JSON.decode, JSON, jmiString)

	if ok and type(json_data) == "table" and json_data.IsOpenCode then
		openCode = json_data.IsOpenCode
	end

	MiniCodeUtils:Log("zuoyou**** openCode = ", openCode)

	return openCode
end

function MiniCodeUtils:getMapOriginType()
	local originType = 2
	local mapSource = 0
	local worldDesc = AccountManager:findWorldDesc(WorldMgr:getWorldId())
	local jmiString = MCodeMgr:getJmiJson()
	local ok, json_data = pcall(JSON.decode, JSON, jmiString)

	if ok and type(json_data) == "table" and json_data.mapSource then
		mapSource = json_data.mapSource
	end

	if worldDesc then
		local toolVesion = worldDesc.editorSceneSwitch and 2 or 0

		if toolVesion < 2 then
			if mapSource == 1 then
				originType = 1
			else
				originType = 2
			end
		elseif worldDesc.gwid == 0 and worldDesc.pwid == 0 or worldDesc.gwid == 0 and worldDesc.pwid ~= 0 then
			originType = 1
		else
			originType = 2
		end
	end

	MiniCodeUtils:Log("zuoyou**** originType = ", originType)

	return originType
end

function MiniCodeUtils:_hookShowGameTipsStart(newShowGameTipsFunc)
	if not newShowGameTipsFunc then
		return
	end

	if self.oldShowGameTipsFunc ~= nil then
		return
	end

	self.oldShowGameTipsFunc = _G.ShowGameTips
	_G.ShowGameTips = newShowGameTipsFunc
end

function MiniCodeUtils:_hookShowGameTipsEnd()
	if not self.oldShowGameTipsFunc then
		return
	end

	_G.ShowGameTips = self.oldShowGameTipsFunc
	self.oldShowGameTipsFunc = nil
end

function MiniCodeUtils.showGameTipsForMinicodePlayTogether(text, type, itemId, num, bNoLimit, withoutFilter)
	local sceneInfo = MCodeManager:getSceneInfo()
	local worldName = "进入了"

	if sceneInfo and sceneInfo.data and sceneInfo.data.sensorsParam and sceneInfo.data.sensorsParam.content_name then
		worldName = sceneInfo.data.sensorsParam.content_name
	end

	MiniCodeUtils:Log("zuoyou***** showGameTipsForMinicodePlayTogether worldName", text, worldName)

	if (string.find(text, "进入了") or string.find(text, "游戏为虚拟世界") or string.find(text, "当前为虚拟场景") or worldName == text) and self.oldShowGameTipsFunc then
		self.oldShowGameTipsFunc(text, type, itemId, num, bNoLimit, withoutFilter)

		return
	end

	threadpool:work(function ()
		if not string.find(text, "操作超时") then
			local nCount = 0

			while true do
				nCount = nCount + 1

				if nCount >= 30 then
					break
				end

				local m_CurGame = ClientGameMgr:getCurGame()

				if m_CurGame and m_CurGame:isInGame() then
					break
				else
					threadpool:wait(1)
				end
			end
		end

		if sceneInfo and sceneInfo.type and sceneInfo.type == MCEnterMapType.createLiteRoom then
			MsgApi.sendcreateLiteRoomRet(1)
		end

		GoToMainMenu()
		MCodeMgr:showFullScreenLoading(true)

		if string.find(text, "已达到上限") or string.find(text, "房间人数已满") or string.find(text, "加入了黑名单") then
			MsgApi.mapLoadedFail({
				type = 2,
				msg = text,
				sceneInfo = MCodeManager:getSceneInfo()
			})
		else
			MsgApi.mapLoadedFail({
				type = 1,
				msg = text,
				sceneInfo = MCodeManager:getSceneInfo()
			})
		end
	end)
	MiniCodeUtils:playTogetherHookShowGameTipsEnd()
end

function MiniCodeUtils:playTogetherHookShowGameTipsStart()
	self:_hookShowGameTipsStart(self.showGameTipsForMinicodePlayTogether)

	self.hookShowGameTipsTimer = GetInst("MiniUIScheduler"):regGloabel(function ()
		ShowGameTips("操作超时", 3)
	end, 0, 1, 60, false)
end

function MiniCodeUtils:playTogetherHookShowGameTipsEnd()
	self:_hookShowGameTipsEnd()

	if self.hookShowGameTipsTimer then
		GetInst("MiniUIScheduler"):unreg(self.hookShowGameTipsTimer)

		self.hookShowGameTipsTimer = nil
	end
end

function MiniCodeUtils:playTogetherInGameTips(text)
	if ClientCurGame and ClientCurGame:isInGame() then
		self.playTogetherInGameErrorOccur = true
		local data = {
			mbuttonName = "知道了",
			midCallBack = function ()
				MiniCodeApi:quitWorld(true, nil, false, false, {})
			end,
			showContext = text
		}

		GetInst("ConfirmInterface"):ShowPopView(1, data)

		local sceneInfo = MCodeManager:getSceneInfo()

		if sceneInfo and (sceneInfo.type == MCEnterMapType.createLiteRoom or sceneInfo.type == MCEnterMapType.joinLiteRoom) then
			MsgApi.quitRoomSensorsTrack()
		end
	else
		ShowGameTips(text, 3)
	end
end

function MiniCodeUtils:setPlayerHeadByMinicode(iconName, uin)
	self:getUinHeadUrlAndNickName(uin, function (headUrl, nickName)
		MiniCodeUtils:Log("pyf test setPlayerHeadByMinicode headUrl = ", headUrl)
		HeadCtrl:SetPlayerHead(iconName, 1, headUrl)
	end)
end

function MiniCodeUtils:getUinHeadUrlAndNickName(uin, callBackParam)
	self.tPlayerHeadUrl = self.tPlayerHeadUrl or {}
	self.tPlayerNickName = self.tPlayerNickName or {}

	if self.tPlayerHeadUrl[uin] then
		local headUrl = self.tPlayerHeadUrl[uin]
		local nickName = self.tPlayerNickName[uin]

		MiniCodeUtils:Log("pyf test getUinHeadUrl headUrl in cache = ", headUrl, nickName)

		if callBackParam then
			callBackParam(headUrl, nickName, "useCache")
		end

		return "useCache"
	end

	local function callBack(str)
		MiniCodeUtils:Log("pyf test getUinHeadUrl str = ", str)

		local resInfo = JSON:decode(str)

		if resInfo and resInfo.code == 0 and resInfo.data.userList then
			local headUrl = resInfo.data.userList[1].avatarUrl
			local nickName = resInfo.data.userList[1].nickname
			local resolutionIndex = string.find(headUrl, "?resolution")

			if resolutionIndex and resolutionIndex > 0 then
				headUrl = string.sub(headUrl, 1, resolutionIndex - 1)
			end

			self.tPlayerNickName[uin] = nickName
			self.tPlayerHeadUrl[uin] = headUrl

			MiniCodeUtils:Log("pyf test getUinHeadUrl headUrl = ", headUrl, nickName)

			if callBackParam then
				callBackParam(headUrl, nickName)
			end
		else
			MiniCodeUtils:Log("pyf test getUinHeadUrl failed uin = ", uin)

			if callBackParam then
				callBackParam("https://minioss.miniaixue.com/images/coolmini.png", "")
			end
		end
	end

	MCNetworkApi:getUinHeadUrl({
		uin
	}, callBack)

	return "waitCallBack"
end

function MiniCodeUtils:setPlayTogetherRoomName(name)
	self.playTogetherRoomName = name
end

function MiniCodeUtils:getPlayTogetherRoomName(name)
	return self.playTogetherRoomName or ""
end

function MiniCodeUtils:setPlayTogetherStartInfo(curTime)
	self.playTogetherStartTime = curTime
	self.playTogetherInGameErrorOccur = false
end

function MiniCodeUtils:getPlayTogetherStartTime()
	return self.playTogetherStartTime
end

function MiniCodeUtils:getPlayTogetherInGameErrorOccur()
	return self.playTogetherInGameErrorOccur
end
