DataReport = {
	reportEditDuration = function (self)
		local sceneInfo = MCodeManager:getSceneInfo()

		if sceneInfo.type == MCEnterMapType.workshopEnterMap and sceneInfo.newType ~= MCEnterMapType.play2EditInlite or sceneInfo.type == MCEnterMapType.publishWorks or sceneInfo.type == MCEnterMapType.uploadToMiniCode or sceneInfo.type == MCEnterMapType.uploadToMiniworld or sceneInfo.type == MCEnterMapType.changeToCreateModel then
			return
		end

		local mapInfo = MCodeManager:getMapData()
		local duration = MCodeManager:getEditMapTime() or 0

		if not mapInfo then
			return
		end

		local data = {
			event = "duration",
			payload = {
				id = tostring(mapInfo.mapId),
				duration = duration
			}
		}

		MCNetworkApi:dataReport(data)
	end,
	reportRoleEnterRoom = function (self, guestUin)
		local mapInfo = MCodeManager:getMapData()
		local userInfo = MCodeManager:getUserInfo()

		if not mapInfo or not userInfo then
			return
		end

		local data = {
			event = "enterRoom",
			payload = {
				guestUin = tostring(guestUin),
				roomId = userInfo.uin,
				mapId = tostring(mapInfo.mapId)
			}
		}

		MCNetworkApi:dataReport(data)
	end
}
