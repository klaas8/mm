print("minicode apiUtils.lua------------")

MiniCodeApiUtils = {
	downloadFile = function (url)
		MCodeMgr:doAction(-1, JSON:encode({
			"downloadFileReq",
			url,
			MiniCodeUtils.getDownloadDir() .. "\\" .. MiniCodeUtils.getUrlFileName(url),
			60
		}), 1)
	end,
	recompress = function ()
	end
}
