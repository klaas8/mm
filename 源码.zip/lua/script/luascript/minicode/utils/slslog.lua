LuaInterface:log("zuoyou*********MiniCode SlsLog*********")

SlsLog = {
	e_name_time = {},
	logStart = function (self, moduleName, e_name, jsonInfo, level)
		SlsLog.e_name_time[e_name] = os.time()
		local jsonObj = {
			module_p = "lua",
			e_name = e_name .. "_start",
			info = jsonInfo or "no info"
		}
		level = level or 3

		MCodeMgr:mlogSLS(moduleName, JSON:encode(jsonObj), level)
	end,
	logSuccess = function (self, moduleName, e_name, jsonInfo, level)
		local usedTime = 0
		local tCur = os.time()

		if SlsLog.e_name_time[e_name] then
			usedTime = tCur - SlsLog.e_name_time[e_name]
		else
			usedTime = tCur
		end

		local jsonObj = {
			module_p = "lua",
			e_name = e_name .. "_success",
			e_value = usedTime,
			info = jsonInfo or "no info"
		}
		level = level or 3

		MCodeMgr:mlogSLS(moduleName, JSON:encode(jsonObj), level)
	end,
	logFail = function (self, moduleName, e_name, jsonInfo, level)
		local usedTime = 0
		local tCur = os.time()

		if SlsLog.e_name_time[e_name] then
			usedTime = tCur - SlsLog.e_name_time[e_name]
		else
			usedTime = tCur
		end

		local jsonObj = {
			module_p = "lua",
			e_name = e_name .. "_fail",
			e_value = usedTime,
			info = jsonInfo or "no info"
		}
		level = level or 4

		MCodeMgr:mlogSLS(moduleName, JSON:encode(jsonObj), level)
	end,
	logReport = function (self, moduleName, e_name, jsonInfo, level)
		local jsonObj = {
			module_p = "lua",
			e_name = e_name,
			info = jsonInfo or "no info"
		}
		level = level or 3

		MCodeMgr:mlogSLS(moduleName, JSON:encode(jsonObj), level)
	end
}
