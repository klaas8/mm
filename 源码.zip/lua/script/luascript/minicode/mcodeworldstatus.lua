MCodeWorldStatus = {
	teamWorkers = {},
	playerBeginLogin = function (self)
		MiniCodeUtils:Log("zuoyouStatus******playerBeginLogin: 开始登录")

		if MCodeManager then
			MCodeManager.loginSuccessed = false

			MCodeManager:processLoading({
				process = 90,
				type = "login"
			})
		end
	end,
	playerLoginSuccess = function (self)
		MiniCodeUtils:Log("zuoyouStatus******playerLoginSuccess: 登录成功", MCodeManager.loginSuccessed)
		MCodeManager:notifyLoginSuccess()
	end,
	beginEnterWorld = function (self, mapId, toolVersion)
		MiniCodeUtils:Log("zuoyouStatus******beginEnterWorld: 开始加载地图", mapid, toolVersion)
		MCLoadMapHandler:beginEnterWorld({
			mapId = mapId,
			toolVersion = toolVersion
		})
	end,
	resgisterBlockStatisticEvent = function (self)
		self.switch = {
			[SceneEditorUIDef.common.switch_visual_code] = function (eventName, param)
				threadpool:work(function ()
					threadpool:wait(0.1)

					local switch = {
						[VisualCodeDef.msg.SAVE_CUSTOM_VAR] = function (eventName, param)
							local nEventCount, nBlockCount = MiniCodeBlockStatistic()

							MiniCodeUtils:Log("zuoyouStatus******onMapLoaded nBlockCount event: ", nBlockCount)
							MCodeMgr:addJmiJson(JSON:encode({
								CurBlockCount = tostring(nBlockCount)
							}))
							MCodeMgr:saveJmiToFile()
							MCodeMgr:syncJMIToBackup()
						end
					}

					GetInst("VisualCodeMsgHandler"):regByEventTab(switch)
				end)
			end
		}

		GetInst("SceneEditorMsgHandler"):regByEventTab(self.switch)
	end,
	prepareForJMIStorage = function (self)
		local info = MsgApi.screenShot()

		MiniCodeUtils:Log("zuoyouStatus******onMapLoaded 2 thumbPath: ", info.thumbPath or "nothing")

		local nEventCount, nBlockCount = MiniCodeBlockStatistic()

		MCodeMgr:addJmiJson(JSON:encode({
			CurBlockCount = tostring(nBlockCount)
		}))
		MCodeMgr:saveJmiToFile()
		MCodeMgr:syncJMIToBackup()
	end
}

function MCodeWorldStatus:onMapLoaded(data)
	MiniCodeUtils:Log("zuoyouStatus******onMapLoaded: 地图加载完成", data)

	local sceneInfo = MCodeManager:getSceneInfo()

	if MCodeMgr:loadJmiJson() == false then
		if (sceneInfo.type == MCEnterMapType.createTerrain or sceneInfo.type == MCEnterMapType.programGameMap) and MCodeMgr:generateJmiFromWDesc(AccountManager:getCurWorldId(), AccountManager:getUin(), AccountManager:getNickName() .. "的作品", 0) and MCodeMgr:loadJmiJson() then
			-- Nothing
		elseif data.toolVersion == 2 then
			MsgApi.mapLoadedFail({
				msg = "进入地图失败【JMI缺失】",
				type = 2,
				sceneInfo = sceneInfo
			})

			return
		end
	end

	MCLoadMapHandler:onMapLoaded(data)
	MCCourseHandler:onMapLoaded(data)

	if sceneInfo.type == MCEnterMapType.templateEnterExampleMCode or sceneInfo.type == MCEnterMapType.adaptTemplate or sceneInfo.type == MCEnterMapType.programGameMap or sceneInfo.type == MCEnterMapType.createTerrain or sceneInfo.type == MCEnterMapType.changeToCreateModel or sceneInfo.type == MCEnterMapType.challengeLevel or sceneInfo.newType and sceneInfo.newType == MCEnterMapType.play2EditInlite and sceneInfo.type == MCEnterMapType.workshopEnterMap or sceneInfo.type == MCEnterMapType.createLiteRoom then
		threadpool:work(function ()
			MCodeWorldStatus:prepareForJMIStorage(data)
			MCodeWorldStatus:resgisterBlockStatisticEvent()
		end)
	elseif sceneInfo.type == MCEnterMapType.enterLocalBackup then
		MCodeWorldStatus:resgisterBlockStatisticEvent()
	end
end

function MCodeWorldStatus:ToggleGameMode(newModeIsRun)
	MiniCodeUtils:Log("zuoyouStatus******ToggleGameMode#### newModeIsRun: ", newModeIsRun)

	if newModeIsRun then
		MiniCodeUtils:Log("zuoyouStatus******ToggleGameMode: 玩法模式")
		MCLoadMapHandler:onWorldModeChanged({
			liteMode = 5
		})
		MCCourseHandler:onModeChanged(5)
	else
		MiniCodeUtils:Log("zuoyouStatus******ToggleGameMode: 编辑模式")
		MCLoadMapHandler:onWorldModeChanged({
			liteMode = 4
		})
		MCCourseHandler:onModeChanged(4)
	end

	GetInst("ScreenShotInterface"):CheckScreenStatus()
end

function MCodeWorldStatus:onPlayerDie()
	MiniCodeUtils:Log("zuoyouStatus******onPlayerDie: 玩家死亡")
end

function MCodeWorldStatus:onPlayerRevive()
	MiniCodeUtils:Log("zuoyouStatus******onPlayerRevive: 玩家复活")
	MCCourseHandler:onPlayerRevive()
end

function MCodeWorldStatus:onPlayerSuccess()
	MiniCodeUtils:Log("zuoyouStatus******onPlayerSuccess: 玩家胜利")
end

function MCodeWorldStatus:onPlayerFail()
	MiniCodeUtils:Log("zuoyouStatus******onPlayerFail: 玩家失败")
end

function MCodeWorldStatus:onBattleFrameClick()
	MiniCodeUtils:Log("zuoyouStatus******onBattleFrameClick: 玩家游戏结算，点击离开", UGCModeMgr and UGCModeMgr:IsUGCMode())

	local sceneInfo = MCodeManager:getSceneInfo()

	if sceneInfo.type == MCEnterMapType.workshopEnterMap and sceneInfo.newType ~= MCEnterMapType.play2EditInlite then
		MiniCodeApi:quitWorld(true, nil, true, nil, {})

		return
	end

	if UGCModeMgr and UGCModeMgr:IsUGCMode() then
		MCodeMgr:doAction(-1, JSON:encode({
			"changeGameMode",
			5
		}), 1)
	else
		MiniCodeApi:quitWorld(true, nil, true, nil, {})
	end
end

function MCodeWorldStatus:exitWorld(data)
	if self.switch then
		GetInst("VisualCodeMsgHandler"):unregByEventTab(self.switch)
	end

	DataReport:reportEditDuration()
	MiniCodeUtils:Log("zuoyouStatus******exitWorld: 退出地图", data)
	MCCourseHandler:onQuitMap()
	MCodeMgr:doAction(-1, JSON:encode({
		"setUndoOperationSwitch",
		false
	}), 1)

	if GetInst("MainInterface") then
		GetInst("MainInterface"):Reset()
	end

	self:RoomHostScreenShotStop()
end

function MCodeWorldStatus:onRoleEnterRoom(uin, nickname)
	MiniCodeUtils:Log("zuoyouStatus******onRoleEnterRoom: 主机收到玩家进入：", uin, nickname)
	MCodeWorldStatus:onWorkersJoinWorld(uin, nickname)
	DataReport:reportRoleEnterRoom(uin)
end

function MCodeWorldStatus:onRoleExitRoom(uin)
	MiniCodeUtils:Log("zuoyouStatus******onRoleExitRoom: 主机收到玩家退出：", uin)
	MCodeWorldStatus:onWorkersExitWorld(uin)
end

function MCodeWorldStatus:onRoleHeartBeatTimeout(uin)
	MiniCodeUtils:Log("zuoyouStatus******onRoleExitRoom: 主机收到玩家心跳超时，异常退出：", uin)
	MCodeWorldStatus:onWorkersExitWorld(uin)
end

function _G.OnRoleEnterRoom(uin, nickname)
	MCodeWorldStatus:onRoleEnterRoom(uin, nickname)
end

function _G.OnRoleExitRoom(uin)
	MCodeWorldStatus:onRoleExitRoom(uin)
end

function _G.OnRoleHeartBeatTimeout(uin)
	MCodeWorldStatus:onRoleHeartBeatTimeout(uin)
end

function MCodeWorldStatus:RoomHostScreenShotStart()
	local sceneInfo = MCodeManager:getSceneInfo()

	if not sceneInfo then
		return
	end

	if sceneInfo.type ~= MCEnterMapType.createLiteRoom then
		return
	end

	local worldInfo = AccountManager:getCurWorldDesc()

	if not worldInfo then
		return
	end

	local curMapId = worldInfo.worldid

	local function intervalFunc()
		if not ClientCurGame then
			GetInst("MiniUIScheduler"):unreg(self.roomHostScreenShotScheduler)

			self.roomHostScreenShotScheduler = nil

			return
		end

		local sceneInfo2 = MCodeManager:getSceneInfo()

		if not sceneInfo2 then
			GetInst("MiniUIScheduler"):unreg(self.roomHostScreenShotScheduler)

			self.roomHostScreenShotScheduler = nil

			return
		end

		if sceneInfo2.type ~= MCEnterMapType.createLiteRoom then
			GetInst("MiniUIScheduler"):unreg(self.roomHostScreenShotScheduler)

			self.roomHostScreenShotScheduler = nil

			return
		end

		local worldInfo2 = AccountManager:getCurWorldDesc()

		if not worldInfo2 or worldInfo2.worldid ~= curMapId then
			GetInst("MiniUIScheduler"):unreg(self.roomHostScreenShotScheduler)

			self.roomHostScreenShotScheduler = nil

			return
		end

		threadpool:work(function ()
			local screenShotData = MsgApi.screenShot({
				copyToBackupPath = false
			})

			MiniCodeUtils:Log("pyf test MCodeWorldStatus:RoomHostScreenShotStart screenShotData ", screenShotData)

			if not screenShotData or not screenShotData.thumbPath then
				return
			end

			local ret, coverUrl = nil
			ret, coverUrl = MCodeUploadMgr:uploadMinicodeCloud("image", "png", "uploadCover")

			MiniCodeUtils:Log("pyf test MCodeWorldStatus:RoomHostScreenShotStart uploadMinicodeCloud ", ret, coverUrl)

			if ret < 0 then
				return
			end

			self.roomHostScreenShotUrl = coverUrl

			local function callBack(str)
				MiniCodeUtils:Log("pyf test RoomHostScreenShotStart roomCoverUpdate ret str = ", str)
			end

			MCNetworkApi:roomCoverUpdate(tostring(ClientCurGame:getHostUin()), coverUrl, callBack)
			MCodeWorldStatus:updateWorkerCodeTime(true)
		end)
	end

	self.roomHostScreenShotScheduler = GetInst("MiniUIScheduler"):regGloabel(function ()
		intervalFunc()
	end, 300, nil, 0, false)

	intervalFunc()
end

function MCodeWorldStatus:RoomHostScreenShotStop()
	if self.roomHostScreenShotScheduler then
		MiniCodeUtils:Log("pyf test RoomHostScreenShotStart RoomHostScreenShotStop ", self.roomHostScreenShotScheduler)
		GetInst("MiniUIScheduler"):unreg(self.roomHostScreenShotScheduler)

		self.roomHostScreenShotScheduler = nil
		self.roomHostScreenShotUrl = nil
	end
end

function MCodeWorldStatus:getTeamWorkers()
	return self.teamWorkers
end

function MCodeWorldStatus:onWorkersJoinWorld(uin, nickName)
	local jmiString = MCodeMgr:getJmiJson()
	local ok, json_data = pcall(JSON.decode, JSON, jmiString)
	local oldWorker = nil

	if ok and type(json_data) == "table" and json_data.teamWorkers and type(json_data.teamWorkers) == "table" then
		for i = 1, #json_data.teamWorkers do
			if json_data.teamWorkers[i].authorId == uin then
				oldWorker = json_data.teamWorkers[i]
			end
		end
	end

	local now_ = os.time()

	if ok and type(json_data) == "table" then
		if json_data.teamWorkers == nil then
			json_data.teamWorkers = {}
		end

		if oldWorker == nil then
			json_data.teamWorkers[#json_data.teamWorkers + 1] = {
				codeTime = 0,
				authorId = uin,
				nickName = nickName
			}

			MCodeMgr:addJmiJson(JSON:encode({
				teamWorkers = json_data.teamWorkers
			}))
			MCodeMgr:saveJmiToFile()
			MCodeMgr:syncJMIToBackup()
		elseif oldWorker.codeTime and type(oldWorker.codeTime) == "number" then
			now_ = now_ - oldWorker.codeTime
		end
	end

	self.teamWorkers[uin] = now_

	MiniCodeUtils:Log("zuoyouStatus******onWorkersJoinWorld 当前时间", now_, type(now_), self.teamWorkers)
end

function MCodeWorldStatus:onWorkersExitWorld(uin)
	if self.teamWorkers[uin] then
		self.teamWorkers[uin] = nil

		MiniCodeUtils:Log("zuoyouStatus******onRoleExitRoom ", self.teamWorkers or "")
	end
end

function MCodeWorldStatus:updateWorkerCodeTime(needSave)
	MiniCodeUtils:Log("zuoyouStatus******updateWorkerCodeTime1")

	local jmiString = MCodeMgr:getJmiJson()
	local ok, json_data = pcall(JSON.decode, JSON, jmiString)
	local teamWorkers = nil

	if ok and type(json_data) == "table" and json_data.teamWorkers and type(json_data.teamWorkers) == "table" then
		teamWorkers = json_data.teamWorkers
	end

	MiniCodeUtils:Log("zuoyouStatus******updateWorkerCodeTime2")

	local workerMap = MCodeWorldStatus:getTeamWorkers()
	local now_ = os.time()

	MiniCodeUtils:Log("zuoyouStatus******update codetime ", teamWorkers, " workerMap", workerMap or "")

	if teamWorkers and #teamWorkers > 0 and workerMap then
		for key, value in pairs(teamWorkers) do
			if value.authorId and workerMap[value.authorId] then
				teamWorkers[key].codeTime = now_ - workerMap[value.authorId]
			end
		end

		for i = 1, #teamWorkers do
			if teamWorkers[i] and teamWorkers[i].authorId and workerMap[teamWorkers[i].authorId] then
				teamWorkers[i].codeTime = now_ - workerMap[teamWorkers[i].authorId]

				MiniCodeUtils:Log("zuoyouStatus******update time ", now_ or "", workerMap[teamWorkers[i].authorId] or "")
			end
		end

		MiniCodeUtils:Log("zuoyouStatus******updateWorkerCodeTime3")

		if #teamWorkers > 0 then
			MCodeMgr:addJmiJson(JSON:encode({
				teamWorkers = teamWorkers
			}))

			if needSave then
				MCodeMgr:saveJmiToFile()
			end

			MiniCodeUtils:Log("zuoyouStatus******update time save Jmi")
		end
	end
end
