AiParameterFoods = {
	{
		EditType = 1,
		EditTypeStringId = 4515,
		t = {
			241,
			12503,
			12500,
			11403,
			229,
			236,
			11400,
			11402,
			11401,
			12508,
			239,
			230,
			12522,
			12530,
			12516,
			12518,
			12527,
			11326,
			12520,
			11302,
			12526,
			12524,
			12581,
			12521,
			12531,
			12512,
			12541,
			12525,
			12543,
			12517,
			12519,
			12523,
			11223,
			12502,
			12507,
			12515,
			12546,
			12547,
			12548,
			12540,
			12545,
			12544,
			12510,
			12542,
			12501,
			12505,
			12577,
			12509,
			830,
			831,
			12498,
			12499,
			12549,
			12550,
			12551,
			12552,
			12553,
			12554,
			12555,
			12556,
			12557,
			12558,
			12559,
			12560,
			12561,
			12562,
			12563
		}
	}
}
AiParameterActors = {
	{
		EditType = 1,
		EditTypeStringId = 3932,
		t = {
			3813,
			3811,
			3814,
			3812,
			3810,
			3817,
			3818,
			3819,
			3820,
			3400,
			3402,
			3403,
			3401,
			3407,
			3409,
			3411,
			3412,
			3413,
			3414,
			3418,
			3419,
			3421,
			3422,
			3423,
			3424,
			3600,
			3602,
			3604,
			3605,
			3606,
			3607,
			3608,
			3612,
			3613,
			3614,
			3615,
			3616,
			3617,
			3618,
			3619,
			3110,
			3111,
			3112,
			3103,
			3124,
			3125,
			3126,
			3121,
			3102,
			3101,
			3105,
			3107,
			3109,
			3501,
			3130,
			3131
		}
	}
}
AiParameterBlocks = {
	{
		EditType = 1,
		EditTypeStringId = 6325,
		t = {
			212,
			213,
			214,
			215,
			216,
			217,
			256,
			259,
			224,
			226,
			227,
			228,
			229,
			230,
			232,
			234,
			236,
			238,
			239,
			241,
			242,
			243,
			251,
			253,
			269,
			300,
			301,
			302,
			303,
			304,
			305,
			306,
			307,
			308,
			309,
			310,
			311,
			312,
			313,
			263,
			431,
			432,
			433,
			434,
			435,
			436,
			437,
			438,
			439,
			440,
			441,
			442,
			443,
			444
		}
	},
	{
		EditType = 2,
		EditTypeStringId = 6326,
		t = {
			711,
			712,
			724,
			715,
			716,
			731,
			812,
			814,
			854,
			855,
			856,
			857,
			858,
			859,
			860,
			696,
			690,
			691,
			692,
			693,
			694,
			695,
			697,
			698,
			699,
			717,
			817,
			834,
			725,
			816,
			1019,
			1020,
			830,
			822,
			813,
			737,
			738,
			739,
			802,
			968,
			973,
			978,
			800,
			824,
			828,
			801,
			555,
			556,
			557,
			466,
			467,
			468,
			1047,
			1048,
			1101,
			1111,
			1143,
			1144
		}
	},
	{
		EditType = 3,
		EditTypeStringId = 6327,
		t = {
			8,
			9,
			100,
			101,
			103,
			104,
			105,
			106,
			107,
			108,
			109,
			112,
			114,
			115,
			116,
			117,
			118,
			119,
			122,
			123,
			124,
			125,
			126,
			127,
			132,
			133,
			134,
			135,
			136,
			137,
			200,
			201,
			202,
			203,
			204,
			205,
			206,
			207,
			208,
			209,
			210,
			211,
			254,
			257,
			258,
			260,
			261,
			264,
			265,
			266,
			267,
			268,
			270,
			400,
			401,
			402,
			403,
			404,
			405,
			406,
			407,
			408,
			409,
			410,
			411,
			412,
			413,
			414,
			415,
			416,
			417,
			418,
			419,
			420,
			421,
			422,
			423,
			424,
			425,
			426,
			427,
			428,
			429,
			430,
			445,
			446,
			447,
			448,
			449,
			450,
			558,
			561,
			562,
			563,
			600,
			616,
			649,
			632,
			666
		}
	}
}
AiParameterContainer = {
	{
		EditType = 1,
		EditTypeStringId = 4685,
		t = {
			801,
			717,
			839,
			1032,
			969,
			974,
			979,
			1180,
			1181
		}
	}
}
AiParameterTargetBlock = {
	{
		EditType = 1,
		EditTypeStringId = 4685,
		t = {
			3,
			100,
			101,
			102,
			103,
			106,
			117,
			229,
			236,
			241
		}
	}
}
AiParameterUseItem = {
	{
		EditType = 1,
		EditTypeStringId = 4685,
		t = {
			11031,
			11032,
			11033,
			11034,
			11035,
			11021,
			11022,
			11023,
			11024,
			11025,
			236,
			241,
			11400,
			11401,
			11402,
			11404,
			212,
			213,
			214,
			215,
			216,
			217,
			253,
			259,
			431,
			432,
			433,
			434,
			435,
			436,
			437,
			438,
			439,
			440,
			441,
			442,
			443,
			444
		}
	}
}

local function TableDeepCopy(obj)
	local InTable = {}

	local function Func(obj)
		if type(obj) ~= "table" then
			return obj
		end

		local NewTable = {}
		InTable[obj] = NewTable

		for k, v in pairs(obj) do
			NewTable[Func(k)] = Func(v)
		end

		return setmetatable(NewTable, getmetatable(obj))
	end

	return Func(obj)
end

local function GetMonsterDef(id)
	if id == nil then
		return ""
	end

	return ModEditorMgr:getMonsterDefById(id) or DefMgr:getMonsterDef(id)
end

local function GetItemDef(id)
	if id == nil then
		return ""
	end

	return ModEditorMgr:getItemDefById(id) or ModEditorMgr:getBlockItemDefById(id) or DefMgr:getItemDef(id)
end

local function GetBlockDef(id)
	if id == nil then
		return ""
	end

	return ModEditorMgr:getBlockItemDefById(id) or DefMgr:getBlockDef(id)
end

local function GetFoodDef(id)
	if id == nil then
		return ""
	end

	return ModEditorMgr:getFoodDefById(id) or DefMgr:getFoodDef(id)
end

function GetCraftDef(id)
	if id == nil then
		return ""
	end

	return ModEditorMgr:getCraftingDefById(id) or DefMgr:getCraftingDef(id)
end

OpenAiTable = {
	TempForeignIds = {},
	GetOpenFeature2Class = function (class)
		local t = {}

		for k, v in pairs(OpenAiTable) do
			if type(v) == "table" and v.Class == class then
				t[k] = TableDeepCopy(v)
			end
		end

		return t
	end,
	GetSortOpenFeature2Class = function (class)
		local t = OpenAiTable.GetOpenFeature2Class(class)
		local t_sortedKey = OpenAiTable.SortbyOrderId(t)
		local t_sortOpenAI = {}

		for i = 1, #t_sortedKey do
			local key = t_sortedKey[i]

			table.insert(t_sortOpenAI, t[key])

			t_sortOpenAI[i].Name = key
		end

		return t_sortOpenAI
	end,
	SortbyOrderId = function (ai_table)
		local key_table = {}
		local sorted_table = {}

		for k, v in pairs(ai_table) do
			table.insert(key_table, {
				key = k,
				order = v.OrderId
			})
		end

		table.sort(key_table, function (a, b)
			return a.order < b.order
		end)

		for _, item in pairs(key_table) do
			table.insert(sorted_table, item.key)
		end

		return sorted_table
	end,
	MakeDefaultFeatureItem = function (feature_ai)
		local t = {}

		if type(feature_ai) ~= "table" or feature_ai.Name == nil or feature_ai.Parameters == nil then
			return t
		end

		local param = feature_ai.Parameters

		for i = 1, #param do
			param[i].Save(t, param[i].Name, param[i].Default)
		end

		t.name = feature_ai.Name

		return t
	end,
	showConfigPremise = {},
	ChangeConfigShowPremise = function (type, premise)
		if type == "add" then
			table.insert(OpenAiTable.showConfigPremise, premise)
		elseif type == "remove" then
			for i = 1, #OpenAiTable.showConfigPremise do
				if premise == OpenAiTable.showConfigPremise[i] then
					table.remove(OpenAiTable.showConfigPremise, i)

					return
				end
			end
		end
	end,
	InShowPremise = function (premise)
		for i = 1, #OpenAiTable.showConfigPremise do
			if premise == OpenAiTable.showConfigPremise[i] then
				return true
			end
		end

		return false
	end,
	Init = function (self)
		self.showConfigPremise = {}
	end,
	go_ceiling = {
		OrderId = 1,
		Icon = 1001,
		NameStringId = 6221,
		Class = 1,
		Parameters = {
			prob = 1,
			name = "go_ceiling",
			priority = 1
		}
	},
	flee_sun = {
		OrderId = 2,
		Icon = 1001,
		NameStringId = 6222,
		Class = 1,
		Parameters = {
			priority = 3,
			name = "flee_sun",
			speed = 1
		}
	},
	restrict_sun = {
		OrderId = 3,
		Icon = 1001,
		NameStringId = 6223,
		Class = 1,
		Parameters = {
			priority = 2,
			name = "restrict_sun"
		}
	},
	swimming = {
		OrderId = 4,
		Icon = 1001,
		NameStringId = 6224,
		Class = 1,
		Parameters = {
			priority = 1,
			name = "swimming"
		}
	},
	avoid_water = {
		OrderId = 5,
		Icon = 1001,
		NameStringId = 6225,
		Class = 1,
		Parameters = {
			name = "avoid_water"
		}
	},
	can_fly = {
		OrderId = 6,
		Icon = 1001,
		NameStringId = 6226,
		Class = 1,
		Parameters = {
			name = "can_fly"
		}
	},
	can_pass_closed_wooden_doors = {
		OrderId = 7,
		Icon = 1001,
		NameStringId = 6227,
		Class = 1,
		Parameters = {
			name = "can_pass_closed_wooden_doors"
		}
	},
	target_nearest = {
		OrderId = 1,
		Icon = 1001,
		NameStringId = 3668,
		Class = 4,
		Parameters = {
			priority = 2,
			name = "target_nearest",
			minhp = 0,
			brightness = 0,
			check_sight = true,
			chance = 0
		}
	},
	target_hurtee = {
		OrderId = 2,
		Icon = 1001,
		NameStringId = 6246,
		Class = 4,
		Parameters = {
			priority = 2,
			name = "target_hurtee",
			help = false
		}
	},
	attack = {
		AttackType = 0,
		OrderId = 1,
		Icon = 1001,
		NameStringId = 4502,
		Class = 5,
		Parameters = {
			priority = 2,
			name = "attack",
			move_speed = 1,
			will_trace = false,
			attack_type = 0
		}
	},
	projectile_attack = {
		AttackType = 1,
		OrderId = 2,
		Icon = 1001,
		NameStringId = 4503,
		Class = 5,
		Parameters = {
			name = "projectile_attack",
			priority = 2,
			count = 1,
			buffid = 0,
			power = 0.8,
			atkrange = 1500,
			min_atktime = 20,
			max_atktime = 60,
			speed = 1
		}
	},
	boom_atk = {
		AttackType = 2,
		OrderId = 3,
		Icon = 1001,
		NameStringId = 4504,
		Class = 5,
		Parameters = {
			priority = 2,
			name = "boom_atk"
		}
	},
	ceiling_atk = {
		OrderId = 8,
		Icon = 1001,
		NameStringId = 6228,
		Class = 2,
		Parameters = {
			priority = 0,
			name = "ceiling_atk",
			attach_timer = 200
		}
	},
	leap_at_target = {
		OrderId = 9,
		Icon = 1001,
		NameStringId = 6229,
		Class = 2,
		Parameters = {
			min_range = 100,
			priority = 2,
			name = "leap_at_target",
			motion_y = 40,
			max_range = 600
		}
	},
	invulnerable_prob = {
		OrderId = 10,
		Icon = 1001,
		NameStringId = 6230,
		Class = 2,
		Parameters = {
			prob = 3,
			name = "invulnerable_prob"
		}
	},
	immune_fire = {
		OrderId = 11,
		Icon = 1001,
		NameStringId = 6231,
		Class = 2,
		Parameters = {
			type = 2,
			name = "immune_fire"
		}
	},
	path_hide = {
		OrderId = 12,
		Icon = 1001,
		NameStringId = 6232,
		Class = 2,
		Parameters = {
			type = 1,
			name = "path_hide"
		}
	},
	sun_hurt = {
		OrderId = 13,
		Icon = 1001,
		NameStringId = 6233,
		Class = 2,
		Parameters = {
			name = "sun_hurt"
		}
	},
	hold_monster = {
		OrderId = 14,
		DescStringId = 6286,
		Icon = 3001,
		NameStringId = 6234,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "monster_id",
				Type = "selector",
				NameStringId = 6248,
				Default = 3102,
				SelectClass = "monster",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getMonsterDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getActorKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 2.5,
				Name = "prob",
				Step = 0.5,
				NameStringId = 6249,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local monsterid = ai_itemdata.monster_id

			if monsterid == nil then
				monsterid = OpenAiTable.hold_monster.Parameters[2].Default
			end

			local def = GetMonsterDef(monsterid)
			local param = OpenAiTable.hold_monster.Parameters[3]

			return string.format(GetS(stringid), param.GetDesc(param.GetUiData(ai_itemdata.prob)), def.Name)
		end
	},
	love_block = {
		OrderId = 15,
		DescStringId = 6287,
		Icon = 3002,
		NameStringId = 6235,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "block_id",
				Type = "selector",
				NameStringId = 6250,
				Default = 812,
				SelectClass = "block",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getBlockDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getBlockKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 50,
				Name = "prob",
				Step = 0.5,
				NameStringId = 6251,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 6252,
				Type = "slider",
				Max = 2,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetItemDef(ai_itemdata.block_id)
			def = def or GetItemDef(OpenAiTable.love_block.Parameters[2].Default)
			local param = OpenAiTable.love_block.Parameters[3]

			return string.format(GetS(stringid), def.Name, param.GetDesc(param.GetUiData(ai_itemdata.prob)))
		end
	},
	target_following_player = {
		OrderId = 16,
		DescStringId = 6288,
		Icon = 3003,
		NameStringId = 6236,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 3,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 50,
				Name = "prob",
				Step = 0.5,
				NameStringId = 6253,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Name = "check_sight",
				Type = "option",
				NameStringId = 6254,
				Default = false,
				Options = {
					{
						Name_StringID = 6280,
						Val = true,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					},
					{
						Name_StringID = 6281,
						Val = false,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					}
				},
				GetOption = function (val, options)
					if options then
						for k, v in pairs(options) do
							if v.Val == val then
								return v
							end
						end
					end

					return nil
				end,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 6255,
				Type = "slider",
				Max = 2,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			return string.format(GetS(stringid))
		end
	},
	beg = {
		OrderId = 17,
		DescStringId = 6289,
		Icon = 3004,
		NameStringId = 6237,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 8,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "id",
				Type = "selector",
				NameStringId = 6256,
				Default = 12500,
				SelectClass = "food",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getItemDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 20,
				Name = "dist",
				Step = 1,
				NameStringId = 6257,
				Type = "slider",
				Max = 30,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetItemDef(ai_itemdata.id)
			def = def or GetItemDef(OpenAiTable.beg.Parameters[2].Default)

			return string.format(GetS(stringid), def.Name)
		end
	},
	closest_dance = {
		OrderId = 18,
		DescStringId = 6290,
		Icon = 3005,
		NameStringId = 6238,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 20,
				Name = "dist",
				Step = 1,
				NameStringId = 6258,
				Type = "slider",
				Max = 30,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Default = 3,
				Name = "number",
				Step = 1,
				NameStringId = 6259,
				Type = "slider",
				Max = 20,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(6282))
				end
			},
			{
				Name = "speed",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 500,
				Name = "cd_time",
				Step = 10,
				NameStringId = 6260,
				Type = "slider",
				Max = 1000,
				Min = 10,
				Save = function (t, key, val)
					t[key] = val * 20
				end,
				GetUiData = function (val)
					return val / 20
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(6283))
				end
			},
			{
				Name = "width",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 5,
				Name = "dance_time",
				Step = 1,
				NameStringId = 6261,
				Type = "slider",
				Max = 100,
				Min = 5,
				Save = function (t, key, val)
					t[key] = val * 20
				end,
				GetUiData = function (val)
					return val / 20
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(6283))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			return string.format(GetS(stringid), OpenAiTable.closest_dance.Parameters[2].GetUiData(ai_itemdata.dist), ai_itemdata.number)
		end
	},
	kick_away = {
		OrderId = 19,
		DescStringId = 6291,
		Icon = 3006,
		NameStringId = 6239,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 3,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "monster_id",
				Type = "selector",
				NameStringId = 6262,
				Default = 3109,
				SelectClass = "monster",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getMonsterDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getActorKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 50,
				Name = "prob",
				Step = 0.5,
				NameStringId = 6263,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 5,
				Name = "force",
				Step = 1,
				NameStringId = 6264,
				Type = "slider",
				Max = 20,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%d", val)
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetMonsterDef(ai_itemdata.monster_id)
			def = def or GetMonsterDef(OpenAiTable.kick_away.Parameters[2].Default)
			local param = OpenAiTable.kick_away.Parameters[3]

			return string.format(GetS(stringid), param.GetDesc(param.GetUiData(ai_itemdata.prob)), def.Name)
		end
	},
	make_trouble = {
		OrderId = 20,
		DescStringId = 6292,
		Icon = 3007,
		NameStringId = 6240,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 3,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "block_id",
				Type = "selector",
				NameStringId = 6265,
				Default = 812,
				SelectClass = "block",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getBlockDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getBlockKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 50,
				Name = "prob",
				Step = 0.5,
				NameStringId = 6266,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 6267,
				Type = "slider",
				Max = 2,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 20,
				Name = "search_block_dist",
				Step = 1,
				NameStringId = 6268,
				Type = "slider",
				Max = 30,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "is_hit",
				Type = "option",
				NameStringId = 6269,
				Default = false,
				Options = {
					{
						Name_StringID = 6284,
						Val = true,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					},
					{
						Name_StringID = 6285,
						Val = false,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					}
				},
				GetOption = function (val, options)
					if options then
						for k, v in pairs(options) do
							if v.Val == val then
								return v
							end
						end
					end

					return nil
				end,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetBlockDef(ai_itemdata.block_id)
			def = def or GetBlockDef(OpenAiTable.make_trouble.Parameters[2].Default)
			local param6 = OpenAiTable.make_trouble.Parameters[6]
			local param3 = OpenAiTable.make_trouble.Parameters[3]

			return string.format(GetS(stringid), param3.GetDesc(param3.GetUiData(ai_itemdata.prob)), GetS(param6.GetOption(ai_itemdata.is_hit, param6.Options).Name_StringID), OpenAiTable.make_trouble.Parameters[5].GetUiData(ai_itemdata.search_block_dist), def.Name)
		end
	},
	panic = {
		OrderId = 21,
		DescStringId = 6293,
		Icon = 3008,
		NameStringId = 6241,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 6298,
				Type = "slider",
				Max = 2,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 50,
				Name = "maxhp",
				Step = 1,
				NameStringId = 6270,
				Type = "slider",
				Max = 100,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%d%%", val)
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local param3 = OpenAiTable.panic.Parameters[3]
			local val = ai_itemdata.maxhp

			if val == nil then
				val = param3.Default
			end

			return string.format(GetS(stringid), param3.GetDesc(val))
		end
	},
	sleep = {
		OrderId = 22,
		DescStringId = 6294,
		Icon = 3009,
		NameStringId = 6242,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 5,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 50,
				Name = "period",
				Step = 0.5,
				NameStringId = 6271,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%s%%", val)
				end
			},
			{
				Default = 200,
				Name = "sleep_ticks",
				Step = 1,
				NameStringId = 6272,
				Type = "slider",
				Max = 100,
				Min = 5,
				Save = function (t, key, val)
					t[key] = val * 20
				end,
				GetUiData = function (val)
					return val / 20
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(6283))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local param = OpenAiTable.sleep.Parameters[2]

			return string.format(GetS(stringid), param.GetDesc(param.GetUiData(ai_itemdata.period)))
		end
	},
	target_specific_entity = {
		OrderId = 23,
		DescStringId = 6295,
		Icon = 3010,
		NameStringId = 6243,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "atkeeid",
				Type = "selector",
				NameStringId = 6273,
				Default = 3400,
				SelectClass = "monster",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getMonsterDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getActorKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 2,
				Name = "chance",
				Step = 0.5,
				NameStringId = 6274,
				Type = "slider",
				Max = 100,
				Min = 0.5,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetMonsterDef(ai_itemdata.atkeeid)
			def = def or GetMonsterDef(OpenAiTable.target_specific_entity.Parameters[2].Default)
			local param = OpenAiTable.target_specific_entity.Parameters[3]

			return string.format(GetS(stringid), param.GetDesc(param.GetUiData(ai_itemdata.chance)), def.Name)
		end
	},
	tempt = {
		OrderId = 24,
		DescStringId = 6296,
		Icon = 3011,
		NameStringId = 6244,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 3,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 6275,
				Type = "slider",
				Max = 2,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Name = "id",
				Type = "selector",
				NameStringId = 6276,
				Default = 12500,
				SelectClass = "food",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getItemDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "scared",
				Type = "option",
				NameStringId = 6277,
				Default = false,
				Options = {
					{
						Name_StringID = 6280,
						Val = true,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					},
					{
						Name_StringID = 6281,
						Val = false,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					}
				},
				GetOption = function (val, options)
					if options then
						for k, v in pairs(options) do
							if v.Val == val then
								return v
							end
						end
					end

					return nil
				end,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetItemDef(ai_itemdata.id)
			def = def or GetItemDef(OpenAiTable.tempt.Parameters[3].Default)

			return string.format(GetS(stringid), def.Name)
		end
	},
	watch_closest = {
		OrderId = 25,
		DescStringId = 6297,
		Icon = 3012,
		NameStringId = 6245,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 6,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 20,
				Name = "dist",
				Step = 1,
				NameStringId = 6278,
				Type = "slider",
				Max = 30,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val and val / 100 or 0
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "prob",
				Type = "noneditable",
				Default = 50,
				Save = function (t, key, val)
					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					return 2000 / val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			return string.format(GetS(stringid), OpenAiTable.watch_closest.Parameters[2].GetUiData(ai_itemdata.dist))
		end
	},
	gather = {
		OrderId = 26,
		DescStringId = 4603,
		Icon = 3013,
		NameStringId = 4602,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 8,
				Name = "range",
				Step = 1,
				NameStringId = 4605,
				Type = "slider",
				Max = 24,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "block_id",
				Type = "selector",
				NameStringId = 4606,
				Default = 200,
				SelectClass = "block",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getBlockDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getBlockKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 4608,
				Type = "slider",
				Max = 5,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "hungry_expend",
				Step = 1,
				NameStringId = 4610,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "distance",
				Type = "noneditable",
				Default = 400,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			Log("LLDO_AI_ITEMDATA:")

			local def = GetItemDef(ai_itemdata.block_id)
			def = def or GetItemDef(OpenAiTable.gather.Parameters[4].Default)
			local t = OpenAiTable.gather.Parameters

			return string.format(GetS(stringid), t[7].GetUiData(ai_itemdata.hungry_check), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), def.Name)
		end
	},
	pick = {
		OrderId = 27,
		DescStringId = 4613,
		Icon = 3014,
		NameStringId = 4612,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 8,
				Name = "range",
				Step = 1,
				NameStringId = 4605,
				Type = "slider",
				Max = 24,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "item_id",
				Type = "selector",
				NameStringId = 4614,
				Default = 200,
				SelectClass = "ai_dropitem",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = GetItemDef(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 30,
				Name = "quantity",
				Step = 1,
				NameStringId = 4615,
				Type = "slider",
				Max = 640,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 4608,
				Type = "slider",
				Max = 5,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "hungry_expend",
				Step = 1,
				NameStringId = 4610,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "distance",
				Type = "noneditable",
				Default = 200,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetItemDef(ai_itemdata.item_id) or GetItemDef(200)
			def = def or GetItemDef(OpenAiTable.pick.Parameters[4].Default)
			local t = OpenAiTable.pick.Parameters

			return string.format(GetS(stringid), t[7].GetUiData(ai_itemdata.hungry_check), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), def.Name, t[5].GetUiData(ai_itemdata.quantity))
		end
	},
	store_item = {
		OrderId = 28,
		DescStringId = 4617,
		Icon = 3015,
		NameStringId = 4616,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 8,
				Name = "range",
				Step = 1,
				NameStringId = 4605,
				Type = "slider",
				Max = 24,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "item_id",
				Type = "selector",
				NameStringId = 4618,
				Default = 200,
				SelectClass = "ai_dropitem",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = GetItemDef(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "quantity",
				Step = 1,
				NameStringId = 4619,
				Type = "slider",
				Max = 640,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "container_id",
				Type = "selector",
				NameStringId = 4620,
				Default = 801,
				SelectClass = "container",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = GetItemDef(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 4608,
				Type = "slider",
				Max = 5,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "hungry_expend",
				Step = 1,
				NameStringId = 4610,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "distance",
				Type = "noneditable",
				Default = 200,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local item_def = GetItemDef(ai_itemdata.item_id) or GetItemDef(200)
			local container_def = GetItemDef(ai_itemdata.container_id) or GetItemDef(801)
			local t = OpenAiTable.store_item.Parameters

			return string.format(GetS(stringid), t[8].GetUiData(ai_itemdata.hungry_check), item_def.Name, t[5].GetUiData(ai_itemdata.quantity), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), container_def.Name)
		end
	},
	plant = {
		OrderId = 29,
		DescStringId = 4627,
		Icon = 3021,
		NameStringId = 4626,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 8,
				Name = "range",
				Step = 1,
				NameStringId = 4605,
				Type = "slider",
				Max = 24,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "block_id",
				Type = "selector",
				NameStringId = 4628,
				Default = 100,
				SelectClass = "ai_targetblock",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getBlockDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getBlockKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "item_id",
				Type = "selector",
				NameStringId = 4629,
				Default = 11031,
				SelectClass = "ai_useitem",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = GetItemDef(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 4608,
				Type = "slider",
				Max = 5,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "hungry_expend",
				Step = 1,
				NameStringId = 4610,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "distance",
				Type = "noneditable",
				Default = 200,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local block_def = GetItemDef(ai_itemdata.block_id) or GetItemDef(100)
			local item_def = GetItemDef(ai_itemdata.item_id) or GetItemDef(11031)
			local t = OpenAiTable.plant.Parameters

			return string.format(GetS(stringid), t[7].GetUiData(ai_itemdata.hungry_check), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), block_def.Name, item_def.Name)
		end
	},
	get_item = {
		OrderId = 31,
		DescStringId = 4639,
		Icon = 3016,
		NameStringId = 4638,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 8,
				Name = "range",
				Step = 1,
				NameStringId = 4605,
				Type = "slider",
				Max = 24,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Name = "container_id",
				Type = "selector",
				NameStringId = 4640,
				Default = 801,
				SelectClass = "container",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = GetItemDef(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "item_id",
				Type = "selector",
				NameStringId = 4641,
				Default = 200,
				SelectClass = "ai_dropitem",
				Save = function (t, key, val)
					local id = val

					if type(id) == number and USER_MOD_NEWID_BASE <= id then
						local paramDef = GetItemDef(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 10,
				Name = "quantity",
				Step = 1,
				NameStringId = 4619,
				Type = "slider",
				Max = 640,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 4608,
				Type = "slider",
				Max = 5,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "hungry_expend",
				Step = 1,
				NameStringId = 4610,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "container_type",
				Type = "noneditable",
				Default = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Name = "distance",
				Type = "noneditable",
				Default = 200,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local item_def = GetItemDef(ai_itemdata.item_id) or GetItemDef(200)
			local container_def = GetItemDef(ai_itemdata.container_id) or GetItemDef(801)
			local t = OpenAiTable.get_item.Parameters

			return string.format(GetS(stringid), t[8].GetUiData(ai_itemdata.hungry_check), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), container_def.Name, item_def.Name, t[6].GetUiData(ai_itemdata.quantity))
		end
	},
	compose_item = {
		OrderId = 32,
		DescStringId = 4644,
		Icon = 3017,
		NameStringId = 4643,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Name = "craft_id",
				Type = "selector",
				NameStringId = 4645,
				Default = 46,
				SelectClass = "craft",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getCraftingDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getCraftingKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 3,
				Name = "craft_time",
				Step = 0.1,
				NameStringId = 4646,
				Type = "slider",
				Max = 10,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6283))
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 0,
				Name = "hungry_expend",
				Step = 1,
				NameStringId = 4610,
				Type = "slider",
				Max = 200,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local craft_def = GetCraftDef(ai_itemdata.craft_id)

			if craft_def then
				local item_def = GetItemDef(craft_def.ResultID) or GetItemDef(101)
				local t = OpenAiTable.compose_item.Parameters

				return string.format(GetS(stringid), t[5].GetUiData(ai_itemdata.hungry_check), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), item_def.Name)
			end
		end
	},
	like_sleep = {
		OrderId = 33,
		DescStringId = 4649,
		Icon = 3018,
		NameStringId = 4648,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 8,
				Name = "range",
				Step = 1,
				NameStringId = 4605,
				Type = "slider",
				Max = 24,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val * 100
				end,
				GetUiData = function (val)
					return val / 100
				end,
				GetDesc = function (val)
					local stringId = nil

					if val >= 0 and val < 4 then
						stringId = 4814
					elseif val >= 4 and val < 10 then
						stringId = 4815
					elseif val >= 10 and val <= 30 then
						stringId = 4816
					end

					return string.format("%d%s", val, GetS(stringId))
				end
			},
			{
				Default = 20,
				Name = "what_time",
				Step = 1,
				NameStringId = 4650,
				Type = "slider",
				Max = 23,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(4653))
				end
			},
			{
				Default = 8,
				Name = "how_long",
				Step = 0.5,
				NameStringId = 4651,
				Type = "slider",
				Max = 24,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(4088))
				end
			},
			{
				Name = "sleep_blockid",
				Type = "selector",
				NameStringId = 4652,
				Default = 828,
				SelectClass = "block",
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getBlockDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getBlockKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 1,
				Name = "speed",
				Step = 0.1,
				NameStringId = 4608,
				Type = "slider",
				Max = 5,
				Min = 0.1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%.1f%s", val, GetS(6279))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local item_def = GetItemDef(ai_itemdata.craft_id)
			local t = OpenAiTable.like_sleep.Parameters

			return string.format(GetS(stringid), t[2].GetDesc(t[2].GetUiData(ai_itemdata.prob)), t[4].GetUiData(ai_itemdata.what_time), t[5].GetUiData(ai_itemdata.how_long))
		end
	},
	hungry = {
		OrderId = 35,
		DescStringId = 4655,
		Icon = 3019,
		NameStringId = 4654,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Default = 5,
				Name = "how_long",
				Step = 1,
				NameStringId = 4657,
				Type = "slider",
				Max = 60,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(6283))
				end
			},
			{
				Name = "onlyone_food",
				NameStringId = 4658,
				Type = "option",
				Default = true,
				Options = {
					{
						Name_StringID = 4501,
						Val = true,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					},
					{
						Name_StringID = 4500,
						Val = false,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					}
				},
				GetOption = function (val, options)
					if options then
						for k, v in pairs(options) do
							if v.Val == val then
								return v
							end
						end
					end

					return nil
				end,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				Func = function (type)
					OpenAiTable.ChangeConfigShowPremise(type, "need_food")
				end
			},
			{
				Name = "food_id",
				Type = "selector",
				NameStringId = 4660,
				Default = 12502,
				SelectClass = "food",
				CanShow = function ()
					return OpenAiTable.InShowPremise("need_food")
				end,
				Save = function (t, key, val)
					local id = val

					if USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getItemDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local t = OpenAiTable.hungry.Parameters

			return string.format(GetS(stringid), t[3].GetUiData(ai_itemdata.hungry_check))
		end
	},
	eat_food = {
		OrderId = 34,
		DescStringId = 4666,
		Icon = 3020,
		NameStringId = 4665,
		Class = 3,
		Parameters = {
			{
				Name = "priority",
				Type = "noneditable",
				Default = 2,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 100,
				Name = "prob",
				Step = 0.5,
				NameStringId = 4604,
				Type = "slider",
				Max = 100,
				Min = 0,
				Save = function (t, key, val)
					if val == 0 then
						t[key] = 0
					end

					t[key] = 2000 / val
				end,
				GetUiData = function (val)
					if val == 0 then
						return 0
					end

					return 2000 / val
				end,
				GetDesc = function (val)
					return string.format("%.1f%%", val)
				end
			},
			{
				Default = 0,
				Name = "hungry_check",
				Step = 1,
				NameStringId = 4609,
				Type = "slider",
				Max = 200,
				Min = 1,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return val
				end
			},
			{
				Name = "onlyone_food",
				NameStringId = 4658,
				Type = "option",
				Default = true,
				Options = {
					{
						Name_StringID = 4501,
						Val = true,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					},
					{
						Name_StringID = 4500,
						Val = false,
						Color = {
							r = 54,
							g = 51,
							b = 49
						}
					}
				},
				GetOption = function (val, options)
					if options then
						for k, v in pairs(options) do
							if v.Val == val then
								return v
							end
						end
					end

					return nil
				end,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				Func = function (type)
					OpenAiTable.ChangeConfigShowPremise(type, "food_select")
				end
			},
			{
				Name = "food_id",
				Type = "selector",
				NameStringId = 4668,
				Default = 12502,
				SelectClass = "food",
				CanShow = function ()
					return OpenAiTable.InShowPremise("food_select")
				end,
				Save = function (t, key, val)
					local id = val

					if type(id) == number and USER_MOD_NEWID_BASE <= id then
						local paramDef = ModEditorMgr:getItemDefById(id)

						table.insert(OpenAiTable.TempForeignIds, {
							id = id,
							key = ModEditorMgr:getItemKey(paramDef)
						})
					end

					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end
			},
			{
				Default = 5,
				Name = "how_long",
				Step = 1,
				NameStringId = 4657,
				Type = "slider",
				Max = 60,
				Min = 0,
				Save = function (t, key, val)
					t[key] = val
				end,
				GetUiData = function (val)
					return val
				end,
				GetDesc = function (val)
					return string.format("%d%s", val, GetS(6283))
				end
			}
		},
		GetFormatDesc = function (stringid, ai_itemdata)
			local def = GetItemDef(ai_itemdata.food_id) or GetItemDef(12502)
			local t = OpenAiTable.eat_food.Parameters

			return string.format(GetS(stringid), t[3].GetUiData(ai_itemdata.hungry_check), def.Name)
		end
	}
}
AIConfig = {
	GetAI = function (monsterId, aiName)
		local t = AIConfig[monsterId]

		if t == nil then
			return ""
		end

		for i = 1, #t do
			if t[i].AI.name == aiName then
				return t[i].AI
			end
		end

		return ""
	end,
	GetAllDefaultAI = function (monsterId)
		local t = AIConfig[monsterId]
		local ai_tbl = {}

		if t == nil then
			return ai_tbl
		end

		for i = 1, #t do
			table.insert(ai_tbl, t[i].AI)
		end

		return ai_tbl
	end,
	[3101] = {
		{
			Class = 99,
			AI = {
				name = "can_pass_closed_wooden_doors"
			}
		},
		{
			Class = 99,
			AI = {
				monster_id = 3407,
				name = "ride",
				priority = 0,
				dist = 3000
			}
		},
		{
			Class = 99,
			AI = {
				name = "sun_hurt"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "break_door"
			}
		},
		{
			Class = 99,
			AI = {
				maxhp = 0.0001,
				name = "panic",
				speed = 3.25,
				priority = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 200,
				priority = 3,
				name = "kick_away",
				force = 100,
				monster_id = 3109
			}
		},
		{
			Class = 1,
			AI = {
				priority = 2,
				name = "attack",
				move_speed = 1,
				will_trace = false,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "move_towards_restriction",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 7
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 2,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		}
	},
	[3102] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "break_door"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 7
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 2,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 1,
			AI = {
				priority = 2,
				name = "attack",
				move_speed = 1,
				will_trace = false,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 239,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 229,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 230,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 236,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 241,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200111,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200114,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200118,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200121,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200124,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200128,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200134,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200137,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200140,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200143,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200146,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 200152,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 724,
				search_block_dist = 20,
				is_hit = false,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 715,
				search_block_dist = 20,
				is_hit = false,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 716,
				search_block_dist = 20,
				is_hit = false,
				speed = 1
			}
		}
	},
	[3105] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_specific_entity",
				atkeeid = 3121,
				chance = 10
			}
		},
		{
			Class = 99,
			AI = {
				name = "sun_hurt"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				name = "projectile_attack",
				priority = 4,
				projectileid = 15050,
				count = 1,
				buffid = 0,
				power = 1,
				atkrange = 1500,
				min_atktime = 80,
				max_atktime = 60,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "restrict_sun"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "flee_sun",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				maxhp = 0.0001,
				name = "panic",
				speed = 3.25,
				priority = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 2,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				prob = 20,
				priority = 6,
				name = "get_special_attack_attr",
				block_id = 817,
				speed = 1
			}
		}
	},
	[3107] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "ceiling_atk",
				attach_timer = 200
			}
		},
		{
			Class = 99,
			AI = {
				prob = 1,
				name = "go_ceiling",
				priority = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				min_range = 200,
				priority = 2,
				name = "leap_at_target",
				motion_y = 40,
				max_range = 600
			}
		},
		{
			Class = 1,
			AI = {
				priority = 3,
				name = "attack",
				move_speed = 1,
				will_trace = false,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "wander",
				speed = 0.8
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 5
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 2,
			AI = {
				priority = 1,
				name = "target_nearest",
				brightness = 0.5,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_hurtee",
				help = false
			}
		}
	},
	[3109] = {
		{
			Class = 99,
			AI = {
				prob = 3,
				name = "invulnerable_prob"
			}
		},
		{
			Class = 99,
			AI = {
				type = 1,
				name = "path_hide"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "boom_atk"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 0.8
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 2,
			AI = {
				priority = 1,
				name = "target_nearest",
				brightness = 0.5,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_hurtee",
				help = false
			}
		},
		{
			Class = 99,
			AI = {
				prob = 1,
				priority = 1,
				name = "love_block",
				block_id = 834,
				speed = 1
			}
		}
	},
	[3130] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "break_door"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 1,
			AI = {
				priority = 2,
				name = "attack",
				move_speed = 1,
				will_trace = false,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 7
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 2,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				type = 2,
				name = "immune_fire"
			}
		}
	},
	[3131] = {
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "restrict_sun"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "flee_sun",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 2,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				type = 1,
				name = "immune_fire"
			}
		},
		{
			Class = 99,
			AI = {
				name = "projectile_attack",
				priority = 4,
				projectileid = 15051,
				count = 1,
				buffid = 100001,
				power = 1,
				atkrange = 1500,
				min_atktime = 20,
				max_atktime = 60,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_specific_entity",
				atkeeid = 3121,
				chance = 10
			}
		}
	},
	[3501] = {
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 1,
			AI = {
				priority = 1,
				name = "attack",
				move_speed = 1,
				will_trace = false,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				monster_id = 3102,
				name = "hold_monster",
				priority = 0,
				prob = 800
			}
		},
		{
			Class = 99,
			AI = {
				monster_id = 3109,
				name = "hold_monster",
				priority = 0,
				prob = 800
			}
		}
	},
	[3400] = {
		{
			Class = 99,
			AI = {
				name = "can_fly"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 1020,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "hatch",
				baby_id = 3913,
				max_ticks = 200,
				hatch_blockid = 1019
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "eat_feed_block",
				max_ticks = 40,
				feed_block = 1020
			}
		},
		{
			Class = 99,
			AI = {
				block_id = 1019,
				egg_id = 12052,
				name = "lay_egg_in_nest",
				priority = 7,
				nestgen = 3000,
				egg_blockid = 1185
			}
		},
		{
			Class = 99,
			AI = {
				priority = 8,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 10,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				block_id = 466,
				name = "eat_then_mutate",
				buff_tick = 200,
				buff_id = 71001,
				die_tick = 100,
				eat_tick = 20,
				prob = 200,
				priority = 1,
				speed = 1.5
			}
		}
	},
	[3401] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "tempt",
				scared = false,
				id = 229,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "tempt",
				scared = false,
				id = 11400,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 8
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "milking"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "logger_heads",
				speed = 0.8,
				item_id = 12578
			}
		}
	},
	[3402] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "panic",
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 12577,
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "sleep",
				period = 200,
				sleep_ticks = 100
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 8
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		}
	},
	[3403] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 229,
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 11400,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "eat_grass"
			}
		},
		{
			Class = 99,
			AI = {
				prob = 5,
				name = "eat_leaf",
				priority = 5,
				prob_adult = 200
			}
		},
		{
			Class = 99,
			AI = {
				prob = 5,
				name = "eat_flower",
				priority = 5,
				prob_adult = 200
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 8
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		}
	},
	[3405] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 1,
			AI = {
				priority = 1,
				name = "attack",
				move_speed = 1.2,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 0.5
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 12546,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 12524,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "look_idle",
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "beg",
				priority = 7,
				id = 12524
			}
		}
	},
	[3406] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 1,
			AI = {
				priority = 1,
				name = "attack",
				move_speed = 1.5,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 12558,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 12543,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "look_idle",
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "beg",
				priority = 7,
				id = 12543
			}
		}
	},
	[3407] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				name = "can_ride_by_player"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "sit"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_onwner_hurter"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				min_range = 200,
				priority = 4,
				name = "leap_at_target",
				motion_y = 40,
				max_range = 400
			}
		},
		{
			Class = 1,
			AI = {
				priority = 4,
				name = "attack",
				move_speed = 1,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 1,
			AI = {
				prob = 10,
				priority = 3,
				name = "target_following_player",
				speed = 1,
				check_sight = false
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 6,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 7,
				id = 11302
			}
		},
		{
			Class = 99,
			AI = {
				priority = 8,
				name = "target_nontamed",
				atkeeid = 3403,
				chance = 200
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "wander",
				speed = 1,
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle",
				prop = 60
			}
		}
	},
	[3408] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "topple_over"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "sitby_item",
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				min_range = 200,
				priority = 3,
				name = "leap_at_target",
				motion_y = 40,
				max_range = 400
			}
		},
		{
			Class = 1,
			AI = {
				priority = 4,
				name = "attack",
				move_speed = 2,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 5,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 11302
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_onwner_hurter"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		}
	},
	[3409] = {
		{
			Class = 99,
			AI = {
				name = "can_fly"
			}
		},
		{
			Class = 99,
			AI = {
				cd_time = 2000,
				priority = 0,
				name = "closest_dance",
				width = 2,
				dist = 30,
				dance_time = 200,
				speed = 2,
				number = 3
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 11400,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "lay_eggs",
				item1 = 12053,
				lay_sound = "",
				lay_prob = 6000
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 8
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		}
	},
	[3410] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 11321,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 12508,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 5
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle",
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "beg",
				priority = 7,
				id = 12508
			}
		}
	},
	[3411] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "wander",
				speed = 1,
				prop = 20
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "look_idle",
				prop = 20
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "beg",
				priority = 7,
				id = 12508
			}
		}
	},
	[3412] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 1,
			AI = {
				priority = 1,
				name = "attack",
				move_speed = 1.2,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 0.5
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_nontamed",
				atkeeid = 3409,
				chance = 200
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "wander",
				speed = 1,
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "look_idle",
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "beg",
				priority = 7,
				id = 12524
			}
		}
	},
	[3413] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				maxhp = 0.4,
				name = "panic",
				speed = 1.4,
				priority = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				min_range = 200,
				priority = 3,
				name = "leap_at_target",
				motion_y = 50,
				max_range = 500
			}
		},
		{
			Class = 2,
			AI = {
				priority = 3,
				name = "target_nearest",
				brightness = 0.8,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 1,
			AI = {
				priority = 3,
				name = "attack",
				move_speed = 1.2,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "target_nontamed",
				atkeeid = 3400,
				chance = 200
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "target_nontamed",
				atkeeid = 3401,
				chance = 200
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "target_nontamed",
				atkeeid = 3402,
				chance = 200
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "target_nontamed",
				atkeeid = 3403,
				chance = 200
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 7
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1,
				prop = 40
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle",
				prop = 60
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "beg",
				priority = 8,
				id = 12543
			}
		}
	},
	[3809] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "sit"
			}
		},
		{
			Class = 99,
			AI = {
				min_range = 200,
				priority = 3,
				name = "leap_at_target",
				motion_y = 40,
				max_range = 400
			}
		},
		{
			Class = 1,
			AI = {
				priority = 4,
				name = "attack",
				move_speed = 1,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 5,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 11302
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_onwner_hurter"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "target_nontamed",
				atkeeid = 3403,
				chance = 200
			}
		}
	},
	[3810] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "sit"
			}
		},
		{
			Class = 99,
			AI = {
				min_range = 200,
				priority = 3,
				name = "leap_at_target",
				motion_y = 0.4,
				max_range = 400
			}
		},
		{
			Class = 1,
			AI = {
				priority = 4,
				name = "attack",
				move_speed = 1,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 5,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 11302
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_onwner_hurter"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		}
	},
	[3811] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 236,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 7
			}
		},
		{
			Class = 99,
			AI = {
				priority = 8,
				name = "look_idle"
			}
		}
	},
	[3812] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 229,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "follow_parent",
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		}
	},
	[3813] = {
		{
			Class = 99,
			AI = {
				name = "can_fly"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 1020,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		}
	},
	[3814] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 229,
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "eat_grass"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 8
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		}
	},
	[3817] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 12508,
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "follow_parent",
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				prob = 60,
				name = "wander",
				speed = 1,
				priority = 5
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 5
			}
		},
		{
			Class = 99,
			AI = {
				prob = 60,
				name = "look_idle",
				priority = 5
			}
		}
	},
	[3818] = {
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "tempt",
				scared = false,
				id = 12543,
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "follow_parent",
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				prob = 60,
				name = "wander",
				speed = 1,
				priority = 4
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 4
			}
		},
		{
			Class = 99,
			AI = {
				prob = 60,
				name = "look_idle",
				priority = 4
			}
		}
	},
	[3819] = {
		{
			Class = 99,
			AI = {
				name = "can_fly"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 11403,
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "follow_parent",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		}
	},
	[3820] = {
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "panic",
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 12524,
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "follow_parent",
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				prob = 60,
				name = "wander",
				speed = 1,
				priority = 5
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 5
			}
		},
		{
			Class = 99,
			AI = {
				prob = 60,
				name = "look_idle",
				priority = 5
			}
		}
	},
	[3103] = {
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "wizard_projectile_attack",
				max_atk_time = 60,
				buff_id = 0,
				count = 1,
				projectile_id = 15067,
				atk_range = 1500,
				power = 1,
				min_atk_time = 80,
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				no_confine_tick = 160,
				name = "wizard_attack",
				confine_tick = 20,
				atk_dist = 0,
				damage = 0,
				priority = 2,
				continue_tick = 60,
				buff_id = 46,
				prob = 15,
				speed = 0.2,
				buff_level = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				name = "wizard_fly",
				priority = 4,
				min_height = 0,
				max_height = 16,
				interval = 50,
				max_range = 1000
			}
		}
	},
	[3110] = {
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				range = 500,
				priority = 5,
				name = "player_panic",
				panic_tick = 40,
				interval_tick = 40,
				speed = 4
			}
		},
		{
			Class = 99,
			AI = {
				interval_tick = 0,
				priority = 1,
				name = "combine",
				fit_tick = 100,
				dist = 1600,
				min_hp_fit = 0.3,
				speed = 1.4,
				fit_circle_angle = 22
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "separate_panic",
				speed = 1.4,
				panic_tick = 300
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 12553,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				name = "projectile_attack",
				priority = 4,
				projectileid = 15058,
				count = 1,
				buffid = 0,
				power = 1,
				atkrange = 1500,
				min_atktime = 80,
				max_atktime = 60,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 12553
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				cd_time = 2000,
				priority = 6,
				name = "closest_dance",
				width = 20,
				dist = 30,
				dance_time = 200,
				speed = 2,
				number = 3
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 1045,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 800,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 160,
				priority = 3,
				name = "make_trouble",
				block_id = 802,
				search_block_dist = 20,
				is_hit = true,
				speed = 1
			}
		}
	},
	[3124] = {
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "sit"
			}
		},
		{
			Class = 99,
			AI = {
				name = "projectile_attack",
				priority = 4,
				projectileid = 15058,
				count = 1,
				buffid = 0,
				power = 1,
				atkrange = 1500,
				min_atktime = 80,
				max_atktime = 60,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 5,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 12553
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_onwner_hurter"
			}
		}
	},
	[3111] = {
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				interval_tick = 0,
				priority = 1,
				name = "combine",
				fit_tick = 100,
				dist = 1600,
				min_hp_fit = 0.3,
				speed = 1.4,
				fit_circle_angle = 22
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "separate_panic",
				speed = 1.4,
				panic_tick = 300
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				name = "projectile_attack",
				priority = 4,
				projectileid = 15059,
				count = 1,
				buffid = 0,
				power = 1,
				atkrange = 1500,
				min_atktime = 80,
				max_atktime = 60,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 12557
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				cd_time = 2000,
				priority = 0,
				name = "closest_dance",
				width = 20,
				dist = 30,
				dance_time = 200,
				speed = 2,
				number = 3
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = false
			}
		}
	},
	[3125] = {
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "sit"
			}
		},
		{
			Class = 99,
			AI = {
				name = "projectile_attack",
				priority = 4,
				projectileid = 15059,
				count = 1,
				buffid = 0,
				power = 1,
				atkrange = 1500,
				min_atktime = 80,
				max_atktime = 60,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 5,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 12557
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_onwner_hurter"
			}
		}
	},
	[3112] = {
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				prob = 10,
				priority = 1,
				name = "bump_attack",
				dizzy_tick = 30,
				pre_tick = 50,
				back = 110,
				dist = 1000,
				mode = 2,
				speed = 1,
				up = 60
			}
		},
		{
			Class = 99,
			AI = {
				interval_tick = 0,
				priority = 1,
				name = "combine",
				fit_tick = 100,
				dist = 1600,
				min_hp_fit = 0.3,
				speed = 1.4,
				fit_circle_angle = 22
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "separate_panic",
				speed = 1.4,
				panic_tick = 300
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "attack",
				move_speed = 2,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 12552
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				cd_time = 2000,
				priority = 0,
				name = "closest_dance",
				width = 20,
				dist = 30,
				dance_time = 200,
				speed = 2,
				number = 3
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = false
			}
		}
	},
	[3126] = {
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				name = "avoid_water"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "sit"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "attack",
				move_speed = 1,
				will_trace = true,
				attack_type = 0
			}
		},
		{
			Class = 99,
			AI = {
				name = "follow_owner",
				priority = 5,
				min_dist = 200,
				max_dist = 1000,
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "beg",
				priority = 8,
				id = 12507
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 9
			}
		},
		{
			Class = 99,
			AI = {
				priority = 9,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_onwner_hurtee"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_onwner_hurter"
			}
		}
	},
	[3600] = {
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "rand_swim",
				interval = 50
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "fish_attack",
				will_trace = true,
				speed = 1.5
			}
		},
		{
			Class = 99,
			AI = {
				range = 800,
				priority = 1,
				name = "fish_beg",
				need_favor_food = 1,
				fear_motion = false
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "mate",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_nearest",
				brightness = 0,
				check_sight = true,
				chance = 0
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_nontamed",
				atkeeid = 3604,
				chance = 200
			}
		}
	},
	[3602] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 100
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "fish_attack",
				will_trace = true,
				speed = 1.5
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		}
	},
	[3604] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		},
		{
			Class = 99,
			AI = {
				range = 800,
				priority = 1,
				name = "fish_beg",
				need_favor_food = -1,
				fear_motion = false
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		}
	},
	[3605] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3606] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3607] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3608] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3609] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3610] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3611] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3612] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3613] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3614] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3615] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3616] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3617] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3618] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3619] = {
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "rand_swim",
				interval = 25
			}
		},
		{
			Class = 99,
			AI = {
				dist = 400,
				name = "fear_player",
				speed = 2,
				priority = 2
			}
		}
	},
	[3418] = {
		{
			Class = 99,
			AI = {
				name = "rand_fly",
				priority = 4,
				max_height = 16,
				interval = 25,
				max_range = 2000
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "fly_attack",
				trace = true,
				buff_id = 44,
				speed = 1,
				buff_level = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				prob = 500,
				priority = 3,
				name = "fly_love_block",
				love_tick = 400,
				block_id = 133,
				speed = 1.2
			}
		},
		{
			Class = 99,
			AI = {
				fear_motion = false,
				priority = 1,
				food_id = 300,
				name = "fly_beg",
				dist = 800
			}
		}
	},
	[3419] = {
		{
			Class = 99,
			AI = {
				name = "rand_fly",
				priority = 3,
				max_height = 16,
				interval = 50,
				max_range = 3000
			}
		},
		{
			Class = 99,
			AI = {
				fear_motion = false,
				priority = 1,
				food_id = 12511,
				name = "fly_beg",
				dist = 800
			}
		},
		{
			Class = 99,
			AI = {
				maxhp = 0.0001,
				name = "panic",
				speed = 3.25,
				priority = 2
			}
		}
	},
	[3421] = {
		{
			Class = 99,
			AI = {
				name = "can_fly"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				fear_motion = false,
				priority = 1,
				food_id = 12511,
				name = "fly_beg",
				dist = 800
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				trigger_tick = 300,
				priority = 4,
				name = "mutate_fly",
				block_id = 221,
				speed = 1.6
			}
		},
		{
			Class = 99,
			AI = {
				trigger_tick = 300,
				priority = 4,
				name = "mutate_fly",
				block_id = 258,
				speed = 1.6
			}
		},
		{
			Class = 99,
			AI = {
				trigger_tick = 300,
				priority = 4,
				name = "mutate_fly",
				block_id = 220,
				speed = 1.6
			}
		},
		{
			Class = 99,
			AI = {
				trigger_tick = 300,
				priority = 4,
				name = "mutate_fly",
				block_id = 255,
				speed = 1.6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 600,
				name = "watch_closest",
				priority = 3
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "look_idle"
			}
		}
	},
	[3422] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "panic",
				speed = 2
			}
		},
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "tempt",
				scared = false,
				id = 263,
				speed = 1
			}
		}
	},
	[3423] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				prob = 100,
				priority = 3,
				name = "patrol_on_block",
				block_id = 550,
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				prob = 20,
				priority = 2,
				name = "target_mutate",
				buff_id = 102001,
				block_id = 550,
				length = 16,
				check_sight = false
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 269,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "tempt",
				scared = false,
				id = 12589,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "tempt",
				scared = false,
				id = 12591,
				speed = 1.25
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "attack",
				move_speed = 1.4,
				will_trace = true,
				attack_type = 0
			}
		}
	},
	[3424] = {
		{
			Class = 99,
			AI = {
				priority = 0,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				name = "oxygen_need"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_scream",
				sound_tick = 1000
			}
		},
		{
			Class = 99,
			AI = {
				priority = 2,
				name = "tempt",
				scared = false,
				id = 1020,
				speed = 1.4
			}
		},
		{
			Class = 99,
			AI = {
				priority = 3,
				name = "target_panic_buff",
				speed = 1.8,
				buff_id = 102001
			}
		}
	},
	[4000] = {
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 4,
				name = "move_towards_restriction",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				priority = 5,
				name = "wander",
				speed = 1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 7
			}
		},
		{
			Class = 99,
			AI = {
				priority = 7,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		}
	},
	[4001] = {
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "swimming"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "follow_direction",
				speed = 1.1
			}
		},
		{
			Class = 99,
			AI = {
				dist = 800,
				name = "watch_closest",
				priority = 6
			}
		},
		{
			Class = 99,
			AI = {
				priority = 6,
				name = "look_idle"
			}
		},
		{
			Class = 99,
			AI = {
				priority = 1,
				name = "target_hurtee",
				help = true
			}
		},
		{
			Class = 99,
			AI = {
				type = 1,
				name = "setImmuneToFire"
			}
		}
	}
}
