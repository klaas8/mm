return {
	[2] = {
		UpMultiple = 2,
		EndTime = 1508083199,
		TWDesc = 1021,
		Desc = 1021,
		Open = 0,
		ENDesc = 1021,
		StartTime = 1507737600
	}
}
