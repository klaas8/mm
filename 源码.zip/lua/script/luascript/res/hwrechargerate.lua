return {
	md5sum = "c576c48fbe858e28033536c18b7a392a",
	RateTable = {
		{
			CountryCode = "ID",
			Desc = "印度尼西亚",
			Rate = 14460,
			CoinCode = "IDR"
		},
		{
			CountryCode = "IN",
			Desc = "印度",
			Rate = 70.25,
			CoinCode = "INR"
		},
		{
			CountryCode = "TH",
			Desc = "泰国",
			Rate = 31.58,
			CoinCode = "THB"
		},
		{
			CountryCode = "VN",
			Desc = "越南",
			Rate = 23275,
			CoinCode = "VND"
		},
		{
			CountryCode = "MY",
			Desc = "马来西亚",
			Rate = 4.16,
			CoinCode = "MYR"
		},
		{
			CountryCode = "PH",
			Desc = "菲律宾",
			Rate = 52.4,
			CoinCode = "PHP"
		},
		{
			CountryCode = "TW",
			Desc = "台湾",
			Rate = 31.15,
			CoinCode = "TWD"
		},
		{
			CountryCode = "CN",
			Desc = "中国",
			Rate = 6.91,
			CoinCode = "CNY"
		}
	}
}
