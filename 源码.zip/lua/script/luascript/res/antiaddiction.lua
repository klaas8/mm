return {
	{
		AuthType = 2,
		Name = "官网移动",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 1,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "4399移动",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 2,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "UC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 3,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "咪咕",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 4,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "沃商店",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 5,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "爱游戏",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 6,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "华为",
		AuthNum = 5000000,
		Auth = 0,
		ApiID = 7,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	{
		AuthType = 2,
		Name = "百度91",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 8,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "当乐",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 9,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "联想应用中心",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 10,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "魅族",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 11,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "小米",
		AuthNum = 5000000,
		Auth = 0,
		ApiID = 12,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	{
		AuthType = 2,
		Name = "游戏中心",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 13,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "安智",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 14,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "360移动",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 15,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "酷狗",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 16,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "百度多酷",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 17,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "百度手机助手",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 18,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "百度贴吧",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 19,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "联想游戏中心",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 20,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "腾讯应用宝",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 21,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "其他-被浇水(原腾讯QQ浏览器",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 22,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位1",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 23,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "腾讯华为游戏中心",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 24,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位2",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 25,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位3",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 26,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位4",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 27,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "今日头条2",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 28,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "美图",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 29,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "拇指玩",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 30,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "机锋",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 31,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "金立",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 32,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "木蚂蚁",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 33,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "豌豆荚",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 34,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "酷派",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 35,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "vivo",
		AuthNum = 5000000,
		Auth = 0,
		ApiID = 36,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	{
		AuthType = 2,
		Name = "乐视",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 37,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "搜狗浏览器",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 38,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "搜狗手机助手",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 39,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "搜狗输入法",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 40,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "搜狗搜索",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 41,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "搜狗游戏",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 42,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "google",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 43,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "全民点游",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 44,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "苹果",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 45,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位6",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 46,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "腾讯QQ大厅移动",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 47,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位7",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 48,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "三星",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 49,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "海信",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 50,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "腾讯极光",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 51,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	{
		AuthType = 2,
		Name = "B站",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 52,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "苹果分包4399",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 53,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	{
		AuthType = 2,
		Name = "OPPO体验",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 54,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "百度网讯",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 55,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "手Q",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 56,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "快手",
		AuthNum = 5000000,
		Auth = 0,
		ApiID = 57,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "233游戏盒子",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 58,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位11",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 59,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "快发助手",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 60,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "天天游戏中心",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 61,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cpsGG助手",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 62,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps捷酷",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 63,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps聚丰",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 64,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps酷比",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 65,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps雷震",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 66,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps努比亚",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 67,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps青橙",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 68,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps锤子",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 69,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps友方",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 70,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps中兴",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 71,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS多玩",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 72,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS应用汇",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 73,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS移动MM",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 74,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS青柠",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 75,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS18183",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 76,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps仙果",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 77,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps金立应用",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 78,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "官方版-公众号",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 79,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS美图",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 80,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "官方版-IP线",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 81,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cpsPP助手",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 82,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps神马搜索",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 83,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps豌豆荚",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 84,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "小7手游",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 85,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "GG助手",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 86,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "今日头条",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 87,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps7723",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 88,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "爱奇艺",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 89,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "芒果TV",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 90,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps市场部",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 91,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cpsNew7723",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 92,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cpsYiLe",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 93,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps极速互动",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 94,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "CPS葫芦侠",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 95,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps虫虫游戏",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 96,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "cps233游戏盒",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 97,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位12",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 98,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "国内先遣服移动",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 99,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	{
		AuthType = 2,
		Name = "PC官方",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 100,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "腾讯QQ大厅PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 101,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "WeGame-PC ",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 102,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位13",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 103,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位14",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 104,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位15",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 105,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位16",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 106,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位17",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 107,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位18",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 108,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "QQ空间",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 109,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "官网PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 110,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位19",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 111,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "PC端联想-CPS",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 112,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "快吧游戏-CPS",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 113,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "PC端雷神加速器-CPS",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 114,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位20",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 115,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "QQ大厅推广包",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 116,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "PC-QQ大厅推广渠道",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 117,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "PC大厅推广-联想软件商店",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 118,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位20",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 119,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "占位21",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 120,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "4399PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 121,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "7K7K",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 122,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "pc 2144渠道",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 123,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "飞火网吧平台-PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 124,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "迅雷-PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 125,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "360-PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 126,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "爱拍",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 127,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "爱奇艺PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 128,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "4399趣核平台-PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 129,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "新增PC渠道130",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 130,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "新增PC渠道131",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 131,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	{
		AuthType = 2,
		Name = "新增PC渠道132",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 132,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	[134] = {
		AuthType = 2,
		Name = "云刺1",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 134,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	[135] = {
		AuthType = 2,
		Name = "云刺2",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 135,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	[151] = {
		AuthType = 2,
		Name = "迷你星工场地图审核-PC",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 151,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	[299] = {
		AuthType = 2,
		Name = "迷你爱学",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 299,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	[500] = {
		AuthType = 2,
		Name = "MiniStudio",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 500,
		ForceAuth = 1,
		AntiAddiction = 1
	},
	[991] = {
		AuthType = 2,
		Name = "盒子",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 991,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	[998] = {
		AuthType = 2,
		Name = "小程序",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 998,
		ForceAuth = 1,
		AntiAddiction = 0
	},
	[999] = {
		AuthType = 2,
		Name = "内网pc",
		AuthNum = 5000000,
		Auth = 1,
		ApiID = 999,
		ForceAuth = 1,
		AntiAddiction = 0
	}
}
