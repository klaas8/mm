return {
	[14] = {
		Name = "10\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		ID = 14,
		BuyNum = "",
		PurchaseLimitID = "",
		Tag = "",
		Desc = "\\xb3\\xe4ֵ\\xba\\xf3\\xbb\\xf1\\xb5\\xc310\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		Cost = 1,
		Num = 10,
		IconId = 14100
	},
	[15] = {
		Name = "50\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		ID = 15,
		BuyNum = "",
		PurchaseLimitID = "",
		Tag = "",
		Desc = "\\xb3\\xe4ֵ\\xba\\xf3\\xbb\\xf1\\xb5\\xc350\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		Cost = 5,
		Num = 50,
		IconId = 14102
	},
	[16] = {
		Name = "250\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		ID = 16,
		BuyNum = "",
		PurchaseLimitID = "",
		Tag = "",
		Desc = "\\xb3\\xe4ֵ\\xba\\xf3\\xbb\\xf1\\xb5\\xc3250\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		Cost = 25,
		Num = 250,
		IconId = 14104
	},
	[17] = {
		Name = "500\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		ID = 17,
		BuyNum = "",
		PurchaseLimitID = "",
		Tag = "",
		Desc = "\\xb3\\xe4ֵ\\xba\\xf3\\xbb\\xf1\\xb5\\xc3500\\xc3\\xd4\\xc4\\xe3\\xb1\\xd2",
		Cost = 50,
		Num = 500,
		IconId = 14105
	}
}
