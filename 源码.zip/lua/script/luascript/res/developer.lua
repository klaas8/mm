return {
	md5sum = "2b8f1c531c1974558ed154a3e466359c",
	Taxe = {
		{
			ID = 1,
			Min = 0,
			Rate = 0.07,
			Num = 0,
			Max = 800
		},
		{
			ID = 2,
			Min = 801,
			Rate = 0.07,
			Num = 0,
			Max = 4000
		},
		{
			ID = 3,
			Min = 4001,
			Rate = 0.07,
			Num = 0,
			Max = 20000
		},
		{
			ID = 4,
			Min = 20000,
			Rate = 0.07,
			Num = 0,
			Max = 50000
		},
		{
			ID = 5,
			Min = 50001,
			Rate = 0.07,
			Num = 0,
			Max = 0
		}
	},
	LimitGoods = {
		{
			LevelLimit = 0,
			PresentList = "",
			PresentNumList = "",
			ItemID = 10005,
			BlockValue = 1,
			CostNum = 1,
			CostType = 0
		},
		{
			LevelLimit = 2,
			PresentList = "",
			PresentNumList = "",
			ItemID = 10006,
			BlockValue = 1,
			CostNum = 66,
			CostType = 2
		},
		{
			LevelLimit = 3,
			PresentList = "10005",
			PresentNumList = "1",
			ItemID = 10007,
			BlockValue = 2,
			CostNum = 20,
			CostType = 1
		},
		{
			LevelLimit = 4,
			PresentList = "10005",
			PresentNumList = "3",
			ItemID = 10008,
			BlockValue = 5,
			CostNum = 50,
			CostType = 1
		}
	},
	Developer = {
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 199,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 1,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 0,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 9999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 40,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		},
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 299,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 2,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 60,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 50,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		},
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 499,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 3,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 500,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 29999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 65,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		},
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 999,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 4,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 2500,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 39999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 90,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		},
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 2999,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 5,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 12500,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 49999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 110,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		},
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 5999,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 6,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 62500,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 59999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 140,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		},
		{
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 9999,
			LimitMapStoreItemMiniCoinPrice = 9999,
			Level = 7,
			RateMiniCoinAppMarket = 0.55,
			CommissionNum = 0.2,
			LimitMapStoreItem = 999,
			RateMiniBeanAppMarket = 0.55,
			Rank = 250000,
			RateMiniCoinToMoney = 15,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 69999,
			RateMiniCoinMiniW = 0.3,
			DeltaArchiveNum = 190,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7
		}
	},
	Config = {
		DayDrawOutMiniBeanTo = 30,
		DayDrawOutMiniBeanFrom = 1,
		ConfirmDay = 10,
		MinChestLevel = 3,
		MaxCountOneMonthDrawOutContribution = 1,
		DayDrawOutContributionTo = 20,
		MinNumDrawOutMiniBean = 50,
		MinNumDrawOutContribution = 1,
		DayDrawOutContributionFrom = 15
	}
}
