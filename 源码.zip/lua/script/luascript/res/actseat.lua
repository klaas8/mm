return {
	{
		CloseEnv = "-1",
		CltVersion = "0.50.0",
		ID = 1,
		Num = 500,
		CostType = 1,
		SeatType = 0
	},
	{
		CloseEnv = "-1",
		CltVersion = "0.50.0",
		ID = 2,
		Num = 50,
		CostType = 2,
		SeatType = 0
	},
	{
		CloseEnv = "-1",
		CltVersion = "0.50.0",
		ID = 3,
		Num = 50,
		CostType = 2,
		SeatType = 0
	},
	{
		CloseEnv = "-1",
		CltVersion = "0.50.0",
		ID = 4,
		Num = 50,
		CostType = 2,
		SeatType = 0
	},
	{
		CloseEnv = "-1",
		CltVersion = "0.50.0",
		ID = 5,
		Num = 50,
		CostType = 2,
		SeatType = 0
	},
	md5sum = "38f752b5a5cc3ee4a5add70e9b4bcae8"
}
