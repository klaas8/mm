return {
	["3"] = {
		["4"] = {
			ID = "1",
			avatar_type = "皮肤本次不上，暂时别动",
			type = "3",
			avatar_name = "迷斯拉",
			avatarID = "4",
			version_min = "0.57.2",
			uin = "1000",
			appids_no = {}
		},
		["21"] = {
			ID = "2",
			avatar_type = "皮肤本次不上，暂时别动",
			type = "3",
			avatar_name = "花小楼",
			avatarID = "21",
			version_min = "0.57.2",
			uin = "1000",
			appids_no = {}
		},
		["113"] = {
			ID = "3",
			avatar_type = "皮肤本次不上，暂时别动",
			type = "3",
			avatar_name = "泡泡",
			avatarID = "113",
			version_min = "0.57.2",
			uin = "1000",
			appids_no = {}
		}
	},
	["2"] = {
		{
			ID = "4",
			type = "2",
			avatar_name = "邻家男孩套",
			avatarID = "6,8,9,10",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "5",
			type = "2",
			avatar_name = "邻家女孩套",
			avatarID = "11,13,14",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "6",
			type = "2",
			avatar_name = "足球少年套",
			avatarID = "15,17,18,19",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "7",
			type = "2",
			avatar_name = "足球宝贝套",
			avatarID = "20,22,23,24",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "8",
			type = "2",
			avatar_name = "冬季俏皮套",
			avatarID = "99,101,102,104",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "9",
			type = "2",
			avatar_name = "冬季暖风套",
			avatarID = "105,107,109",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "11",
			type = "2",
			avatar_name = "海滨假日套",
			avatarID = "41,43,44,45",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		{
			ID = "12",
			type = "2",
			avatar_name = "冲浪男孩套",
			avatarID = "35,37,38,39",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		}
	},
	["1"] = {
		["8"] = {
			ID = "13",
			type = "1",
			avatar_name = "邻家男孩上衣",
			avatarID = "8",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["13"] = {
			ID = "14",
			type = "1",
			avatar_name = "邻家女孩连衣裙",
			avatarID = "13",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["17"] = {
			ID = "15",
			type = "1",
			avatar_name = "足球少年上衣",
			avatarID = "17",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["22"] = {
			ID = "16",
			type = "1",
			avatar_name = "足球宝贝上衣",
			avatarID = "22",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["43"] = {
			ID = "17",
			type = "1",
			avatar_name = "海滨假日上衣",
			avatarID = "43",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["37"] = {
			ID = "18",
			type = "1",
			avatar_name = "冲浪男孩上衣",
			avatarID = "37",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["102"] = {
			ID = "19",
			type = "1",
			avatar_name = "冬季俏皮衣服",
			avatarID = "102",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["107"] = {
			ID = "20",
			type = "1",
			avatar_name = "冬季暖风衣服",
			avatarID = "107",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["9"] = {
			ID = "29",
			type = "1",
			avatar_name = "邻家男孩裤子",
			avatarID = "9",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["18"] = {
			ID = "30",
			type = "1",
			avatar_name = "足球少年裤子",
			avatarID = "18",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["23"] = {
			ID = "31",
			type = "1",
			avatar_name = "足球宝贝裤子",
			avatarID = "23",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["38"] = {
			ID = "32",
			type = "1",
			avatar_name = "冲浪男孩裤子",
			avatarID = "38",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["44"] = {
			ID = "33",
			type = "1",
			avatar_name = "海滨假日裤子",
			avatarID = "44",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["101"] = {
			ID = "34",
			type = "1",
			avatar_name = "冬季俏皮裙子",
			avatarID = "101",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["466"] = {
			ID = "37",
			type = "1",
			avatar_name = "格子物语",
			avatarID = "466",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["681"] = {
			ID = "38",
			type = "1",
			avatar_name = "热带风光",
			avatarID = "681",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["10"] = {
			ID = "45",
			type = "1",
			avatar_name = "邻家男孩鞋子",
			avatarID = "10",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["14"] = {
			ID = "46",
			type = "1",
			avatar_name = "邻家女孩鞋子",
			avatarID = "14",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["19"] = {
			ID = "47",
			type = "1",
			avatar_name = "足球少年鞋子",
			avatarID = "19",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["24"] = {
			ID = "48",
			type = "1",
			avatar_name = "足球宝贝鞋子",
			avatarID = "24",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["39"] = {
			ID = "49",
			type = "1",
			avatar_name = "冲浪男孩鞋子",
			avatarID = "39",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["45"] = {
			ID = "50",
			type = "1",
			avatar_name = "海滨假日鞋子",
			avatarID = "45",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["99"] = {
			ID = "51",
			type = "1",
			avatar_name = "冬季俏皮鞋子",
			avatarID = "99",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["105"] = {
			ID = "52",
			type = "1",
			avatar_name = "冬季暖风鞋子",
			avatarID = "105",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["6"] = {
			ID = "61",
			type = "1",
			avatar_name = "邻家男孩头饰",
			avatarID = "6",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["11"] = {
			ID = "62",
			type = "1",
			avatar_name = "邻家女孩头饰",
			avatarID = "11",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["15"] = {
			ID = "63",
			type = "1",
			avatar_name = "足球少年头饰",
			avatarID = "15",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["20"] = {
			ID = "64",
			type = "1",
			avatar_name = "足球宝贝头饰",
			avatarID = "20",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["35"] = {
			ID = "65",
			type = "1",
			avatar_name = "冲浪男孩头饰",
			avatarID = "35",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["41"] = {
			ID = "66",
			type = "1",
			avatar_name = "海滨假日头饰",
			avatarID = "41",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["104"] = {
			ID = "68",
			type = "1",
			avatar_name = "冬季俏皮头饰",
			avatarID = "104",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		},
		["109"] = {
			ID = "69",
			type = "1",
			avatar_name = "冬季暖风头饰",
			avatarID = "109",
			version_min = "0.57.2",
			uin = "1000",
			avatar_type = {},
			appids_no = {}
		}
	}
}
