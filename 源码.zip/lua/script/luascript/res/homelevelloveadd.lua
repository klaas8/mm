return {
	{
		LoveAdd = 12,
		ID = 1,
		Name = "金果实"
	},
	{
		LoveAdd = 5,
		ID = 2,
		Name = "大果实"
	},
	{
		LoveAdd = 1,
		ID = 3,
		Name = "小果实"
	},
	{
		LoveAdd = 12,
		ID = 4,
		Name = "金果实1抽"
	},
	{
		LoveAdd = 120,
		ID = 5,
		Name = "金果实10抽"
	}
}
