return {
	md5sum = "ebcab27b7337e554d1ce7b4b4465162c",
	Taxe = {
		{
			ID = 1,
			Min = 0,
			Rate = 0,
			Num = 0,
			Max = 0
		},
		{
			ID = 2,
			Min = 0,
			Rate = 0,
			Num = 0,
			Max = 0
		},
		{
			ID = 3,
			Min = 0,
			Rate = 0,
			Num = 0,
			Max = 0
		},
		{
			ID = 4,
			Min = 0,
			Rate = 0,
			Num = 0,
			Max = 0
		},
		{
			ID = 5,
			Min = 0,
			Rate = 0,
			Num = 0,
			Max = 0
		}
	},
	LimitGoods = {
		{
			LevelLimit = 0,
			PresentList = "",
			PresentNumList = "",
			ItemID = 10005,
			BlockValue = 1,
			CostNum = 1,
			CostType = 0
		},
		{
			LevelLimit = 2,
			PresentList = "",
			PresentNumList = "",
			ItemID = 10006,
			BlockValue = 1,
			CostNum = 66,
			CostType = 2
		},
		{
			LevelLimit = 3,
			PresentList = "10005",
			PresentNumList = "1",
			ItemID = 10007,
			BlockValue = 2,
			CostNum = 20,
			CostType = 1
		},
		{
			LevelLimit = 4,
			PresentList = "10005",
			PresentNumList = "3",
			ItemID = 10008,
			BlockValue = 5,
			CostNum = 50,
			CostType = 1
		}
	},
	Developer = {
		{
			Rank = 0,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 10,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 99,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 199,
			Level = 1,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 10,
			RateMiniBeanAppMarket = 0.3
		},
		{
			Rank = 60,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 15,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 99,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 299,
			Level = 2,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 20,
			RateMiniBeanAppMarket = 0.3
		},
		{
			Rank = 500,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 25,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 199,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 499,
			Level = 3,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 30,
			RateMiniBeanAppMarket = 0.3
		},
		{
			Rank = 2500,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 45,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 299,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 999,
			Level = 4,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 50,
			RateMiniBeanAppMarket = 0.3
		},
		{
			Rank = 10000,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 55,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 399,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 2999,
			Level = 5,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 80,
			RateMiniBeanAppMarket = 0.3
		},
		{
			Rank = 40000,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 65,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 499,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 5999,
			Level = 6,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 100,
			RateMiniBeanAppMarket = 0.3
		},
		{
			Rank = 160000,
			RateMiniCoinToMoney = 65,
			DayMiniBeanMoneyBack = 7,
			LimitMapStoreItemMiniPointPrice = 19999,
			DeltaArchiveNum = 90,
			RateMiniCoinMiniW = 0.3,
			RateMiniBeanMoneyBack = 0.1,
			DayMiniCoinMoneyBack = 7,
			LimitMapStoreItemMiniCoinPrice = 599,
			RateMiniCoinMoneyBack = 0.1,
			LimitMapStoreItemMiniBeanPrice = 9999,
			Level = 7,
			RateMiniCoinAppMarket = 0.3,
			CommissionNum = 0,
			LimitMapStoreItem = 150,
			RateMiniBeanAppMarket = 0.3
		}
	},
	Config = {
		DayDrawOutContributionTo = 30,
		MinNumDrawOutMiniBean = 50,
		MinNumDrawOutContribution = 0,
		DayDrawOutContributionFrom = 25,
		DayDrawOutMiniBeanTo = 30,
		DayDrawOutMiniBeanFrom = 25,
		ConfirmDay = 20,
		MinChestLevel = 0,
		MaxCountOneMonthDrawOutContribution = 1
	}
}
