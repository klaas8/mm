return {
	[0] = {
		RandomRate = 33,
		Env = 0,
		RefreshTimeOut = 144000,
		StuffNum = 4,
		OpenLevel = 5,
		TryTimeOut = 3600,
		ShowTimeOut = 3600
	},
	{
		RandomRate = 100,
		Env = 1,
		RefreshTimeOut = 120,
		StuffNum = 4,
		OpenLevel = 5,
		TryTimeOut = 1,
		ShowTimeOut = 120
	}
}
