return {
	{
		ID = 1,
		Num = 0,
		CostType = 0,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 2,
		Num = 0,
		CostType = 0,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 3,
		Num = 0,
		CostType = 0,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 4,
		Num = 100,
		CostType = 1,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 5,
		Num = 300,
		CostType = 1,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 6,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 7,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 8,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 9,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 10,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 11,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 12,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 13,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 14,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 15,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 16,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 17,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 18,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 19,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	{
		ID = 20,
		Num = 50,
		CostType = 2,
		SeatType = 1,
		CloseEnv = "-1",
		CltVersion = "0.25.0"
	},
	md5sum = "bd35786ed97d20e7ebfe87aca45039f6",
	[1001] = {
		ID = 1001,
		Num = 0,
		CostType = 0,
		SeatType = 2,
		CloseEnv = "-1",
		CltVersion = "0.31.0"
	},
	[1002] = {
		ID = 1002,
		Num = 0,
		CostType = 0,
		SeatType = 2,
		CloseEnv = "-1",
		CltVersion = "0.31.0"
	},
	[1003] = {
		ID = 1003,
		Num = 0,
		CostType = 0,
		SeatType = 2,
		CloseEnv = "-1",
		CltVersion = "0.31.0"
	},
	[1004] = {
		ID = 1004,
		Num = 0,
		CostType = 0,
		SeatType = 2,
		CloseEnv = "-1",
		CltVersion = "0.31.0"
	},
	[1005] = {
		ID = 1005,
		Num = 0,
		CostType = 0,
		SeatType = 2,
		CloseEnv = "-1",
		CltVersion = "0.31.0"
	}
}
