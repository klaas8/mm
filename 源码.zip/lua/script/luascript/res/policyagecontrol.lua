return {
	policyAgeControl = {
		city = "Shenzhen,Beijing",
		age_control = {
			{
				pay = {
					once = 0,
					amount = 0
				},
				holidayList = {
					"2019-11-30 00:00:00 - 2019-12-01 00:00:00"
				},
				inhibitLogin = {
					max = 22,
					min = 8
				},
				age = {
					max = 7,
					min = 0
				},
				onlineTimeLimit = {
					holiday = 3,
					work = 1.5
				}
			},
			{
				pay = {
					once = 50,
					amount = 200
				},
				holidayList = {
					"2019-11-30 00:00:00 - 2019-12-01 00:00:00"
				},
				inhibitLogin = {
					max = 22,
					min = 8
				},
				age = {
					max = 15,
					min = 8
				},
				onlineTimeLimit = {
					holiday = 3,
					work = 1.5
				}
			},
			{
				pay = {
					once = 100,
					amount = 400
				},
				holidayList = {
					"2019-11-30 00:00:00 - 2019-12-01 00:00:00"
				},
				inhibitLogin = {
					max = 22,
					min = 8
				},
				age = {
					max = 17,
					min = 16
				},
				onlineTimeLimit = {
					holiday = 3,
					work = 1.5
				}
			}
		}
	},
	policyAgeControlurl = {
		displace = 10,
		test_url = "http://120.24.64.132:8087/miniw/profile/?time=1575291793&uin=204836446&ver=0.33.10&apiid=45&log=2&cmd=getAgeControl&token=70970f37a0942540b1fab5a0eb2d99b0",
		url = "https://shequ.mini1.cn:8081/miniw/profile/?time=1575291793&uin=204836446&ver=0.33.10&apiid=45&log=2&cmd=getAgeControl&token=70970f37a0942540b1fab5a0eb2d99b0"
	}
}
