return {
	{
		Level = 1,
		TWDesc = "Ripen fruits to collect enery and then claim bonus.",
		ENName = "獎勵：雙人陸行鳥坐騎！",
		OpenLevel = 10,
		ID = 1,
		Desc = "开果实收集满能量即可领取奖励，果实越好加的能量越多哦。",
		ENDesc = "開果實收集滿能量即可領取獎勵，果實越好加的能量越多哦。",
		DescStringID = 1023,
		InvolvedID = 3439,
		TWName = " Bonus: Double Hawkstrider!",
		NameStringID = 1022,
		Name = "奖励：双人陆行鸟坐骑！",
		Time = 1500,
		Type = 4,
		IconName = 3440
	}
}
