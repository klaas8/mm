return {
	[1000] = {
		ItemType = 1000
	},
	[2000] = {
		ItemType = 2000
	},
	[3000] = {
		ItemType = 3000
	},
	[4000] = {
		ItemType = 4000
	},
	[4001] = {
		ItemType = 4001
	},
	[4002] = {
		ItemType = 4002
	},
	[4003] = {
		ItemType = 4003
	},
	[4004] = {
		ItemType = 4004
	},
	[5000] = {
		ItemType = 5000
	},
	[5001] = {
		ItemType = 5001
	},
	[5002] = {
		ItemType = 5002
	},
	[5003] = {
		ItemType = 5003
	},
	[6000] = {
		ItemType = 6000
	},
	[7000] = {
		ItemType = 7000
	}
}
