return {
	{
		ID = 1,
		Name = "\\xcf\\xc9\\xc8\\xcb\\xd5\\xc6",
		Attack = 5,
		ENName = "Cactus"
	},
	{
		ID = 2,
		Name = "\\xd1ҽ\\xac",
		Attack = 5,
		ENName = "Magma"
	},
	{
		ID = 3,
		Name = "\\xd6\\xcfϢ",
		Attack = 5,
		ENName = "Asphyxia"
	},
	{
		ID = 4,
		Name = "\\xd0\\xe9\\xbf\\xd5",
		Attack = 5,
		ENName = "Void"
	},
	[7] = {
		ID = 7,
		Name = "\\xc4\\xe7ˮ",
		Attack = 5,
		ENName = "Drowning"
	}
}
