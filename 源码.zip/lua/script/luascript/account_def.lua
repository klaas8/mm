return {
	md5sum = "d594b44513590cf9096c10bf7f2e7d55",
	ActiveEventDef = {
		{
			TimesLimit = 3,
			EventID = 1,
			Active = 15
		},
		{
			TimesLimit = 3,
			EventID = 2,
			Active = 15
		},
		{
			TimesLimit = 0,
			EventID = 3,
			Active = 0
		},
		{
			TimesLimit = 0,
			EventID = 4,
			Active = 0
		},
		{
			TimesLimit = 0,
			EventID = 5,
			Active = 0
		},
		{
			TimesLimit = 10,
			EventID = 6,
			Active = 3
		}
	},
	ApiDef = {
		{
			Name = "官版",
			MobileQQ = 1,
			ApiID = 1,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		{
			Name = 4399,
			MobileQQ = "",
			ApiID = 2,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.m4399"
		},
		{
			Name = "UC",
			MobileQQ = "",
			ApiID = 3,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.uc"
		},
		{
			Name = "咪咕",
			MobileQQ = "",
			ApiID = 4,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.Migu"
		},
		{
			Name = "鸿蒙",
			MobileQQ = "",
			ApiID = 5,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.Wo"
		},
		{
			Name = "爱游戏",
			MobileQQ = "",
			ApiID = 6,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.Egame"
		},
		{
			Name = "华为",
			MobileQQ = "",
			ApiID = 7,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.huawei"
		},
		{
			Name = "百度91",
			MobileQQ = "",
			ApiID = 8,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.TMobile.baidu"
		},
		{
			Name = "当乐",
			MobileQQ = "",
			ApiID = 9,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.dcn"
		},
		{
			Name = "联想应用中心",
			MobileQQ = "",
			ApiID = 10,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.TMobile.Lenovo"
		},
		{
			Name = "魅族",
			MobileQQ = "",
			ApiID = 11,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.meizu"
		},
		{
			Name = "小米",
			MobileQQ = "",
			ApiID = 12,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.TMobile.mi"
		},
		{
			Name = "oppo",
			MobileQQ = "",
			ApiID = 13,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.nearme.gamecenter"
		},
		{
			Name = "安智",
			MobileQQ = "",
			ApiID = 14,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.anzhi"
		},
		{
			Name = 360,
			MobileQQ = "",
			ApiID = 15,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.qihu"
		},
		[17] = {
			Name = "百度多酷",
			MobileQQ = "",
			ApiID = 17,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.TMobile.baidu"
		},
		[18] = {
			Name = "百度手机助手",
			MobileQQ = "",
			ApiID = 18,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.TMobile.baidu"
		},
		[19] = {
			Name = "百度贴吧",
			MobileQQ = "",
			ApiID = 19,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.TMobile.baidu"
		},
		[21] = {
			Name = "腾讯应用宝",
			MobileQQ = "",
			ApiID = 21,
			Tag = "",
			Platform = "android",
			Package = "com.tencent.tmgp.minitech.miniworld"
		},
		[29] = {
			Name = "美图",
			MobileQQ = "",
			ApiID = 29,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.meitu"
		},
		[30] = {
			Name = "拇指玩",
			MobileQQ = "",
			ApiID = 30,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.mzw"
		},
		[31] = {
			Name = "机锋",
			MobileQQ = "",
			ApiID = 31,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.gfan"
		},
		[32] = {
			Name = "金立",
			MobileQQ = "",
			ApiID = 32,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.jinli"
		},
		[33] = {
			Name = "木蚂蚁",
			MobileQQ = "",
			ApiID = 33,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.mumayi"
		},
		[34] = {
			Name = "豌豆荚",
			MobileQQ = "",
			ApiID = 34,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.wdj"
		},
		[35] = {
			Name = "酷派",
			MobileQQ = "",
			ApiID = 35,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.coolpad"
		},
		[36] = {
			Name = "vivo",
			MobileQQ = "",
			ApiID = 36,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.vivo"
		},
		[37] = {
			Name = "乐视",
			MobileQQ = "",
			ApiID = 37,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.leshi"
		},
		[38] = {
			Name = "搜狗浏览器",
			MobileQQ = "",
			ApiID = 38,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.sougou"
		},
		[39] = {
			Name = "搜狗手机助手",
			MobileQQ = "",
			ApiID = 39,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.sougou"
		},
		[40] = {
			Name = "搜狗输入法",
			MobileQQ = "",
			ApiID = 40,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.sougou"
		},
		[41] = {
			Name = "搜狗搜索",
			MobileQQ = "",
			ApiID = 41,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.sougou"
		},
		[42] = {
			Name = "搜狗游戏",
			MobileQQ = "",
			ApiID = 42,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.sougou"
		},
		[44] = {
			Name = "抖音直播联运",
			MobileQQ = "",
			ApiID = 44,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.net.bytedance.gamecenter"
		},
		[45] = {
			Name = "苹果",
			MobileQQ = "",
			ApiID = 45,
			Tag = "",
			Platform = "ios",
			Package = "com.minitech.miniworld"
		},
		[47] = {
			Name = "腾讯QQ大厅移动",
			MobileQQ = "",
			ApiID = 47,
			Tag = "",
			Platform = "android",
			Package = "com.tencent.hall.minitech.miniworld"
		},
		[49] = {
			Name = "三星",
			MobileQQ = "",
			ApiID = 49,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.samsung"
		},
		[50] = {
			Name = "海信",
			MobileQQ = "",
			ApiID = 50,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.hisense"
		},
		[51] = {
			Name = "腾讯极光",
			MobileQQ = "",
			ApiID = 51,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[52] = {
			Name = "苹果分包1",
			MobileQQ = "",
			ApiID = 52,
			Tag = "",
			Platform = "ios",
			Package = ""
		},
		[53] = {
			Name = "苹果分包4399",
			MobileQQ = "",
			ApiID = 53,
			Tag = "",
			Platform = "ios",
			Package = ""
		},
		[54] = {
			Name = "OPPO预装",
			MobileQQ = "",
			ApiID = 54,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.nearme.gamecenter"
		},
		[55] = {
			Name = "百度网讯",
			MobileQQ = "",
			ApiID = 55,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.g.baidu"
		},
		[56] = {
			Name = "手Q渠道",
			MobileQQ = "",
			ApiID = 56,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.sq"
		},
		[57] = {
			Name = "快手渠道",
			MobileQQ = "",
			ApiID = 57,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.kuaishou"
		},
		[58] = {
			Name = "233游戏盒联运",
			MobileQQ = "",
			ApiID = 58,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.meta"
		},
		[59] = {
			Name = "迷你世界单机版",
			MobileQQ = "",
			ApiID = 59,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[60] = {
			Name = "抖音云游戏",
			MobileQQ = "",
			ApiID = 60,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.douyincloud"
		},
		[61] = {
			Name = "天天游戏中心",
			MobileQQ = "",
			ApiID = 61,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.jjcq"
		},
		[62] = {
			Name = "cpsGG助手",
			MobileQQ = "",
			ApiID = 62,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[63] = {
			Name = "cps诺基亚",
			MobileQQ = "",
			ApiID = 63,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[64] = {
			Name = "cps聚丰",
			MobileQQ = "",
			ApiID = 64,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[65] = {
			Name = "cps酷比",
			MobileQQ = "",
			ApiID = 65,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[66] = {
			Name = "cps雷震",
			MobileQQ = "",
			ApiID = 66,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[67] = {
			Name = "cps努比亚",
			MobileQQ = "",
			ApiID = 67,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[68] = {
			Name = "cps青橙",
			MobileQQ = "",
			ApiID = 68,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[69] = {
			Name = "cps锤子",
			MobileQQ = "",
			ApiID = 69,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[70] = {
			Name = "cps友方",
			MobileQQ = "",
			ApiID = 70,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[71] = {
			Name = "cps中兴",
			MobileQQ = "",
			ApiID = 71,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[72] = {
			Name = "CPS多玩",
			MobileQQ = "",
			ApiID = 72,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[73] = {
			Name = "CPS应用汇",
			MobileQQ = "",
			ApiID = 73,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[74] = {
			Name = "CPS移动MM",
			MobileQQ = "",
			ApiID = 74,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[75] = {
			Name = "CPS青柠",
			MobileQQ = "",
			ApiID = 75,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[76] = {
			Name = "CPS18183",
			MobileQQ = "",
			ApiID = 76,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[77] = {
			Name = "CPS仙果",
			MobileQQ = "",
			ApiID = 77,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[78] = {
			Name = "cps金立应用",
			MobileQQ = "",
			ApiID = 78,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[79] = {
			Name = "cps饭悟游戏厅",
			MobileQQ = "",
			ApiID = 79,
			Tag = "cps",
			Platform = "android",
			Package = "com.minitech.miniworld"
		},
		[85] = {
			Name = "小7手游",
			MobileQQ = "",
			ApiID = 85,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.x7sy"
		},
		[86] = {
			Name = "GG助手",
			MobileQQ = "",
			ApiID = 86,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.gg"
		},
		[87] = {
			Name = "今日头条",
			MobileQQ = "",
			ApiID = 87,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.jrtt"
		},
		[89] = {
			Name = "爱奇艺",
			MobileQQ = "",
			ApiID = 89,
			Tag = "",
			Platform = "android",
			Package = "com.minitech.miniworld.iqiyi"
		},
		[98] = {
			Name = "盒子Lite",
			MobileQQ = "",
			ApiID = 98,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[99] = {
			Name = "安卓官方外网测试",
			MobileQQ = "",
			ApiID = 99,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[101] = {
			Name = "腾讯QQ大厅PC",
			MobileQQ = "",
			ApiID = 101,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[109] = {
			Name = "QQ空间PC",
			MobileQQ = "",
			ApiID = 109,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[110] = {
			Name = "PC官方",
			MobileQQ = "",
			ApiID = 110,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[111] = {
			Name = "PC官方CPS1",
			MobileQQ = "",
			ApiID = 111,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[112] = {
			Name = "PC官方CPS2",
			MobileQQ = "",
			ApiID = 112,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[121] = {
			Name = "4399PC",
			MobileQQ = "",
			ApiID = 121,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[122] = {
			Name = "7k7kPC",
			MobileQQ = "",
			ApiID = 122,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[130] = {
			Name = "PC端CPS-yingxing1",
			MobileQQ = "",
			ApiID = 130,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[131] = {
			Name = "PC端CPS-yingxing2",
			MobileQQ = "",
			ApiID = 131,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[132] = {
			Name = "PC端CPS-fengqu",
			MobileQQ = "",
			ApiID = 132,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[199] = {
			Name = "PC官方外网测试",
			MobileQQ = "",
			ApiID = 199,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[200] = {
			Name = "网页官方",
			MobileQQ = "",
			ApiID = 200,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[299] = {
			Name = "网页官方外网测试",
			MobileQQ = "",
			ApiID = 299,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[303] = {
			Name = "谷歌",
			MobileQQ = "",
			ApiID = 303,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[345] = {
			Name = "IOS",
			MobileQQ = "",
			ApiID = 345,
			Tag = "",
			Platform = "ios",
			Package = ""
		},
		[398] = {
			Name = "海外Lite",
			MobileQQ = "",
			ApiID = 398,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[500] = {
			Name = "MiniStudio",
			MobileQQ = "",
			ApiID = 500,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[501] = {
			Name = "教育Lite_移动",
			MobileQQ = "",
			ApiID = 501,
			Tag = "",
			Platform = "android",
			Package = ""
		},
		[610] = {
			Name = "教育Lite_PC",
			MobileQQ = "",
			ApiID = 610,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[991] = {
			Name = "盒子-充值统计",
			MobileQQ = "",
			ApiID = 991,
			Tag = "",
			Platform = "",
			Package = ""
		},
		[992] = {
			Name = "国内-网页充值统计",
			MobileQQ = "",
			ApiID = 992,
			Tag = "",
			Platform = "",
			Package = ""
		},
		[998] = {
			Name = "PC版署版本",
			MobileQQ = "",
			ApiID = 998,
			Tag = "",
			Platform = "pc",
			Package = ""
		},
		[999] = {
			Name = "官方内部开发",
			MobileQQ = "",
			ApiID = 999,
			Tag = "",
			Platform = "pc",
			Package = "com.minitech.miniworld"
		}
	},
	ApiGroupDef = {
		{
			ApiID = 1,
			GroupID = 9
		},
		{
			ApiID = 2,
			GroupID = 6
		},
		{
			ApiID = 3,
			GroupID = 9
		},
		{
			ApiID = 4,
			GroupID = 9
		},
		{
			ApiID = 5,
			GroupID = 14
		},
		{
			ApiID = 6,
			GroupID = 9
		},
		{
			ApiID = 7,
			GroupID = 14
		},
		{
			ApiID = 8,
			GroupID = 3
		},
		{
			ApiID = 9,
			GroupID = 9
		},
		{
			ApiID = 10,
			GroupID = 2
		},
		[13] = {
			ApiID = 13,
			GroupID = 11
		},
		[14] = {
			ApiID = 14,
			GroupID = 9
		},
		[16] = {
			ApiID = 16,
			GroupID = 9
		},
		[17] = {
			ApiID = 17,
			GroupID = 3
		},
		[18] = {
			ApiID = 18,
			GroupID = 3
		},
		[19] = {
			ApiID = 19,
			GroupID = 9
		},
		[20] = {
			ApiID = 20,
			GroupID = 2
		},
		[21] = {
			ApiID = 21,
			GroupID = 1
		},
		[22] = {
			ApiID = 22,
			GroupID = 1
		},
		[23] = {
			ApiID = 23,
			GroupID = 1
		},
		[24] = {
			ApiID = 24,
			GroupID = 1
		},
		[25] = {
			ApiID = 25,
			GroupID = 1
		},
		[26] = {
			ApiID = 26,
			GroupID = 1
		},
		[27] = {
			ApiID = 27,
			GroupID = 1
		},
		[28] = {
			ApiID = 28,
			GroupID = 13
		},
		[29] = {
			ApiID = 29,
			GroupID = 9
		},
		[30] = {
			ApiID = 30,
			GroupID = 9
		},
		[31] = {
			ApiID = 31,
			GroupID = 9
		},
		[32] = {
			ApiID = 32,
			GroupID = 9
		},
		[33] = {
			ApiID = 33,
			GroupID = 9
		},
		[34] = {
			ApiID = 34,
			GroupID = 9
		},
		[35] = {
			ApiID = 35,
			GroupID = 9
		},
		[37] = {
			ApiID = 37,
			GroupID = 15
		},
		[38] = {
			ApiID = 38,
			GroupID = 9
		},
		[39] = {
			ApiID = 39,
			GroupID = 9
		},
		[40] = {
			ApiID = 40,
			GroupID = 9
		},
		[41] = {
			ApiID = 41,
			GroupID = 9
		},
		[42] = {
			ApiID = 42,
			GroupID = 9
		},
		[44] = {
			ApiID = 44,
			GroupID = 13
		},
		[46] = {
			ApiID = 46,
			GroupID = 1
		},
		[47] = {
			ApiID = 47,
			GroupID = 9
		},
		[50] = {
			ApiID = 50,
			GroupID = 9
		},
		[52] = {
			ApiID = 52,
			GroupID = 9
		},
		[54] = {
			ApiID = 54,
			GroupID = 11
		},
		[56] = {
			ApiID = 56,
			GroupID = 9
		},
		[57] = {
			ApiID = 57,
			GroupID = 15
		},
		[58] = {
			ApiID = 58,
			GroupID = 9
		},
		[60] = {
			ApiID = 60,
			GroupID = 9
		},
		[62] = {
			ApiID = 62,
			GroupID = 9
		},
		[63] = {
			ApiID = 63,
			GroupID = 9
		},
		[64] = {
			ApiID = 64,
			GroupID = 9
		},
		[65] = {
			ApiID = 65,
			GroupID = 9
		},
		[66] = {
			ApiID = 66,
			GroupID = 9
		},
		[67] = {
			ApiID = 67,
			GroupID = 9
		},
		[68] = {
			ApiID = 68,
			GroupID = 9
		},
		[69] = {
			ApiID = 69,
			GroupID = 9
		},
		[70] = {
			ApiID = 70,
			GroupID = 9
		},
		[71] = {
			ApiID = 71,
			GroupID = 9
		},
		[72] = {
			ApiID = 72,
			GroupID = 9
		},
		[73] = {
			ApiID = 73,
			GroupID = 9
		},
		[74] = {
			ApiID = 74,
			GroupID = 9
		},
		[75] = {
			ApiID = 75,
			GroupID = 9
		},
		[76] = {
			ApiID = 76,
			GroupID = 9
		},
		[77] = {
			ApiID = 77,
			GroupID = 9
		},
		[78] = {
			ApiID = 78,
			GroupID = 9
		},
		[79] = {
			ApiID = 79,
			GroupID = 9
		},
		[80] = {
			ApiID = 80,
			GroupID = 9
		},
		[81] = {
			ApiID = 81,
			GroupID = 9
		},
		[82] = {
			ApiID = 82,
			GroupID = 9
		},
		[83] = {
			ApiID = 83,
			GroupID = 9
		},
		[84] = {
			ApiID = 84,
			GroupID = 9
		},
		[85] = {
			ApiID = 85,
			GroupID = 9
		},
		[86] = {
			ApiID = 86,
			GroupID = 9
		},
		[87] = {
			ApiID = 87,
			GroupID = 13
		},
		[88] = {
			ApiID = 88,
			GroupID = 9
		},
		[89] = {
			ApiID = 89,
			GroupID = 9
		},
		[90] = {
			ApiID = 90,
			GroupID = 9
		},
		[91] = {
			ApiID = 91,
			GroupID = 9
		},
		[92] = {
			ApiID = 92,
			GroupID = 9
		},
		[93] = {
			ApiID = 93,
			GroupID = 9
		},
		[94] = {
			ApiID = 94,
			GroupID = 9
		},
		[95] = {
			ApiID = 95,
			GroupID = 9
		},
		[96] = {
			ApiID = 96,
			GroupID = 9
		},
		[97] = {
			ApiID = 97,
			GroupID = 9
		},
		[99] = {
			ApiID = 99,
			GroupID = 5
		},
		[101] = {
			ApiID = 101,
			GroupID = 9
		},
		[109] = {
			ApiID = 109,
			GroupID = 9
		},
		[110] = {
			ApiID = 110,
			GroupID = 9
		},
		[112] = {
			ApiID = 112,
			GroupID = 9
		},
		[113] = {
			ApiID = 113,
			GroupID = 9
		},
		[114] = {
			ApiID = 114,
			GroupID = 9
		},
		[115] = {
			ApiID = 115,
			GroupID = 9
		},
		[116] = {
			ApiID = 116,
			GroupID = 9
		},
		[117] = {
			ApiID = 117,
			GroupID = 9
		},
		[118] = {
			ApiID = 118,
			GroupID = 9
		},
		[119] = {
			ApiID = 119,
			GroupID = 9
		},
		[121] = {
			ApiID = 121,
			GroupID = 6
		},
		[123] = {
			ApiID = 123,
			GroupID = 9
		},
		[124] = {
			ApiID = 124,
			GroupID = 9
		},
		[125] = {
			ApiID = 125,
			GroupID = 9
		},
		[128] = {
			ApiID = 128,
			GroupID = 9
		},
		[129] = {
			ApiID = 129,
			GroupID = 6
		},
		[130] = {
			ApiID = 130,
			GroupID = 9
		},
		[131] = {
			ApiID = 131,
			GroupID = 9
		},
		[132] = {
			ApiID = 132,
			GroupID = 9
		},
		[199] = {
			ApiID = 199,
			GroupID = 5
		},
		[299] = {
			ApiID = 299,
			GroupID = 9
		},
		[302] = {
			ApiID = 302,
			GroupID = 8
		},
		[303] = {
			ApiID = 303,
			GroupID = 8
		},
		[307] = {
			ApiID = 307,
			GroupID = 8
		},
		[310] = {
			ApiID = 310,
			GroupID = 8
		},
		[312] = {
			ApiID = 312,
			GroupID = 8
		},
		[313] = {
			ApiID = 313,
			GroupID = 8
		},
		[336] = {
			ApiID = 336,
			GroupID = 8
		},
		[345] = {
			ApiID = 345,
			GroupID = 8
		},
		[399] = {
			ApiID = 399,
			GroupID = 10
		},
		[402] = {
			ApiID = 402,
			GroupID = 8
		},
		[410] = {
			ApiID = 410,
			GroupID = 8
		},
		[411] = {
			ApiID = 411,
			GroupID = 8
		},
		[499] = {
			ApiID = 499,
			GroupID = 10
		},
		[500] = {
			ApiID = 500,
			GroupID = 9
		}
	},
	ApiLoginDef = {
		{
			ApiID = 1,
			LoginGroupID = 199
		},
		{
			ApiID = 2,
			LoginGroupID = 199
		},
		{
			ApiID = 3,
			LoginGroupID = 199
		},
		{
			ApiID = 4,
			LoginGroupID = 199
		},
		{
			ApiID = 5,
			LoginGroupID = 199
		},
		{
			ApiID = 6,
			LoginGroupID = 199
		},
		{
			ApiID = 7,
			LoginGroupID = 199
		},
		{
			ApiID = 8,
			LoginGroupID = 199
		},
		{
			ApiID = 9,
			LoginGroupID = 199
		},
		{
			ApiID = 10,
			LoginGroupID = 199
		},
		{
			ApiID = 11,
			LoginGroupID = 199
		},
		{
			ApiID = 12,
			LoginGroupID = 199
		},
		{
			ApiID = 13,
			LoginGroupID = 199
		},
		{
			ApiID = 14,
			LoginGroupID = 199
		},
		{
			ApiID = 15,
			LoginGroupID = 199
		},
		{
			ApiID = 16,
			LoginGroupID = 199
		},
		{
			ApiID = 17,
			LoginGroupID = 199
		},
		{
			ApiID = 18,
			LoginGroupID = 199
		},
		{
			ApiID = 19,
			LoginGroupID = 199
		},
		{
			ApiID = 20,
			LoginGroupID = 199
		},
		{
			ApiID = 21,
			LoginGroupID = 199
		},
		{
			ApiID = 22,
			LoginGroupID = 199
		},
		{
			ApiID = 23,
			LoginGroupID = 199
		},
		{
			ApiID = 24,
			LoginGroupID = 199
		},
		{
			ApiID = 25,
			LoginGroupID = 199
		},
		{
			ApiID = 26,
			LoginGroupID = 199
		},
		{
			ApiID = 27,
			LoginGroupID = 199
		},
		{
			ApiID = 28,
			LoginGroupID = 199
		},
		{
			ApiID = 29,
			LoginGroupID = 199
		},
		{
			ApiID = 30,
			LoginGroupID = 199
		},
		{
			ApiID = 31,
			LoginGroupID = 199
		},
		{
			ApiID = 32,
			LoginGroupID = 199
		},
		{
			ApiID = 33,
			LoginGroupID = 199
		},
		{
			ApiID = 34,
			LoginGroupID = 199
		},
		{
			ApiID = 35,
			LoginGroupID = 199
		},
		{
			ApiID = 36,
			LoginGroupID = 199
		},
		{
			ApiID = 37,
			LoginGroupID = 199
		},
		{
			ApiID = 38,
			LoginGroupID = 199
		},
		{
			ApiID = 39,
			LoginGroupID = 199
		},
		{
			ApiID = 40,
			LoginGroupID = 199
		},
		{
			ApiID = 41,
			LoginGroupID = 199
		},
		{
			ApiID = 42,
			LoginGroupID = 199
		},
		{
			ApiID = 43,
			LoginGroupID = 199
		},
		{
			ApiID = 44,
			LoginGroupID = 199
		},
		{
			ApiID = 45,
			LoginGroupID = 199
		},
		{
			ApiID = 46,
			LoginGroupID = 199
		},
		{
			ApiID = 47,
			LoginGroupID = 101
		},
		{
			ApiID = 48,
			LoginGroupID = 199
		},
		[99] = {
			ApiID = 99,
			LoginGroupID = 199
		},
		[101] = {
			ApiID = 101,
			LoginGroupID = 47
		},
		[199] = {
			ApiID = 199,
			LoginGroupID = 99
		},
		[999] = {
			ApiID = 999,
			LoginGroupID = 1
		}
	},
	CDKeyGiftDef = {
		[60] = {
			MaxNum = 30000,
			LimitGroup = 33,
			CltVersion = 0,
			CDKeyGiftType = 60,
			ApiID = 0,
			PreCode = "miniweixin",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12971,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[61] = {
			MaxNum = 30000,
			LimitGroup = 34,
			CltVersion = 0,
			CDKeyGiftType = 61,
			ApiID = 0,
			PreCode = "minifensi1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12972,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[62] = {
			MaxNum = 30000,
			LimitGroup = 35,
			CltVersion = 0,
			CDKeyGiftType = 62,
			ApiID = 0,
			PreCode = "minifensi2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12973,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[63] = {
			MaxNum = 30000,
			LimitGroup = 36,
			CltVersion = 0,
			CDKeyGiftType = 63,
			ApiID = 0,
			PreCode = "minifensi3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12974,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[64] = {
			MaxNum = 30000,
			LimitGroup = 37,
			CltVersion = 0,
			CDKeyGiftType = 64,
			ApiID = 0,
			PreCode = "minifensi4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12975,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[65] = {
			MaxNum = 30000,
			LimitGroup = 38,
			CltVersion = 0,
			CDKeyGiftType = 65,
			ApiID = 0,
			PreCode = "mnyg",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12966,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[66] = {
			MaxNum = 30000,
			LimitGroup = 39,
			CltVersion = 0,
			CDKeyGiftType = 66,
			ApiID = 0,
			PreCode = "mnbiuld11",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20031,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[67] = {
			MaxNum = 30000,
			LimitGroup = 40,
			CltVersion = 0,
			CDKeyGiftType = 67,
			ApiID = 0,
			PreCode = "mnbiuld12",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20029,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				400,
				0,
				0,
				0,
				0
			}
		},
		[68] = {
			MaxNum = 30000,
			LimitGroup = 41,
			CltVersion = 0,
			CDKeyGiftType = 68,
			ApiID = 0,
			PreCode = "mnbiuld13",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20060,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				500,
				0,
				0,
				0,
				0
			}
		},
		[69] = {
			MaxNum = 30000,
			LimitGroup = 42,
			CltVersion = 0,
			CDKeyGiftType = 69,
			ApiID = 0,
			PreCode = "mnbiuld14",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20061,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				500,
				0,
				0,
				0,
				0
			}
		},
		[70] = {
			MaxNum = 30000,
			LimitGroup = 43,
			CltVersion = 0,
			CDKeyGiftType = 70,
			ApiID = 0,
			PreCode = "mnbiuld15",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[200] = {
			MaxNum = 30000,
			LimitGroup = 173,
			CltVersion = 0,
			CDKeyGiftType = 200,
			ApiID = 0,
			PreCode = "dashen1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				500,
				0,
				0,
				0,
				0
			}
		},
		[201] = {
			MaxNum = 30000,
			LimitGroup = 174,
			CltVersion = 0,
			CDKeyGiftType = 201,
			ApiID = 0,
			PreCode = "dashen2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12960,
				0,
				0,
				0
			},
			ItemNum = {
				1666,
				50,
				0,
				0,
				0
			}
		},
		[202] = {
			MaxNum = 30000,
			LimitGroup = 175,
			CltVersion = 0,
			CDKeyGiftType = 202,
			ApiID = 0,
			PreCode = "dashen3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20031,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				150,
				0,
				0,
				0,
				0
			}
		},
		[203] = {
			MaxNum = 30000,
			LimitGroup = 176,
			CltVersion = 0,
			CDKeyGiftType = 203,
			ApiID = 0,
			PreCode = "douyu1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				600,
				0,
				0,
				0,
				0
			}
		},
		[204] = {
			MaxNum = 30000,
			LimitGroup = 177,
			CltVersion = 0,
			CDKeyGiftType = 204,
			ApiID = 0,
			PreCode = "douyu2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1200,
				0,
				0,
				0,
				0
			}
		},
		[205] = {
			MaxNum = 30000,
			LimitGroup = 178,
			CltVersion = 0,
			CDKeyGiftType = 205,
			ApiID = 0,
			PreCode = "douyu3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				3600,
				0,
				0,
				0,
				0
			}
		},
		[206] = {
			MaxNum = 30000,
			LimitGroup = 179,
			CltVersion = 0,
			CDKeyGiftType = 206,
			ApiID = 0,
			PreCode = "douyu4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				6666,
				0,
				0,
				0,
				0
			}
		},
		[207] = {
			MaxNum = 30000,
			LimitGroup = 180,
			CltVersion = 0,
			CDKeyGiftType = 207,
			ApiID = 0,
			PreCode = "douyu5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20031,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[208] = {
			MaxNum = 30000,
			LimitGroup = 181,
			CltVersion = 0,
			CDKeyGiftType = 208,
			ApiID = 0,
			PreCode = "dashen4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20033,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				100,
				0,
				0,
				0,
				0
			}
		},
		[209] = {
			MaxNum = 30000,
			LimitGroup = 182,
			CltVersion = 0,
			CDKeyGiftType = 209,
			ApiID = 0,
			PreCode = "douyu6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20033,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[247] = {
			MaxNum = 30000,
			LimitGroup = 220,
			CltVersion = 0,
			CDKeyGiftType = 247,
			ApiID = 0,
			PreCode = "miniT1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				0,
				0,
				0,
				0
			}
		},
		[248] = {
			MaxNum = 30000,
			LimitGroup = 221,
			CltVersion = 0,
			CDKeyGiftType = 248,
			ApiID = 0,
			PreCode = "miniT2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				120,
				0,
				0,
				0,
				0
			}
		},
		[249] = {
			MaxNum = 30000,
			LimitGroup = 222,
			CltVersion = 0,
			CDKeyGiftType = 249,
			ApiID = 0,
			PreCode = "miniT3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				200,
				0,
				0,
				0,
				0
			}
		},
		[250] = {
			MaxNum = 30000,
			LimitGroup = 223,
			CltVersion = 0,
			CDKeyGiftType = 250,
			ApiID = 2,
			PreCode = "4399T",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[251] = {
			MaxNum = 30000,
			LimitGroup = 224,
			CltVersion = 0,
			CDKeyGiftType = 251,
			ApiID = 21,
			PreCode = "yybT",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[252] = {
			MaxNum = 30000,
			LimitGroup = 225,
			CltVersion = 0,
			CDKeyGiftType = 252,
			ApiID = 3,
			PreCode = "ucT",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[253] = {
			MaxNum = 30000,
			LimitGroup = 226,
			CltVersion = 0,
			CDKeyGiftType = 253,
			ApiID = 0,
			PreCode = "baiduT",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[254] = {
			MaxNum = 30000,
			LimitGroup = 227,
			CltVersion = 0,
			CDKeyGiftType = 254,
			ApiID = 13,
			PreCode = "oppoT",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[255] = {
			MaxNum = 30000,
			LimitGroup = 228,
			CltVersion = 0,
			CDKeyGiftType = 255,
			ApiID = 36,
			PreCode = "vivoT",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[256] = {
			MaxNum = 30000,
			LimitGroup = 229,
			CltVersion = 0,
			CDKeyGiftType = 256,
			ApiID = 12,
			PreCode = "miT",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[287] = {
			MaxNum = 30000,
			LimitGroup = 260,
			CltVersion = 0,
			CDKeyGiftType = 287,
			ApiID = 0,
			PreCode = "zhibo1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12960,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				50,
				0,
				0,
				0,
				0
			}
		},
		[288] = {
			MaxNum = 30000,
			LimitGroup = 261,
			CltVersion = 0,
			CDKeyGiftType = 288,
			ApiID = 0,
			PreCode = "zhibo2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12960,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				68,
				0,
				0,
				0,
				0
			}
		},
		[289] = {
			MaxNum = 30000,
			LimitGroup = 262,
			CltVersion = 0,
			CDKeyGiftType = 289,
			ApiID = 0,
			PreCode = "zhibo3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12960,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				100,
				0,
				0,
				0,
				0
			}
		},
		[290] = {
			MaxNum = 30000,
			LimitGroup = 263,
			CltVersion = 0,
			CDKeyGiftType = 290,
			ApiID = 0,
			PreCode = "zhibo4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12960,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				150,
				0,
				0,
				0,
				0
			}
		},
		[291] = {
			MaxNum = 1,
			LimitGroup = 264,
			CltVersion = 0,
			CDKeyGiftType = 291,
			ApiID = 0,
			PreCode = "k1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				12964,
				12981,
				0
			},
			ItemNum = {
				100,
				2,
				2,
				7,
				0
			}
		},
		[292] = {
			MaxNum = 1,
			LimitGroup = 265,
			CltVersion = 0,
			CDKeyGiftType = 292,
			ApiID = 121,
			PreCode = "4399pc51",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				12964,
				12981,
				0
			},
			ItemNum = {
				100,
				2,
				2,
				7,
				0
			}
		},
		[293] = {
			MaxNum = 1,
			LimitGroup = 266,
			CltVersion = 0,
			CDKeyGiftType = 293,
			ApiID = 0,
			PreCode = "7k61",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				12998,
				0,
				0
			},
			ItemNum = {
				100,
				2,
				3,
				0,
				0
			}
		},
		[324] = {
			MaxNum = 1,
			LimitGroup = 297,
			CltVersion = 0,
			CDKeyGiftType = 324,
			ApiID = 121,
			PreCode = "439961",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				13415,
				0,
				0
			},
			ItemNum = {
				60,
				2,
				1,
				0,
				0
			}
		},
		[325] = {
			MaxNum = 1,
			LimitGroup = 298,
			CltVersion = 0,
			CDKeyGiftType = 325,
			ApiID = 121,
			PreCode = "439961QD1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[326] = {
			MaxNum = 1,
			LimitGroup = 299,
			CltVersion = 0,
			CDKeyGiftType = 326,
			ApiID = 121,
			PreCode = "439961QD2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12831,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[327] = {
			MaxNum = 1,
			LimitGroup = 300,
			CltVersion = 0,
			CDKeyGiftType = 327,
			ApiID = 121,
			PreCode = "439961QD3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				120,
				0,
				0,
				0,
				0
			}
		},
		[328] = {
			MaxNum = 1,
			LimitGroup = 301,
			CltVersion = 0,
			CDKeyGiftType = 328,
			ApiID = 121,
			PreCode = "439961QD4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[329] = {
			MaxNum = 1,
			LimitGroup = 302,
			CltVersion = 0,
			CDKeyGiftType = 329,
			ApiID = 121,
			PreCode = "439961QD5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				13415,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[330] = {
			MaxNum = 1,
			LimitGroup = 303,
			CltVersion = 0,
			CDKeyGiftType = 330,
			ApiID = 121,
			PreCode = "439961QD6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				13806,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[331] = {
			MaxNum = 1,
			LimitGroup = 304,
			CltVersion = 0,
			CDKeyGiftType = 331,
			ApiID = 121,
			PreCode = "439961QD7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				845,
				12961,
				0,
				0
			},
			ItemNum = {
				150,
				1,
				2,
				0,
				0
			}
		},
		[332] = {
			MaxNum = 1,
			LimitGroup = 305,
			CltVersion = 0,
			CDKeyGiftType = 332,
			ApiID = 121,
			PreCode = "4399CL1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				845,
				12963,
				0,
				0
			},
			ItemNum = {
				120,
				1,
				1,
				0,
				0
			}
		},
		[333] = {
			MaxNum = 1,
			LimitGroup = 306,
			CltVersion = 0,
			CDKeyGiftType = 333,
			ApiID = 121,
			PreCode = "4399CL2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				13415,
				12833,
				0,
				0
			},
			ItemNum = {
				100,
				1,
				2,
				0,
				0
			}
		},
		[334] = {
			MaxNum = 1,
			LimitGroup = 307,
			CltVersion = 0,
			CDKeyGiftType = 334,
			ApiID = 121,
			PreCode = "4399CL3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				13806,
				12831,
				0,
				0
			},
			ItemNum = {
				60,
				1,
				1,
				0,
				0
			}
		},
		[335] = {
			MaxNum = 1,
			LimitGroup = 308,
			CltVersion = 0,
			CDKeyGiftType = 335,
			ApiID = 121,
			PreCode = "4399CL4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12964,
				0,
				0,
				0
			},
			ItemNum = {
				20,
				1,
				0,
				0,
				0
			}
		},
		[336] = {
			MaxNum = 1,
			LimitGroup = 309,
			CltVersion = 0,
			CDKeyGiftType = 336,
			ApiID = 121,
			PreCode = "4399JZ1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20033,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[337] = {
			MaxNum = 1,
			LimitGroup = 310,
			CltVersion = 0,
			CDKeyGiftType = 337,
			ApiID = 121,
			PreCode = "4399JZ2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20031,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[338] = {
			MaxNum = 1,
			LimitGroup = 311,
			CltVersion = 0,
			CDKeyGiftType = 338,
			ApiID = 1,
			PreCode = "duowanA",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[339] = {
			MaxNum = 1,
			LimitGroup = 312,
			CltVersion = 0,
			CDKeyGiftType = 339,
			ApiID = 2,
			PreCode = "4399ZQ7T1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[340] = {
			MaxNum = 1,
			LimitGroup = 313,
			CltVersion = 0,
			CDKeyGiftType = 340,
			ApiID = 2,
			PreCode = "4399ZQ7T2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[341] = {
			MaxNum = 1,
			LimitGroup = 314,
			CltVersion = 0,
			CDKeyGiftType = 341,
			ApiID = 2,
			PreCode = "4399ZQ7T3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[342] = {
			MaxNum = 1,
			LimitGroup = 315,
			CltVersion = 0,
			CDKeyGiftType = 342,
			ApiID = 2,
			PreCode = "4399ZQ7T4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[343] = {
			MaxNum = 1,
			LimitGroup = 316,
			CltVersion = 0,
			CDKeyGiftType = 343,
			ApiID = 2,
			PreCode = "4399ZQ7T5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[344] = {
			MaxNum = 1,
			LimitGroup = 317,
			CltVersion = 0,
			CDKeyGiftType = 344,
			ApiID = 2,
			PreCode = "4399ZQ7T6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[345] = {
			MaxNum = 1,
			LimitGroup = 318,
			CltVersion = 0,
			CDKeyGiftType = 345,
			ApiID = 2,
			PreCode = "4399ZQ7T7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[346] = {
			MaxNum = 1,
			LimitGroup = 319,
			CltVersion = 0,
			CDKeyGiftType = 346,
			ApiID = 2,
			PreCode = "4399n9d1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				3,
				0,
				0,
				0,
				0
			}
		},
		[347] = {
			MaxNum = 1,
			LimitGroup = 320,
			CltVersion = 0,
			CDKeyGiftType = 347,
			ApiID = 2,
			PreCode = "4399n9d2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[348] = {
			MaxNum = 1,
			LimitGroup = 321,
			CltVersion = 0,
			CDKeyGiftType = 348,
			ApiID = 2,
			PreCode = "4399n9d3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12964,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				4,
				0,
				0,
				0,
				0
			}
		},
		[349] = {
			MaxNum = 1,
			LimitGroup = 322,
			CltVersion = 0,
			CDKeyGiftType = 349,
			ApiID = 2,
			PreCode = "4399n9d4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[350] = {
			MaxNum = 1,
			LimitGroup = 323,
			CltVersion = 0,
			CDKeyGiftType = 350,
			ApiID = 2,
			PreCode = "4399n9d5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12831,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				5,
				0,
				0,
				0,
				0
			}
		},
		[351] = {
			MaxNum = 1,
			LimitGroup = 324,
			CltVersion = 0,
			CDKeyGiftType = 351,
			ApiID = 2,
			PreCode = "4399n9d6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[352] = {
			MaxNum = 1,
			LimitGroup = 325,
			CltVersion = 0,
			CDKeyGiftType = 352,
			ApiID = 2,
			PreCode = "4399n9d7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[353] = {
			MaxNum = 1,
			LimitGroup = 326,
			CltVersion = 0,
			CDKeyGiftType = 353,
			ApiID = 2,
			PreCode = "4399n9d8",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[354] = {
			MaxNum = 1,
			LimitGroup = 327,
			CltVersion = 0,
			CDKeyGiftType = 354,
			ApiID = 2,
			PreCode = "4399n9d9",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12255,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[355] = {
			MaxNum = 1,
			LimitGroup = 328,
			CltVersion = 0,
			CDKeyGiftType = 355,
			ApiID = 2,
			PreCode = "4399n9d10",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[356] = {
			MaxNum = 1,
			LimitGroup = 329,
			CltVersion = 0,
			CDKeyGiftType = 356,
			ApiID = 2,
			PreCode = "4399n9d11",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[357] = {
			MaxNum = 1,
			LimitGroup = 330,
			CltVersion = 0,
			CDKeyGiftType = 357,
			ApiID = 2,
			PreCode = "4399n9d12",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[358] = {
			MaxNum = 1,
			LimitGroup = 331,
			CltVersion = 0,
			CDKeyGiftType = 358,
			ApiID = 2,
			PreCode = "4399n9d13",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[359] = {
			MaxNum = 1,
			LimitGroup = 332,
			CltVersion = 0,
			CDKeyGiftType = 359,
			ApiID = 2,
			PreCode = "4399n9d14",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[360] = {
			MaxNum = 1,
			LimitGroup = 333,
			CltVersion = 0,
			CDKeyGiftType = 360,
			ApiID = 2,
			PreCode = "4399n9d15",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12960,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				30,
				0,
				0,
				0,
				0
			}
		},
		[361] = {
			MaxNum = 1,
			LimitGroup = 334,
			CltVersion = 0,
			CDKeyGiftType = 361,
			ApiID = 2,
			PreCode = "4399n9d16",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[362] = {
			MaxNum = 1,
			LimitGroup = 335,
			CltVersion = 0,
			CDKeyGiftType = 362,
			ApiID = 2,
			PreCode = "4399n9d17",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[363] = {
			MaxNum = 1,
			LimitGroup = 336,
			CltVersion = 0,
			CDKeyGiftType = 363,
			ApiID = 2,
			PreCode = "4399n9d18",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[364] = {
			MaxNum = 1,
			LimitGroup = 337,
			CltVersion = 0,
			CDKeyGiftType = 364,
			ApiID = 2,
			PreCode = "4399n9d19",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[365] = {
			MaxNum = 1,
			LimitGroup = 338,
			CltVersion = 0,
			CDKeyGiftType = 365,
			ApiID = 2,
			PreCode = "4399n9d20",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[366] = {
			MaxNum = 1,
			LimitGroup = 339,
			CltVersion = 0,
			CDKeyGiftType = 366,
			ApiID = 2,
			PreCode = "4399n9d21",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[367] = {
			MaxNum = 1,
			LimitGroup = 340,
			CltVersion = 0,
			CDKeyGiftType = 367,
			ApiID = 2,
			PreCode = "4399n9d22",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[368] = {
			MaxNum = 1,
			LimitGroup = 341,
			CltVersion = 0,
			CDKeyGiftType = 368,
			ApiID = 2,
			PreCode = "4399n9d23",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[369] = {
			MaxNum = 1,
			LimitGroup = 342,
			CltVersion = 0,
			CDKeyGiftType = 369,
			ApiID = 2,
			PreCode = "4399n9d24",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12955,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				50,
				0,
				0,
				0,
				0
			}
		},
		[370] = {
			MaxNum = 1,
			LimitGroup = 343,
			CltVersion = 0,
			CDKeyGiftType = 370,
			ApiID = 2,
			PreCode = "4399n9d25",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[371] = {
			MaxNum = 1,
			LimitGroup = 344,
			CltVersion = 0,
			CDKeyGiftType = 371,
			ApiID = 2,
			PreCode = "4399n9d26",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[372] = {
			MaxNum = 1,
			LimitGroup = 345,
			CltVersion = 0,
			CDKeyGiftType = 372,
			ApiID = 2,
			PreCode = "4399n9d27",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[373] = {
			MaxNum = 1,
			LimitGroup = 346,
			CltVersion = 0,
			CDKeyGiftType = 373,
			ApiID = 2,
			PreCode = "4399n9d28",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[374] = {
			MaxNum = 1,
			LimitGroup = 347,
			CltVersion = 0,
			CDKeyGiftType = 374,
			ApiID = 2,
			PreCode = "4399n9d29",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[375] = {
			MaxNum = 1,
			LimitGroup = 348,
			CltVersion = 0,
			CDKeyGiftType = 375,
			ApiID = 2,
			PreCode = "4399n9d30",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[376] = {
			MaxNum = 1,
			LimitGroup = 349,
			CltVersion = 0,
			CDKeyGiftType = 376,
			ApiID = 2,
			PreCode = "4399n9T",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[377] = {
			MaxNum = 1,
			LimitGroup = 350,
			CltVersion = 0,
			CDKeyGiftType = 377,
			ApiID = 2,
			PreCode = "43997D7m1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[378] = {
			MaxNum = 1,
			LimitGroup = 351,
			CltVersion = 0,
			CDKeyGiftType = 378,
			ApiID = 2,
			PreCode = "43997D7m2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[379] = {
			MaxNum = 1,
			LimitGroup = 352,
			CltVersion = 0,
			CDKeyGiftType = 379,
			ApiID = 2,
			PreCode = "43997D7m3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[380] = {
			MaxNum = 1,
			LimitGroup = 353,
			CltVersion = 0,
			CDKeyGiftType = 380,
			ApiID = 2,
			PreCode = "43997D7m4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[381] = {
			MaxNum = 1,
			LimitGroup = 354,
			CltVersion = 0,
			CDKeyGiftType = 381,
			ApiID = 2,
			PreCode = "43997D7m5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[382] = {
			MaxNum = 1,
			LimitGroup = 355,
			CltVersion = 0,
			CDKeyGiftType = 382,
			ApiID = 2,
			PreCode = "43997D7m6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[383] = {
			MaxNum = 1,
			LimitGroup = 356,
			CltVersion = 0,
			CDKeyGiftType = 383,
			ApiID = 2,
			PreCode = "43997D7m7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[384] = {
			MaxNum = 3,
			LimitGroup = 357,
			CltVersion = 0,
			CDKeyGiftType = 384,
			ApiID = 122,
			PreCode = "7k7kGZ",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				845,
				0,
				0
			},
			ItemNum = {
				120,
				2,
				1,
				0,
				0
			}
		},
		[385] = {
			MaxNum = 1,
			LimitGroup = 358,
			CltVersion = 0,
			CDKeyGiftType = 385,
			ApiID = 123,
			PreCode = "2144XS",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				12964,
				12981,
				0
			},
			ItemNum = {
				100,
				2,
				2,
				1,
				0
			}
		},
		[386] = {
			MaxNum = 1,
			LimitGroup = 359,
			CltVersion = 0,
			CDKeyGiftType = 386,
			ApiID = 123,
			PreCode = "21447D1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12833,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[387] = {
			MaxNum = 1,
			LimitGroup = 360,
			CltVersion = 0,
			CDKeyGiftType = 387,
			ApiID = 123,
			PreCode = "21447D2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[388] = {
			MaxNum = 1,
			LimitGroup = 361,
			CltVersion = 0,
			CDKeyGiftType = 388,
			ApiID = 123,
			PreCode = "21447D3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[389] = {
			MaxNum = 1,
			LimitGroup = 362,
			CltVersion = 0,
			CDKeyGiftType = 389,
			ApiID = 123,
			PreCode = "21447D4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[390] = {
			MaxNum = 1,
			LimitGroup = 363,
			CltVersion = 0,
			CDKeyGiftType = 390,
			ApiID = 123,
			PreCode = "21447D5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12999,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[391] = {
			MaxNum = 1,
			LimitGroup = 364,
			CltVersion = 0,
			CDKeyGiftType = 391,
			ApiID = 123,
			PreCode = "21447D6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12833,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[392] = {
			MaxNum = 1,
			LimitGroup = 365,
			CltVersion = 0,
			CDKeyGiftType = 392,
			ApiID = 123,
			PreCode = "21447D7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12988,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[393] = {
			MaxNum = 1,
			LimitGroup = 366,
			CltVersion = 0,
			CDKeyGiftType = 393,
			ApiID = 2,
			PreCode = "4399ZQD3Q1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[394] = {
			MaxNum = 1,
			LimitGroup = 367,
			CltVersion = 0,
			CDKeyGiftType = 394,
			ApiID = 2,
			PreCode = "4399ZQD3Q2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[395] = {
			MaxNum = 1,
			LimitGroup = 368,
			CltVersion = 0,
			CDKeyGiftType = 395,
			ApiID = 2,
			PreCode = "4399ZQD3Q3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[396] = {
			MaxNum = 1,
			LimitGroup = 369,
			CltVersion = 0,
			CDKeyGiftType = 396,
			ApiID = 2,
			PreCode = "4399ZQD3Q4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[397] = {
			MaxNum = 1,
			LimitGroup = 370,
			CltVersion = 0,
			CDKeyGiftType = 397,
			ApiID = 2,
			PreCode = "4399ZQD3Q5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[398] = {
			MaxNum = 1,
			LimitGroup = 371,
			CltVersion = 0,
			CDKeyGiftType = 398,
			ApiID = 2,
			PreCode = "4399ZQD3Q6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[399] = {
			MaxNum = 1,
			LimitGroup = 372,
			CltVersion = 0,
			CDKeyGiftType = 399,
			ApiID = 2,
			PreCode = "4399ZQD3Q7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[400] = {
			MaxNum = 1,
			LimitGroup = 373,
			CltVersion = 0,
			CDKeyGiftType = 400,
			ApiID = 2,
			PreCode = "4399ZQD4Q1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[401] = {
			MaxNum = 1,
			LimitGroup = 374,
			CltVersion = 0,
			CDKeyGiftType = 401,
			ApiID = 2,
			PreCode = "4399ZQD4Q2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[402] = {
			MaxNum = 1,
			LimitGroup = 375,
			CltVersion = 0,
			CDKeyGiftType = 402,
			ApiID = 2,
			PreCode = "4399ZQD4Q3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[403] = {
			MaxNum = 1,
			LimitGroup = 376,
			CltVersion = 0,
			CDKeyGiftType = 403,
			ApiID = 2,
			PreCode = "4399ZQD4Q4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[404] = {
			MaxNum = 1,
			LimitGroup = 377,
			CltVersion = 0,
			CDKeyGiftType = 404,
			ApiID = 2,
			PreCode = "4399ZQD4Q5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[405] = {
			MaxNum = 1,
			LimitGroup = 378,
			CltVersion = 0,
			CDKeyGiftType = 405,
			ApiID = 2,
			PreCode = "4399ZQD4Q6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[406] = {
			MaxNum = 1,
			LimitGroup = 379,
			CltVersion = 0,
			CDKeyGiftType = 406,
			ApiID = 2,
			PreCode = "4399ZQD4Q7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[407] = {
			MaxNum = 100,
			LimitGroup = 380,
			CltVersion = 0,
			CDKeyGiftType = 407,
			ApiID = 0,
			PreCode = "MNzhibo1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20031,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				100,
				0,
				0,
				0,
				0
			}
		},
		[408] = {
			MaxNum = 100,
			LimitGroup = 381,
			CltVersion = 0,
			CDKeyGiftType = 408,
			ApiID = 0,
			PreCode = "MNzhibo2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20032,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				100,
				0,
				0,
				0,
				0
			}
		},
		[409] = {
			MaxNum = 100,
			LimitGroup = 382,
			CltVersion = 0,
			CDKeyGiftType = 409,
			ApiID = 0,
			PreCode = "MNzhibo3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				20033,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				100,
				0,
				0,
				0,
				0
			}
		},
		[410] = {
			MaxNum = 100,
			LimitGroup = 383,
			CltVersion = 0,
			CDKeyGiftType = 410,
			ApiID = 0,
			PreCode = "MNzhibo4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				100,
				0,
				0,
				0,
				0
			}
		},
		[411] = {
			MaxNum = 100,
			LimitGroup = 384,
			CltVersion = 0,
			CDKeyGiftType = 411,
			ApiID = 0,
			PreCode = "MNzhibo5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				200,
				0,
				0,
				0,
				0
			}
		},
		[412] = {
			MaxNum = 100,
			LimitGroup = 385,
			CltVersion = 0,
			CDKeyGiftType = 412,
			ApiID = 0,
			PreCode = "MNzhibo6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				300,
				0,
				0,
				0,
				0
			}
		},
		[413] = {
			MaxNum = 100,
			LimitGroup = 386,
			CltVersion = 0,
			CDKeyGiftType = 413,
			ApiID = 0,
			PreCode = "MNzhibo7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				600,
				0,
				0,
				0,
				0
			}
		},
		[414] = {
			MaxNum = 1,
			LimitGroup = 387,
			CltVersion = 0,
			CDKeyGiftType = 414,
			ApiID = 2,
			PreCode = "4399ZQD5Q1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[415] = {
			MaxNum = 1,
			LimitGroup = 388,
			CltVersion = 0,
			CDKeyGiftType = 415,
			ApiID = 2,
			PreCode = "4399ZQD5Q2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[416] = {
			MaxNum = 1,
			LimitGroup = 389,
			CltVersion = 0,
			CDKeyGiftType = 416,
			ApiID = 2,
			PreCode = "4399ZQD5Q3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[417] = {
			MaxNum = 1,
			LimitGroup = 390,
			CltVersion = 0,
			CDKeyGiftType = 417,
			ApiID = 2,
			PreCode = "4399ZQD5Q4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[418] = {
			MaxNum = 1,
			LimitGroup = 391,
			CltVersion = 0,
			CDKeyGiftType = 418,
			ApiID = 2,
			PreCode = "4399ZQD5Q5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[419] = {
			MaxNum = 1,
			LimitGroup = 392,
			CltVersion = 0,
			CDKeyGiftType = 419,
			ApiID = 2,
			PreCode = "4399ZQD5Q6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[420] = {
			MaxNum = 1,
			LimitGroup = 393,
			CltVersion = 0,
			CDKeyGiftType = 420,
			ApiID = 2,
			PreCode = "4399ZQD5Q7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[421] = {
			MaxNum = 1,
			LimitGroup = 394,
			CltVersion = 0,
			CDKeyGiftType = 421,
			ApiID = 2,
			PreCode = "4399ZQD6Q1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[422] = {
			MaxNum = 1,
			LimitGroup = 395,
			CltVersion = 0,
			CDKeyGiftType = 422,
			ApiID = 2,
			PreCode = "4399ZQD6Q2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[423] = {
			MaxNum = 1,
			LimitGroup = 396,
			CltVersion = 0,
			CDKeyGiftType = 423,
			ApiID = 2,
			PreCode = "4399ZQD6Q3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[424] = {
			MaxNum = 1,
			LimitGroup = 397,
			CltVersion = 0,
			CDKeyGiftType = 424,
			ApiID = 2,
			PreCode = "4399ZQD6Q4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[425] = {
			MaxNum = 1,
			LimitGroup = 398,
			CltVersion = 0,
			CDKeyGiftType = 425,
			ApiID = 2,
			PreCode = "4399ZQD6Q5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[426] = {
			MaxNum = 1,
			LimitGroup = 399,
			CltVersion = 0,
			CDKeyGiftType = 426,
			ApiID = 2,
			PreCode = "4399ZQD6Q6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[427] = {
			MaxNum = 1,
			LimitGroup = 400,
			CltVersion = 0,
			CDKeyGiftType = 427,
			ApiID = 2,
			PreCode = "4399ZQD6Q7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[428] = {
			MaxNum = 1,
			LimitGroup = 401,
			CltVersion = 0,
			CDKeyGiftType = 428,
			ApiID = 21,
			PreCode = "YYBSJQD1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[429] = {
			MaxNum = 1,
			LimitGroup = 402,
			CltVersion = 0,
			CDKeyGiftType = 429,
			ApiID = 21,
			PreCode = "YYBSJQD2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[430] = {
			MaxNum = 1,
			LimitGroup = 403,
			CltVersion = 0,
			CDKeyGiftType = 430,
			ApiID = 21,
			PreCode = "YYBSJQD3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12964,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[431] = {
			MaxNum = 1,
			LimitGroup = 404,
			CltVersion = 0,
			CDKeyGiftType = 431,
			ApiID = 21,
			PreCode = "YYBSJQD4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[432] = {
			MaxNum = 1,
			LimitGroup = 405,
			CltVersion = 0,
			CDKeyGiftType = 432,
			ApiID = 21,
			PreCode = "YYBSJQD5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12831,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[433] = {
			MaxNum = 1,
			LimitGroup = 406,
			CltVersion = 0,
			CDKeyGiftType = 433,
			ApiID = 21,
			PreCode = "YYBSJQD6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				846,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[434] = {
			MaxNum = 1,
			LimitGroup = 407,
			CltVersion = 0,
			CDKeyGiftType = 434,
			ApiID = 21,
			PreCode = "YYBSJQD7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				150,
				0,
				0,
				0,
				0
			}
		},
		[435] = {
			MaxNum = 1,
			LimitGroup = 408,
			CltVersion = 0,
			CDKeyGiftType = 435,
			ApiID = 0,
			PreCode = "WDJSJ1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				0,
				0,
				0,
				0
			}
		},
		[436] = {
			MaxNum = 1,
			LimitGroup = 409,
			CltVersion = 0,
			CDKeyGiftType = 436,
			ApiID = 0,
			PreCode = "WDJSJ2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[437] = {
			MaxNum = 1,
			LimitGroup = 410,
			CltVersion = 0,
			CDKeyGiftType = 437,
			ApiID = 2,
			PreCode = "4399SJ1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		},
		[438] = {
			MaxNum = 1,
			LimitGroup = 411,
			CltVersion = 0,
			CDKeyGiftType = 438,
			ApiID = 121,
			PreCode = "4399PCQM1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12963,
				12964,
				12981,
				0
			},
			ItemNum = {
				100,
				2,
				2,
				7,
				0
			}
		},
		[439] = {
			MaxNum = 1,
			LimitGroup = 412,
			CltVersion = 0,
			CDKeyGiftType = 439,
			ApiID = 2,
			PreCode = "4399ZQD7Q1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[440] = {
			MaxNum = 1,
			LimitGroup = 413,
			CltVersion = 0,
			CDKeyGiftType = 440,
			ApiID = 2,
			PreCode = "4399ZQD7Q2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12962,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[441] = {
			MaxNum = 1,
			LimitGroup = 414,
			CltVersion = 0,
			CDKeyGiftType = 441,
			ApiID = 2,
			PreCode = "4399ZQD7Q3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[442] = {
			MaxNum = 1,
			LimitGroup = 415,
			CltVersion = 0,
			CDKeyGiftType = 442,
			ApiID = 2,
			PreCode = "4399ZQD7Q4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12961,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[443] = {
			MaxNum = 1,
			LimitGroup = 416,
			CltVersion = 0,
			CDKeyGiftType = 443,
			ApiID = 2,
			PreCode = "4399ZQD7Q5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[444] = {
			MaxNum = 1,
			LimitGroup = 417,
			CltVersion = 0,
			CDKeyGiftType = 444,
			ApiID = 2,
			PreCode = "4399ZQD7Q6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				845,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[445] = {
			MaxNum = 1,
			LimitGroup = 418,
			CltVersion = 0,
			CDKeyGiftType = 445,
			ApiID = 2,
			PreCode = "4399ZQD7Q7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[446] = {
			MaxNum = 1,
			LimitGroup = 419,
			CltVersion = 0,
			CDKeyGiftType = 446,
			ApiID = 2,
			PreCode = "4399n10d1",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12963,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				3,
				0,
				0,
				0,
				0
			}
		},
		[447] = {
			MaxNum = 1,
			LimitGroup = 420,
			CltVersion = 0,
			CDKeyGiftType = 447,
			ApiID = 2,
			PreCode = "4399n10d2",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[448] = {
			MaxNum = 1,
			LimitGroup = 421,
			CltVersion = 0,
			CDKeyGiftType = 448,
			ApiID = 2,
			PreCode = "4399n10d3",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12964,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				4,
				0,
				0,
				0,
				0
			}
		},
		[449] = {
			MaxNum = 1,
			LimitGroup = 422,
			CltVersion = 0,
			CDKeyGiftType = 449,
			ApiID = 2,
			PreCode = "4399n10d4",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[450] = {
			MaxNum = 1,
			LimitGroup = 423,
			CltVersion = 0,
			CDKeyGiftType = 450,
			ApiID = 2,
			PreCode = "4399n10d5",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12831,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				5,
				0,
				0,
				0,
				0
			}
		},
		[451] = {
			MaxNum = 1,
			LimitGroup = 424,
			CltVersion = 0,
			CDKeyGiftType = 451,
			ApiID = 2,
			PreCode = "4399n10d6",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[452] = {
			MaxNum = 1,
			LimitGroup = 425,
			CltVersion = 0,
			CDKeyGiftType = 452,
			ApiID = 2,
			PreCode = "4399n10d7",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[453] = {
			MaxNum = 1,
			LimitGroup = 426,
			CltVersion = 0,
			CDKeyGiftType = 453,
			ApiID = 2,
			PreCode = "4399n10d8",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[454] = {
			MaxNum = 1,
			LimitGroup = 427,
			CltVersion = 0,
			CDKeyGiftType = 454,
			ApiID = 2,
			PreCode = "4399n10d9",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12255,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[455] = {
			MaxNum = 1,
			LimitGroup = 428,
			CltVersion = 0,
			CDKeyGiftType = 455,
			ApiID = 2,
			PreCode = "4399n10d10",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[456] = {
			MaxNum = 1,
			LimitGroup = 429,
			CltVersion = 0,
			CDKeyGiftType = 456,
			ApiID = 2,
			PreCode = "4399n10d11",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[457] = {
			MaxNum = 1,
			LimitGroup = 430,
			CltVersion = 0,
			CDKeyGiftType = 457,
			ApiID = 2,
			PreCode = "4399n10d12",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[458] = {
			MaxNum = 1,
			LimitGroup = 431,
			CltVersion = 0,
			CDKeyGiftType = 458,
			ApiID = 2,
			PreCode = "4399n10d13",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[459] = {
			MaxNum = 1,
			LimitGroup = 432,
			CltVersion = 0,
			CDKeyGiftType = 459,
			ApiID = 2,
			PreCode = "4399n10d14",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				1,
				0,
				0,
				0,
				0
			}
		},
		[460] = {
			MaxNum = 1,
			LimitGroup = 433,
			CltVersion = 0,
			CDKeyGiftType = 460,
			ApiID = 2,
			PreCode = "4399n10d15",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12960,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				30,
				0,
				0,
				0,
				0
			}
		},
		[461] = {
			MaxNum = 1,
			LimitGroup = 434,
			CltVersion = 0,
			CDKeyGiftType = 461,
			ApiID = 2,
			PreCode = "4399n10d16",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[462] = {
			MaxNum = 1,
			LimitGroup = 435,
			CltVersion = 0,
			CDKeyGiftType = 462,
			ApiID = 2,
			PreCode = "4399n10d17",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[463] = {
			MaxNum = 1,
			LimitGroup = 436,
			CltVersion = 0,
			CDKeyGiftType = 463,
			ApiID = 2,
			PreCode = "4399n10d18",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[464] = {
			MaxNum = 1,
			LimitGroup = 437,
			CltVersion = 0,
			CDKeyGiftType = 464,
			ApiID = 2,
			PreCode = "4399n10d19",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[465] = {
			MaxNum = 1,
			LimitGroup = 438,
			CltVersion = 0,
			CDKeyGiftType = 465,
			ApiID = 2,
			PreCode = "4399n10d20",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[466] = {
			MaxNum = 1,
			LimitGroup = 439,
			CltVersion = 0,
			CDKeyGiftType = 466,
			ApiID = 2,
			PreCode = "4399n10d21",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[467] = {
			MaxNum = 1,
			LimitGroup = 440,
			CltVersion = 0,
			CDKeyGiftType = 467,
			ApiID = 2,
			PreCode = "4399n10d22",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[468] = {
			MaxNum = 1,
			LimitGroup = 441,
			CltVersion = 0,
			CDKeyGiftType = 468,
			ApiID = 2,
			PreCode = "4399n10d23",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[469] = {
			MaxNum = 1,
			LimitGroup = 442,
			CltVersion = 0,
			CDKeyGiftType = 469,
			ApiID = 2,
			PreCode = "4399n10d24",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12955,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				50,
				0,
				0,
				0,
				0
			}
		},
		[470] = {
			MaxNum = 1,
			LimitGroup = 443,
			CltVersion = 0,
			CDKeyGiftType = 470,
			ApiID = 2,
			PreCode = "4399n10d25",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[471] = {
			MaxNum = 1,
			LimitGroup = 444,
			CltVersion = 0,
			CDKeyGiftType = 471,
			ApiID = 2,
			PreCode = "4399n10d26",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[472] = {
			MaxNum = 1,
			LimitGroup = 445,
			CltVersion = 0,
			CDKeyGiftType = 472,
			ApiID = 2,
			PreCode = "4399n10d27",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[473] = {
			MaxNum = 1,
			LimitGroup = 446,
			CltVersion = 0,
			CDKeyGiftType = 473,
			ApiID = 2,
			PreCode = "4399n10d28",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[474] = {
			MaxNum = 1,
			LimitGroup = 447,
			CltVersion = 0,
			CDKeyGiftType = 474,
			ApiID = 2,
			PreCode = "4399n10d29",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[475] = {
			MaxNum = 1,
			LimitGroup = 448,
			CltVersion = 0,
			CDKeyGiftType = 475,
			ApiID = 2,
			PreCode = "4399n10d30",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				12928,
				0,
				0,
				0,
				0
			},
			ItemNum = {
				2,
				0,
				0,
				0,
				0
			}
		},
		[476] = {
			MaxNum = 1,
			LimitGroup = 449,
			CltVersion = 0,
			CDKeyGiftType = 476,
			ApiID = 2,
			PreCode = "4399n10FS",
			MiniCoin = 0,
			MiniBean = 0,
			ItemID = {
				10000,
				12981,
				0,
				0,
				0
			},
			ItemNum = {
				60,
				3,
				0,
				0,
				0
			}
		}
	},
	FirstWeekGiftDef = {
		[0] = {
			CltVersion = 0,
			ItemID = 12963,
			Num = 2,
			DayID = 0
		},
		{
			CltVersion = 0,
			ItemID = 12964,
			Num = 2,
			DayID = 1
		},
		{
			CltVersion = 0,
			ItemID = 845,
			Num = 2,
			DayID = 2
		},
		{
			CltVersion = 0,
			ItemID = 12831,
			Num = 1,
			DayID = 3
		},
		{
			CltVersion = 0,
			ItemID = 12833,
			Num = 2,
			DayID = 4
		},
		{
			CltVersion = 0,
			ItemID = 12988,
			Num = 1,
			DayID = 5
		},
		{
			CltVersion = 0,
			ItemID = 12949,
			Num = 1,
			DayID = 6
		}
	},
	ItemConvertDef = {
		[10031] = {
			FragmentID = 10032,
			ItemNum = 5,
			ItemID = 10031,
			ItemType = 2,
			FragmentNum = 1
		},
		[10032] = {
			FragmentID = "",
			ItemNum = 0,
			ItemID = 10032,
			ItemType = "",
			FragmentNum = 0
		},
		[20031] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 20031,
			ItemType = 1,
			FragmentNum = 1
		},
		[20032] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 20032,
			ItemType = 1,
			FragmentNum = 1
		},
		[20033] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 20033,
			ItemType = 1,
			FragmentNum = 1
		},
		[20034] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 20034,
			ItemType = 1,
			FragmentNum = 1
		},
		[20036] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 20036,
			ItemType = 1,
			FragmentNum = 1
		},
		[20038] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 20038,
			ItemType = 1,
			FragmentNum = 1
		},
		[24800] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24800,
			ItemType = 2,
			FragmentNum = 1
		},
		[24801] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24801,
			ItemType = 2,
			FragmentNum = 1
		},
		[24804] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24804,
			ItemType = 2,
			FragmentNum = 1
		},
		[24809] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24809,
			ItemType = 2,
			FragmentNum = 1
		},
		[24811] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24811,
			ItemType = 2,
			FragmentNum = 1
		},
		[24815] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24815,
			ItemType = 2,
			FragmentNum = 1
		},
		[24816] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 24816,
			ItemType = 1,
			FragmentNum = 1
		},
		[24817] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 24817,
			ItemType = 1,
			FragmentNum = 1
		},
		[24818] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24818,
			ItemType = 2,
			FragmentNum = 1
		},
		[24819] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24819,
			ItemType = 2,
			FragmentNum = 1
		},
		[24820] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 24820,
			ItemType = 2,
			FragmentNum = 1
		},
		[25001] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25001,
			ItemType = 2,
			FragmentNum = 1
		},
		[25002] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25002,
			ItemType = 2,
			FragmentNum = 1
		},
		[25003] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25003,
			ItemType = 1,
			FragmentNum = 1
		},
		[25005] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25005,
			ItemType = 1,
			FragmentNum = 1
		},
		[25007] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25007,
			ItemType = 2,
			FragmentNum = 1
		},
		[25009] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25009,
			ItemType = 2,
			FragmentNum = 1
		},
		[25010] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25010,
			ItemType = 1,
			FragmentNum = 1
		},
		[25011] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25011,
			ItemType = 2,
			FragmentNum = 1
		},
		[25012] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25012,
			ItemType = 2,
			FragmentNum = 1
		},
		[25013] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25013,
			ItemType = 2,
			FragmentNum = 1
		},
		[25014] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25014,
			ItemType = 2,
			FragmentNum = 1
		},
		[25015] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25015,
			ItemType = 2,
			FragmentNum = 1
		},
		[25016] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25016,
			ItemType = 2,
			FragmentNum = 1
		},
		[25017] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25017,
			ItemType = 1,
			FragmentNum = 1
		},
		[25018] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25018,
			ItemType = 2,
			FragmentNum = 1
		},
		[25019] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25019,
			ItemType = 2,
			FragmentNum = 1
		},
		[25020] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25020,
			ItemType = 2,
			FragmentNum = 1
		},
		[25021] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25021,
			ItemType = 1,
			FragmentNum = 1
		},
		[25022] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25022,
			ItemType = 2,
			FragmentNum = 1
		},
		[25023] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25023,
			ItemType = 2,
			FragmentNum = 1
		},
		[25024] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25024,
			ItemType = 2,
			FragmentNum = 1
		},
		[25026] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25026,
			ItemType = 2,
			FragmentNum = 1
		},
		[25027] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25027,
			ItemType = 2,
			FragmentNum = 1
		},
		[25028] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25028,
			ItemType = 2,
			FragmentNum = 1
		},
		[25029] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25029,
			ItemType = 2,
			FragmentNum = 1
		},
		[25030] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25030,
			ItemType = 2,
			FragmentNum = 1
		},
		[25031] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25031,
			ItemType = 1,
			FragmentNum = 1
		},
		[25032] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25032,
			ItemType = 1,
			FragmentNum = 1
		},
		[25033] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25033,
			ItemType = 2,
			FragmentNum = 1
		},
		[25034] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25034,
			ItemType = 2,
			FragmentNum = 1
		},
		[25035] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25035,
			ItemType = 2,
			FragmentNum = 1
		},
		[25036] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25036,
			ItemType = 1,
			FragmentNum = 1
		},
		[25037] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25037,
			ItemType = 2,
			FragmentNum = 1
		},
		[25038] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25038,
			ItemType = 2,
			FragmentNum = 1
		},
		[25039] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25039,
			ItemType = 2,
			FragmentNum = 1
		},
		[25040] = {
			FragmentID = 10032,
			ItemNum = 3,
			ItemID = 25040,
			ItemType = 2,
			FragmentNum = 1
		},
		[25041] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25041,
			ItemType = 1,
			FragmentNum = 1
		},
		[25042] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25042,
			ItemType = 1,
			FragmentNum = 1
		},
		[25043] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25043,
			ItemType = 1,
			FragmentNum = 1
		},
		[25044] = {
			FragmentID = 10031,
			ItemNum = 10,
			ItemID = 25044,
			ItemType = 1,
			FragmentNum = 1
		}
	},
	ItemCostDef = {
		[845] = {
			Cost = 10,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 845,
			CltVersion = 0,
			MiniBean = 0
		},
		[846] = {
			Cost = 20,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 846,
			CltVersion = 0,
			MiniBean = 0
		},
		[1055] = {
			Cost = 10,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 1055,
			CltVersion = 0,
			MiniBean = 0
		},
		[1056] = {
			Cost = 20,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 1056,
			CltVersion = 0,
			MiniBean = 0
		},
		[10023] = {
			Cost = 25,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 10023,
			CltVersion = 0,
			MiniBean = 0
		},
		[10025] = {
			Cost = 20,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 10025,
			CltVersion = 0,
			MiniBean = 0
		},
		[12750] = {
			Cost = 50,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 12750,
			CltVersion = 0,
			MiniBean = 300
		},
		[12751] = {
			Cost = 20,
			PresentItem = 10010,
			PresentNum = 1,
			ItemID = 12751,
			CltVersion = 0,
			MiniBean = 0
		},
		[12752] = {
			Cost = 20,
			PresentItem = 10012,
			PresentNum = 1,
			ItemID = 12752,
			CltVersion = 0,
			MiniBean = 0
		},
		[12831] = {
			Cost = 15,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 12831,
			CltVersion = 0,
			MiniBean = 0
		},
		[12856] = {
			Cost = 300,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 12856,
			CltVersion = 0,
			MiniBean = 0
		},
		[12965] = {
			Cost = 20,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 12965,
			CltVersion = 0,
			MiniBean = 0
		},
		[24601] = {
			Cost = 188,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 24601,
			CltVersion = 0,
			MiniBean = 0
		},
		[43001] = {
			Cost = 30,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 43001,
			CltVersion = 0,
			MiniBean = 0
		},
		[43002] = {
			Cost = 18,
			PresentItem = "",
			PresentNum = 0,
			ItemID = 43002,
			CltVersion = 0,
			MiniBean = 0
		}
	},
	ItemModelRelaceDef = {},
	ItemReclaimDef = {
		[10009] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 10009,
			TreeExp = 0,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[10043] = {
			UnlockID = 1,
			UnlockType = 5,
			ItemID = 10043,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12950] = {
			UnlockID = 1,
			UnlockType = 5,
			ItemID = 12950,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12951] = {
			UnlockID = 7,
			UnlockType = 5,
			ItemID = 12951,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12952] = {
			UnlockID = 2,
			UnlockType = 5,
			ItemID = 12952,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12953] = {
			UnlockID = 8,
			UnlockType = 5,
			ItemID = 12953,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12954] = {
			UnlockID = 6,
			UnlockType = 5,
			ItemID = 12954,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12955] = {
			UnlockID = 4,
			UnlockType = 5,
			ItemID = 12955,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12956] = {
			UnlockID = 9,
			UnlockType = 5,
			ItemID = 12956,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12957] = {
			UnlockID = 5,
			UnlockType = 5,
			ItemID = 12957,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12958] = {
			UnlockID = 10,
			UnlockType = 5,
			ItemID = 12958,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12959] = {
			UnlockID = 3,
			UnlockType = 5,
			ItemID = 12959,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 2,
			GenItemID = 10000
		},
		[12960] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 12960,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20000] = {
			UnlockID = 854,
			UnlockType = 6,
			ItemID = 20000,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20001] = {
			UnlockID = 855,
			UnlockType = 6,
			ItemID = 20001,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20002] = {
			UnlockID = 856,
			UnlockType = 6,
			ItemID = 20002,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20003] = {
			UnlockID = 857,
			UnlockType = 6,
			ItemID = 20003,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20004] = {
			UnlockID = 858,
			UnlockType = 6,
			ItemID = 20004,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20005] = {
			UnlockID = 859,
			UnlockType = 6,
			ItemID = 20005,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20006] = {
			UnlockID = 860,
			UnlockType = 6,
			ItemID = 20006,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20007] = {
			UnlockID = 861,
			UnlockType = 6,
			ItemID = 20007,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20008] = {
			UnlockID = 862,
			UnlockType = 6,
			ItemID = 20008,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20009] = {
			UnlockID = 863,
			UnlockType = 6,
			ItemID = 20009,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20010] = {
			UnlockID = 864,
			UnlockType = 6,
			ItemID = 20010,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20011] = {
			UnlockID = 865,
			UnlockType = 6,
			ItemID = 20011,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20012] = {
			UnlockID = 866,
			UnlockType = 6,
			ItemID = 20012,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20013] = {
			UnlockID = 867,
			UnlockType = 6,
			ItemID = 20013,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20014] = {
			UnlockID = 868,
			UnlockType = 6,
			ItemID = 20014,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20015] = {
			UnlockID = 869,
			UnlockType = 6,
			ItemID = 20015,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20016] = {
			UnlockID = 870,
			UnlockType = 6,
			ItemID = 20016,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20017] = {
			UnlockID = 871,
			UnlockType = 6,
			ItemID = 20017,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20018] = {
			UnlockID = 872,
			UnlockType = 6,
			ItemID = 20018,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20019] = {
			UnlockID = 873,
			UnlockType = 6,
			ItemID = 20019,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20020] = {
			UnlockID = 874,
			UnlockType = 6,
			ItemID = 20020,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20021] = {
			UnlockID = 875,
			UnlockType = 6,
			ItemID = 20021,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20022] = {
			UnlockID = 876,
			UnlockType = 6,
			ItemID = 20022,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20023] = {
			UnlockID = 877,
			UnlockType = 6,
			ItemID = 20023,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20024] = {
			UnlockID = 960,
			UnlockType = 6,
			ItemID = 20024,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20025] = {
			UnlockID = 961,
			UnlockType = 6,
			ItemID = 20025,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20026] = {
			UnlockID = 962,
			UnlockType = 6,
			ItemID = 20026,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20027] = {
			UnlockID = 963,
			UnlockType = 6,
			ItemID = 20027,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20028] = {
			UnlockID = 964,
			UnlockType = 6,
			ItemID = 20028,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20029] = {
			UnlockID = 5,
			UnlockType = 3,
			ItemID = 20029,
			TreeExp = 3,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20030] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20030,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20031] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20031,
			TreeExp = 3,
			OneStep = "",
			GenItemNum = 5,
			GenItemID = 10000
		},
		[20032] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20032,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20033] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20033,
			TreeExp = 3,
			OneStep = "",
			GenItemNum = 5,
			GenItemID = 10000
		},
		[20034] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20034,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20035] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20035,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20036] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20036,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 2,
			GenItemID = 10000
		},
		[20037] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20037,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20038] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20038,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 2,
			GenItemID = 10000
		},
		[20039] = {
			UnlockID = 883,
			UnlockType = 6,
			ItemID = 20039,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20040] = {
			UnlockID = 884,
			UnlockType = 6,
			ItemID = 20040,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20041] = {
			UnlockID = 885,
			UnlockType = 6,
			ItemID = 20041,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20042] = {
			UnlockID = 965,
			UnlockType = 6,
			ItemID = 20042,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20043] = {
			UnlockID = 966,
			UnlockType = 6,
			ItemID = 20043,
			TreeExp = 2,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20044] = {
			UnlockID = 967,
			UnlockType = 6,
			ItemID = 20044,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20045] = {
			UnlockID = 968,
			UnlockType = 6,
			ItemID = 20045,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20046] = {
			UnlockID = 969,
			UnlockType = 6,
			ItemID = 20046,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20047] = {
			UnlockID = 970,
			UnlockType = 6,
			ItemID = 20047,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20048] = {
			UnlockID = 971,
			UnlockType = 6,
			ItemID = 20048,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20049] = {
			UnlockID = 972,
			UnlockType = 6,
			ItemID = 20049,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20050] = {
			UnlockID = 973,
			UnlockType = 6,
			ItemID = 20050,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20051] = {
			UnlockID = 974,
			UnlockType = 6,
			ItemID = 20051,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20052] = {
			UnlockID = 975,
			UnlockType = 6,
			ItemID = 20052,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20053] = {
			UnlockID = 976,
			UnlockType = 6,
			ItemID = 20053,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20054] = {
			UnlockID = 977,
			UnlockType = 6,
			ItemID = 20054,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20055] = {
			UnlockID = 978,
			UnlockType = 6,
			ItemID = 20055,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20056] = {
			UnlockID = 979,
			UnlockType = 6,
			ItemID = 20056,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20057] = {
			UnlockID = 886,
			UnlockType = 6,
			ItemID = 20057,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20058] = {
			UnlockID = 888,
			UnlockType = 6,
			ItemID = 20058,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20059] = {
			UnlockID = 890,
			UnlockType = 6,
			ItemID = 20059,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 8,
			GenItemID = 10000
		},
		[20060] = {
			UnlockID = 6,
			UnlockType = 3,
			ItemID = 20060,
			TreeExp = 3,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20061] = {
			UnlockID = 7,
			UnlockType = 3,
			ItemID = 20061,
			TreeExp = 3,
			OneStep = 1,
			GenItemNum = 3,
			GenItemID = 10000
		},
		[20062] = {
			UnlockID = 12280,
			UnlockType = 6,
			ItemID = 20062,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20063] = {
			UnlockID = 12281,
			UnlockType = 6,
			ItemID = 20063,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20064] = {
			UnlockID = 12283,
			UnlockType = 6,
			ItemID = 20064,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 16,
			GenItemID = 10000
		},
		[20065] = {
			UnlockID = 12284,
			UnlockType = 6,
			ItemID = 20065,
			TreeExp = 0,
			OneStep = 1,
			GenItemNum = 0,
			GenItemID = 10000
		},
		[20066] = {
			UnlockID = 892,
			UnlockType = 6,
			ItemID = 20066,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20067] = {
			UnlockID = 893,
			UnlockType = 6,
			ItemID = 20067,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20068] = {
			UnlockID = 894,
			UnlockType = 6,
			ItemID = 20068,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20069] = {
			UnlockID = 895,
			UnlockType = 6,
			ItemID = 20069,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20070] = {
			UnlockID = 896,
			UnlockType = 6,
			ItemID = 20070,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20071] = {
			UnlockID = 897,
			UnlockType = 6,
			ItemID = 20071,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20072] = {
			UnlockID = 898,
			UnlockType = 6,
			ItemID = 20072,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20073] = {
			UnlockID = 899,
			UnlockType = 6,
			ItemID = 20073,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20074] = {
			UnlockID = 900,
			UnlockType = 6,
			ItemID = 20074,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20075] = {
			UnlockID = 926,
			UnlockType = 6,
			ItemID = 20075,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20076] = {
			UnlockID = 927,
			UnlockType = 6,
			ItemID = 20076,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20077] = {
			UnlockID = 928,
			UnlockType = 6,
			ItemID = 20077,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20078] = {
			UnlockID = 929,
			UnlockType = 6,
			ItemID = 20078,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20079] = {
			UnlockID = 931,
			UnlockType = 6,
			ItemID = 20079,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20080] = {
			UnlockID = 933,
			UnlockType = 6,
			ItemID = 20080,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20081] = {
			UnlockID = 934,
			UnlockType = 6,
			ItemID = 20081,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20082] = {
			UnlockID = 935,
			UnlockType = 6,
			ItemID = 20082,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20083] = {
			UnlockID = 936,
			UnlockType = 6,
			ItemID = 20083,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20084] = {
			UnlockID = 881,
			UnlockType = 6,
			ItemID = 20084,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20085] = {
			UnlockID = 940,
			UnlockType = 6,
			ItemID = 20085,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20086] = {
			UnlockID = 941,
			UnlockType = 6,
			ItemID = 20086,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20087] = {
			UnlockID = 942,
			UnlockType = 6,
			ItemID = 20087,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20088] = {
			UnlockID = 943,
			UnlockType = 6,
			ItemID = 20088,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20089] = {
			UnlockID = 945,
			UnlockType = 6,
			ItemID = 20089,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20090] = {
			UnlockID = 946,
			UnlockType = 6,
			ItemID = 20090,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20091] = {
			UnlockID = 947,
			UnlockType = 6,
			ItemID = 20091,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20092] = {
			UnlockID = 948,
			UnlockType = 6,
			ItemID = 20092,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20093] = {
			UnlockID = 949,
			UnlockType = 6,
			ItemID = 20093,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20094] = {
			UnlockID = 12253,
			UnlockType = 6,
			ItemID = 20094,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20095] = {
			UnlockID = 12830,
			UnlockType = 6,
			ItemID = 20095,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20096] = {
			UnlockID = 13808,
			UnlockType = 6,
			ItemID = 20096,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20097] = {
			UnlockID = 419,
			UnlockType = 6,
			ItemID = 20097,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20098] = {
			UnlockID = 420,
			UnlockType = 6,
			ItemID = 20098,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20099] = {
			UnlockID = 424,
			UnlockType = 6,
			ItemID = 20099,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20100] = {
			UnlockID = 427,
			UnlockType = 6,
			ItemID = 20100,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20101] = {
			UnlockID = 428,
			UnlockType = 6,
			ItemID = 20101,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20102] = {
			UnlockID = 429,
			UnlockType = 6,
			ItemID = 20102,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20103] = {
			UnlockID = 539,
			UnlockType = 6,
			ItemID = 20103,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20104] = {
			UnlockID = 551,
			UnlockType = 6,
			ItemID = 20104,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20105] = {
			UnlockID = 552,
			UnlockType = 6,
			ItemID = 20105,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20106] = {
			UnlockID = 553,
			UnlockType = 6,
			ItemID = 20106,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20107] = {
			UnlockID = 554,
			UnlockType = 6,
			ItemID = 20107,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20108] = {
			UnlockID = 13609,
			UnlockType = 6,
			ItemID = 20108,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20109] = {
			UnlockID = 13610,
			UnlockType = 6,
			ItemID = 20109,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20110] = {
			UnlockID = 13611,
			UnlockType = 6,
			ItemID = 20110,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 40,
			GenItemID = 10000
		},
		[20111] = {
			UnlockID = 1101,
			UnlockType = 6,
			ItemID = 20111,
			TreeExp = 25,
			OneStep = 1,
			GenItemNum = 60,
			GenItemID = 10000
		},
		[20112] = {
			UnlockID = 1102,
			UnlockType = 6,
			ItemID = 20112,
			TreeExp = 10,
			OneStep = 1,
			GenItemNum = 24,
			GenItemID = 10000
		},
		[20113] = {
			UnlockID = 1103,
			UnlockType = 6,
			ItemID = 20113,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 36,
			GenItemID = 10000
		},
		[20114] = {
			UnlockID = 1104,
			UnlockType = 6,
			ItemID = 20114,
			TreeExp = 25,
			OneStep = 1,
			GenItemNum = 60,
			GenItemID = 10000
		},
		[20115] = {
			UnlockID = 1105,
			UnlockType = 6,
			ItemID = 20115,
			TreeExp = 10,
			OneStep = 1,
			GenItemNum = 24,
			GenItemID = 10000
		},
		[20116] = {
			UnlockID = 1106,
			UnlockType = 6,
			ItemID = 20116,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 36,
			GenItemID = 10000
		},
		[20117] = {
			UnlockID = 1107,
			UnlockType = 6,
			ItemID = 20117,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 36,
			GenItemID = 10000
		},
		[20118] = {
			UnlockID = 1108,
			UnlockType = 6,
			ItemID = 20118,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20119] = {
			UnlockID = 1109,
			UnlockType = 6,
			ItemID = 20119,
			TreeExp = 10,
			OneStep = 1,
			GenItemNum = 24,
			GenItemID = 10000
		},
		[20120] = {
			UnlockID = 1110,
			UnlockType = 6,
			ItemID = 20120,
			TreeExp = 20,
			OneStep = 1,
			GenItemNum = 48,
			GenItemID = 10000
		},
		[20121] = {
			UnlockID = 1111,
			UnlockType = 6,
			ItemID = 20121,
			TreeExp = 25,
			OneStep = 1,
			GenItemNum = 60,
			GenItemID = 10000
		},
		[20122] = {
			UnlockID = 1112,
			UnlockType = 6,
			ItemID = 20122,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20123] = {
			UnlockID = 1113,
			UnlockType = 6,
			ItemID = 20123,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20124] = {
			UnlockID = 1114,
			UnlockType = 6,
			ItemID = 20124,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20125] = {
			UnlockID = 1115,
			UnlockType = 6,
			ItemID = 20125,
			TreeExp = 10,
			OneStep = 1,
			GenItemNum = 24,
			GenItemID = 10000
		},
		[20126] = {
			UnlockID = 1116,
			UnlockType = 6,
			ItemID = 20126,
			TreeExp = 10,
			OneStep = 1,
			GenItemNum = 24,
			GenItemID = 10000
		},
		[20127] = {
			UnlockID = 1117,
			UnlockType = 6,
			ItemID = 20127,
			TreeExp = 15,
			OneStep = 1,
			GenItemNum = 36,
			GenItemID = 10000
		},
		[20128] = {
			UnlockID = 1118,
			UnlockType = 6,
			ItemID = 20128,
			TreeExp = 20,
			OneStep = 1,
			GenItemNum = 48,
			GenItemID = 10000
		},
		[20129] = {
			UnlockID = 1119,
			UnlockType = 6,
			ItemID = 20129,
			TreeExp = 10,
			OneStep = 1,
			GenItemNum = 24,
			GenItemID = 10000
		},
		[20130] = {
			UnlockID = 1120,
			UnlockType = 6,
			ItemID = 20130,
			TreeExp = 30,
			OneStep = 1,
			GenItemNum = 72,
			GenItemID = 10000
		},
		[20131] = {
			UnlockID = 12589,
			UnlockType = 6,
			ItemID = 20131,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20132] = {
			UnlockID = 15506,
			UnlockType = 6,
			ItemID = 20132,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20133] = {
			UnlockID = 15507,
			UnlockType = 6,
			ItemID = 20133,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20134] = {
			UnlockID = 15508,
			UnlockType = 6,
			ItemID = 20134,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20135] = {
			UnlockID = 12291,
			UnlockType = 6,
			ItemID = 20135,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20136] = {
			UnlockID = 15519,
			UnlockType = 6,
			ItemID = 20136,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20137] = {
			UnlockID = 15520,
			UnlockType = 6,
			ItemID = 20137,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20138] = {
			UnlockID = 1060,
			UnlockType = 6,
			ItemID = 20138,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 15,
			GenItemID = 10000
		},
		[20139] = {
			UnlockID = 1136,
			UnlockType = 6,
			ItemID = 20139,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20140] = {
			UnlockID = 1137,
			UnlockType = 6,
			ItemID = 20140,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 12,
			GenItemID = 10000
		},
		[20142] = {
			UnlockID = 1159,
			UnlockType = 6,
			ItemID = 20142,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 5,
			GenItemID = 10000
		},
		[20143] = {
			UnlockID = 1160,
			UnlockType = 6,
			ItemID = 20143,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 5,
			GenItemID = 10000
		},
		[20144] = {
			UnlockID = 1161,
			UnlockType = 6,
			ItemID = 20144,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 5,
			GenItemID = 10000
		},
		[20145] = {
			UnlockID = 1164,
			UnlockType = 6,
			ItemID = 20145,
			TreeExp = 5,
			OneStep = 1,
			GenItemNum = 5,
			GenItemID = 10000
		},
		[20147] = {
			UnlockID = 1145,
			UnlockType = 6,
			ItemID = 20147,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20148] = {
			UnlockID = 1749,
			UnlockType = 6,
			ItemID = 20148,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20149] = {
			UnlockID = 1747,
			UnlockType = 6,
			ItemID = 20149,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20150] = {
			UnlockID = 1748,
			UnlockType = 6,
			ItemID = 20150,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20151] = {
			UnlockID = 1750,
			UnlockType = 6,
			ItemID = 20151,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20152] = {
			UnlockID = 1751,
			UnlockType = 6,
			ItemID = 20152,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20153] = {
			UnlockID = 1752,
			UnlockType = 6,
			ItemID = 20153,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20154] = {
			UnlockID = 12301,
			UnlockType = 6,
			ItemID = 20154,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20155] = {
			UnlockID = 12302,
			UnlockType = 6,
			ItemID = 20155,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20156] = {
			UnlockID = 12303,
			UnlockType = 6,
			ItemID = 20156,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20157] = {
			UnlockID = 12304,
			UnlockType = 6,
			ItemID = 20157,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20158] = {
			UnlockID = 12305,
			UnlockType = 6,
			ItemID = 20158,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20159] = {
			UnlockID = 12306,
			UnlockType = 6,
			ItemID = 20159,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20160] = {
			UnlockID = 12307,
			UnlockType = 6,
			ItemID = 20160,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20161] = {
			UnlockID = 1816,
			UnlockType = 6,
			ItemID = 20161,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20162] = {
			UnlockID = 1817,
			UnlockType = 6,
			ItemID = 20162,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20163] = {
			UnlockID = 1818,
			UnlockType = 6,
			ItemID = 20163,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20164] = {
			UnlockID = 1819,
			UnlockType = 6,
			ItemID = 20164,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20165] = {
			UnlockID = 1820,
			UnlockType = 6,
			ItemID = 20165,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20166] = {
			UnlockID = 1821,
			UnlockType = 6,
			ItemID = 20166,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20167] = {
			UnlockID = 1822,
			UnlockType = 6,
			ItemID = 20167,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20168] = {
			UnlockID = 1823,
			UnlockType = 6,
			ItemID = 20168,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20169] = {
			UnlockID = 1824,
			UnlockType = 6,
			ItemID = 20169,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20170] = {
			UnlockID = 1825,
			UnlockType = 6,
			ItemID = 20170,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20171] = {
			UnlockID = 1826,
			UnlockType = 6,
			ItemID = 20171,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20172] = {
			UnlockID = 1827,
			UnlockType = 6,
			ItemID = 20172,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20173] = {
			UnlockID = 1828,
			UnlockType = 6,
			ItemID = 20173,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20174] = {
			UnlockID = 1829,
			UnlockType = 6,
			ItemID = 20174,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20175] = {
			UnlockID = 1830,
			UnlockType = 6,
			ItemID = 20175,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20176] = {
			UnlockID = 1831,
			UnlockType = 6,
			ItemID = 20176,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20177] = {
			UnlockID = 1832,
			UnlockType = 6,
			ItemID = 20177,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20178] = {
			UnlockID = 1833,
			UnlockType = 6,
			ItemID = 20178,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20179] = {
			UnlockID = 1834,
			UnlockType = 6,
			ItemID = 20179,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20180] = {
			UnlockID = 1835,
			UnlockType = 6,
			ItemID = 20180,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20181] = {
			UnlockID = 1836,
			UnlockType = 6,
			ItemID = 20181,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20182] = {
			UnlockID = 1837,
			UnlockType = 6,
			ItemID = 20182,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20183] = {
			UnlockID = 1838,
			UnlockType = 6,
			ItemID = 20183,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20184] = {
			UnlockID = 1839,
			UnlockType = 6,
			ItemID = 20184,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20185] = {
			UnlockID = 1840,
			UnlockType = 6,
			ItemID = 20185,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20186] = {
			UnlockID = 1841,
			UnlockType = 6,
			ItemID = 20186,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20187] = {
			UnlockID = 1842,
			UnlockType = 6,
			ItemID = 20187,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20188] = {
			UnlockID = 1843,
			UnlockType = 6,
			ItemID = 20188,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20189] = {
			UnlockID = 1844,
			UnlockType = 6,
			ItemID = 20189,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20190] = {
			UnlockID = 1845,
			UnlockType = 6,
			ItemID = 20190,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20191] = {
			UnlockID = 1846,
			UnlockType = 6,
			ItemID = 20191,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20192] = {
			UnlockID = 1847,
			UnlockType = 6,
			ItemID = 20192,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20193] = {
			UnlockID = 1848,
			UnlockType = 6,
			ItemID = 20193,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20194] = {
			UnlockID = 1849,
			UnlockType = 6,
			ItemID = 20194,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20195] = {
			UnlockID = 1850,
			UnlockType = 6,
			ItemID = 20195,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20196] = {
			UnlockID = 1851,
			UnlockType = 6,
			ItemID = 20196,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20197] = {
			UnlockID = 1852,
			UnlockType = 6,
			ItemID = 20197,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20198] = {
			UnlockID = 1853,
			UnlockType = 6,
			ItemID = 20198,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20293] = {
			UnlockID = 1147,
			UnlockType = 6,
			ItemID = 20293,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20294] = {
			UnlockID = 1811,
			UnlockType = 6,
			ItemID = 20294,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20295] = {
			UnlockID = 1812,
			UnlockType = 6,
			ItemID = 20295,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20296] = {
			UnlockID = 1813,
			UnlockType = 6,
			ItemID = 20296,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20297] = {
			UnlockID = 1814,
			UnlockType = 6,
			ItemID = 20297,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20298] = {
			UnlockID = 1815,
			UnlockType = 6,
			ItemID = 20298,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20428] = {
			UnlockID = 51,
			UnlockType = 3,
			ItemID = 20428,
			TreeExp = 0,
			OneStep = 1,
			GenItemNum = 10,
			GenItemID = 10000
		},
		[20489] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20489,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20490] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20490,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[20491] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 20491,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24800] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24800,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 2,
			GenItemID = 10000
		},
		[24801] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24801,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 2,
			GenItemID = 10000
		},
		[24802] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24802,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24803] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24803,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24804] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24804,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24805] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24805,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24807] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24807,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24808] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24808,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24809] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24809,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 2,
			GenItemID = 10000
		},
		[24810] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24810,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24811] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24811,
			TreeExp = 2,
			OneStep = "",
			GenItemNum = 2,
			GenItemID = 10000
		},
		[24812] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24812,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24813] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24813,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24814] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24814,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24815] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24815,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24816] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24816,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24817] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24817,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24818] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24818,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24819] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24819,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24820] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24820,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24821] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24821,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24822] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24822,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24823] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24823,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24824] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24824,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24825] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24825,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24826] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24826,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24827] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24827,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24828] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24828,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24829] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24829,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[24830] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 24830,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25001] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25001,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25002] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25002,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25003] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25003,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25004] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25004,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25005] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25005,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25006] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25006,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25007] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25007,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25008] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25008,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25009] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25009,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25010] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25010,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25011] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25011,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25012] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25012,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25013] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25013,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25014] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25014,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25015] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25015,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25016] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25016,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25017] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25017,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25018] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25018,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25019] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25019,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25020] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25020,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25021] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25021,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25022] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25022,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25023] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25023,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25024] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25024,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25025] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25025,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25026] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25026,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25027] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25027,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25028] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25028,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25029] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25029,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25030] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25030,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25031] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25031,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25032] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25032,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25033] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25033,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25034] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25034,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25035] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25035,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25036] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25036,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25037] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25037,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25038] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25038,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25039] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25039,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25040] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25040,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25041] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25041,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25042] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25042,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25043] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25043,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25044] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25044,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25501] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25501,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25502] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25502,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25503] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25503,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25504] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25504,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25505] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25505,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25506] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25506,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25507] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25507,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25508] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25508,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25509] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25509,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25510] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25510,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25511] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25511,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25512] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25512,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25513] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25513,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25514] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25514,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25515] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25515,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25516] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25516,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25517] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25517,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25518] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25518,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25519] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25519,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25520] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25520,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25521] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25521,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25522] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25522,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25523] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25523,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25524] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25524,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[25525] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 25525,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[77501] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 77501,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[77502] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 77502,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[84001] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 84001,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[84002] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 84002,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[84003] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 84003,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97001] = {
			UnlockID = 1854,
			UnlockType = 6,
			ItemID = 97001,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97002] = {
			UnlockID = 1855,
			UnlockType = 6,
			ItemID = 97002,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97003] = {
			UnlockID = 1856,
			UnlockType = 6,
			ItemID = 97003,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97004] = {
			UnlockID = 1857,
			UnlockType = 6,
			ItemID = 97004,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97005] = {
			UnlockID = 1858,
			UnlockType = 6,
			ItemID = 97005,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97006] = {
			UnlockID = 1859,
			UnlockType = 6,
			ItemID = 97006,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97007] = {
			UnlockID = 1860,
			UnlockType = 6,
			ItemID = 97007,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97008] = {
			UnlockID = 1861,
			UnlockType = 6,
			ItemID = 97008,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97009] = {
			UnlockID = 1862,
			UnlockType = 6,
			ItemID = 97009,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97010] = {
			UnlockID = 1863,
			UnlockType = 6,
			ItemID = 97010,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97011] = {
			UnlockID = 1864,
			UnlockType = 6,
			ItemID = 97011,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97012] = {
			UnlockID = 1865,
			UnlockType = 6,
			ItemID = 97012,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97013] = {
			UnlockID = 1866,
			UnlockType = 6,
			ItemID = 97013,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97014] = {
			UnlockID = 1867,
			UnlockType = 6,
			ItemID = 97014,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97015] = {
			UnlockID = 1868,
			UnlockType = 6,
			ItemID = 97015,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97016] = {
			UnlockID = 1869,
			UnlockType = 6,
			ItemID = 97016,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97017] = {
			UnlockID = 1870,
			UnlockType = 6,
			ItemID = 97017,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97018] = {
			UnlockID = 1871,
			UnlockType = 6,
			ItemID = 97018,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97019] = {
			UnlockID = 1872,
			UnlockType = 6,
			ItemID = 97019,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97020] = {
			UnlockID = 1784,
			UnlockType = 6,
			ItemID = 97020,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97021] = {
			UnlockID = 1785,
			UnlockType = 6,
			ItemID = 97021,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97022] = {
			UnlockID = 1786,
			UnlockType = 6,
			ItemID = 97022,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97023] = {
			UnlockID = 1787,
			UnlockType = 6,
			ItemID = 97023,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97024] = {
			UnlockID = 1788,
			UnlockType = 6,
			ItemID = 97024,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97025] = {
			UnlockID = 1789,
			UnlockType = 6,
			ItemID = 97025,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97026] = {
			UnlockID = 1790,
			UnlockType = 6,
			ItemID = 97026,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97027] = {
			UnlockID = 1791,
			UnlockType = 6,
			ItemID = 97027,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97028] = {
			UnlockID = 1792,
			UnlockType = 6,
			ItemID = 97028,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97029] = {
			UnlockID = 1793,
			UnlockType = 6,
			ItemID = 97029,
			TreeExp = 1,
			OneStep = 1,
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97502] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 97502,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		},
		[97503] = {
			UnlockID = "",
			UnlockType = "",
			ItemID = 97503,
			TreeExp = 1,
			OneStep = "",
			GenItemNum = 1,
			GenItemID = 10000
		}
	},
	ItemUnlockAwardDef = {
		{
			GroupID = 1,
			ItemNum = 20,
			ItemID = 20060
		},
		{
			GroupID = 2,
			ItemNum = 20,
			ItemID = 20061
		},
		{
			GroupID = 3,
			ItemNum = 150,
			ItemID = 10000
		},
		{
			GroupID = 4,
			ItemNum = 40,
			ItemID = 10043
		},
		{
			GroupID = 5,
			ItemNum = 500,
			ItemID = 10000
		},
		{
			GroupID = 6,
			ItemNum = 60,
			ItemID = 10043
		},
		{
			GroupID = 7,
			ItemNum = 20,
			ItemID = 20029
		},
		{
			GroupID = 8,
			ItemNum = 20,
			ItemID = 20031
		},
		{
			GroupID = 9,
			ItemNum = 40,
			ItemID = 10043
		},
		{
			GroupID = 10,
			ItemNum = 150,
			ItemID = 10000
		},
		{
			GroupID = 11,
			ItemNum = 150,
			ItemID = 10000
		},
		{
			GroupID = 12,
			ItemNum = 150,
			ItemID = 10000
		},
		{
			GroupID = 13,
			ItemNum = 150,
			ItemID = 10000
		},
		{
			GroupID = 14,
			ItemNum = 20,
			ItemID = 20033
		},
		{
			GroupID = 15,
			ItemNum = 50,
			ItemID = 10000
		},
		{
			GroupID = 16,
			ItemNum = 100,
			ItemID = 10000
		},
		{
			GroupID = 17,
			ItemNum = 100,
			ItemID = 10000
		},
		{
			GroupID = 18,
			ItemNum = 100,
			ItemID = 10000
		},
		{
			GroupID = 19,
			ItemNum = 88,
			ItemID = 10000
		},
		{
			GroupID = 20,
			ItemNum = 88,
			ItemID = 10000
		},
		{
			GroupID = 21,
			ItemNum = 88,
			ItemID = 10000
		},
		[25] = {
			GroupID = 25,
			ItemNum = 88,
			ItemID = 10000
		}
	},
	ItemUnlockDef = {
		[20000] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 854,
			FragmentItemID = 20000,
			FlagPos = 1,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 5
		},
		[20001] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 855,
			FragmentItemID = 20001,
			FlagPos = 2,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 5
		},
		[20002] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 856,
			FragmentItemID = 20002,
			FlagPos = 3,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 10
		},
		[20003] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 857,
			FragmentItemID = 20003,
			FlagPos = 4,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 10
		},
		[20004] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 858,
			FragmentItemID = 20004,
			FlagPos = 5,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 5
		},
		[20005] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 859,
			FragmentItemID = 20005,
			FlagPos = 6,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 2
		},
		[20006] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 860,
			FragmentItemID = 20006,
			FlagPos = 7,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 6,
			Num = 10
		},
		[20007] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 861,
			FragmentItemID = 20007,
			FlagPos = 8,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 5
		},
		[20008] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 30,
			ReplaceItemID = 10000,
			ItemID = 862,
			FragmentItemID = 20008,
			FlagPos = 9,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 2
		},
		[20009] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 30,
			ReplaceItemID = 10000,
			ItemID = 863,
			FragmentItemID = 20009,
			FlagPos = 10,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 3
		},
		[20010] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 30,
			ReplaceItemID = 10000,
			ItemID = 864,
			FragmentItemID = 20010,
			FlagPos = 11,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 5
		},
		[20011] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 30,
			ReplaceItemID = 10000,
			ItemID = 865,
			FragmentItemID = 20011,
			FlagPos = 12,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 8
		},
		[20012] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 866,
			FragmentItemID = 20012,
			FlagPos = 13,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 3
		},
		[20013] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 867,
			FragmentItemID = 20013,
			FlagPos = 14,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 5
		},
		[20014] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 868,
			FragmentItemID = 20014,
			FlagPos = 15,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 10
		},
		[20015] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 869,
			FragmentItemID = 20015,
			FlagPos = 16,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 1,
			Num = 2
		},
		[20016] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 870,
			FragmentItemID = 20016,
			FlagPos = 17,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 2
		},
		[20017] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 871,
			FragmentItemID = 20017,
			FlagPos = 18,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 5
		},
		[20018] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 872,
			FragmentItemID = 20018,
			FlagPos = 19,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 12
		},
		[20019] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 873,
			FragmentItemID = 20019,
			FlagPos = 20,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 4
		},
		[20020] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 874,
			FragmentItemID = 20020,
			FlagPos = 21,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 8
		},
		[20021] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 875,
			FragmentItemID = 20021,
			FlagPos = 22,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 3
		},
		[20022] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 876,
			FragmentItemID = 20022,
			FlagPos = 23,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 10
		},
		[20023] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 877,
			FragmentItemID = 20023,
			FlagPos = 24,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 2,
			Num = 10
		},
		[20024] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 960,
			FragmentItemID = 20024,
			FlagPos = 36,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 8,
			Num = 2
		},
		[20025] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 961,
			FragmentItemID = 20025,
			FlagPos = 37,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 8,
			Num = 5
		},
		[20026] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 962,
			FragmentItemID = 20026,
			FlagPos = 38,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 8,
			Num = 3
		},
		[20027] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 963,
			FragmentItemID = 20027,
			FlagPos = 39,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 8,
			Num = 10
		},
		[20028] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 964,
			FragmentItemID = 20028,
			FlagPos = 40,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 8,
			Num = 10
		},
		[20039] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 1,
			ReplaceItemID = 10000,
			ItemID = 965,
			FragmentItemID = 20039,
			FlagPos = 44,
			CostType = 4,
			CostMiniBean = 0,
			GroupID = 3,
			Num = 60
		},
		[20040] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 1,
			ReplaceItemID = 10000,
			ItemID = 966,
			FragmentItemID = 20040,
			FlagPos = 45,
			CostType = 4,
			CostMiniBean = 0,
			GroupID = 3,
			Num = 120
		},
		[20041] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 967,
			FragmentItemID = 20041,
			FlagPos = 46,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 3,
			Num = 5
		},
		[20042] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 1,
			ReplaceItemID = 10000,
			ItemID = 968,
			FragmentItemID = 20042,
			FlagPos = 47,
			CostType = 4,
			CostMiniBean = 0,
			GroupID = 3,
			Num = 270
		},
		[20043] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 1,
			ReplaceItemID = 10000,
			ItemID = 969,
			FragmentItemID = 20043,
			FlagPos = 48,
			CostType = 4,
			CostMiniBean = 0,
			GroupID = 3,
			Num = 180
		},
		[20044] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 970,
			FragmentItemID = 20044,
			FlagPos = 49,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 4,
			Num = 6
		},
		[20045] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 971,
			FragmentItemID = 20045,
			FlagPos = 50,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 4,
			Num = 8
		},
		[20046] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 972,
			FragmentItemID = 20046,
			FlagPos = 51,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 4,
			Num = 20
		},
		[20047] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 973,
			FragmentItemID = 20047,
			FlagPos = 52,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 4,
			Num = 10
		},
		[20048] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 974,
			FragmentItemID = 20048,
			FlagPos = 53,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 4,
			Num = 16
		},
		[20049] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 975,
			FragmentItemID = 20049,
			FlagPos = 54,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 5,
			Num = 4
		},
		[20050] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 976,
			FragmentItemID = 20050,
			FlagPos = 55,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 5,
			Num = 6
		},
		[20051] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 977,
			FragmentItemID = 20051,
			FlagPos = 56,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 5,
			Num = 12
		},
		[20052] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 978,
			FragmentItemID = 20052,
			FlagPos = 57,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 5,
			Num = 6
		},
		[20053] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 979,
			FragmentItemID = 20053,
			FlagPos = 58,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 5,
			Num = 8
		},
		[20054] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 883,
			FragmentItemID = 20054,
			FlagPos = 30,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 7,
			Num = 2
		},
		[20055] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 884,
			FragmentItemID = 20055,
			FlagPos = 31,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 7,
			Num = 5
		},
		[20056] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 885,
			FragmentItemID = 20056,
			FlagPos = 32,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 7,
			Num = 15
		},
		[20057] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 886,
			FragmentItemID = 20057,
			FlagPos = 41,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 9,
			Num = 6
		},
		[20058] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 888,
			FragmentItemID = 20058,
			FlagPos = 42,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 9,
			Num = 10
		},
		[20059] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 890,
			FragmentItemID = 20059,
			FlagPos = 43,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 9,
			Num = 16
		},
		[20062] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12280,
			FragmentItemID = 20062,
			FlagPos = 59,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 10,
			Num = 5
		},
		[20063] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 1,
			ReplaceItemID = 10000,
			ItemID = 12281,
			FragmentItemID = 20063,
			FlagPos = 60,
			CostType = 4,
			CostMiniBean = 0,
			GroupID = 10,
			Num = 60
		},
		[20064] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12283,
			FragmentItemID = 20064,
			FlagPos = 61,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 10,
			Num = 12
		},
		[20065] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12284,
			FragmentItemID = 20065,
			FlagPos = 62,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 10,
			Num = 10
		},
		[20066] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 892,
			FragmentItemID = 20066,
			FlagPos = 63,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 11,
			Num = 5
		},
		[20067] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 893,
			FragmentItemID = 20067,
			FlagPos = 64,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 11,
			Num = 5
		},
		[20068] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 894,
			FragmentItemID = 20068,
			FlagPos = 65,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 11,
			Num = 5
		},
		[20069] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 895,
			FragmentItemID = 20069,
			FlagPos = 66,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 11,
			Num = 5
		},
		[20070] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 896,
			FragmentItemID = 20070,
			FlagPos = 67,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 11,
			Num = 5
		},
		[20071] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 897,
			FragmentItemID = 20071,
			FlagPos = 68,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 11,
			Num = 5
		},
		[20072] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 898,
			FragmentItemID = 20072,
			FlagPos = 69,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20073] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 899,
			FragmentItemID = 20073,
			FlagPos = 70,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20074] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 900,
			FragmentItemID = 20074,
			FlagPos = 71,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20075] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 926,
			FragmentItemID = 20075,
			FlagPos = 72,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 13,
			Num = 5
		},
		[20076] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 927,
			FragmentItemID = 20076,
			FlagPos = 73,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 13,
			Num = 5
		},
		[20077] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 928,
			FragmentItemID = 20077,
			FlagPos = 74,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 13,
			Num = 5
		},
		[20078] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 929,
			FragmentItemID = 20078,
			FlagPos = 75,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 13,
			Num = 5
		},
		[20079] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 931,
			FragmentItemID = 20079,
			FlagPos = 76,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20080] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 933,
			FragmentItemID = 20080,
			FlagPos = 77,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20081] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 934,
			FragmentItemID = 20081,
			FlagPos = 78,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20082] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 935,
			FragmentItemID = 20082,
			FlagPos = 79,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20083] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 936,
			FragmentItemID = 20083,
			FlagPos = 80,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 12,
			Num = 5
		},
		[20084] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 881,
			FragmentItemID = 20084,
			FlagPos = 81,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 2
		},
		[20085] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 940,
			FragmentItemID = 20085,
			FlagPos = 82,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 3
		},
		[20086] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 941,
			FragmentItemID = 20086,
			FlagPos = 83,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 4
		},
		[20087] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 942,
			FragmentItemID = 20087,
			FlagPos = 84,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 5
		},
		[20088] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 943,
			FragmentItemID = 20088,
			FlagPos = 85,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 6
		},
		[20089] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 945,
			FragmentItemID = 20089,
			FlagPos = 86,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 10
		},
		[20090] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 946,
			FragmentItemID = 20090,
			FlagPos = 87,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 2
		},
		[20091] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 947,
			FragmentItemID = 20091,
			FlagPos = 88,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 3
		},
		[20092] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 948,
			FragmentItemID = 20092,
			FlagPos = 89,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 4
		},
		[20093] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 949,
			FragmentItemID = 20093,
			FlagPos = 90,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 8
		},
		[20094] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12253,
			FragmentItemID = 20094,
			FlagPos = 91,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 14,
			Num = 20
		},
		[20095] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12830,
			FragmentItemID = 20095,
			FlagPos = 92,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 15,
			Num = 5
		},
		[20096] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 13808,
			FragmentItemID = 20096,
			FlagPos = 93,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 15,
			Num = 5
		},
		[20097] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 419,
			FragmentItemID = 20097,
			FlagPos = 94,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 16,
			Num = 1
		},
		[20098] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 420,
			FragmentItemID = 20098,
			FlagPos = 95,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 16,
			Num = 1
		},
		[20099] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 424,
			FragmentItemID = 20099,
			FlagPos = 96,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 16,
			Num = 1
		},
		[20100] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 427,
			FragmentItemID = 20100,
			FlagPos = 97,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 16,
			Num = 1
		},
		[20101] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 428,
			FragmentItemID = 20101,
			FlagPos = 98,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 16,
			Num = 1
		},
		[20102] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 429,
			FragmentItemID = 20102,
			FlagPos = 99,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 16,
			Num = 1
		},
		[20103] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 539,
			FragmentItemID = 20103,
			FlagPos = 100,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 17,
			Num = 1
		},
		[20104] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 551,
			FragmentItemID = 20104,
			FlagPos = 101,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 17,
			Num = 1
		},
		[20105] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 552,
			FragmentItemID = 20105,
			FlagPos = 102,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 17,
			Num = 1
		},
		[20106] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 553,
			FragmentItemID = 20106,
			FlagPos = 103,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 17,
			Num = 1
		},
		[20107] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 554,
			FragmentItemID = 20107,
			FlagPos = 104,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 17,
			Num = 1
		},
		[20108] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 13609,
			FragmentItemID = 20108,
			FlagPos = 105,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 18,
			Num = 1
		},
		[20109] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 13610,
			FragmentItemID = 20109,
			FlagPos = 106,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 18,
			Num = 1
		},
		[20110] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 13611,
			FragmentItemID = 20110,
			FlagPos = 107,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 18,
			Num = 1
		},
		[20111] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 450,
			ReplaceItemID = 10000,
			ItemID = 1101,
			FragmentItemID = 20111,
			FlagPos = 116,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20112] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 180,
			ReplaceItemID = 10000,
			ItemID = 1102,
			FragmentItemID = 20112,
			FlagPos = 117,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20113] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 1103,
			FragmentItemID = 20113,
			FlagPos = 118,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20114] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 450,
			ReplaceItemID = 10000,
			ItemID = 1104,
			FragmentItemID = 20114,
			FlagPos = 119,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20115] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 180,
			ReplaceItemID = 10000,
			ItemID = 1105,
			FragmentItemID = 20115,
			FlagPos = 120,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20116] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 1106,
			FragmentItemID = 20116,
			FlagPos = 121,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20117] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 1107,
			FragmentItemID = 20117,
			FlagPos = 122,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20118] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1108,
			FragmentItemID = 20118,
			FlagPos = 123,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20119] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 180,
			ReplaceItemID = 10000,
			ItemID = 1109,
			FragmentItemID = 20119,
			FlagPos = 124,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20120] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 360,
			ReplaceItemID = 10000,
			ItemID = 1110,
			FragmentItemID = 20120,
			FlagPos = 125,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 19,
			Num = 1
		},
		[20121] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 450,
			ReplaceItemID = 10000,
			ItemID = 1111,
			FragmentItemID = 20121,
			FlagPos = 126,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20122] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1112,
			FragmentItemID = 20122,
			FlagPos = 127,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20123] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1113,
			FragmentItemID = 20123,
			FlagPos = 128,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20124] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1114,
			FragmentItemID = 20124,
			FlagPos = 129,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20125] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 180,
			ReplaceItemID = 10000,
			ItemID = 1115,
			FragmentItemID = 20125,
			FlagPos = 130,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20126] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 180,
			ReplaceItemID = 10000,
			ItemID = 1116,
			FragmentItemID = 20126,
			FlagPos = 131,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20127] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 270,
			ReplaceItemID = 10000,
			ItemID = 1117,
			FragmentItemID = 20127,
			FlagPos = 132,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20128] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 360,
			ReplaceItemID = 10000,
			ItemID = 1118,
			FragmentItemID = 20128,
			FlagPos = 133,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20129] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 180,
			ReplaceItemID = 10000,
			ItemID = 1119,
			FragmentItemID = 20129,
			FlagPos = 134,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20130] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 540,
			ReplaceItemID = 10000,
			ItemID = 1120,
			FragmentItemID = 20130,
			FlagPos = 135,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 20,
			Num = 1
		},
		[20131] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12589,
			FragmentItemID = 20131,
			FlagPos = 136,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 21,
			Num = 12
		},
		[20132] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 15506,
			FragmentItemID = 20132,
			FlagPos = 137,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 21,
			Num = 5
		},
		[20133] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 15507,
			FragmentItemID = 20133,
			FlagPos = 138,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 21,
			Num = 6
		},
		[20134] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 15508,
			FragmentItemID = 20134,
			FlagPos = 139,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 21,
			Num = 3
		},
		[20135] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12291,
			FragmentItemID = 20135,
			FlagPos = 140,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 22,
			Num = 14
		},
		[20136] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 15519,
			FragmentItemID = 20136,
			FlagPos = 141,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 22,
			Num = 9
		},
		[20137] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 15520,
			FragmentItemID = 20137,
			FlagPos = 142,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 22,
			Num = 12
		},
		[20138] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1060,
			FragmentItemID = 20138,
			FlagPos = 143,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 22,
			Num = 10
		},
		[20139] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1136,
			FragmentItemID = 20139,
			FlagPos = 144,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 23,
			Num = 10
		},
		[20140] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1137,
			FragmentItemID = 20140,
			FlagPos = 145,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 23,
			Num = 4
		},
		[20142] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1159,
			FragmentItemID = 20142,
			FlagPos = 147,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 24,
			Num = 10
		},
		[20143] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1160,
			FragmentItemID = 20143,
			FlagPos = 148,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 24,
			Num = 10
		},
		[20144] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1161,
			FragmentItemID = 20144,
			FlagPos = 149,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 24,
			Num = 10
		},
		[20145] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1164,
			FragmentItemID = 20145,
			FlagPos = 150,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 24,
			Num = 10
		},
		[20147] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1145,
			FragmentItemID = 20147,
			FlagPos = 151,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 23,
			Num = 12
		},
		[20148] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1749,
			FragmentItemID = 20148,
			FlagPos = 155,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 25,
			Num = 15
		},
		[20149] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1747,
			FragmentItemID = 20149,
			FlagPos = 153,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 25,
			Num = 5
		},
		[20150] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1748,
			FragmentItemID = 20150,
			FlagPos = 154,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 25,
			Num = 10
		},
		[20151] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1750,
			FragmentItemID = 20151,
			FlagPos = 156,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 25,
			Num = 4
		},
		[20152] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1751,
			FragmentItemID = 20152,
			FlagPos = 157,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 25,
			Num = 5
		},
		[20153] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1752,
			FragmentItemID = 20153,
			FlagPos = 158,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 25,
			Num = 6
		},
		[20154] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12301,
			FragmentItemID = 20154,
			FlagPos = 159,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20155] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12302,
			FragmentItemID = 20155,
			FlagPos = 160,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20156] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12303,
			FragmentItemID = 20156,
			FlagPos = 161,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20157] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12304,
			FragmentItemID = 20157,
			FlagPos = 162,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20158] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12305,
			FragmentItemID = 20158,
			FlagPos = 163,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20159] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12306,
			FragmentItemID = 20159,
			FlagPos = 164,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20160] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 12307,
			FragmentItemID = 20160,
			FlagPos = 165,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 26,
			Num = 10
		},
		[20161] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1816,
			FragmentItemID = 20161,
			FlagPos = 172,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20162] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1817,
			FragmentItemID = 20162,
			FlagPos = 173,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20163] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1818,
			FragmentItemID = 20163,
			FlagPos = 174,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20164] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1819,
			FragmentItemID = 20164,
			FlagPos = 175,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20165] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1820,
			FragmentItemID = 20165,
			FlagPos = 176,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20166] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1821,
			FragmentItemID = 20166,
			FlagPos = 177,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20167] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1822,
			FragmentItemID = 20167,
			FlagPos = 178,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20168] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1823,
			FragmentItemID = 20168,
			FlagPos = 179,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20169] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1824,
			FragmentItemID = 20169,
			FlagPos = 180,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20170] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1825,
			FragmentItemID = 20170,
			FlagPos = 181,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20171] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1826,
			FragmentItemID = 20171,
			FlagPos = 182,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20172] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1827,
			FragmentItemID = 20172,
			FlagPos = 183,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20173] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1828,
			FragmentItemID = 20173,
			FlagPos = 184,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20174] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1829,
			FragmentItemID = 20174,
			FlagPos = 185,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20175] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1830,
			FragmentItemID = 20175,
			FlagPos = 186,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20176] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1831,
			FragmentItemID = 20176,
			FlagPos = 187,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20177] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1832,
			FragmentItemID = 20177,
			FlagPos = 188,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20178] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1833,
			FragmentItemID = 20178,
			FlagPos = 189,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 29,
			Num = 12
		},
		[20179] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1834,
			FragmentItemID = 20179,
			FlagPos = 190,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 28,
			Num = 12
		},
		[20180] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1835,
			FragmentItemID = 20180,
			FlagPos = 191,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20181] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1836,
			FragmentItemID = 20181,
			FlagPos = 192,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20182] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1837,
			FragmentItemID = 20182,
			FlagPos = 193,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20183] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1838,
			FragmentItemID = 20183,
			FlagPos = 194,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20184] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1839,
			FragmentItemID = 20184,
			FlagPos = 195,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20185] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1840,
			FragmentItemID = 20185,
			FlagPos = 196,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20186] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1841,
			FragmentItemID = 20186,
			FlagPos = 197,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20187] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1842,
			FragmentItemID = 20187,
			FlagPos = 198,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20188] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1843,
			FragmentItemID = 20188,
			FlagPos = 199,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 30,
			Num = 12
		},
		[20189] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1844,
			FragmentItemID = 20189,
			FlagPos = 200,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20190] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1845,
			FragmentItemID = 20190,
			FlagPos = 201,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20191] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1846,
			FragmentItemID = 20191,
			FlagPos = 202,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20192] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1847,
			FragmentItemID = 20192,
			FlagPos = 203,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20193] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1848,
			FragmentItemID = 20193,
			FlagPos = 204,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20194] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1849,
			FragmentItemID = 20194,
			FlagPos = 205,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20195] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1850,
			FragmentItemID = 20195,
			FlagPos = 206,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20196] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1851,
			FragmentItemID = 20196,
			FlagPos = 207,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20197] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1852,
			FragmentItemID = 20197,
			FlagPos = 208,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20198] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1853,
			FragmentItemID = 20198,
			FlagPos = 209,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 31,
			Num = 12
		},
		[20199] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1854,
			FragmentItemID = 20199,
			FlagPos = 210,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20200] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1855,
			FragmentItemID = 20200,
			FlagPos = 211,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20201] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1856,
			FragmentItemID = 20201,
			FlagPos = 212,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20202] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1857,
			FragmentItemID = 20202,
			FlagPos = 213,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20203] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1858,
			FragmentItemID = 20203,
			FlagPos = 214,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20204] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1859,
			FragmentItemID = 20204,
			FlagPos = 215,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20205] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1860,
			FragmentItemID = 20205,
			FlagPos = 216,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20206] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1861,
			FragmentItemID = 20206,
			FlagPos = 217,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20207] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1862,
			FragmentItemID = 20207,
			FlagPos = 218,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 32,
			Num = 12
		},
		[20208] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1863,
			FragmentItemID = 20208,
			FlagPos = 219,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20209] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1864,
			FragmentItemID = 20209,
			FlagPos = 220,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20210] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1865,
			FragmentItemID = 20210,
			FlagPos = 221,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20211] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1866,
			FragmentItemID = 20211,
			FlagPos = 222,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20212] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1867,
			FragmentItemID = 20212,
			FlagPos = 223,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20213] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1868,
			FragmentItemID = 20213,
			FlagPos = 224,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20214] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1869,
			FragmentItemID = 20214,
			FlagPos = 225,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20215] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1870,
			FragmentItemID = 20215,
			FlagPos = 226,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20216] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1871,
			FragmentItemID = 20216,
			FlagPos = 227,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20217] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1872,
			FragmentItemID = 20217,
			FlagPos = 228,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 33,
			Num = 12
		},
		[20218] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1874,
			FragmentItemID = 20218,
			FlagPos = 229,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20219] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1875,
			FragmentItemID = 20219,
			FlagPos = 230,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20220] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1876,
			FragmentItemID = 20220,
			FlagPos = 231,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20221] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1877,
			FragmentItemID = 20221,
			FlagPos = 232,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20222] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1878,
			FragmentItemID = 20222,
			FlagPos = 233,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20223] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1879,
			FragmentItemID = 20223,
			FlagPos = 234,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20224] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1880,
			FragmentItemID = 20224,
			FlagPos = 235,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20225] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1881,
			FragmentItemID = 20225,
			FlagPos = 236,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20226] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1882,
			FragmentItemID = 20226,
			FlagPos = 237,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20227] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 120,
			ReplaceItemID = 10000,
			ItemID = 1883,
			FragmentItemID = 20227,
			FlagPos = 238,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 34,
			Num = 12
		},
		[20293] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 90,
			ReplaceItemID = 10000,
			ItemID = 1147,
			FragmentItemID = 20293,
			FlagPos = 166,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 23,
			Num = 12
		},
		[20294] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 1811,
			FragmentItemID = 20294,
			FlagPos = 167,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 27,
			Num = 6
		},
		[20295] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 1812,
			FragmentItemID = 20295,
			FlagPos = 168,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 27,
			Num = 8
		},
		[20296] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 1813,
			FragmentItemID = 20296,
			FlagPos = 169,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 27,
			Num = 20
		},
		[20297] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 1814,
			FragmentItemID = 20297,
			FlagPos = 170,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 27,
			Num = 10
		},
		[20298] = {
			MiniBeanPerItem = 10,
			ReplaceItemNum = 45,
			ReplaceItemID = 10000,
			ItemID = 1815,
			FragmentItemID = 20298,
			FlagPos = 171,
			CostType = 5,
			CostMiniBean = 0,
			GroupID = 27,
			Num = 16
		}
	},
	ItemUseDef = {
		[0] = {
			ResetTime = "",
			ItemID = 0,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[10025] = {
			ResetTime = "",
			ItemID = 10025,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 3,
					GenItemID = 10024
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12839] = {
			ResetTime = "",
			ItemID = 12839,
			GenType = 0,
			GenItemIDNum = 5,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 10,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12831
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 12,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12840] = {
			ResetTime = "",
			ItemID = 12840,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12841] = {
			ResetTime = "",
			ItemID = 12841,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12842] = {
			ResetTime = "",
			ItemID = 12842,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12843] = {
			ResetTime = "",
			ItemID = 12843,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 10,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12844] = {
			ResetTime = "",
			ItemID = 12844,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 10,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12845] = {
			ResetTime = "",
			ItemID = 12845,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 15,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12846] = {
			ResetTime = "",
			ItemID = 12846,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 15,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12262
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12847] = {
			ResetTime = "",
			ItemID = 12847,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 5,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12848] = {
			ResetTime = "",
			ItemID = 12848,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 10,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12255
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12849] = {
			ResetTime = "",
			ItemID = 12849,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 3,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12850] = {
			ResetTime = "",
			ItemID = 12850,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 10,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12851] = {
			ResetTime = "",
			ItemID = 12851,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 2000,
					MinNum = 3,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 6,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 900,
					MinNum = 10,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 66,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12962
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 845
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12833
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12834
				},
				{
					RandNum = 0,
					Odds = 200,
					MinNum = 1,
					GenItemID = 12948
				},
				{
					RandNum = 0,
					Odds = 250,
					MinNum = 1,
					GenItemID = 12988
				},
				{
					RandNum = 0,
					Odds = 250,
					MinNum = 1,
					GenItemID = 20032
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12852] = {
			ResetTime = "",
			ItemID = 12852,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 200000,
					MinNum = 6,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100000,
					MinNum = 8,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 25000,
					MinNum = 66,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 20000,
					MinNum = 88,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 888,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100000,
					MinNum = 1,
					GenItemID = 12962
				},
				{
					RandNum = 0,
					Odds = 100000,
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = 100000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 845
				},
				{
					RandNum = 0,
					Odds = 50000,
					MinNum = 1,
					GenItemID = 12833
				},
				{
					RandNum = 0,
					Odds = 50000,
					MinNum = 1,
					GenItemID = 12834
				},
				{
					RandNum = 0,
					Odds = 20000,
					MinNum = 1,
					GenItemID = 12948
				},
				{
					RandNum = 0,
					Odds = 25000,
					MinNum = 1,
					GenItemID = 12988
				},
				{
					RandNum = 0,
					Odds = 25000,
					MinNum = 1,
					GenItemID = 20032
				},
				{
					RandNum = 0,
					Odds = 4898,
					MinNum = 1,
					GenItemID = 20315
				},
				{
					RandNum = 0,
					Odds = 150000,
					MinNum = 1,
					GenItemID = 13015
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 10,
					ItemID = 13022,
					Odds = 1,
					MinNum = 1
				},
				{
					RandNum = 0,
					LimitNum = 10,
					ItemID = 20032,
					Odds = 1,
					MinNum = 300
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12853] = {
			ResetTime = "",
			ItemID = 12853,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 2000,
					MinNum = 3,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 6,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 900,
					MinNum = 10,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 66,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12962
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 845
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 20759
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 1,
					GenItemID = 20623
				},
				{
					RandNum = 0,
					Odds = 200,
					MinNum = 1,
					GenItemID = 12948
				},
				{
					RandNum = 0,
					Odds = 250,
					MinNum = 1,
					GenItemID = 12988
				},
				{
					RandNum = 0,
					Odds = 250,
					MinNum = 1,
					GenItemID = 20032
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12854] = {
			ResetTime = 1,
			ItemID = 12854,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 7500,
					MinNum = 20,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 1000,
					MinNum = 40,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 888,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 20519
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 20520
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 12993
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 20512
				},
				{
					RandNum = 0,
					Odds = 550,
					MinNum = 3,
					GenItemID = 20032
				},
				{
					RandNum = 0,
					Odds = 448,
					MinNum = 1,
					GenItemID = 20315
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 100,
					GenItemID = 20032
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 3,
					ItemID = 20407,
					Odds = 1,
					MinNum = 1
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12855] = {
			ResetTime = 2,
			ItemID = 12855,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 1500,
					MinNum = 10,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 1300,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 1200,
					MinNum = 1,
					GenItemID = 12833
				},
				{
					RandNum = 0,
					Odds = 1100,
					MinNum = 1,
					GenItemID = 845
				},
				{
					RandNum = 0,
					Odds = 900,
					MinNum = 3,
					GenItemID = 20511
				},
				{
					RandNum = 0,
					Odds = 700,
					MinNum = 7,
					GenItemID = 13001
				},
				{
					RandNum = 0,
					Odds = 600,
					MinNum = 4,
					GenItemID = 20780
				},
				{
					RandNum = 0,
					Odds = 600,
					MinNum = 4,
					GenItemID = 20729
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 7,
					GenItemID = 20509
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 30,
					GenItemID = 20505
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 66,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 216,
					MinNum = 25,
					GenItemID = 20036
				},
				{
					RandNum = 0,
					Odds = 133,
					MinNum = 1,
					GenItemID = 21889
				},
				{
					RandNum = 0,
					Odds = 123,
					MinNum = 1,
					GenItemID = 21742
				},
				{
					RandNum = 0,
					Odds = 113,
					MinNum = 1,
					GenItemID = 21979
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 22038
				},
				{
					RandNum = 0,
					Odds = 66,
					MinNum = 1,
					GenItemID = 20418
				},
				{
					RandNum = 0,
					Odds = 33,
					MinNum = 1,
					GenItemID = 20421
				},
				{
					RandNum = 0,
					Odds = 13,
					MinNum = 1,
					GenItemID = 20407
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 900,
					ItemID = 20033,
					Odds = 3,
					MinNum = 900
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12856] = {
			ResetTime = "",
			ItemID = 12856,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12858] = {
			ResetTime = "",
			ItemID = 12858,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 9000,
					MinNum = 12,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 9000,
					MinNum = 15,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 9000,
					MinNum = 18,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 8000,
					MinNum = 2,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 8000,
					MinNum = 2,
					GenItemID = 12962
				},
				{
					RandNum = 0,
					Odds = 8000,
					MinNum = 2,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 12991
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 13003
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 13004
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 13005
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 13008
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 20509
				},
				{
					RandNum = 0,
					Odds = 6999,
					MinNum = 1,
					GenItemID = 20510
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 13031
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 13039
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 13038
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 13037
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 13034
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 20409
				},
				{
					RandNum = 0,
					Odds = 1,
					MinNum = 1,
					GenItemID = 20410
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12859] = {
			ResetTime = "",
			ItemID = 12859,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 12833
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 12834
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 12962
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 12828
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21106
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21107
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21108
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21109
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21110
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21118
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21067
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21099
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21096
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 20991
				},
				{
					RandNum = 0,
					Odds = 100,
					MinNum = 1,
					GenItemID = 21069
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12900] = {
			ResetTime = "",
			ItemID = 12900,
			GenType = 1,
			GenItemIDNum = 5,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12989
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12990
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12991
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12992
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12993
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12901] = {
			ResetTime = "",
			ItemID = 12901,
			GenType = 1,
			GenItemIDNum = 5,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12994
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12995
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12996
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12997
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12998
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12902] = {
			ResetTime = "",
			ItemID = 12902,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12999
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 13000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12914] = {
			ResetTime = "",
			ItemID = 12914,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12915] = {
			ResetTime = "",
			ItemID = 12915,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12831
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 5,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12916] = {
			ResetTime = "",
			ItemID = 12916,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12831
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 5,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12917] = {
			ResetTime = "",
			ItemID = 12917,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 60,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12918] = {
			ResetTime = "",
			ItemID = 12918,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12831
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12919] = {
			ResetTime = "",
			ItemID = 12919,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 60,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12920] = {
			ResetTime = "",
			ItemID = 12920,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12921] = {
			ResetTime = "",
			ItemID = 12921,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 300,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12922] = {
			ResetTime = "",
			ItemID = 12922,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 400,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 30,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12923] = {
			ResetTime = "",
			ItemID = 12923,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 500,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 40,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12269
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12924] = {
			ResetTime = "",
			ItemID = 12924,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12925] = {
			ResetTime = "",
			ItemID = 12925,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 500,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 50,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12269
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12926] = {
			ResetTime = "",
			ItemID = 12926,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 600,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 60,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12269
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12927] = {
			ResetTime = "",
			ItemID = 12927,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 800,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 80,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12269
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12928] = {
			ResetTime = "",
			ItemID = 12928,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 10,
					Odds = "",
					MinNum = 15,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12929] = {
			ResetTime = "",
			ItemID = 12929,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12930] = {
			ResetTime = "",
			ItemID = 12930,
			GenType = 1,
			GenItemIDNum = 4,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 3,
					GenItemID = 12954
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12948] = {
			ResetTime = "",
			ItemID = 12948,
			GenType = 0,
			GenItemIDNum = 5,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 20,
					GenItemID = 12950
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 20,
					GenItemID = 12951
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 20,
					GenItemID = 12952
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 20,
					GenItemID = 12953
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 20,
					GenItemID = 12954
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12949] = {
			ResetTime = "",
			ItemID = 12949,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 30,
					GenItemID = 12950
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12961] = {
			ResetTime = "",
			ItemID = 12961,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 2,
					Odds = "",
					MinNum = 1,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12962] = {
			ResetTime = "",
			ItemID = 12962,
			GenType = 0,
			GenItemIDNum = 5,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 13400
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 13401
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 13403
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 13402
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 13409
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12965] = {
			ResetTime = "",
			ItemID = 12965,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 3,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12966] = {
			ResetTime = "",
			ItemID = 12966,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12968] = {
			ResetTime = "",
			ItemID = 12968,
			GenType = 1,
			GenItemIDNum = 4,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 3,
					GenItemID = 12954
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12969] = {
			ResetTime = "",
			ItemID = 12969,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12970] = {
			ResetTime = "",
			ItemID = 12970,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 60,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12971] = {
			ResetTime = "",
			ItemID = 12971,
			GenType = 1,
			GenItemIDNum = 2,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 60,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 10,
					GenItemID = 12960
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12972] = {
			ResetTime = "",
			ItemID = 12972,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 150,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12973] = {
			ResetTime = "",
			ItemID = 12973,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 300,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12974] = {
			ResetTime = "",
			ItemID = 12974,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 450,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12975] = {
			ResetTime = "",
			ItemID = 12975,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 600,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12976] = {
			ResetTime = "",
			ItemID = 12976,
			GenType = 1,
			GenItemIDNum = 4,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12977] = {
			ResetTime = "",
			ItemID = 12977,
			GenType = 1,
			GenItemIDNum = 4,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 100,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12831
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12961
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12978] = {
			ResetTime = "",
			ItemID = 12978,
			GenType = 1,
			GenItemIDNum = 3,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 60,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 2,
					GenItemID = 12963
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 3,
					GenItemID = 12951
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12980] = {
			ResetTime = "",
			ItemID = 12980,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 19,
					Odds = "",
					MinNum = 1,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12986] = {
			ResetTime = "",
			ItemID = 12986,
			GenType = 1,
			GenItemIDNum = 1,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 120,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[12988] = {
			ResetTime = "",
			ItemID = 12988,
			GenType = 0,
			GenItemIDNum = 5,
			GenItem = {
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12989
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12991
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12994
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12998
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 1,
					GenItemID = 12981
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49010] = {
			ResetTime = "",
			ItemID = 49010,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20515
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20518
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 1,
					GenItemID = 20418
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 1,
					GenItemID = 20421
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49015] = {
			ResetTime = "",
			ItemID = 49015,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20516
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20524
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 20419
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 20427
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49016] = {
			ResetTime = "",
			ItemID = 49016,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 12991
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = "⁣13003"
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = "⁣13031"
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = "⁣13039"
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49021] = {
			ResetTime = "",
			ItemID = 49021,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20525
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 13004
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 20428
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 13038
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49022] = {
			ResetTime = "",
			ItemID = 49022,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 13006
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 13007
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 13036
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 13035
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49023] = {
			ResetTime = "",
			ItemID = 49023,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20515
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20518
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 1,
					GenItemID = 20418
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 1,
					GenItemID = 20421
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49024] = {
			ResetTime = "",
			ItemID = 49024,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20516
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20524
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 20419
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 20427
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49025] = {
			ResetTime = "",
			ItemID = 49025,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 12991
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = "⁣13003"
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = "⁣13031"
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = "⁣13039"
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49026] = {
			ResetTime = "",
			ItemID = 49026,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20525
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 13004
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 20428
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 13038
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49027] = {
			ResetTime = "",
			ItemID = 49027,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 13006
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 13007
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 13036
				},
				{
					RandNum = 0,
					Odds = 300,
					MinNum = 1,
					GenItemID = 13035
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		},
		[49028] = {
			ResetTime = "",
			ItemID = 49028,
			GenType = 0,
			GenItemIDNum = 0,
			GenItem = {
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 50,
					GenItemID = 10000
				},
				{
					RandNum = 0,
					Odds = 35000,
					MinNum = 1,
					GenItemID = 12964
				},
				{
					RandNum = 0,
					Odds = 6000,
					MinNum = 1,
					GenItemID = 10012
				},
				{
					RandNum = 0,
					Odds = 10000,
					MinNum = 1,
					GenItemID = 10010
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20515
				},
				{
					RandNum = 0,
					Odds = 30000,
					MinNum = 1,
					GenItemID = 20518
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 1,
					GenItemID = 20418
				},
				{
					RandNum = 0,
					Odds = 500,
					MinNum = 1,
					GenItemID = 20421
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				},
				{
					RandNum = 0,
					Odds = "",
					MinNum = 0,
					GenItemID = 0
				}
			},
			SpclItem = {
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				},
				{
					RandNum = 0,
					LimitNum = 0,
					ItemID = 0,
					Odds = "",
					MinNum = 0
				}
			}
		}
	},
	MiniCoinCostDef = {
		[12] = {
			RmbCost = 10,
			PayID = 12,
			MiniCoinIOS = 240,
			BuyLimitMax = 1,
			CltVersion = 0,
			BuyLimitID = 4,
			MiniCoin = 200
		},
		[13] = {
			RmbCost = 100,
			PayID = 13,
			MiniCoinIOS = 2160,
			BuyLimitMax = 1,
			CltVersion = 0,
			BuyLimitID = 5,
			MiniCoin = 2000
		},
		[14] = {
			RmbCost = 1,
			PayID = 14,
			MiniCoinIOS = "",
			BuyLimitMax = 0,
			CltVersion = 0,
			BuyLimitID = 0,
			MiniCoin = 10
		},
		[15] = {
			RmbCost = 5,
			PayID = 15,
			MiniCoinIOS = "",
			BuyLimitMax = 0,
			CltVersion = 0,
			BuyLimitID = 0,
			MiniCoin = 55
		},
		[16] = {
			RmbCost = 25,
			PayID = 16,
			MiniCoinIOS = "",
			BuyLimitMax = 0,
			CltVersion = 0,
			BuyLimitID = 0,
			MiniCoin = 280
		},
		[17] = {
			RmbCost = 50,
			PayID = 17,
			MiniCoinIOS = "",
			BuyLimitMax = 0,
			CltVersion = 0,
			BuyLimitID = 0,
			MiniCoin = 580
		}
	},
	NationalDayGiftDef = {
		{
			CltVersion = 0,
			ItemID = 12963,
			Num = 4,
			DayID = 1
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 2
		},
		{
			CltVersion = 0,
			ItemID = 12964,
			Num = 4,
			DayID = 3
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 4
		},
		{
			CltVersion = 0,
			ItemID = 12831,
			Num = 5,
			DayID = 5
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 6
		},
		{
			CltVersion = 0,
			ItemID = 12254,
			Num = 1,
			DayID = 7
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 8
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 9
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 10
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 1,
			DayID = 11
		},
		{
			CltVersion = 0,
			ItemID = 12960,
			Num = 30,
			DayID = 12
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 13
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 14
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 15
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 16
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 17
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 18
		},
		{
			CltVersion = 0,
			ItemID = 12928,
			Num = 2,
			DayID = 19
		},
		{
			CltVersion = 0,
			ItemID = 12955,
			Num = 50,
			DayID = 20
		}
	},
	PetDef = {
		[4200] = {
			Model = 110054,
			BuyTips = "",
			Tag = "",
			TextureID = "",
			SellEndTime = 0,
			SellBeginTime = 0,
			CltVersion = 0,
			PetName = 7000,
			PetID = 4200,
			ApiID = "",
			Head = "",
			EndTime = "",
			EffectType = "",
			Effect = "",
			Desc = 7001,
			CloseEnv = "",
			BeginTime = "",
			BuyTipsType = "",
			Cost = {
				500,
				500
			},
			EffectDesc = {
				"",
				"",
				"",
				"",
				""
			},
			EffectIcon = {
				"",
				"",
				"",
				"",
				""
			},
			ItemID = {
				0,
				0
			},
			MoneyType = {
				2,
				2
			}
		},
		[4201] = {
			Model = 110055,
			BuyTips = "",
			Tag = "",
			TextureID = "",
			SellEndTime = 0,
			SellBeginTime = 0,
			CltVersion = 0,
			PetName = 7008,
			PetID = 4201,
			ApiID = "",
			Head = "",
			EndTime = "",
			EffectType = "",
			Effect = "",
			Desc = 7009,
			CloseEnv = "",
			BeginTime = "",
			BuyTipsType = "",
			Cost = {
				500,
				500
			},
			EffectDesc = {
				"",
				"",
				"",
				"",
				""
			},
			EffectIcon = {
				"",
				"",
				"",
				"",
				""
			},
			ItemID = {
				0,
				0
			},
			MoneyType = {
				2,
				2
			}
		}
	},
	RenameCostDef = {
		{
			Cost = 300,
			Times = 1
		}
	},
	SkinCostDef = {
		{
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 1,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 12960,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 90,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 180,
				Tag = 0,
				SkinID = 1,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 1,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 2,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = 20254,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 3,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 12960,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 90,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 180,
				Tag = 0,
				SkinID = 3,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 3,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 4,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 12960,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 150,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 180,
				Tag = 0,
				SkinID = 4,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 4,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 5,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 20029,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 400,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 6,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 20060,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[0] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 7,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = "",
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 0,
				ExpireTime = 0,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 7,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 20061,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[0] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 8,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = "",
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 0,
				ExpireTime = 0,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 388,
				Tag = 0,
				SkinID = 8,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 1,
				SkinID = 9,
				SellEndTime = 1511711999,
				SellBeginTime = 1509379200,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 485,
				Tag = 1,
				SkinID = 10,
				SellEndTime = 1546790400,
				SellBeginTime = 1544716800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 369,
				Tag = 0,
				SkinID = 11,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = -1,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,2,10,12",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 689,
				Tag = 1,
				SkinID = 12,
				SellEndTime = 1580140799,
				SellBeginTime = 1578967200,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 589,
				Tag = 0,
				SkinID = 13,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 388,
				Tag = 0,
				SkinID = 14,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 258,
				Tag = 0,
				SkinID = 15,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 258,
				Tag = 0,
				SkinID = 16,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 258,
				Tag = 0,
				SkinID = 17,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 18,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 258,
				Tag = 0,
				SkinID = 19,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 20,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 21,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 1,
				SkinID = 22,
				SellEndTime = 1551023940,
				SellBeginTime = 1549209600,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20202,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 23,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1514476800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 24,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1517328000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 668,
				Tag = 1,
				SkinID = 25,
				SellEndTime = 1549209600,
				SellBeginTime = 1547740800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20214,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 26,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 1,
				SkinID = 27,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 1,
				SkinID = 27,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 20035,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 1,
				SkinID = 27,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 20035,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 598,
				Tag = 0,
				SkinID = 28,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 29,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 1,
				SkinID = 30,
				SellEndTime = 1664121599,
				SellBeginTime = 1662602400,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20223,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 31,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 32,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 33,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1546012800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 34,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "35,36",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 2
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 4,
				SkinID = 35,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 4,
				SkinID = 36,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 37,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 668,
				Tag = 1,
				SkinID = 38,
				SellEndTime = 1580140799,
				SellBeginTime = 1578967200,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20231,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 39,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 39,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 20037,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 39,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 20037,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 40,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1553047200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 41,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1556589600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 42,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1559268000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 43,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1581732000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 44,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 45,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1565143200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 46,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1563588000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 47,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 498,
				Tag = 0,
				SkinID = 48,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1569722410,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 1,
				SkinID = 49,
				SellEndTime = 1609430399,
				SellBeginTime = 1609129449,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1569636010,
				OpenService = "0,1,2",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 50,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1572487200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20245,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 51,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1573696800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 1288,
				Tag = 1,
				SkinID = 52,
				SellEndTime = 1593273599,
				SellBeginTime = 1588039200,
				CostType = 2,
				PreUnLockSkin = 3449,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 988,
				Tag = 1,
				SkinID = 53,
				SellEndTime = 1593273599,
				SellBeginTime = 1588039200,
				CostType = 2,
				PreUnLockSkin = 3451,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 54,
				SellEndTime = 1609689599,
				SellBeginTime = 1608256800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1576807200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20248,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 368,
				Tag = 0,
				SkinID = 55,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 56,
				SellEndTime = 1612713599,
				SellBeginTime = 1610935200,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1579312800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 57,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1579312800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 57,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24802,
				CltVersion = 0,
				BeginTime = 1579312800,
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 57,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24802,
				CltVersion = 0,
				BeginTime = 1579312800,
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 888,
				Tag = 1,
				SkinID = 58,
				SellEndTime = 1593273599,
				SellBeginTime = 1588039200,
				CostType = 2,
				PreUnLockSkin = 3453,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 59,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 60,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1584669600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_60",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 61,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1584669600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_61",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 61,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24803,
				CltVersion = 0,
				BeginTime = 1584669600,
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "giflogo_61",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 61,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24803,
				CltVersion = 0,
				BeginTime = 1584669600,
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "giflogo_61",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 62,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[2] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 63,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24805,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 63,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24805,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 888,
				Tag = 1,
				SkinID = 64,
				SellEndTime = 1593273599,
				SellBeginTime = 1587027613,
				CostType = 2,
				PreUnLockSkin = 3464,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 788,
				Tag = 1,
				SkinID = 65,
				SellEndTime = 1685894400,
				SellBeginTime = 1685066400,
				CostType = 2,
				PreUnLockSkin = 3466,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 788,
				Tag = 1,
				SkinID = 66,
				SellEndTime = 1594742399,
				SellBeginTime = 1587027613,
				CostType = 2,
				PreUnLockSkin = 3468,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 67,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 68,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 68,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24807,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 68,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24807,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 69,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1592964000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 1,
				SkinID = 70,
				SellEndTime = 1639324799,
				SellBeginTime = 1637805600,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 71,
				SellEndTime = 1615132799,
				SellBeginTime = 1613354400,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 1,
				SkinID = 72,
				SellEndTime = 1616774399,
				SellBeginTime = 1596592800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 73,
				SellEndTime = 1621180799,
				SellBeginTime = 1619107201,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609466400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 688,
				Tag = 1,
				SkinID = 74,
				SellEndTime = 1621180799,
				SellBeginTime = 1619107201,
				CostType = 2,
				PreUnLockSkin = 3473,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 3
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 588,
				Tag = 0,
				SkinID = 75,
				SellEndTime = 1603036799,
				SellBeginTime = 1601431200,
				CostType = 2,
				PreUnLockSkin = 3475,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 3
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 588,
				Tag = 1,
				SkinID = 76,
				SellEndTime = 1614355199,
				SellBeginTime = 1606356000,
				CostType = 2,
				PreUnLockSkin = 3477,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1606356000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 3
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 77,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 77,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24810,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 77,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24810,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 78,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24812,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 600,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 79,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 80,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = 3482,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 1,
				SkinID = 81,
				SellEndTime = 1616774399,
				SellBeginTime = 1601431200,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 82,
				SellEndTime = 1668959999,
				SellBeginTime = 1667268000,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 83,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24813,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 700,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 84,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24814,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 700,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 85,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 1,
				SkinID = 86,
				SellEndTime = 1617206399,
				SellBeginTime = 1608688800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 1,
				SkinID = 87,
				SellEndTime = 1617206399,
				SellBeginTime = 1608688800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 88,
				SellEndTime = 1614527999,
				SellBeginTime = 1610676000,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1610676000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 89,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_71",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 1588,
				Tag = 1,
				SkinID = 90,
				SellEndTime = 1644940799,
				SellBeginTime = 1642471200,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 2
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 91,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 92,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 93,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 94,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 95,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 1588,
				Tag = 1,
				SkinID = 96,
				SellEndTime = 1685894400,
				SellBeginTime = 1685066400,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 2
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 97,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 98,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 99,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 100,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 101,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = 1609129449,
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1609043049,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "transformers_icon1",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 102,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 103,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = 3494,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 104,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 105,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1612972801,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 106,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24824,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 107,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 108,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			{
				ItemRate = 0,
				Cost = 300,
				Tag = 0,
				SkinID = 109,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 4,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 1,
				ExpireTime = 604800,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 109,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24821,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			{
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 109,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24821,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 110,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_132",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[2] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 111,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24822,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 111,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24822,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 112,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_132",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 113,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 0,
				SkinID = 114,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 20289,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 1,
				SkinID = 115,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 116,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 117,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 118,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 119,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 120,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = "",
				Tag = 0,
				SkinID = 121,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 0,
				SkinID = 122,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 123,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 124,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 125,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 1,
				SkinID = 126,
				SellEndTime = 1651247400,
				SellBeginTime = 1641052799,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 0,
				SkinID = 127,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 128,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 168,
				Tag = 1,
				SkinID = 129,
				SellEndTime = 1651247400,
				SellBeginTime = 1641052799,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 130,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 131,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_133",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 132,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_133",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 218,
				Tag = 0,
				SkinID = 133,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 218,
				Tag = 0,
				SkinID = 134,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 218,
				Tag = 0,
				SkinID = 135,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[2] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 136,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24825,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 136,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24825,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 137,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 0,
				SkinID = 138,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 368,
				Tag = 0,
				SkinID = 139,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 1,
				SkinID = 140,
				SellEndTime = 1630598399,
				SellBeginTime = 1627869600,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 141,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1627869600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 0,
				SkinID = 142,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1627869600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33025,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 143,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1627869600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 144,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1627869600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 145,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1627869600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 1,
				SkinID = 146,
				SellEndTime = 1630598399,
				SellBeginTime = 1627869600,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 1,
				SkinID = 147,
				SellEndTime = 1630598399,
				SellBeginTime = 1627869600,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 1,
				SkinID = 148,
				SellEndTime = 1630598399,
				SellBeginTime = 1627869600,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 149,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629943200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 150,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629943200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 0,
				SkinID = 151,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629943200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 152,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629252000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 153,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629252000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 154,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629252000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 155,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629252000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 4,
				SkinID = 156,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629252000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_127",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 318,
				Tag = 4,
				SkinID = 157,
				SellEndTime = 1663603199,
				SellBeginTime = 1651456800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1651456800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33071,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 158,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1629943200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 159,
				SellEndTime = 1664121599,
				SellBeginTime = 1662688800,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1631757600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33035,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 160,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1631757600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 161,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1631757600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_131",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 162,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1631757600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_131",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 498,
				Tag = 0,
				SkinID = 163,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1632621600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33038,
				GifLogo = "giflogo_129",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 318,
				Tag = 0,
				SkinID = 164,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1632621600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_129",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 165,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1632621600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 166,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1632621600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 167,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1634522400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 318,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 168,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1971482400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = 33077,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 368,
				Tag = 0,
				SkinID = 169,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1634522400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 318,
				Tag = 4,
				SkinID = 170,
				SellEndTime = 1663603199,
				SellBeginTime = 1649901600,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1649901600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33070,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 0,
				SkinID = 171,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1634522400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 172,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1640966400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 173,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1634522400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 328,
				Tag = 0,
				SkinID = 174,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1635127200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 368,
				Tag = 0,
				SkinID = 175,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1635127200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 176,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1950919200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 177,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1950919200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 178,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1636336800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 179,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1636336800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 180,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1637251200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 181,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1637805600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_130",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 182,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1637805600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_130",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 183,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1951833600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 184,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1638151200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 185,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1644422400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 186,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1638151200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 187,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1639533600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 188,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1639533600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 0,
				SkinID = 189,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1641348000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33054,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[2] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 190,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24827,
				CltVersion = 0,
				BeginTime = 1641348000,
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 190,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24827,
				CltVersion = 0,
				BeginTime = 1641348000,
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 191,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24826,
				CltVersion = 0,
				BeginTime = 1641780000,
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 192,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = 1,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1641348000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 193,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = 1,
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1641348000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 194,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 195,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 196,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = 4568,
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1642557600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33055,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 1088,
				Tag = 1,
				SkinID = 197,
				SellEndTime = 1645113599,
				SellBeginTime = 1642557600,
				CostType = 2,
				PreUnLockSkin = 4570,
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1642557600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 1,
				SkinID = 198,
				SellEndTime = 1646063999,
				SellBeginTime = 1643421600,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1643421600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33059,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 368,
				Tag = 0,
				SkinID = 199,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1643421600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33063,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 200,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1643335200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_134",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 201,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1643335200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_134",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 202,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1643644800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 0,
				SkinID = 203,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1643990400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = 33056,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 298,
				Tag = 0,
				SkinID = 204,
				SellEndTime = 1674575999,
				SellBeginTime = 1669168800,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1644422400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 205,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 206,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 207,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1986256800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 198,
				Tag = 0,
				SkinID = 208,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1645581600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 209,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1647482400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 398,
				Tag = 0,
				SkinID = 210,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1647655200,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[2] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 211,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24828,
				CltVersion = 0,
				BeginTime = 1647396000,
				OpenService = "0,1,10",
				Num = 200,
				HeadFrame = "",
				GifLogo = "giflogo_135",
				ExpireTimeType = 2,
				ExpireTime = 2592000,
				ClearType = ""
			},
			[3] = {
				ItemRate = 0,
				Cost = 0,
				Tag = 0,
				SkinID = 211,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 3,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24828,
				CltVersion = 0,
				BeginTime = 1647396000,
				OpenService = "0,1,10",
				Num = 500,
				HeadFrame = "",
				GifLogo = "giflogo_135",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 268,
				Tag = 0,
				SkinID = 212,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1666317600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 213,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1961546400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 214,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1648692000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 215,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1961546400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 216,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1961546400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 217,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1961546400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 218,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1961546400,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 468,
				Tag = 1,
				SkinID = 219,
				SellEndTime = 1678896000,
				SellBeginTime = 1678327200,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1648692000,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 220,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1648864800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_137",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 221,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1648864800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_137",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 222,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1658368800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_136",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 223,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1658368800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "giflogo_138",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 368,
				Tag = 0,
				SkinID = 224,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1651197600,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				ItemRate = 0,
				Cost = 999,
				Tag = 0,
				SkinID = 225,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				VipType = "",
				ApiID = 0,
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1651024800,
				OpenService = "0,1,10",
				Num = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1674575999,
				SellBeginTime = 1669168800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 226,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1652407200,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 227,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1652320800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 228,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1652407200,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 229,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1675821600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "231,232",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 230,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1653962400,
				OpenService = "0,1,12",
				ItemRate = 0,
				HeadFrame = 33076,
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "230,232",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 231,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1653962400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "230,231",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 232,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1653962400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 268,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1678291200,
				SellBeginTime = 1677722400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 233,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1653962400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 268,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1678291200,
				SellBeginTime = 1677722400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 234,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1654221600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 268,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1678896000,
				SellBeginTime = 1678327200,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 235,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1655344800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 236,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1654394400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_139",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 237,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1654394400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_139",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 238,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1657072800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 239,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1675821600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 318,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1672502399,
				SellBeginTime = 1667786400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 240,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1657245600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1672502399,
				SellBeginTime = 1667786400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 241,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1657245600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 318,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1672502399,
				SellBeginTime = 1667786400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 242,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1657764000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1665158399,
				SellBeginTime = 1657159200,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 243,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1657159200,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 0,
				LinkSkin = "",
				FrontID = "",
				Num = 600,
				SellEndTime = 1665158399,
				SellBeginTime = 1657072800,
				CostType = 3,
				PreUnLockSkin = "",
				SkinID = 244,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 24829,
				CltVersion = 0,
				BeginTime = 1657072800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 245,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1657764000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 268,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1672502399,
				SellBeginTime = 1667786400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 246,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1658973600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1672502399,
				SellBeginTime = 1667786400,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 247,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1658973600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1665158399,
				SellBeginTime = 1658973600,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 248,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1658973600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 428,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1677686399,
				SellBeginTime = 1673056800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 249,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 468,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1677686399,
				SellBeginTime = 1673056800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 250,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "269,",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 251,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1664503200,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 252,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1659924000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_141",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 253,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1659924000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_141",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 254,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1660701600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 255,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_138",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 256,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_136",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 168,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 257,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 168,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 258,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 259,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 260,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 261,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 268,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 262,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 218,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 263,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 218,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 264,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 198,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 265,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 198,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 266,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1662516000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1677686400,
				SellBeginTime = 1676512800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 267,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1677686399,
				SellBeginTime = 1673056800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 268,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "251,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 269,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1664503200,
				ItemPresentNum = "1,1",
				ItemPresent = "90002,86002",
				HeadFrame = 33089,
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 270,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1660701600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1677686400,
				SellBeginTime = 1676512800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 271,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 1677686400,
				SellBeginTime = 1676512800,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 272,
				Tag = 1,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = "",
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 273,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1664676000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 274,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1664848800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 275,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673834400,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_143",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 276,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1664589600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_144",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 277,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1664589600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "giflogo_144",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 688,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = 4622,
				SkinID = 278,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1666317600,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 279,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1981936800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 280,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1981936800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 281,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1981936800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 282,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1981936800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 283,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1981936800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				SkinID = 284,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1669824000,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 318,
				LinkSkin = "",
				FrontID = "",
				Num = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				SkinID = 285,
				Tag = 0,
				ApiID = 0,
				VipType = "",
				EndTime = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1668736800,
				OpenService = "0,1,10",
				ItemRate = 0,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 286,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1671156000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 428,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1673193599,
				SellBeginTime = 1671501600,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 287,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1671501600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 288,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1671156000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1677686399,
				SellBeginTime = 1672452000,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 289,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1672452000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1677686399,
				SellBeginTime = 1672452000,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 290,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1672452000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 291,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1672538400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_145",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 292,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1672538400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_145",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 293,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 294,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1676822399,
				SellBeginTime = 1674266400,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 295,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1674266400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = 33125,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 296,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1674266400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = 33126,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 297,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 298,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 1288,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1677427199,
				SellBeginTime = 1674525600,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 299,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1674525600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 300,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1676822399,
				SellBeginTime = 1675216800,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 301,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1675216800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 302,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 303,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 304,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1674352800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 305,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_143",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "307,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = 4640,
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 306,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "306,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = 4642,
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 307,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1673488800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = 33113,
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 308,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1677722400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_146",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 309,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1677722400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_146",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 310,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1677204000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 328,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 311,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1677204000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 312,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1677808800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 313,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_143",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 314,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1679018400,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_143",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 315,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_147",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 316,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_148",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 317,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 318,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1678845600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1682524800,
				SellBeginTime = 1680300000,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 319,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1680300000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 368,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 320,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1681956000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 321,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1682388000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_150",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 322,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1682388000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_150",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "324,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 323,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1681264800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "323,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 324,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1681264800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = 33137,
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 325,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1682388000,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 468,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1684944000,
				SellBeginTime = 1682560800,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 326,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1682560800,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 327,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1682388000,
				ItemPresentNum = 1,
				ItemPresent = 38016,
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 328,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1966471200,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 329,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1966471200,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 330,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1966471200,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 331,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1966471200,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 332,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1966471200,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 688,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1686153600,
				SellBeginTime = 1684893600,
				CostType = 2,
				PreUnLockSkin = 4652,
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 333,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1684893600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "transformers_icon2",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = 1
			}
		},
		{
			[3] = {
				Cost = 468,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1688918400,
				SellBeginTime = 1686189600,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 334,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1686189600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 298,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 1688918400,
				SellBeginTime = 1686189600,
				CostType = 2,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 335,
				EndTime = "",
				Tag = 1,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1686189600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 336,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1684893600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "giflogo_70",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "338,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 337,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1684893600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = 33142,
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "337,",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 338,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1684893600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = 33141,
				GifLogo = "giflogo_140",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		},
		{
			[3] = {
				Cost = 999,
				LinkSkin = "",
				FrontID = "",
				ItemRate = 0,
				SellEndTime = 0,
				SellBeginTime = 0,
				CostType = 6,
				PreUnLockSkin = "",
				OpenService = "0,1,10",
				Num = 0,
				ApiID = 0,
				SkinID = 339,
				EndTime = "",
				Tag = 0,
				VipType = "",
				CloseEnv = 2,
				ItemID = 0,
				CltVersion = 0,
				BeginTime = 1684893600,
				ItemPresentNum = 0,
				ItemPresent = "",
				HeadFrame = "",
				GifLogo = "",
				ExpireTimeType = 3,
				ExpireTime = -1,
				ClearType = ""
			}
		}
	},
	StarCostDef = {
		{
			Cost = 1,
			Star = 1
		}
	},
	UnOpenedResouceDef = {
		["entity/140129/body.omod"] = {
			CltVersion = 99999,
			ResourcePath = "entity/140129/body.omod"
		},
		["entity/140130/body.omod"] = {
			CltVersion = 99999,
			ResourcePath = "entity/140130/body.omod"
		}
	},
	UnlockRiderCostDef = {
		[3430] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 20031,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3430,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 20031,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3430,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3433] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 20032,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3433,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 20032,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3433,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3436] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 20033,
				CltVersion = 3329,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3436,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 20033,
				CltVersion = 3329,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3436,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3439] = {
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 20034,
				CltVersion = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				RiderID = 3439,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3442] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 20036,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3442,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 20036,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3442,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3445] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 20038,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3445,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 20038,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3445,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3454] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24800,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3454,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24800,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3454,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3457] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24801,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3457,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24801,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3457,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3460] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24804,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3460,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24804,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3460,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3469] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24809,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3469,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24809,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3469,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3478] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24811,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3478,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24811,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3478,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3483] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24815,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3483,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24815,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3483,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3486] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24816,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3486,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3488] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24817,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 3488,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3490] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24818,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3490,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24818,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3490,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[3495] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24819,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3495,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24819,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 3495,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4500] = {
			{
				Cost = 298,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4500,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 20489
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 24820,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4500,
				Level = 2,
				GoodsNum = 1,
				GoodsID = 20490
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 24820,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4500,
				Level = 3,
				GoodsNum = 1,
				GoodsID = 20491
			}
		},
		[4504] = {
			{
				Cost = 498,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4504,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25507
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25001,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4504,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25002,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4504,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4508] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25003,
				CltVersion = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				RiderID = 4508,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4511] = {
			{
				Cost = 30000,
				Num = 80,
				SellEndTime = 0,
				ItemID = 25005,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4511,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25007,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4511,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25007,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4511,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 450,
				SellEndTime = 0,
				ItemID = 25007,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4511,
				Level = 4,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4516] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25009,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4516,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25009,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4516,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4519] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25009,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4519,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25009,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4519,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4522] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25010,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4522,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4524] = {
			{
				Cost = 198,
				Num = 0,
				RiderID = 4524,
				ItemID = 0,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				StartTime = 1627833600,
				EndTime = 1663516800,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25508
			},
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4524,
				ItemID = 25011,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = 1627833600,
				EndTime = 1663516800,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4527] = {
			{
				Cost = 198,
				Num = 0,
				RiderID = 4527,
				ItemID = 0,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				StartTime = 1629216000,
				EndTime = 1663516800,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25509
			},
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4527,
				ItemID = 25012,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = 1629216000,
				EndTime = 1663516800,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4530] = {
			{
				Cost = 218,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4530,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25013,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4530,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25013,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4530,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4534] = {
			{
				Cost = 298,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4534,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25510
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25014,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4534,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25014,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4534,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4538] = {
			{
				Cost = 468,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4538,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25511
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25015,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4538,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25015,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4538,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4542] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25017,
				CltVersion = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				RiderID = 4542,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25016,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4542,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25016,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4542,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4546] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25018,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4546,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25018,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4546,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4549] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25019,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4549,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25019,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4549,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4552] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25020,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4552,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25020,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4552,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4555] = {
			{
				Cost = 30000,
				Num = 200,
				SellEndTime = 0,
				ItemID = 25021,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4555,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4559] = {
			{
				Cost = 368,
				Num = 0,
				RiderID = 4559,
				ItemID = 0,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				StartTime = 1670983200,
				EndTime = 1674575999,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25504
			},
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4559,
				ItemID = 25022,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = 1670983200,
				EndTime = 1674575999,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				RiderID = 4559,
				ItemID = 25022,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = 1670983200,
				EndTime = 1674575999,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4563] = {
			{
				Cost = 298,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4563,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25505
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25023,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4563,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25023,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4563,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4571] = {
			{
				Cost = 298,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4571,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25506
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25024,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4571,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25024,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4571,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4575] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25025,
				CltVersion = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				RiderID = 4575,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25025,
				CltVersion = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				RiderID = 4575,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 900,
				SellEndTime = 0,
				ItemID = 25025,
				CltVersion = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				RiderID = 4575,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4579] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25028,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4579,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25028,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4579,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4582] = {
			{
				Cost = 328,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4582,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 200,
				SellEndTime = 0,
				ItemID = 25026,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4582,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 400,
				SellEndTime = 0,
				ItemID = 25026,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4582,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4586] = {
			{
				Cost = 298,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4586,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25513
			},
			{
				Cost = 30000,
				Num = 450,
				SellEndTime = 0,
				ItemID = 25027,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4586,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4589] = {
			{
				Cost = 218,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4589,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25514
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25029,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4589,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25029,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4589,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4593] = {
			{
				Cost = 398,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4593,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25515
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25030,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4593,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25030,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4593,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4597] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25031,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4597,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4601] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25032,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4601,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25032,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4601,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4605] = {
			{
				Cost = 368,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4605,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25516
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25033,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4605,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25033,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4605,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4609] = {
			{
				Cost = 328,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4609,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25517
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25034,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4609,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25034,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4609,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4613] = {
			{
				Cost = 328,
				Num = 0,
				SellEndTime = 0,
				ItemID = 0,
				CltVersion = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				RiderID = 4613,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25518
			},
			{
				Cost = 30000,
				Num = 150,
				SellEndTime = 0,
				ItemID = 25035,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4613,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25035,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4613,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4617] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25036,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4617,
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25036,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10031,
				ItemRate = 30000,
				RiderID = 4617,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4623] = {
			{
				Cost = 30000,
				Num = 300,
				SellEndTime = 0,
				ItemID = 25037,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4623,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25519
			},
			{
				Cost = 30000,
				Num = 600,
				SellEndTime = 0,
				ItemID = 25037,
				CltVersion = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				RiderID = 4623,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4627] = {
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4627,
				ItemID = 25038,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = "",
				EndTime = "",
				Level = 1,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 600,
				RiderID = 4627,
				ItemID = 25038,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = "",
				EndTime = "",
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4631] = {
			{
				Cost = 468,
				Num = 0,
				RiderID = 4631,
				ItemID = 0,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				StartTime = 1674316800,
				EndTime = 1677427199,
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25520
			},
			{
				Cost = 30000,
				Num = 150,
				RiderID = 4631,
				ItemID = 25039,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = 1674316800,
				EndTime = 1677427199,
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			},
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4631,
				ItemID = 25039,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = 1674316800,
				EndTime = 1677427199,
				Level = 3,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4635] = {
			{
				Cost = 368,
				Num = 0,
				RiderID = 4635,
				ItemID = 0,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 2,
				FragmentID = "",
				ItemRate = 0,
				StartTime = "",
				EndTime = "",
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25521
			},
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4635,
				ItemID = 25040,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = 10032,
				ItemRate = 30000,
				StartTime = "",
				EndTime = "",
				Level = 2,
				GoodsNum = 0,
				GoodsID = ""
			}
		},
		[4643] = {
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4643,
				ItemID = 25041,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				StartTime = 1678845600,
				EndTime = "",
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25522
			}
		},
		[4645] = {
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4645,
				ItemID = 25042,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				StartTime = "",
				EndTime = "",
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25523
			}
		},
		[4647] = {
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4647,
				ItemID = 25043,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				StartTime = "",
				EndTime = "",
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25524
			}
		},
		[4649] = {
			{
				Cost = 30000,
				Num = 300,
				RiderID = 4649,
				ItemID = 25044,
				CltVersion = 0,
				SellEndTime = 0,
				CostType = 3,
				FragmentID = "",
				ItemRate = 30000,
				StartTime = "",
				EndTime = "",
				Level = 1,
				GoodsNum = 1,
				GoodsID = 25525
			}
		}
	},
	UnlockRoleCostDef = {
		{
			[0] = {
				ModelID = 1,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12950,
				CltVersion = 0,
				Cost = 30,
				CostType = 1,
				Num = 30
			},
			{
				ModelID = 1,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12950,
				CltVersion = 0,
				Cost = 150,
				CostType = 1,
				Num = 150
			},
			{
				ModelID = 1,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12950,
				CltVersion = 0,
				Cost = 300,
				CostType = 1,
				Num = 300
			}
		},
		{
			[0] = {
				ModelID = 2,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12952,
				CltVersion = 0,
				Cost = 100,
				CostType = 1,
				Num = 100
			},
			{
				ModelID = 2,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12952,
				CltVersion = 0,
				Cost = 200,
				CostType = 1,
				Num = 200
			},
			{
				ModelID = 2,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12952,
				CltVersion = 0,
				Cost = 400,
				CostType = 1,
				Num = 400
			}
		},
		{
			[0] = {
				ModelID = 3,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12960,
				CltVersion = 0,
				Cost = 100,
				CostType = 3,
				Num = 120
			},
			{
				ModelID = 3,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12959,
				CltVersion = 0,
				Cost = 200,
				CostType = 3,
				Num = 200
			},
			{
				ModelID = 3,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12959,
				CltVersion = 0,
				Cost = 400,
				CostType = 3,
				Num = 400
			}
		},
		{
			[0] = {
				ModelID = 4,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12960,
				CltVersion = 0,
				Cost = 100,
				CostType = 3,
				Num = 150
			},
			{
				ModelID = 4,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12955,
				CltVersion = 0,
				Cost = 300,
				CostType = 3,
				Num = 300
			},
			{
				ModelID = 4,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12955,
				CltVersion = 0,
				Cost = 600,
				CostType = 3,
				Num = 600
			}
		},
		{
			[0] = {
				ModelID = 5,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12960,
				CltVersion = 0,
				Cost = 100,
				CostType = 3,
				Num = 100
			},
			{
				ModelID = 5,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12957,
				CltVersion = 0,
				Cost = 200,
				CostType = 3,
				Num = 200
			},
			{
				ModelID = 5,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12957,
				CltVersion = 0,
				Cost = 400,
				CostType = 3,
				Num = 400
			}
		},
		{
			[0] = {
				ModelID = 6,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12954,
				CltVersion = 0,
				Cost = 250,
				CostType = 1,
				Num = 250
			},
			{
				ModelID = 6,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12954,
				CltVersion = 0,
				Cost = 300,
				CostType = 1,
				Num = 300
			},
			{
				ModelID = 6,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12954,
				CltVersion = 0,
				Cost = 600,
				CostType = 1,
				Num = 600
			}
		},
		{
			[0] = {
				ModelID = 7,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12951,
				CltVersion = 0,
				Cost = 150,
				CostType = 1,
				Num = 150
			},
			{
				ModelID = 7,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12951,
				CltVersion = 0,
				Cost = 400,
				CostType = 1,
				Num = 400
			},
			{
				ModelID = 7,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12951,
				CltVersion = 0,
				Cost = 800,
				CostType = 1,
				Num = 800
			}
		},
		{
			[0] = {
				ModelID = 8,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12953,
				CltVersion = 0,
				Cost = 100,
				CostType = 1,
				Num = 100
			},
			{
				ModelID = 8,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12953,
				CltVersion = 0,
				Cost = 200,
				CostType = 1,
				Num = 200
			},
			{
				ModelID = 8,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12953,
				CltVersion = 0,
				Cost = 400,
				CostType = 1,
				Num = 400
			}
		},
		{
			[0] = {
				ModelID = 9,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12960,
				CltVersion = 0,
				Cost = 100,
				CostType = 3,
				Num = 200
			},
			{
				ModelID = 9,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12956,
				CltVersion = 0,
				Cost = 300,
				CostType = 3,
				Num = 300
			},
			{
				ModelID = 9,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12956,
				CltVersion = 0,
				Cost = 600,
				CostType = 3,
				Num = 600
			}
		},
		{
			[0] = {
				ModelID = 10,
				GenuisLv = 0,
				ItemRate = 1,
				ItemID = 12960,
				CltVersion = 0,
				Cost = 200,
				CostType = 3,
				Num = 240
			},
			{
				ModelID = 10,
				GenuisLv = 1,
				ItemRate = 1,
				ItemID = 12958,
				CltVersion = 0,
				Cost = 400,
				CostType = 3,
				Num = 400
			},
			{
				ModelID = 10,
				GenuisLv = 2,
				ItemRate = 1,
				ItemID = 12958,
				CltVersion = 0,
				Cost = 800,
				CostType = 3,
				Num = 800
			}
		}
	},
	WeekGiftDef = {
		[0] = {
			CltVersion = 0,
			ItemID = 12962,
			Num = 2,
			DayID = 0
		},
		{
			CltVersion = 0,
			ItemID = 12963,
			Num = 1,
			DayID = 1
		},
		{
			CltVersion = 0,
			ItemID = 12964,
			Num = 1,
			DayID = 2
		},
		{
			CltVersion = 0,
			ItemID = 12963,
			Num = 1,
			DayID = 3
		},
		{
			CltVersion = 0,
			ItemID = 12834,
			Num = 1,
			DayID = 4
		},
		{
			CltVersion = 2048,
			ItemID = 10000,
			Num = 12,
			DayID = 5
		},
		{
			CltVersion = 2048,
			ItemID = 10000,
			Num = 18,
			DayID = 6
		}
	},
	WoChannelDef = {
		[2] = {
			ApiID = 2,
			ChannelID = "00020676"
		},
		[3] = {
			ApiID = 3,
			ChannelID = "00018261"
		},
		[5] = {
			ApiID = 5,
			ChannelID = "00012243"
		},
		[6] = {
			ApiID = 6,
			ChannelID = "00021628"
		},
		[7] = {
			ApiID = 7,
			ChannelID = "00018755"
		},
		[8] = {
			ApiID = 8,
			ChannelID = "00018253"
		},
		[9] = {
			ApiID = 9,
			ChannelID = "00018754"
		},
		[10] = {
			ApiID = 10,
			ChannelID = "00018639"
		},
		[11] = {
			ApiID = 11,
			ChannelID = "00024127"
		},
		[12] = {
			ApiID = 12,
			ChannelID = "00020620"
		},
		[13] = {
			ApiID = 13,
			ChannelID = "00022744"
		},
		[14] = {
			ApiID = 14,
			ChannelID = "00020609"
		},
		[15] = {
			ApiID = 15,
			ChannelID = "00018594"
		},
		[16] = {
			ApiID = 16,
			ChannelID = "00023439"
		},
		[17] = {
			ApiID = 17,
			ChannelID = "00018253"
		},
		[18] = {
			ApiID = 18,
			ChannelID = "00018253"
		},
		[19] = {
			ApiID = 19,
			ChannelID = "00018253"
		},
		[20] = {
			ApiID = 20,
			ChannelID = "00022415"
		},
		[21] = {
			ApiID = 21,
			ChannelID = "00021652"
		},
		[22] = {
			ApiID = 22,
			ChannelID = "00021753"
		},
		[23] = {
			ApiID = 23,
			ChannelID = "00023030"
		},
		[24] = {
			ApiID = 24,
			ChannelID = "00023032"
		},
		[25] = {
			ApiID = 25,
			ChannelID = "00023028"
		},
		[26] = {
			ApiID = 26,
			ChannelID = "00023118"
		},
		[27] = {
			ApiID = 27,
			ChannelID = "00023357"
		},
		[28] = {
			ApiID = 28,
			ChannelID = "00023352"
		},
		[29] = {
			ApiID = 29,
			ChannelID = "00021760"
		},
		[30] = {
			ApiID = 30,
			ChannelID = "00022959"
		},
		[31] = {
			ApiID = 31,
			ChannelID = "00029888"
		},
		[32] = {
			ApiID = 32,
			ChannelID = "00021393"
		},
		[33] = {
			ApiID = 33,
			ChannelID = "00021802"
		},
		[34] = {
			ApiID = 34,
			ChannelID = "00018756"
		},
		[35] = {
			ApiID = 35,
			ChannelID = "00021500"
		},
		[36] = {
			ApiID = 36,
			ChannelID = "00025102"
		},
		[37] = {
			ApiID = 37,
			ChannelID = "00030356"
		},
		[38] = {
			ApiID = 38,
			ChannelID = "00018733"
		},
		[39] = {
			ApiID = 39,
			ChannelID = "00018733"
		},
		[40] = {
			ApiID = 40,
			ChannelID = "00018733"
		},
		[41] = {
			ApiID = 41,
			ChannelID = "00018733"
		},
		[42] = {
			ApiID = 42,
			ChannelID = "00018733"
		},
		[49] = {
			ApiID = 49,
			ChannelID = "00022544"
		},
		[50] = {
			ApiID = 50,
			ChannelID = "00029075"
		}
	}
}
