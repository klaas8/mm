local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("ClientMgr", {
	account = {
		get = function (self)
			return self.service.AccountManager.account
		end
	},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin

		threadpool:work(function ()
			self:loop()
		end)
	end,
	destroy = function (self)
		self.service = nil
		self.origin = nil
	end,
	setAccount = function (self, uin, nickname)
		if self.origin.setAccountEx then
			local acc = self.account
			local svrinfo = acc and acc.svrinfo
			local gvoice = svrinfo and svrinfo.gvoice

			if gvoice then
				return self.origin:setAccountEx(uin, nickname, gvoice.appid, gvoice.appkey)
			else
				return self.origin:setAccount(uin, nickname)
			end
		else
			return self.origin:setAccount(uin, nickname)
		end
	end,
	getShareLink = function (self)
		local eventcache = self.eventcache
		local info = eventcache.postShareGiftInfo

		if info and info.url then
			return info.url
		else
			return self.origin:getShareLink()
		end
	end,
	AdvertisementsLoadStatus = function (self, ad_platform_id, position_id)
		print("AdvertisementsLoadStatus ", ad_platform_id, position_id)

		local apiid = LuaInterface:getApiId()
		local CltVersion = LuaInterface:getCltVersion()

		if CltVersion < 7424 and apiid == 13 or apiid == 32 then
			return true
		else
			return self.origin:AdvertisementsLoadStatus(ad_platform_id, position_id)
		end
	end
}, class.ManagerBase)
