local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("BuddyManager", {
	flags = {},
	account = {
		get = function (self)
			return self.service.AccountManager.account
		end
	},
	Buddy = {
		get = function (self)
			return self.account.Buddy
		end
	},
	BuddyDetail = {},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin

		service:listento("buddy", function (method, version_info, ...)
			local account = self.account
			local conn = self.conn

			while conn.is_doing_rpc do
				threadpool:wait(1)
			end

			local local_version_info = account:version_info()
			local same = true

			for i, v in ipairs(local_version_info) do
				if v ~= version_info[i] then
					same = false
				end
			end

			if not same then
				return
			end

			local code = account:precheck(method, ...)

			if code ~= ErrorCode.OK then
				return
			end

			pcall(account[method], account, ...)
		end)
		service:listentoAccountConn("speek", function (ts, msg, who, speeker)
			local offlinechats = self.offlinechats
			self.offlinechats = self.offlinechats or {}

			print("有人说话", msg, who, speeker)
			self:addOfflineChat(who, who, ts, msg, speeker)
			self:trigger("postOfflineChat")
		end)
		service:listentoAccountConn("chat_query", function (Uin, msglist)
			if Uin and msglist then
				for j, m in ipairs(msglist) do
					self:addOfflineChat(Uin, m[1], m[2], m[3])
				end

				self:sortOfflineChat(Uin)
			end
		end)
		threadpool:work(function ()
			self:loop()
		end)
	end,
	on_switch_account = function (self)
		self.flags = {}
		self.BuddyDetail = {}
		self.offlinechats = {}

		if AccountManager:check_ad_version() then
			threadpool:notify("ad.info.update")
		else
			local first_req = self.account and self.account.is_ad_firstreq or false

			self:remote_call("shopsvr", "ad_info", {
				ApiID = LuaInterface:getApiId(),
				CltVersion = LuaInterface:getCltVersion(),
				platform_id = ad_platform_id,
				first_req = first_req
			})

			if self.account then
				self.account.is_ad_firstreq = false
			end
		end
	end,
	destroy = function (self)
		self.origin = nil
		self.service = nil
		self.valid = false
		self.flags = {}
	end,
	loadOfflineChat = function (self, Uin)
		self.offlinechats = self:load_from_file("chat_" .. Uin) or {}

		for k, v in pairs(self.offlinechats) do
			if v.info then
				v.info = class.FansData.cast(v.info and v.info.QQLoginInfo or v.info)
			end
		end
	end,
	saveOfflineChat = function (self)
		local MyUin = self.Uin

		if MyUin then
			self:save_to_file("chat_" .. MyUin, self.offlinechats)
		end
	end,
	formatChat = function (self, who, nickname, ts, msg, color)
		local time = self:time2string(ts)

		if who == 1000 then
			return msg
		else
			return AccountManager:getBlueVipIconStr(AccountManager:getUin()) .. "#c00ff00" .. nickname .. time .. ":#n\n" .. msg
		end
	end,
	addOfflineChat = function (self, Uin, who, ts, msg, speeker)
		print("addOfflineChat : ", Uin, who, ts, msg, speeker)

		self.offlinechats = self.offlinechats or {}
		local offlinechats = self.offlinechats
		offlinechats[Uin] = offlinechats[Uin] or {
			msglist = {}
		}

		for i, v in ipairs(offlinechats[Uin].msglist) do
			if v[1] == who and v[2] == ts and v[3] == msg then
				return
			end
		end

		if #offlinechats[Uin].msglist >= 20 then
			table.remove(offlinechats[Uin].msglist, 1)
		end

		table.insert(offlinechats[Uin].msglist, {
			who,
			ts,
			msg
		})

		if speeker then
			offlinechats[Uin].info = class.FansData.new(speeker)
		end

		local MyUin = self.Uin

		if MyUin then
			if MyUin ~= who then
				offlinechats[Uin].dirty = true
			end

			local account = self.account

			if account:isBuddy(Uin) then
				offlinechats[Uin].info = nil
			end

			self:saveOfflineChat()
		else
			offlinechats[Uin].dirty = true
		end
	end,
	sortOfflineChat = function (self, Uin)
		local offlinechats = self.offlinechats

		if offlinechats then
			local msglist = offlinechats[Uin] and offlinechats[Uin].msglist

			if msglist then
				table.sort(msglist, function (a, b)
					return a[2] < b[2]
				end)
			end
		end
	end,
	getBuddyNum = function (self)
		local Buddy = self.Buddy
		local BuddyList = Buddy.BuddyList

		return BuddyList.BuddyNum
	end,
	isBuddy = function (self, Uin)
		local account = self.account

		return account:isBuddy(Uin)
	end,
	getOfflineChat = function (self)
		if self.flags.getOfflineChat then
			return
		end

		self.flags.getOfflineChat = true

		threadpool:work(function ()
			do return end

			print("getOfflineChat Just One Time")

			local account = self.account

			while self.valid do
				if account and account.Uin > 1 and self.conn.authed then
					break
				end

				account = self.account

				threadpool:wait(1)
			end

			local sleep = 10
			local Buddy = account.Buddy
			local BuddyList = Buddy.BuddyList

			if BuddyList then
				local BuddyNum = BuddyList.BuddyNum

				if BuddyNum > 0 then
					for i = 1, BuddyNum do
						local BuddyInfo = BuddyList.BuddyInfos[i]

						if not self.valid then
							break
						end

						local code, msglist = self:remote_call("buddysvr", "chat_query", BuddyInfo.Uin)

						if code == ErrorCode.OK then
							for j, m in ipairs(msglist) do
								self:addOfflineChat(BuddyInfo.Uin, m[1], m[2], m[3])
							end

							self:sortOfflineChat(BuddyInfo.Uin)

							break
						elseif code == ErrorCode.TIMEOUT then
							sleep = sleep + 10

							if sleep >= 600 then
								sleep = 600
							end

							threadpool:wait(sleep)
						else
							return
						end

						threadpool:wait(1)
						threadpool:wait(15)
					end
				end
			end
		end)
	end,
	getWatchBuddyInfo = function (self)
		return self.eventcache.postWatchBuddySuccess
	end,
	ClearWatchBuddy = function (self)
		self.eventcache.postWatchBuddySuccess = nil
	end,
	getFriendChat = function (self, Uin)
		local offlinechats = self.offlinechats
		local chat = offlinechats and offlinechats[Uin]

		if not chat then
			return ""
		end

		local s = ""
		local me = self.Uin
		local account = self.account
		local myname = account.Account.RoleInfo.NickName
		local buddy = account:buddy_get(Uin)
		local nickname = buddy and buddy.RoleInfo and buddy.RoleInfo.NickName or chat.info and chat.info.RoleInfo and chat.info.RoleInfo.NickName or ""
		local msglist = chat.msglist

		if msglist then
			for i, v in ipairs(msglist) do
				local who, ts, msg = unpack(v)
				local color = who == me and "#c00ff00" or "#cf4b222"
				s = s .. self:formatChat(who, who == me and myname or nickname, ts, msg, color)
			end
		end

		return s
	end,
	isNewChatUin = function (self, Uin)
		if Uin == 1000 then
			return false
		end

		local offlinechats = self.offlinechats

		return offlinechats and offlinechats[Uin] and offlinechats[Uin].dirty == true
	end,
	removeNewChatUin = function (self, Uin)
		local offlinechats = self.offlinechats

		if offlinechats and offlinechats[Uin] then
			offlinechats[Uin].dirty = false
		end

		self:saveOfflineChat()
	end,
	getNewChatType = function (self)
		local type = 0
		local offlinechats = self.offlinechats
		local account = self.account

		if not offlinechats then
			return type
		end

		for Uin, v in pairs(offlinechats) do
			if account:isBuddy(Uin) and self:isNewChatUin(Uin) then
				type = type + 1

				break
			end
		end

		for Uin, v in pairs(offlinechats) do
			if not account:isBuddy(Uin) and self:isNewChatUin(Uin) then
				type = type + 2

				break
			end
		end

		return type
	end,
	makeBuddyDetail = function (self)
		local account = self.account

		return account:makeBuddyDetail()
	end,
	getBuddyDetail = function (self, index)
		return self.account:getBuddyDetail(index)
	end,
	getBuddyDetailByUin = function (self, Uin)
		return self.account:getBuddyDetailByUin(Uin)
	end,
	getBuddyDetailByYvID = function (self, yvid)
		return self.account:getBuddyDetailByYvID(yvid)
	end,
	removeFans = function (self, Uin)
		local offlinechats = self.offlinechats

		if offlinechats and offlinechats[Uin] then
			offlinechats[Uin] = nil
		end
	end,
	getFansMsgNum = function (self)
		local account = self.account
		local offlinechats = self.offlinechats
		local n = 0

		if offlinechats then
			for Uin, v in pairs(offlinechats) do
				if Uin ~= 1000 and not account:isBuddy(Uin) then
					n = n + 1
				end
			end
		end

		return n
	end,
	getFansInfo = function (self, idx, Uin)
		local offlinechats = self.offlinechats

		if not offlinechats then
			return
		end

		if Uin == nil or Uin <= 1 then
			idx = idx + 1
			local account = self.account
			local n = 0

			for Uin, v in pairs(offlinechats) do
				if Uin ~= 1000 and not account:isBuddy(Uin) then
					n = n + 1

					if n == idx then
						return v.info
					end
				end
			end
		else
			local chat = offlinechats[Uin]

			return chat and chat.info
		end
	end,
	query_friend_list = function (self, force)
		local extra = {
			country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil,
			apiid = LuaInterface:getApiId(),
			lang = get_game_lang and get_game_lang() or 0,
			ver = LuaInterface:getCltVersion()
		}
		force = false
		local code, list = nil

		if not self.chatpushconn or not self.chatpushconn.isopen then
			code, list = self:chatpush_rpc("buddysvr", "friend_list", {
				force,
				extra
			})
		else
			code, list = self.cluster.buddysvr.friend_list()
		end

		return code, list
	end,
	query_friend_baseinfo_list = function (self)
		return self.cluster.buddysvr.friend_baseinfo_list()
	end,
	query_friend_info = function (self, Uin, force)
		local code, info = nil

		if not self.chatpushconn or not self.chatpushconn.isopen then
			code, info = self:chatpush_rpc("buddysvr", "friend_info", {
				Uin,
				force
			})
		else
			code, info = self.cluster.buddysvr.friend_info(Uin, force)
		end

		return code, info
	end,
	batch_friend_info = function (self, Uins, issimple)
		local code, info = nil

		if not self.chatpushconn or not self.chatpushconn.isopen then
			code, info = self:chatpush_rpc("buddysvr", "batch_friend_info", {
				Uins,
				issimple or false
			})
		else
			code, info = self.cluster.buddysvr.batch_friend_info(Uins or {}, issimple or false)
		end

		return code, info
	end,
	query_friend_offlinechat = function (self, Uin)
		if not self.chatpushconn or not self.chatpushconn.isopen then
			return self:chatpush_rpc("buddysvr", "chat_query", {
				Uin
			})
		else
			return self.cluster.buddysvr.chat_query(Uin)
		end
	end,
	friend_check_newchat = function (self, list)
		return self:chatpush_rpc("buddysvr", "friend_check_newchat", list)
	end,
	phonelist2uinlist = function (self, phonelist)
		return self.cluster.buddysvr.phonelist2uinlist(phonelist)
	end,
	requestBuddyAttention = function (self, Uin)
		local code, info = self:remote_call("buddysvr", "buddy_add", Uin)

		if code == ErrorCode.OK then
			self:trigger("postAddBuddySuccess", info.RoleInfo.NickName, info.Uin)

			return true
		else
			return false
		end
	end,
	requestBuddyAttentionDel = function (self, Uin)
		local code, info = self:remote_call("buddysvr", "buddy_rm", Uin)

		if code == ErrorCode.OK then
			self:makeBuddyDetail()
			self:trigger("postAddBuddySuccess", "", Uin)

			return true
		else
			return false
		end
	end,
	requestBuddyWatch = function (self, Uin)
		if Uin <= 0 then
			return false
		end

		if Uin > math.pow(2, 32) - 1 then
			return false
		end

		if friendservice and friendservice.enabled then
			return ModuleMgr:GetMgr("NewFriend"):SearchPlayerByUin(Uin)
		else
			local code, info = self:remote_call("buddysvr", "info", tostring(Uin))

			if code == ErrorCode.OK then
				self.eventcache.postWatchBuddySuccess = class.BuddyInfo.new(info)

				self:trigger("postWatchBuddySuccess")

				return true
			else
				return false
			end
		end
	end,
	is_get_chatpush = function (self)
		return true
	end,
	chatstatuslist = function (self)
		if not self.chatpushconn or not self.chatpushconn.isopen then
			return self:chatpush_rpc("buddysvr", "chatstatuslist")
		else
			return self.cluster.buddysvr.chatstatuslist()
		end
	end,
	reportread = function (self, desid, destype)
		if not self.chatpushconn or not self.chatpushconn.isopen then
			return self:chatpush_rpc("buddysvr", "reportread", {
				uin = self.account.Account.Uin,
				desid = desid,
				destype = destype,
				lasttime = self.now
			})
		else
			local uin = self.account.Account.Uin
			local lasttime = self.now

			return self.cluster.buddysvr.reportread(uin, desid, destype, lasttime)
		end
	end,
	getAccountCreateTime = function (self)
		return AccountManager:get_account_create_time()
	end,
	bindRealAccount = function (self, AccountName, OpenString)
		local code = self:remote_call("baseinfo", "bind", AccountName, OpenString)

		if code == ErrorCode.OK then
			return ErrorCode.OK
		elseif code == ErrorCode.PRECHECK_ACCOUNT_BIND_ALREADY then
			return 7
		else
			return 999
		end
	end
}, class.ManagerBase)
