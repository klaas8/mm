local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("CSMgr", {
	account = {
		get = function (self)
			return self.service.AccountManager.account
		end
	},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin
	end,
	getAccountCreateTime = function (self)
		return AccountManager:get_account_create_time()
	end,
	bindRealAccount = function (self, AccountName, OpenString)
		local code = self:remote_call("baseinfo", "bind", AccountName, OpenString)

		if code == ErrorCode.OK then
			return ErrorCode.OK
		elseif code == ErrorCode.PRECHECK_ACCOUNT_BIND_ALREADY then
			return 7
		else
			return 999
		end
	end
}, class.ManagerBase)
