local class = _G.class

if not class then
	return
end

local container = _G.container

class.define("ManagerBase", {
	account_active_alive = false,
	account_active_seq = 0,
	uin_recycle_freezed_tip = "因你的迷你号账号长期未登录，系统自动对账号进行封禁一个月，期间你可以打客服电话#cff0000 0755-66821978 #n进行申诉，申诉成功后进行解封，一个月后正式对账号进行回收。",
	parents_guard_rule_flag = false,
	is_real_login = false,
	versionlow = false,
	isnewDeviceID = true,
	valid = true,
	events = {},
	eventcache = {
		get = function (self)
			return client_M.eventcache
		end
	},
	container = {
		get = function (self)
			return container
		end
	},
	conn = {
		get = function (self)
			return self.container.conn
		end
	},
	chatpushconn = {
		get = function (self)
			return self.container.chatpushconn
		end
	},
	cluster = {
		get = function (self)
			return self.service.cluster
		end
	},
	now = {
		get = function (self)
			return self.conn.svrtime
		end
	},
	const = {
		get = function (self)
			return cpp_const
		end
	},
	cache = {
		get = function (self)
			return self.account.cache
		end
	},
	Uin = {
		get = function (self)
			return self.account and self.account.Uin
		end
	},
	statics_for_today_cache = {},
	ctxpop = function (self, key)
		return self.account:ctxpop(key)
	end,
	ctxput = function (self, key, value)
		return self.account:ctxput(key, value)
	end,
	ctxclear = function (self, key)
		return self.account:ctxclear(key)
	end,
	GetAccountActiveOwner = function (self)
		return self.service and self.service.AccountManager or self
	end,
	StartAccountActive = function (self, account)
		local owner = self:GetAccountActiveOwner()
		owner.account_active_seq = (owner.account_active_seq or 0) + 1
		owner.account_active_alive = true
		owner.account_active_account = account or self.account

		return self:GetAccountActiveState()
	end,
	StopAccountActive = function (self, reason)
		local owner = self:GetAccountActiveOwner()
		owner.account_active_seq = (owner.account_active_seq or 0) + 1
		owner.account_active_alive = false
		owner.account_active_account = nil

		print("StopAccountActive", reason, owner.account_active_seq)
	end,
	GetAccountActiveState = function (self)
		local owner = self:GetAccountActiveOwner()

		return {
			seq = owner.account_active_seq or 0,
			alive = owner.account_active_alive == true,
			account = owner.account_active_account
		}
	end,
	RestoreAccountActiveState = function (self, state)
		if not state then
			self:StopAccountActive("restore_empty")

			return
		end

		local owner = self:GetAccountActiveOwner()
		owner.account_active_seq = state.seq or 0
		owner.account_active_alive = state.alive == true
		owner.account_active_account = state.account
	end,
	GetAccountActiveToken = function (self, account)
		local owner = self:GetAccountActiveOwner()
		account = account or self.account

		if owner.account_active_alive ~= true then
			return nil
		end

		if not account or owner.account_active_account ~= account then
			return nil
		end

		return {
			seq = owner.account_active_seq or 0,
			account = account
		}
	end,
	IsAccountActiveTokenAlive = function (self, token)
		local owner = self:GetAccountActiveOwner()

		return token and owner.account_active_alive == true and token.seq == (owner.account_active_seq or 0) and token.account == self.account and token.account == owner.account_active_account
	end,
	IsAccountActive = function (self)
		return self:IsAccountActiveTokenAlive(self:GetAccountActiveToken()) and true or false
	end,
	acc_keychain_load = function (self)
		local s = GetClientInfo():getUserAccountInfo()

		if s then
			local ok, json = pcall(JSON.decode, JSON, s)

			if ok and json then
				local url = LuaInterface:geturl()

				if url and json.url and url == json.url then
					return json.data
				end
			end
		end
	end,
	load_from_file = function (self, path)
		local data = self.container:load_from_file(path)

		if not data and path == "current" then
			local env = utils.env
			local jsonstr = GetClientInfo():ReadMemFile("current", "current" .. env)
			local ok, json = pcall(JSON.decode, JSON, jsonstr)

			if ok and json then
				if json.encrypt then
					data = xxtea.decrypt(json.encrypt, string.len(json.encrypt), "b64")
				else
					data = json
				end
			end
		end

		if path == "current" and type(data) == "string" then
			local ok, json = pcall(JSON.decode, JSON, data)

			if ok and type(json) == "table" then
				data = json
			end
		end

		return data
	end,
	acc_keychain_save = function (self, data)
		local ok, jsonstr = pcall(JSON.encode, JSON, {
			data = data,
			url = LuaInterface:geturl()
		})

		if ok and jsonstr then
			GetClientInfo():saveUserAccountInfo(jsonstr)
		end
	end,
	save_to_file = function (self, path, data, no_save_keychain)
		if path == "current" then
			local env = utils.env
			local old = self:load_from_file(path)
			local same = table.equal(old, data)

			if not old then
				local history = self:load_from_file("history")

				if type(history) ~= "table" then
					history = {}
				end

				table.insert(history, data)
				self:save_to_file("history", history)
			end

			if old and same == false then
				local history = self:load_from_file("history")

				if type(history) ~= "table" then
					history = {}
				end

				table.insert(history, data)
				self:save_to_file("history", history)
			end

			local apiid = LuaInterface:getApiId()

			if apiid == 45 or apiid == 345 or apiid == 346 then
				self:acc_keychain_save(data)
			end

			if not no_save_keychain then
				local env = utils.env
				local ok, jsonstr = pcall(JSON.encode, JSON, data)

				if ok and jsonstr then
					if xxtea then
						local b64string = xxtea.encrypt(jsonstr, string.len(jsonstr), "b64")

						GetClientInfo():writeDocumentsFile("current" .. env, JSON:encode({
							encrypt = b64string
						}))
					else
						GetClientInfo():writeDocumentsFile("current" .. env, jsonstr)
					end
				end
			end

			local env = utils.env
			local ok, jsonstr = pcall(JSON.encode, JSON, data)

			if ok and jsonstr then
				if xxtea then
					local b64string = xxtea.encrypt(jsonstr, string.len(jsonstr), "b64")

					GetClientInfo():WriteMemFile("current", "current" .. env, JSON:encode({
						encrypt = b64string
					}))
				else
					GetClientInfo():WriteMemFile("current", "current" .. env, jsonstr)
				end
			end
		end

		return self.container:save_to_file(path, data)
	end,
	delete_file = function (self, path)
		return self.container:delete_file(path)
	end,
	httpstring = function (self, url, timeout)
		return self.container:httpstring(url, timeout)
	end,
	remote_call = function (self, servicename, methodname, ...)
		local netstate = GetClientInfo():getNetworkState() or 1
		local print = _G.print
		local t = CommonUtil:getSystemTick()

		print("remote_call start == ", servicename, methodname, netstate, ...)

		local t_code, account, standalone, pwd_wrong, activeToken = nil

		LoginManager:StartStep("l_rc", {}, {
			servicename = servicename,
			methodname = methodname
		})

		while true do
			if netstate == 0 then
				t_code = ErrorCode.NETWORK_ERROR

				break
			end

			account = self.account

			if not account then
				print("remote_call account nil")

				t_code = ErrorCode.NOT_YET

				break
			end

			activeToken = self:GetAccountActiveToken(account)

			if not activeToken then
				print("remote_call inactive account active", servicename, methodname)

				t_code = ErrorCode.NOT_YET

				break
			end

			standalone = self.container.cfg.standalone

			if not client_M.do_not_showloadloop[methodname] then
				ShowNoTransparentLoadLoop()
			end

			pwd_wrong = self.pwd_wrong or false

			if pwd_wrong == true then
				if not client_M.do_not_showloadloop[methodname] then
					HideNoTransparentLoadLoop()
				end

				t_code = ErrorCode.ACCOUNT_PASSWD_NOT_OK

				break
			end

			local precheckcode = account:precheck(methodname, ...)

			if precheckcode ~= ErrorCode.OK then
				if not client_M.do_not_showloadloop[methodname] then
					HideNoTransparentLoadLoop()
				end

				t_code = precheckcode

				break
			end

			break
		end

		print("remote_call check == ", servicename, methodname, pwd_wrong, standalone, CommonUtil:getSystemTick() - t, self.conn and self.conn.is_doing_rpc)

		t = CommonUtil:getSystemTick()

		if t_code then
			LoginManager:EndStep("l_rc", {}, {
				code = t_code
			})

			return t_code
		end

		local ret = nil

		if standalone == true then
			account:tick(self.now)

			local f = account and account.pseudo[methodname]

			if f then
				local result = {
					pcall(f, account, ...)
				}

				if not result[1] then
					print(result)

					ret = {
						ErrorCode.EXCEPTION,
						result[2]
					}
				else
					table.remove(result, 1)

					ret = result
				end
			else
				ret = {
					ErrorCode.OK
				}
			end
		else
			for i = 1, 600 do
				if self.conn.is_doing_rpc == false then
					break
				end

				threadpool:wait(0.1)
			end

			if not self:IsAccountActiveTokenAlive(activeToken) then
				print("remote_call inactive account active before rpc", servicename, methodname)

				if not client_M.do_not_showloadloop[methodname] then
					HideNoTransparentLoadLoop()
				end

				LoginManager:EndStep("l_rc", {}, {
					inactive = true,
					code = ErrorCode.NOT_YET
				})

				return ErrorCode.NOT_YET
			end

			local version_info = account:version_info()

			account:pre_rpc()
			print("remote_call pre_rpc == ", servicename, methodname, CommonUtil:getSystemTick() - t)

			t = CommonUtil:getSystemTick()

			if self.cluster[servicename][methodname] then
				ret = {
					self.cluster[servicename][methodname](version_info, ...)
				}
			end

			print("remote_call cluster == ", servicename, methodname, CommonUtil:getSystemTick() - t)

			t = CommonUtil:getSystemTick()

			if not client_M.do_not_showloadloop[methodname] then
				HideNoTransparentLoadLoop()
			end

			if not self:IsAccountActiveTokenAlive(activeToken) then
				print("remote_call drop stale account active", servicename, methodname)
				account:post_rpc()
				LoginManager:EndStep("l_rc", {}, {
					inactive = true,
					code = ErrorCode.NOT_YET
				})

				return ErrorCode.NOT_YET
			end

			if ret and ret[1] == ErrorCode.OK and ret[2] then
				local data = table.remove(ret, 2)

				if type(data) == "table" and type(data[1]) == "number" then
					local ts = table.remove(data, 1) + utils.time_2017_01_01

					account:sync(data)
					self.conn:adjust_sec(ts)
					account:tick(ts)
				end
			end

			print("remote_call account sync == ", servicename, methodname, CommonUtil:getSystemTick() - t, ret and ret[1])

			t = CommonUtil:getSystemTick()
		end

		self:do_remote_result(ret, servicename, methodname, ...)
		print("remote_call do_remote_result == ", servicename, methodname, CommonUtil:getSystemTick() - t)

		t = CommonUtil:getSystemTick()

		if not ret then
			print("remote_call ret_nil", debug.traceback())
		end

		local code = ret and ret[1]

		LoginManager:EndStep("l_rc", {}, {
			code = code,
			ret = code ~= ErrorCode.OK and ret or nil
		})

		if code == ErrorCode.OK then
			if type(account[methodname]) == "function" then
				local a = {
					...
				}

				for i = 2, #ret do
					table.insert(a, ret[i])
				end

				local result = {
					pcall(account[methodname], account, unpack(a))
				}

				if not result[1] then
					print("Error", result[2])
					account:post_rpc()

					return ErrorCode.EXCEPTION, result[2]
				end

				account:post_rpc()
				account:flush()

				return unpack(result, 2)
			else
				account:post_rpc()

				return unpack(ret)
			end
		else
			local conn = self.conn

			if code == ErrorCode.TIMEOUT then
				if conn and (conn.timeout_count or 0) >= 3 then
					conn.timeout_count = 0
					conn.authed = false

					conn:closesocket()
				else
					conn.timeout_count = (conn.timeout_count or 0) + 1
				end
			end

			if code == ErrorCode.OK then
				conn.timeout_count = 0
			end

			print("remote_call ", servicename, methodname, "args:", {
				...
			}, "=>", ErrorCode[code], unpack(ret, 2))
			account:post_rpc()

			return unpack(ret)
		end

		print("remote_call end == ", servicename, methodname, CommonUtil:getSystemTick() - t)
	end,
	statics_for_today_dot = function (self, key, num, reset)
		num = num or 1
		local account = self.account
		local Uin = account and account.Uin or 0

		if Uin > 0 and type(key) == "string" then
			local day = utils.ts2day(self.now)
			local path = "statics_for_today_" .. Uin

			if self.statics_for_today_uin ~= Uin then
				self.statics_for_today_uin = Uin
				self.statics_for_today_cache = self:load_from_file(path) or {
					day = day
				}
			end

			local statics = self.statics_for_today_cache

			if day ~= statics.day then
				self.statics_for_today_cache = {
					day = day
				}
			end

			statics = self.statics_for_today_cache

			if reset then
				statics[key] = num
			else
				statics[key] = (statics[key] or 0) + num
			end

			self:save_to_file(path, statics)
		end
	end,
	statics_for_today_get = function (self, key)
		local account = self.account
		local Uin = account and account.Uin or 0

		if Uin > 0 and type(key) == "string" then
			local day = utils.ts2day(self.now)

			if self.statics_for_today_uin ~= Uin then
				self.statics_for_today_uin = Uin
				local path = "statics_for_today_" .. Uin
				self.statics_for_today_cache = self:load_from_file(path) or {
					day = day
				}
			end

			local statics = self.statics_for_today_cache

			if day ~= statics.day then
				self.statics_for_today_cache = {
					day = day
				}
			end

			statics = self.statics_for_today_cache

			return statics and statics[key] or 0
		end
	end,
	savecfg = function (self, key, value)
		local account = self.account

		if account and type(key) == "string" then
			local Uin = account.Uin or 0
			local path = "config_" .. Uin
			local t = self:load_from_file(path) or {}
			t[key] = value

			self:save_to_file(path, t)
		end
	end,
	getcfg = function (self, key)
		local account = self.account

		if account and type(key) == "string" then
			local Uin = account.Uin or 0
			local path = "config_" .. Uin
			local t = self:load_from_file(path)

			return t and t[key]
		end
	end,
	http_encode = function (self, data)
		local packdata = client_M.msgpack.pack(data)
		local s = xxtea.encrypt_zip(packdata, #packdata, "b64") or ""
		s = s:gsub("+", "-"):gsub("/", "_"):gsub("=", ":")

		return s
	end,
	http_decode = function (self, pkg)
		return client_M.msgpack.unpack(xxtea.decrypt_unzip(pkg, string.len(pkg), "b64"))
	end,
	http_rpc = function (self, path, methodname, info, ret_obj, extra_param)
		ret_obj = ret_obj or false
		info.DeviceID = info.DeviceID or GetClientInfo():getDeviceID() or "cantget"
		info.source = info.source or "nosource"
		info.version = info.version or LuaInterface:getCltVersion() or "noversion"
		info.apiid = LuaInterface:getApiId() or ""
		info.svrTime = getServerNow()
		local msg = self:http_encode(info)
		local query = "msg=" .. msg
		local tosign = query .. "&key=" .. client_M.http_authkey
		local sign = g_recharge_md5_related.md5sum(tosign, #tosign)
		local url = LuaInterface:geturl()
		url = url:gsub("/$", "")

		if not path:match("^/") then
			path = "/" .. path
		end

		path = path:gsub("/$", "")
		path = path .. "/" .. methodname

		if not client_M.do_not_showloadloop[methodname] then
			ShowNoTransparentLoadLoop()
		end

		local ret = nil
		url = url .. path .. "?" .. query .. "&sign=" .. sign

		if ret_obj then
			local ret_temp = {
				http_get_string_with_rpc(url, nil, nil, extra_param)
			}
			local l_code = ret_temp[1] or ErrorCode.FAILED

			if l_code ~= ErrorCode.OK then
				ret = {
					l_code
				}
			else
				local l_result = ret_temp[2]
				local ok, json = pcall(JSON.decode, JSON, l_result)

				if ok and type(json) == "table" then
					ret = {
						json.code,
						json
					}
					json.code = nil
				else
					ret = {
						ErrorCode.FAILED
					}
				end
			end
		else
			ret = {
				http_get_with_rpc(url, nil, nil, extra_param)
			}
		end

		if not client_M.do_not_showloadloop[methodname] then
			HideNoTransparentLoadLoop()
		end

		return unpack(ret)
	end,
	http_login = function (self, path, methodname, info, ret_obj, extra_param)
		ret_obj = ret_obj or false
		extra_param = extra_param or {}
		info.DeviceID = info.DeviceID or type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget"
		info.source = info.source or "nosource"
		info.version = info.version or LuaInterface:getCltVersion() or "noversion"
		info.apiid = LuaInterface:getApiId() or ""
		info.svrTime = getServerNow()
		local msg = self:http_encode(info)
		local query = "msg=" .. msg
		local tosign = query .. "&key=" .. client_M.http_authkey
		local sign = g_recharge_md5_related.md5sum(tosign, #tosign)
		local url = "https://wskacchm.mini1.cn:14100/"
		local urlTb = {
			"https://wskacchm.mini1.cn:14100/",
			"https://wskacchm.mini1.cn:14110/",
			"https://wskacchm.mini1.cn:14120/",
			"https://wskacchm.mini1.cn:14130/",
			"https://wskacchm.mini1.cn:14140/",
			"https://wskacchm.mini1.cn:14150/"
		}

		math.randomseed(tostring(os.time()):reverse():sub(1, 7))

		local index = math.random(#urlTb)
		url = urlTb[index]
		local env = utils.env or 0

		if env == 1 then
			url = LuaInterface:geturl()
		end

		url = url:gsub("/$", "")

		if not path:match("^/") then
			path = "/" .. path
		end

		path = path:gsub("/$", "")
		path = path .. "/" .. methodname

		if not client_M.do_not_showloadloop[methodname] then
			ShowNoTransparentLoadLoop()
		end

		url = url .. path .. "?" .. query .. "&sign=" .. sign
		local seq = gen_gid()

		while not ns_http do
			threadpool:wait(0)
		end

		ns_http.func.rpc_string_raw(url, function (ret, user_data, curlCode)
			threadpool:notify(seq, ErrorCode.OK, {
				ret = ret,
				user_data = user_data,
				curlCode = curlCode
			})
		end, nil, 2)

		local timeout = extra_param.timeout or 300
		local t_params = {
			wait_time = timeout
		}

		LoginManager:StartStep("l_hl", t_params, {
			url = url
		})

		local code, http_result = threadpool:wait(seq, timeout, tick)
		http_result = http_result or {}
		local curlCode = http_result.curlCode
		local ret_msg = {}
		local ok = nil

		if code == ErrorCode.OK then
			ok, ret_msg = pcall(JSON.decode, JSON, http_result.ret)

			if not ret_msg then
				self:oplog_login_error("", "http_login", "ret_msg is nil", {
					path = path,
					methodname = methodname,
					info = info,
					http_result = http_result
				})
			end
		end

		if not client_M.do_not_showloadloop[methodname] then
			HideNoTransparentLoadLoop()
		end

		if curlCode then
			ret_msg = ret_msg or {}
			ret_msg.curl_result = {
				curlCode = curlCode
			}
		end

		local t_code = ret_msg and ret_msg.code

		LoginManager:EndStep("l_hl", {}, {
			code = t_code,
			resp = t_code ~= ErrorCode.OK and ret_msg or nil
		})

		return ret_msg
	end,
	http_login_post = function (self, path, methodname, info)
		info.DeviceID = info.DeviceID or GetClientInfo():getDeviceID() or "cantget"
		info.source = info.source or "nosource"
		info.version = info.version or LuaInterface:getCltVersion() or "noversion"
		info.apiid = LuaInterface:getApiId() or ""
		local url = LuaInterface:geturl()
		url = url:gsub("/$", "")

		if not path:match("^/") then
			path = "/" .. path
		end

		path = path:gsub("/$", "")
		path = path .. "/" .. methodname

		if not client_M.do_not_showloadloop[methodname] then
			ShowNoTransparentLoadLoop()
		end

		url = url .. path
		local postdata = JSON:encode(info)
		local seq = gen_gid()

		while not ns_http do
			threadpool:wait(0)
		end

		ns_http.func.rpc_do_http_post(url, function (ret)
			threadpool:notify(seq, ErrorCode.OK, ret)
		end, nil, postdata)

		local code, http_result = threadpool:wait(seq, 300, tick)
		local ret_msg = {}
		local ok = nil

		if code == ErrorCode.OK then
			ok, ret_msg = pcall(JSON.decode, JSON, http_result)
		end

		if not client_M.do_not_showloadloop[methodname] then
			HideNoTransparentLoadLoop()
		end

		return ret_msg
	end,
	show_errormsg = function (self, code, methodname)
		if methodname then
			if not client_M.do_not_showloadloop[methodname] and not client_M.do_not_show_errrocode[code] then
				ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
			end
		elseif not client_M.do_not_show_errrocode[code] then
			ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
		end
	end,
	do_remote_result = function (self, result, servicename, methodname)
		if type(result) == "table" and type(result[1]) == "number" then
			local code = result[1]

			if code == ErrorCode.OK then
				local obj = self.account

				if obj then
					if obj:check_written_off() then
						result[1] = ErrorCode.PRECHECK_ACCOUNT_IS_WRITTEN_OFF
					elseif obj:isFreeze() then
						result[1] = ErrorCode.PRECHECK_ACCOUNT_IS_FREEZED
						result[2] = {
							reason = obj.FreezeReason,
							timeleft = obj.FreezeTimeLeft
						}
					end
				end
			end

			local code = result[1]
			local info = result[2]

			if code == ErrorCode.PRECHECK_ACCOUNT_IS_FREEZED then
				local env = utils.env or 0

				if type(info) == "table" and type(info.timeleft) == "number" and info.timeleft > 0 and not client_M.do_not_showloadloop[methodname] and env < 10 then
					local stringid = 10589
					local s = DefMgr and DefMgr.getStringDef and DefMgr:getStringDef(stringid)
					local reason = info.reason or ""

					if type(s) == "string" and #s > 0 and type(reason) == "string" then
						print("FreezeReason:", reason)

						if reason == "uin_recycled" then
							self:msgbox(self.uin_recycle_freezed_tip)
						else
							self:msgbox(GetS(stringid, os.date("%Y-%m-%d %H:%M", getServerNow() + info.timeleft)))
						end
					elseif not client_M.do_not_showloadloop[methodname] and not client_M.do_not_show_errrocode[code] then
						if ShowGameTipsWithoutFilter then
							ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
						else
							ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
						end
					end
				elseif not client_M.do_not_showloadloop[methodname] and not client_M.do_not_show_errrocode[code] then
					if ShowGameTipsWithoutFilter then
						ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
					else
						ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
					end
				end
			elseif code ~= ErrorCode.OK and not client_M.do_not_showloadloop[methodname] and not client_M.do_not_show_errrocode[code] then
				if ShowGameTipsWithoutFilter then
					ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
				else
					ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)
				end
			end
		end

		return result
	end,
	login_limit = function (self)
		local conn = self.conn
		conn = container and container.conn

		if conn and not conn.other then
			conn:heartbeat()
		end

		print("start login_limit")

		if not self.cluster.baseinfo.login_limit then
			return
		end

		local channel_auth_info = RealNameModule:GetChannelAuthorInfo()

		if channel_auth_info then
			channel_auth_info.apiid = LuaInterface:getApiId() or 1
			channel_auth_info.cltversion = LuaInterface:getCltVersion() or 0
			channel_auth_info.country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or 0
			channel_auth_info.language = get_game_lang and get_game_lang() or 0
			channel_auth_info.ip = self:get_outer_ip_and_delay() or "0.0.0.0"
			channel_auth_info.device_id = GetClientInfo():getDeviceID() or ""
			channel_auth_info.is_first_game = 0
		end

		if not channel_auth_info then
			channel_auth_info = {
				apiid = LuaInterface:getApiId() or 1,
				cltversion = LuaInterface:getCltVersion() or 0,
				country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or 0,
				language = get_game_lang and get_game_lang() or 0,
				ip = self:get_outer_ip_and_delay() or "0.0.0.0",
				device_id = GetClientInfo():getDeviceID() or "",
				is_first_game = 0
			}
		end

		local code, end_time = self:remote_call("baseinfo", "login_limit", channel_auth_info)

		if code == ErrorCode.TIMEOUT or code == ErrorCode.NETWORK_ERROR then
			return
		end

		print("end login_limit", code, end_time)

		if code ~= ErrorCode.OK then
			print("login_limit on card", code)

			if code == ErrorCode.LOGIN_LIMIT_NO_IDCARD then
				print("login_limit on card true")
				ShowIdentityNameAuthFrame()

				return code
			end

			conn:close()

			self.conn.authed = false
			self.conn.token = nil
			self.conn.sign = nil
			self.conn.other = nil
			local tips = "亲爱的冒险家，根据国家游戏防沉迷规定，18岁以下的未成年人仅能在法定节假日和每周五、周六、周日20:00 ~ 21:00玩游戏。"

			if ClientCurGame and ClientCurGame.setOperateUI then
				ClientCurGame:setOperateUI(true)
			end

			if AntiAddictionModule:OpenAntiAddictionBox() then
				threadpool:wait(30)
				LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
			end

			return code
		else
			if end_time and end_time > 0 then
				threadpool:work(function ()
					while true do
						local curTime = AccountManager:getSvrTime() or os.time()
						local tb = os.date("*t", curTime)
						local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
						local last_on_time = end_time - curT

						if last_on_time < 600 and flag == false then
							flag = true
							local tips = "亲爱的冒险家，根据国家最新的游戏防沉迷规定，10分钟后你将无法继续游戏，请合理安排时间"

							MessageBox(4, tips)
						end

						if last_on_time < 0 then
							local tips = "亲爱的冒险家，根据国家游戏防沉迷规定，18岁以下的未成年人仅能在法定节假日和每周五、周六、周日20:00 ~ 21:00玩游戏。"
							local conn = self.conn

							conn:close()

							self.conn.authed = false
							self.conn.token = nil
							self.conn.sign = nil
							self.conn.other = nil

							if ClientCurGame and ClientCurGame.setOperateUI then
								ClientCurGame:setOperateUI(true)
							end

							if AntiAddictionModule:OpenAntiAddictionBox() then
								threadpool:wait(30)
								LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
							end
						end

						threadpool:wait(30)
					end
				end)
			end

			return code
		end
	end,
	do_data_update = function (self, sync_role_info)
		local conn = container and container.conn
		local bHeartbeat = false

		if conn and not conn.other and conn.socket then
			conn:heartbeat()

			bHeartbeat = true
		end

		LoginManager:StartStep("l_dp", {}, {
			bHeartbeat = bHeartbeat
		})

		local cltapiid = LuaInterface:getApiId()
		local device_system = ""
		local devinfo = type(AdGetDeviceInfo) == "function" and AdGetDeviceInfo() or nil

		if devinfo and devinfo.SystemVersion and devinfo.Platform then
			device_system = string.format("%s%s", devinfo.SystemVersion, devinfo.Platform)
		end

		local code, svrinfo = self:remote_call("baseinfo", "update", {
			Latitude = 0,
			Longitude = 0,
			ApiID = cltapiid,
			CltVersion = LuaInterface:getCltVersion(),
			CltType = LuaInterface:getCltTye(),
			RoleInfo = sync_role_info and self.account and self.account.Account and self.account.Account.RoleInfo or nil,
			extra = {
				Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil,
				DeviceToken = GetDeviceManager():getDeviceToken() or nil,
				DeviceVender = GetDeviceManager():getDeviceVender() or nil,
				DeviceModel = type(GetDeviceModel) == "function" and GetDeviceModel() or nil,
				DeviceID = GetClientInfo():getDeviceID() or "cantget",
				CltApiID = cltapiid,
				CltLang = get_game_lang and get_game_lang() or "",
				DeviceSystem = device_system,
				shouq_channel_id = cltapiid == 56 and getShouQChannelId and getShouQChannelId() or nil
			},
			birthday = sync_role_info and self.account and self.account.birthday or nil
		})

		LoginManager:EndStep("l_dp", {}, {
			code = code,
			svrinfo = code ~= ErrorCode.OK and svrinfo or nil
		})
		print("1 .data_update", code, svrinfo)
		print("1 .data_needauthcity", code, svrinfo and svrinfo.needauthcity or "")

		if code == ErrorCode.OK then
			local obj = self.account
			obj.svrinfo = svrinfo

			obj:makeBuddyDetail()

			self.isnewDeviceID = svrinfo.isnewDeviceID
			self.versionlow = svrinfo.versionlow

			self:updateJuheInfo()

			if AccountGameModeClass and AccountGameModeClass.ResetGameMode then
				AccountGameModeClass:ResetGameMode()
			end

			if AccountManager:realname_state() == 1 and HideIdentityNameAuthFrame then
				HideIdentityNameAuthFrame(true)
			end

			if self.account.checkResetNickname then
				threadpool:work(function ()
					self.account:checkResetNickname()
				end)
			end

			local RoleSkinID = self.account.leveldb and self.account.leveldb.RoleSkinID or self.account.RoleInfo and self.account.RoleInfo.SkinID or 0

			if LuaInterface:getCltVersion() < 70144 and RoleSkinID and RoleSkinID >= 257 and RoleSkinID <= 266 then
				print("update getCltVersion", LuaInterface:getCltVersion())

				if self.account.leveldb.RoleSkinID then
					print("windhe self.account.leveldb.RoleSkinID is", self.account.leveldb.RoleSkinID)

					self.account.leveldb.RoleSkinID = 0
				end

				if self.account.RoleInfo and self.account.RoleInfo.SkinID then
					print("windhe self.account.RoleInfo.SkinID is", self.account.RoleInfo.SkinID)

					self.account.RoleInfo.SkinID = 0
				end
			end

			print("windhe RoleSkinID id is", RoleSkinID)
		end

		return code, svrinfo or {}
	end,
	data_update = function (self, sync_role_info)
		if threadpool.running then
			return self:do_data_update(sync_role_info)
		else
			local env = utils.env or 0

			if env == 1 then
				ShowGameTipsWithoutFilter("call data_update error for NOT_IN_THREAD")
				MiniLogWarning("call data_update error for NOT_IN_THREAD" .. tostring(debug.traceback()))
			end

			threadpool:work(function ()
				return self:do_data_update(sync_role_info)
			end)
		end
	end,
	notify_data_update = function (self)
		threadpool:work(function ()
			self:data_update()
		end)
	end,
	do_chatpush = function (self)
		local enable = true
		local chatpushconn = self.chatpushconn

		if not chatpushconn.valid then
			if enable then
				chatpushconn:start()

				if not chatpushconn.isopen then
					local Uin = AccountManager:getUin()

					print("not chatpushconn.isopen " .. Uin)

					local env = utils.env
					local lburl = ""

					if env == 1 then
						lburl = "http://120.24.64.132:19601"
					elseif env == 0 then
						lburl = "https://chatpush.mini1.cn:19602"
					elseif env == 2 then
						lburl = "http://211.159.183.137:19601"
					elseif env == 11 then
						lburl = "http://shequ.miniworldplus.com:19090"
					elseif env == 10 then
						lburl = "http://chatpush.miniworldgame.com:19601"
					end

					if ns_version.pushchat and ns_version.pushchat.pushlb and type(ns_version.pushchat.pushlb) == "string" then
						local pushlb = utils.split(ns_version.pushchat.pushlb, ",")

						if #pushlb > 0 then
							lburl = pushlb[math.random(#pushlb)]
						end
					end

					if lburl and lburl ~= "" then
						chatpushconn:connect(Uin, lburl)
					else
						print("chatpushconn get lburl error")
					end
				else
					print("chatpushconn.isopen " .. Uin)
				end
			else
				print("chatpushconn.disable")
			end
		end
	end,
	get_account_info = function (self, Uin)
		self.account = class.Account.new(Uin, self)

		self:StartAccountActive(self.account)

		local standalone = self.container.cfg.standalone

		AccountManager:enterGame2New()

		return ErrorCode.OK, "not_first_login"
	end,
	create_account = function (self, Uin)
		self.account = class.Account.new(Uin, self)

		self:StartAccountActive(self.account)

		return ErrorCode.OK
	end,
	loop = function (self)
		while self.valid do
			if #self.events > 0 then
				local e = table.remove(self.events, 1)

				if e[1] == "chest_need_update" then
					print("Chest Exp, 应该升级了, 重新调用下chest_update")

					local code = self:remote_call("homesvr", "chest_update")

					self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)
				else
					print("trigger event", e)
					GameEventQue[e[1]](GameEventQue, unpack(e, 2))
				end
			end

			threadpool:wait(0)
		end
	end,
	trigger = function (self, eid, ...)
		local n = #self.events

		for i = n, 1, -1 do
			local e = self.events[i]

			if e[1] == eid then
				table.remove(self.events, i)
			end
		end

		table.insert(self.events, {
			eid,
			...
		})
	end,
	time2string = function (self, ts)
		ts = ts or os.time()

		return "(" .. os.date("%Y", ts) .. "-" .. os.date("%m", ts) .. "-" .. os.date("%d", ts) .. " " .. os.date("%X", ts) .. ")"
	end,
	route = function (self, msgid, Uin, ...)
		self.cluster.buddysvr.route(msgid, Uin, ...)
	end,
	routemore = function (self, msgid, Uins, ...)
		if not self.chatpushconn or not self.chatpushconn.isopen then
			return self:chatpush_rpc("buddysvr", "routemore", {
				msgid,
				Uins,
				...
			})
		else
			self.cluster.buddysvr.routemore(msgid, Uins, ...)
		end
	end,
	listento = function (self, msgid, func)
		if self.service then
			self.service:listento(msgid, func)
		end
	end,
	msgbox = function (self, msg, boxtype, timeout, tick)
		while threadpool:waitting("msgbox") do
			threadpool:wait(0)
		end

		if type(MessageBox) == "function" then
			threadpool:work(function ()
				MessageBox(boxtype or 4, msg, function (btn)
					threadpool:notify("msgbox", ErrorCode.OK, btn)
				end)
			end)

			return threadpool:wait("msgbox", timeout or 86400, tick)
		end

		return ErrorCode.OK
	end,
	chatpush_rpc = function (self, ...)
		if (not self.chatpushconn or not self.chatpushconn.valid) and (not self.conn or not self.conn.authed) then
			return ErrorCode.FAILED
		end

		local base64CharTable = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

		local function base64decode(data)
			data = string.gsub(data, "[^" .. base64CharTable .. "=]", "")

			return data:gsub(".", function (x)
				if x == "=" then
					return ""
				end

				local r = ""
				local f = base64CharTable:find(x) - 1

				for i = 6, 1, -1 do
					r = r .. (f % 2^i - f % 2^(i - 1) > 0 and "1" or "0")
				end

				return r
			end):gsub("%d%d%d?%d?%d?%d?%d?%d?", function (x)
				if #x ~= 8 then
					return ""
				end

				local c = 0

				for i = 1, 8 do
					c = c + (x:sub(i, i) == "1" and 2^(8 - i) or 0)
				end

				return string.char(c)
			end)
		end

		local function encode(data)
			local msg = table2json(data)
			local encmsg = self.chatpushconn:encrypt(msg)
			local b64str = ns_http.func.base64_encode(encmsg)

			return ns_http.func.url_encode(b64str)
		end

		local function decode(data)
			local b64str = base64decode(data)
			local decstr = self.chatpushconn:decrypt(b64str)

			return json2table(decstr)
		end

		local env = utils.env
		local msgurl = ""

		if env == 1 then
			msgurl = "http://120.24.64.132:19601"
		elseif env == 0 then
			msgurl = "https://chatpush.mini1.cn:19602"
		elseif env == 2 then
			msgurl = "http://211.159.183.137:19601"
		elseif env == 11 then
			msgurl = "http://shequ.miniworldplus.com:19090"
		elseif env == 10 then
			msgurl = "http://chatpush.miniworldgame.com:19601"
		end

		if ns_version.chatpushmsg and ns_version.chatpushmsg.msgurls and type(ns_version.chatpushmsg.msgurls) == "string" then
			local urls = utils.split(ns_version.chatpushmsg.msgurls, ",")

			if #urls > 0 then
				msgurl = urls[math.random(#urls)]
			end
		end

		local reqparams = {
			...
		}
		local uin = AccountManager:getUin()
		local key = "#Chat@Push.99#"
		local time = self.now
		local extdata = encode(reqparams)
		local auth = gFunc_getmd5(time .. key .. uin .. extdata)
		local s2_, s2t_, pure_s2t_ = get_login_sign()
		local loginauth = gFunc_getmd5(time .. s2_ .. uin)
		local lbserver = string.format("%s/minilb/rpc?uid=%d&time=%d&auth=%s&loginauth=%s&s2t=%s", msgurl, uin, time, auth, loginauth, tostring(pure_s2t_))
		local seq = gen_gid()

		while not ns_http do
			threadpool:wait(0)
		end

		ns_http.func.rpc_do_http_post(lbserver, function (ret)
			threadpool:notify(seq, ErrorCode.OK, ret)
		end, nil, extdata)

		local code, respdata = threadpool:wait(seq, 10)

		if code and respdata and code == ErrorCode.OK then
			return unpack(decode(respdata))
		end

		return ErrorCode.FAILED
	end,
	set_lookdevice = function (self, islook)
		return self:remote_call("baseinfo", "set_lookdevice", islook)
	end,
	is_lookdevice = function (self)
		if AccountManager:client_ready() == false then
			return false
		end

		if self.account and self.account.leveldb then
			return self.account.leveldb.islookdevice or false
		end

		return false
	end,
	getLastDevices = function (self)
		if self.account and self.account.leveldb and self.account.leveldb.latest_device_rec then
			return self.account.leveldb.latest_device_rec
		end

		return {}
	end
})
