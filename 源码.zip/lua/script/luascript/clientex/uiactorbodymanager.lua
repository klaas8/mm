local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("UIActorBodyManager", {
	account = {
		get = function (self)
			return self.service.AccountManager.account
		end
	},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin
	end
}, class.ManagerBase)
