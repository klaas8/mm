local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("SdkManager", {
	account = {
		get = function (self)
			return self.service.AccountManager.account
		end
	},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin

		threadpool:work(function ()
			self:loop()
		end)
		service:listentoAccountConn("recharge", function (version_info, minicoin)
			local account = self.account
			local conn = self.conn

			while conn.is_doing_rpc do
				threadpool:wait(1)
			end

			local local_version_info = account:version_info()
			local same = true

			for i, v in ipairs(local_version_info) do
				if v ~= version_info[i] then
					same = false
				end
			end

			if not same then
				return
			end

			account:recharge(minicoin)
		end)
		service:listentoAccountConn("recharge.ok", function ()
			threadpool:notify(client_M.recharge_event_id, ErrorCode.OK)
		end)
	end,
	destroy = function (self)
		self.service = nil
		self.origin = nil
	end,
	authbox = function (self, msg)
		while threadpool:waitting("msgbox") do
			threadpool:wait(0)
		end

		threadpool:work(function ()
			if standReportEvent then
				standReportEvent("9904", "MINI_REALNAME_ADS_D", "TextPopup", "view")
				standReportEvent("9904", "MINI_REALNAME_ADS_D", "Authorized", "view")
				standReportEvent("9904", "MINI_REALNAME_ADS_D", "Cancel", "view")
			end

			MessageBox(17, msg, function (btn)
				if btn and btn == "left" then
					if standReportEvent then
						standReportEvent("9904", "MINI_REALNAME_ADS_D", "Authorized", "click")
					end

					threadpool:notify("msgbox", ErrorCode.OK, true)
				else
					if standReportEvent then
						standReportEvent("9904", "MINI_REALNAME_ADS_D", "Cancel", "click")
					end

					threadpool:notify("msgbox", ErrorCode.OK, false)
				end

				if RealNameModule and RealNameModule.SetStatisticsPopupScene and RealNameModule.IdentityNameAuthStatistics then
					RealNameModule:SetStatisticsPopupScene(RealNameModule.StatisticsPopupScene.recharge)
					RealNameModule:IdentityNameAuthStatistics(3, {
						playSelect = btn == "left" and 1 or 2
					})
				end
			end)
		end)

		local code, ok = threadpool:wait("msgbox", 86400)

		if code == ErrorCode.OK and ok == true then
			local adsType = RealNameModule:isShowIdentityNameAuth(8)

			if adsType then
				ShowIdentityNameAuthFrame(nil, nil, nil, nil, nil, adsType, true)
			else
				ShowIdentityNameAuthFrame()
			end
		end
	end,
	check_haiwai_addcoin = function (self)
		local account = self.account
		local env = utils.env

		print("check_haiwai_addcoin", env, IsIosPlatform(), get_game_lang(), account:recharge_minimoney_total(), account.svrinfo.country)

		if (env == 10 or env == 12 or env == 1) and IsIosPlatform() and get_game_lang() == 0 and account and account.svrinfo and account.svrinfo.country and account.svrinfo.country == "CN" then
			local coin = account:recharge_minimoney_total()

			if coin >= 5000 then
				return false
			end
		end

		return true
	end,
	check_recharge_limit = function (self, apiidlist, age, amount, city)
		local env = utils.env or 0
		local account = self.account
		local leveldb = account.leveldb

		if not city or city == "" then
			city = "unknown"
		end

		if env == 0 or env == 1 or env == 2 then
			local limit_rule = ns_version.anti_addiction and ns_version.anti_addiction.limit_rule

			if limit_rule then
				for k, v in ipairs(limit_rule) do
					local apiids_limit = delegate(function ()
						for index, apiid in ipairs(apiidlist) do
							if v.apiids then
								local finder_ = "," .. apiid .. ","
								local ret = string.find("," .. v.apiids .. ",", finder_)

								if ret then
									return true
								else
									return false
								end
							elseif v.apiids_no then
								local finder_ = "," .. apiid .. ","
								local ret = string.find("," .. v.apiids_no .. ",", finder_)

								if ret then
									return false
								else
									return true
								end
							end
						end

						return true
					end)
					local city_limit = delegate(function ()
						if v.city then
							if v.city == "*" then
								return true
							end

							local finder_ = "," .. city .. ","
							local ret = string.find("," .. v.city .. ",", finder_)

							if ret then
								return true
							else
								return false
							end
						elseif v.city_no then
							local finder_ = "," .. city .. ","
							local ret = string.find("," .. v.city_no .. ",", finder_)

							if ret then
								return false
							else
								return true
							end
						end

						return true
					end)

					if city_limit and apiids_limit then
						local stage_minimoney = 0

						if leveldb and leveldb.stage_recharge and type(leveldb.stage_recharge) == "table" then
							stage_minimoney = leveldb.stage_recharge.stage_minimoney
						end

						local displace = client_M.policyAgeControlConfig and client_M.policyAgeControlConfig.policyAgeControlurl and client_M.policyAgeControlConfig.policyAgeControlurl.displace or 10
						local account = self.account
						local money = account:recharge_minimoney_total() / displace
						local stage_money = stage_minimoney / displace

						if v.age_control then
							local age_control = v.age_control

							for k, v in ipairs(age_control) do
								print("check_recharge_moneyage policyAgeControl= v.age.min=", v.age.min, "v.age.max", v.age.max)

								if v.age and v.age.min <= age and age <= v.age.max then
									if v.pay and v.pay.once and v.pay.once < amount then
										print("check_recharge_moneyage once ")

										if GameModeShowPayLimitHint then
											GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.ONCE)
										else
											local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请未成年的您适度娱乐,理性消费!"

											self:msgbox(msg)
										end

										return false
									end

									local AccountCreateTime = AccountManager:get_account_create_time()

									if v.pay and v.pay.acc_createtime_limit and type(v.pay.acc_createtime_limit) == "string" then
										local acclimit = utils.split(v.pay.acc_createtime_limit, "-")

										if acclimit then
											local tlimit = os.time({
												year = tonumber(acclimit[1]),
												month = tonumber(acclimit[2]),
												day = tonumber(acclimit[3])
											})

											if tlimit and AccountCreateTime and tlimit < AccountCreateTime and v.pay and v.pay.amount and v.pay.amount < money + amount then
												print("acc_createtime_limit check_recharge_moneyage amount ")

												if GameModeShowPayLimitHint then
													GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.AMOUNT)
												else
													local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请未成年的您适度娱乐,理性消费!"

													self:msgbox(msg)
												end

												return false
											end
										end
									end

									if v.pay and v.pay.amount and v.pay.amount < money then
										print("check_recharge_moneyage amount ")

										if GameModeShowPayLimitHint then
											GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.AMOUNT)
										else
											local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请未成年的您适度娱乐,理性消费!"

											self:msgbox(msg)
										end

										return false
									end

									if v.pay and v.pay.history and stage_money > 0 and v.pay.history < stage_money then
										print("check_recharge_moneyage stage_minimoney ")

										if GameModeShowPayLimitHint then
											GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.HISTORY)
										else
											local msg = "亲爱的小伙伴，感谢您对迷你世界一直以来的喜爱与支持，您的充值金额已达上限，请未成年的您适度娱乐，理性消费！"

											self:msgbox(msg)
										end

										return false
									end
								end
							end
						end
					end
				end

				return true
			end
		end

		local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请重新登录再充值！"

		self:msgbox(msg)

		return false
	end,
	parents_guard_recharge = function (self, amount)
		if ns_version and ns_version.parents_guard and ns_version.parents_guard == true then
			local seq = gen_gid()
			local url = mapservice.getserver() .. "/miniw/anti_addiction?act=get_anti_addiction_info&uin=" .. self.Uin
			local curTime = AccountManager:getSvrTime() or os.time()
			url = "http://120.24.64.132:8087/miniw/anti_addiction?uin=" .. self.Uin .. "&ver=" .. LuaInterface:getCltVersion() .. "&act=get_anti_addiction_info&json=1"

			if utils.env == 0 then
				url = mapservice.getserver() .. "/miniw/anti_addiction?uin=" .. self.Uin .. "&ver=" .. LuaInterface:getCltVersion() .. "&act=get_anti_addiction_info&json=1"
			end

			url = UrlAddAuth_Ex(url)

			while not ns_http do
				threadpool:wait(0)
			end

			ns_http.func.rpc_string_raw(url, function (ret)
				threadpool:notify(seq, ErrorCode.OK, ret)
			end, nil, 2)

			local code, http_result = threadpool:wait(seq, 5, tick)
			local ok, ret_msg = nil

			if code == ErrorCode.OK then
				ok, ret_msg = pcall(JSON.decode, JSON, http_result)
			else
				return true, end_time
			end

			if ok and ret_msg and ret_msg.ret == 0 and ret_msg.data then
				if ret_msg.data.money_type == -1 then
					return true
				end

				if ret_msg.data.money_type == 1 then
					local account = self.account
					local day_recharge = ret_msg.data.money.single
					local month_recharge = ret_msg.data.money.month
					local displace = client_M.policyAgeControlConfig and client_M.policyAgeControlConfig.policyAgeControlurl and client_M.policyAgeControlConfig.policyAgeControlurl.displace or 10
					local month_money = account:recharge_minimoney_total() / displace
					local day_money = 0
					local leveldb = account.leveldb

					if leveldb.recharge_curday then
						local curTime = AccountManager:getSvrTime() or os.time()
						local cdate = os.date("%Y%m%d", curTime)

						if leveldb.recharge_curday and leveldb.recharge_curday.day == cdate then
							day_money = leveldb.recharge_curday.minimoney / displace
						end
					end

					local tips = [[
受到迷你守护监管，您无法继续充值

规则
单日充值上限]] .. day_recharge .. "\n单月充值上限" .. month_recharge .. "\n\n"

					if day_recharge < day_money + amount then
						AntiAddictionModule:OpenParentsGuardFrame(tips, false)

						return false
					end

					if month_recharge < month_money + amount then
						AntiAddictionModule:OpenParentsGuardFrame(tips, false)

						return false
					end
				end
			end
		end

		return true
	end,
	check_unrealname_can_recharge = function (self, apiidlist, amount, city)
		local env = utils.env or 0
		local stage_minimoney = 0

		if not city or city == "" then
			city = "unknown"
		end

		local leveldb = self.account.leveldb

		if leveldb and leveldb.stage_recharge and type(leveldb.stage_recharge) == "table" then
			stage_minimoney = leveldb.stage_recharge.stage_minimoney
		end

		if env == 0 or env == 1 or env == 2 then
			local displace = client_M.policyAgeControlConfig and client_M.policyAgeControlConfig.policyAgeControlurl and client_M.policyAgeControlConfig.policyAgeControlurl.displace or 10
			local account = self.account
			local money = account:recharge_minimoney_total() / displace
			local stage_money = stage_minimoney / displace

			if ns_version and ns_version.anti_addiction and ns_version.anti_addiction.unrealname_recharge then
				local unrealname_cfg = ns_version.anti_addiction.unrealname_recharge

				if unrealname_cfg then
					local apiids_limit = delegate(function ()
						for index, apiid in ipairs(apiidlist) do
							if unrealname_cfg.apiids then
								local finder_ = "," .. apiid .. ","
								local ret = string.find("," .. unrealname_cfg.apiids .. ",", finder_)

								if ret then
									return true
								else
									return false
								end
							elseif unrealname_cfg.apiids_no then
								local finder_ = "," .. apiid .. ","
								local ret = string.find("," .. unrealname_cfg.apiids_no .. ",", finder_)

								if ret then
									return false
								else
									return true
								end
							end
						end

						return true
					end)
					local city_limit = delegate(function ()
						if unrealname_cfg.city then
							if unrealname_cfg.city == "*" then
								return true
							end

							local finder_ = "," .. city .. ","
							local ret = string.find("," .. unrealname_cfg.city .. ",", finder_)

							if ret then
								return true
							else
								return false
							end
						elseif unrealname_cfg.city_no then
							local finder_ = "," .. city .. ","
							local ret = string.find("," .. unrealname_cfg.city_no .. ",", finder_)

							if ret then
								return false
							else
								return true
							end
						end

						return true
					end)

					if city_limit and apiids_limit then
						if unrealname_cfg.pay and unrealname_cfg.pay.once and unrealname_cfg.pay.once < amount then
							print("check_recharge_moneyage once ")

							if GameModeShowPayLimitHint then
								GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.UNAUTH)
							else
								local msg = "由于您未完成实名认证，充值受到限制，请完成实名认证后重试!"

								self:msgbox(msg)
							end

							return false
						end

						if unrealname_cfg.pay and unrealname_cfg.pay.amount and unrealname_cfg.pay.amount < money then
							print("check_recharge_moneyage amount ")

							if GameModeShowPayLimitHint then
								GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.UNAUTH)
							else
								local msg = "由于您未完成实名认证，充值受到限制，请完成实名认证后重试!"

								self:msgbox(msg)
							end

							return false
						end

						if unrealname_cfg.pay and unrealname_cfg.pay.history and stage_money > 0 and unrealname_cfg.pay.history < stage_money then
							print("check_recharge_moneyage stage_minimoney ")
							print("check_recharge_moneyage amount ")

							if GameModeShowPayLimitHint then
								GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.UNAUTH)
							else
								local msg = "由于您未完成实名认证，充值受到限制，请完成实名认证后重试！"

								self:msgbox(msg)
							end

							return false
						end

						return true
					end
				end
			end
		end

		local msg = "感谢您的喜爱与支持,国家法律法规要求,未实名认证不能充值.请先实名认证再充值!"
		local days = AccountManager:get_idcard_auth_count_for_today()

		if days > 0 then
			self:authbox(msg)
		else
			self:msgbox(msg)
		end

		return false
	end,
	check_special_recharge_limit = function (self, apiidlist, age, amount, city)
		local env = utils.env or 0
		local account = self.account
		local leveldb = account.leveldb

		if not city or city == "" then
			city = "unknown"
		end

		if env == 0 or env == 1 or env == 2 then
			local limit_rule = ns_version.anti_addiction and ns_version.anti_addiction.special_limit_rule

			if limit_rule then
				for k, v in ipairs(limit_rule) do
					local apiids_limit = delegate(function ()
						for index, apiid in ipairs(apiidlist) do
							if v.apiids then
								local finder_ = "," .. apiid .. ","
								local ret = string.find("," .. v.apiids .. ",", finder_)

								if ret then
									return true
								else
									return false
								end
							elseif v.apiids_no then
								local finder_ = "," .. apiid .. ","
								local ret = string.find("," .. v.apiids_no .. ",", finder_)

								if ret then
									return false
								else
									return true
								end
							end
						end

						return true
					end)
					local city_limit = delegate(function ()
						if v.city then
							if v.city == "*" then
								return true
							end

							local finder_ = "," .. city .. ","
							local ret = string.find("," .. v.city .. ",", finder_)

							if ret then
								return true
							else
								return false
							end
						elseif v.city_no then
							local finder_ = "," .. city .. ","
							local ret = string.find("," .. v.city_no .. ",", finder_)

							if ret then
								return false
							else
								return true
							end
						end

						return true
					end)

					if city_limit and apiids_limit then
						local stage_minimoney = 0

						if leveldb and leveldb.stage_recharge and type(leveldb.stage_recharge) == "table" then
							stage_minimoney = leveldb.stage_recharge.stage_minimoney
						end

						local displace = client_M.policyAgeControlConfig and client_M.policyAgeControlConfig.policyAgeControlurl and client_M.policyAgeControlConfig.policyAgeControlurl.displace or 10
						local account = self.account
						local money = account:recharge_minimoney_total() / displace
						local stage_money = stage_minimoney / displace

						if v.age_control then
							local age_control = v.age_control

							for k, v in ipairs(age_control) do
								print("check_recharge_moneyage policyAgeControl= v.age.min=", v.age.min, "v.age.max", v.age.max)

								if v.age and v.age.min <= age and age <= v.age.max then
									if v.pay and v.pay.once and v.pay.once < amount then
										print("check_recharge_moneyage once ")

										if GameModeShowPayLimitHint then
											GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.SPECIAL)
										else
											local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请未成年的您适度娱乐,理性消费!"

											self:msgbox(msg)
										end

										return false
									end

									if v.pay and v.pay.amount and v.pay.amount < money then
										print("check_recharge_moneyage amount ")

										if GameModeShowPayLimitHint then
											GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.SPECIAL)
										else
											local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请未成年的您适度娱乐,理性消费!"

											self:msgbox(msg)
										end

										return false
									end

									if v.pay and v.pay.history and stage_money > 0 and v.pay.history < stage_money then
										print("check_recharge_moneyage stage_minimoney ")

										if GameModeShowPayLimitHint then
											GameModeShowPayLimitHint(AccountGameModeEnum.PayHintType.SPECIAL)
										else
											local msg = "亲爱的小伙伴，感谢您对迷你世界一直以来的喜爱与支持，您的充值金额已达上限，请未成年的您适度娱乐，理性消费！"

											self:msgbox(msg)
										end

										return false
									end
								end
							end
						end
					end
				end

				return true
			end
		end

		local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请重新登录再充值！"

		self:msgbox(msg)

		return false
	end,
	check_realname_auth = function (self, amount)
		return self:policy_limit_recharge(amount)
	end,
	policy_limit_recharge = function (self, pay_money)
		local recharge_money = pay_money
		local ApiID = LuaInterface:getApiId()
		local recharge_type = 1
		local seq = gen_gid()
		local curTime = AccountManager:getSvrTime() or os.time()
		local url_base = "/miniw/anti_addiction?uin=" .. self.Uin .. "&apiid=" .. ApiID .. "&money=" .. recharge_money .. "&type=" .. recharge_type .. "&ver=" .. LuaInterface:getCltVersion() .. "&act=recharge_limit&json=1"
		local url = "http://120.24.64.132:8087" .. url_base

		if utils.env == 0 then
			url = mapservice.getserver() .. url_base
		end

		url = UrlAddAuth_Ex(url)

		while not ns_http do
			threadpool:wait(0)
		end

		ns_http.func.rpc_string_raw(url, function (ret)
			threadpool:notify(seq, ErrorCode.OK, ret)
		end, nil, 2)

		local code, http_result = threadpool:wait(seq, 5, tick)

		print("policy_limit_recharge code=", code, "result=", http_result, "url=", url)

		local ok, ret_msg = nil

		if code == ErrorCode.OK then
			ok, ret_msg = pcall(JSON.decode, JSON, http_result)
		else
			return false
		end

		local code_once_recharge_limit = 11001
		local code_month_recharge_limit = 11002
		local code_age_recharge_limit = 11003
		local code_age_18_recharge_limit = 11004
		local code_channel_age_recharge_limit = 11005
		local code_18_age_recharge_limit = 22010

		if ok and ret_msg then
			if ret_msg.code == 0 then
				return true
			elseif ret_msg.code == code_once_recharge_limit then
				local msg = "根据健康保护规则，您每次充值金额不得超过" .. ret_msg.res_data.money .. "元，请重新选择充值金额"

				self:msgbox(msg)

				return false
			elseif ret_msg.code == code_month_recharge_limit then
				local msg = "根据健康保护规则，您每月累计充值金额不得超过" .. ret_msg.res_data.money .. "元，请适度娱乐，理性消费"

				self:msgbox(msg)

				return false
			elseif ret_msg.code == code_18_age_recharge_limit then
				GetInst("MiniUIManager"):AddPackage({
					"miniui/miniworld/ShopCommon"
				}, "StoreRechargeLimitBoxAutoGen")
				GetInst("MiniUIManager"):OpenUI("StoreRechargeLimitBox", "miniui/miniworld/ShopRecharge", "StoreRechargeLimitBoxAutoGen")

				return false
			elseif ret_msg.code == code_age_recharge_limit then
				local msg = "根据健康保护规则，由于您的年龄不满8周岁，暂时无法为您提供充值业务。"

				self:msgbox(msg)

				return false
			elseif ret_msg.code == code_age_18_recharge_limit then
				local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请未成年的您适度娱乐,理性消费!"

				self:msgbox(msg)

				return false
			elseif ret_msg.code == code_channel_age_recharge_limit then
				local msg = "根据健康保护规则，您每月累计充值金额已达到上限，请适度娱乐，理性消费。"

				self:msgbox(msg)

				return false
			else
				local msg = "亲爱的小伙伴,感谢您对迷你世界一直以来的喜爱与支持,请您适度娱乐,理性消费!"

				self:msgbox(msg)

				return false
			end
		end

		return false
	end,
	pay = function (self, productName, amount, productId, payType, serverNotify, businessCode)
		print("new PlatformSdkManager::pay")

		if AccountManager.data_update then
			AccountManager:data_update()
		end

		local account = self.account

		if account.order_info then
			local orderid = account.order_info.OrderID
			local code = self:remote_call("shopsvr", "order_check", orderid)

			if code ~= ErrorCode.OK or code ~= ErrorCode.PRECHECK_ORDER_CANCEL then
				return -999
			end

			account.order_info = nil
		end

		if self:policy_limit_recharge(amount) == false then
			return ErrorCode.FAILED
		end

		if self:parents_guard_recharge(amount) == false then
			return ErrorCode.FAILED
		end

		serverNotify = serverNotify or 0
		businessCode = businessCode or ""
		local apiId = GetClientInfo():GetAppId()
		local ext = {
			ApiID = apiId
		}

		if apiId == 21 or apiId == 47 then
			local Prepay_id = GetClientInfo():setPayExtendParamsToSdk(0)
			local Signature = GetClientInfo():setPayExtendParamsToSdk(1)
			local strext = GetClientInfo():setPayExtendParamsToSdk(2)
			ext = {
				Prepay_id = Prepay_id,
				Signature = Signature,
				strext = strext,
				ApiID = apiId
			}
		else
			local Prepay_id, Signature, strext, b = nil
			b, Prepay_id, Signature, strext = GetClientInfo():setPayExtendParamsByQQ(Prepay_id, Signature, strext)

			if b then
				ext = {
					Prepay_id = Prepay_id,
					Signature = Signature,
					strext = strext,
					ApiID = apiId
				}
			end
		end

		local code, info = self:remote_call("shopsvr", "order_new", amount, serverNotify, businessCode, ext)

		if code ~= ErrorCode.OK then
			return code
		end

		account.order_info = info
		local enableQrPay = false

		if type(SdkManager.isQrPayEnabled) == "function" then
			enableQrPay = SdkManager:isQrPayEnabled()
		end

		if account.second_order_info then
			account.second_order_info = nil
		end

		local second_code, second_info = nil

		if enableQrPay then
			second_code, second_info = self:remote_call("shopsvr", "order_new", amount, serverNotify, businessCode, ext)

			if second_code == ErrorCode.OK then
				account.second_order_info = second_info
			end
		end

		AccountManager:getAccountData():setPayExtendParamsToServer(0, info.ext.Prepay_id)
		AccountManager:getAccountData():setPayExtendParamsToServer(1, info.ext.Signature)
		AccountManager:getAccountData():setPayExtendParamsToServer(2, info.ext.strext)

		local Account = account and account.Account
		local Uin = Account and Account.Uin or 0
		local sid = string.format("%d_%d", Uin, threadpool:msec())

		GetInst("MiniPayService"):StartPayForTransNew({
			orderId = info.order.OrderID,
			productName = productName,
			amount = amount,
			feeId = productId,
			payType = payType,
			sId = sid
		})
		SdkManager:td_recharge(sid)

		return code, info.order.OrderID
	end,
	td_recharge = function (self, sid)
		threadpool:work(function ()
			local account = self.account
			local Account = account and account.Account
			local Uin = Account and Account.Uin

			if not Uin then
				return
			end

			local MiniCoin = Account and Account.MiniCoin

			if not MiniCoin then
				return
			end

			if threadpool:waitting(client_M.recharge_event_id) then
				threadpool:notify(client_M.recharge_event_id, ErrorCode.FAILED)
			end

			local ok = threadpool:wait(client_M.recharge_event_id, 300)

			if not ok or ok ~= ErrorCode.OK then
				return
			end

			if StatisticsOnChargeSuccess then
				StatisticsOnChargeSuccess(sid)
			end
		end)
	end
}, class.ManagerBase)
