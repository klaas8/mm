local class = _G.class

if not class then
	return
end

local container = _G.container

class.define("BuddyDetail", {
	credit = 0,
	skinid = 0,
	nickname = "",
	model = 0,
	uin = 0,
	isonline = false,
	yvid = 0,
	vipinfo = {},
	chest = {
		ChestTreeLevel = 0,
		worms = 0,
		water = 0
	},
	account = {
		get = function (self)
			return self:get_account()
		end
	},
	constructor = function (self, info, account)
		if info then
			self.uin = info.Uin
			self.model = info.RoleInfo.Model
			self.nickname = info.RoleInfo.NickName
			self.skinid = info.RoleInfo.SkinID
			self.credit = info.Credit
			self.yvid = info.yayaid
			self.vipinfo = account:qqinfo2vipinfo(info.QQLoginInfo or info)
			local chest = self.chest
			chest.water = account:random(0, 3)
			chest.worms = account:random(0, 1)
		end

		function self.get_account()
			return account
		end
	end
})
