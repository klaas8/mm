local class = _G.class

if not class then
	return
end

local container = _G.container

class.define("GM", {
	constructor = function (self, service)
		self.valid = true
		self.service = service

		service:listento("gm", function (method, ...)
			local AccountManager = service.AccountManager
			local account = AccountManager.account
			local ok, why = pcall(account[method], account, ...)

			if not ok then
				print(why)
			end
		end)
		threadpool:work(function ()
			print(pcall(self.Loop, self))
		end)
	end,
	destroy = function (self)
		self.valid = false
		self.service = nil
	end,
	Loop = function (self)
		print("gm loop called")

		if self.cmdfile then
			self.cmdfile:close()

			self.cmdfile = nil
		end

		threadpool:work(function ()
			local path = LuaInterface:getStdioRoot() .. "debug.test"

			while true do
				if gFunc_isFileExist(path) then
					local ok, msg = pcall(function ()
						local file = io.open(path, "r")

						if file then
							while self.valid do
								local line = file:read("*l")

								if not line then
									break
								end
							end

							while self.valid do
								local str = delegate(function ()
									local s = ""
									local num = 0

									while self.valid do
										local line = file:read("*l")

										if not line then
											threadpool:wait(0)
										else
											s = s .. line .. "\n"

											if line == "" then
												num = num + 1
											end

											if num >= 1 then
												break
											end
										end
									end

									return s
								end)

								if str and #str >= 3 then
									print("do string start ==============\n ", str)

									local ok, func = pcall(loadstring, str)

									if ok and type(func) == "function" then
										setfenv(func, setmetatable({
											self = self.service,
											container = container,
											class = class,
											ErrorCode = ErrorCode
										}, {
											__index = _G
										}))
										threadpool:work(function ()
											local ret = {
												pcall(func)
											}
											local ok = table.remove(ret, 1)

											if not ok then
												print("\n\nERROR:", unpack(ret), "\n\n")
											else
												if ret[1] ~= nil then
													print("\n\n", unpack(ret), "\n\n")
												end

												print("do string end ================")
											end
										end)
									end
								end

								threadpool:wait(0)
							end

							file:close()
						end
					end)

					if not ok then
						print("EXCEPTION : ", msg)
					end
				end

				threadpool:wait(1)
			end
		end)

		local file = io.open(LuaInterface:getStdioRoot() .. "debug.cmd", "r")

		if file then
			self.cmdfile = file

			while self.valid do
				local line = file:read("*l")

				if not line then
					break
				end
			end

			while self.valid do
				local line = file:read("*l")

				if line then
					local tty, cmd, arg_string = line:gmatch("([^%s]+)%s+([^%s]+)%s?(.*)")()

					print(tty, cmd, arg_string)
					self:exec(cmd, arg_string)
				end

				threadpool:wait(0)
			end
		end
	end,
	test = function (self, ...)
		print("gm test ", ...)
		print("dbg = ", pause)
		print("???")
	end,
	recharge = function (self, num)
		num = num or 1000
		local service = self.service
		local AccountManager = service.AccountManager
		local account = AccountManager.account
		local ok, why = pcall(account.recharge, account, num)

		if not ok then
			print(why)
		end

		account:flush()
	end,
	exec = function (self, cmd, arg_string)
		if cmd then
			local args = {}

			if arg_string and #arg_string > 0 then
				local t = arg_string

				for k in t:gmatch("'.+'") do
					local trim = k:gsub("'", "")
					arg_string = arg_string:gsub(k, trim:gsub("%s+", "_#_"))
				end

				for k in arg_string:gmatch("[^%s]+") do
					if k == "true" then
						k = true
					elseif k == "false" then
						k = false
					elseif not k:match("^0[^%.]") then
						k = tonumber(k) or k
					end

					if type(k) == "string" then
						k = k:gsub("^'", ""):gsub("'$", ""):gsub("_#_", " ")
					end

					table.insert(args, k)
				end
			end

			if self[cmd] then
				threadpool:work(function ()
					local ret, msg = pcall(self[cmd], self, unpack(args))

					if not ret then
						print("执行出错", msg)
					end
				end)
			else
				local f = self.service.cluster.client[cmd]

				if f then
					threadpool:work(function ()
						print(pcall(f, unpack(args)))
					end)
				end
			end
		end
	end
})
