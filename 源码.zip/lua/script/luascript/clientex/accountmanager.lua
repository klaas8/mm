local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("AccountManager", {
	convertStaring = false,
	juhe_info = {},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin

		threadpool:work(function ()
			self:loop()
		end)
		threadpool:work(function ()
			self:ad_loop()
		end)
		threadpool:work(function ()
			self:ad_loop2()
		end)
		threadpool:work(function ()
			self:order_loop()
		end)
		threadpool:work(function ()
			self:statics_loop()
		end)
		threadpool:work(function ()
			self:wegame_loop()
		end)
		threadpool:work(function ()
			self:steam_loop()
		end)
		threadpool:work(function ()
			self:idcard_loop()
		end)
		threadpool:work(function ()
			self:children_protect_loop()
		end)
		threadpool:work(function ()
			self:chatpush_loop()
		end)
		threadpool:work(function ()
			self:update_SkinCostDef()
		end)
		threadpool:work(function ()
			self:device_multi_online_loop()
		end)

		if not GetClientInfo():isEditorMode() then
			threadpool:work(function ()
				self:anti_addiction_loop()
			end)
		end

		threadpool:work(function ()
			self:disconnect_check_login()
		end)
		threadpool:work(function ()
			self:disconnect_check_server()
		end)
		threadpool:work(function ()
			self:online_report_loop()
		end)
		service:listentoAccountConn("data.update", function ()
			local code = self:data_update()

			if code == ErrorCode.OK then
				self:trigger("postMiniBeanChange")
				self:trigger("postMiniCoinChange")
				self:trigger("postPokedexChange")

				local account = self.account
				local leveldb = account and account.leveldb
				local recharge = leveldb and leveldb.recharge

				if recharge and next(recharge) and RechargeReportEvent then
					RechargeReportEvent()
				end
			end
		end)
		service:listentoAccountConn("gm.kick", function (info)
			local function callback(data)
				if GoToMainMenu then
					pcall(function ()
						GoToMainMenu()
					end)
				end

				MessageBox(14, GetS(10589, os.date("%Y-%m-%d %H:%M", data.FreezeEndTime or 999999999)))

				_G.IgnoreEsc = true

				GetInst("MiniUIScheduler"):regGloabel(function ()
					GameDelayExit()
				end, 1, 1, 3, false)
			end

			if VoiceAccountFreeze then
				VoiceAccountFreeze(callback, info)
			else
				callback(info)
			end
		end)
		service:listentoAccountConn("device_limit_kick", function (info)
			local version_base_ = GetClientInfo():clientVersionFromStr("0.53.5")
			local version_now_ = GetClientInfo():GetClientVersion()

			if version_base_ <= version_now_ then
				_G.IgnoreEsc = true

				standReportEvent("9901", "POPUP_WINDOW_FORCED_OFFLINE", "-", "view")

				if not GetClientInfo():isApple() then
					standReportEvent("9901", "POPUP_WINDOW_FORCED_OFFLINE", "ConfirmButton", "view")
				end

				MessageBox(GetClientInfo():isApple() and 14 or 4, GetS(71013), function (btn)
					if btn == "center" then
						standReportEvent("9901", "POPUP_WINDOW_FORCED_OFFLINE", "ConfirmButton", "click")
						GetClientApp():GameExit(true)
					end
				end)
			end
		end)
		service:listentoAccountConn("device_limit_kick_v2", function (DeviceId, DeviceName, ts)
			MiniLog("device_limit_kick_v2 监听到同端登录消息")

			if DeviceId ~= (GetClientInfo().getDeviceID and GetClientInfo():getDeviceID()) then
				local msgtime = os.date("%Y-%m-%d %H:%M", ts)
				DeviceName = ns_http.func.url_decode(DeviceName)
				local conn = self.conn

				conn:close()

				local chatpushconn = self.chatpushconn

				chatpushconn:close()
				MessageBox(4, "注意!你的迷你号于" .. msgtime .. "在其他地方:" .. DeviceName .. " 设备上登录", function (btn)
					if btn == "center" then
						GetClientApp():GameExit(true)
					end
				end)
			end
		end)
		service:listentoAccountConn("data.capture", function (info)
			if GoToMainMenu then
				pcall(function (info)
					GoToMainMenu(info)
				end)
			end

			_G.IgnoreEsc = true
		end)
		service:listentoAccountConn("mapbag.update", function (Uin, MapID)
			self.cluster.developer.mapbag_info(MapID, true)
		end)
		service:listento("mapstore.update", function (Uin, MapID)
			self.cluster.developer.mapstore_info(Uin, MapID, true)
		end)
		service:listento("mail.update", function ()
			pcall(function ()
				if mailservice then
					for i = 1, 60 do
						if mailservice.pullingMails == false then
							break
						end

						threadpool:wait(1)
					end

					if mailservice.pullingMails ~= false then
						return
					end

					mailservice.mailsPulled = false
					mailservice.mails = {}

					GetInst("MessageCenterDataMgr"):RequestChannelHistoryMsgIDList(GetSelectMailType(), getServerTime())
				end
			end)
		end)
		service:listentoAccountConn("mail.item.notify", function ()
			if DefMgr:getStringDef(7304) then
				ShowGameTipsWithoutFilter(GetS(7304), 3)
			end
		end)
		service:listentoAccountConn("InviteJoinRoom", function (from_uin, ...)
			if BeInviteJoinRoom then
				print("InviteJoinRoom", from_uin, ...)
				BeInviteJoinRoom(from_uin, ...)
			end
		end)
		service:listentoAccountConn("recharge.pc", function (MiniCoin, ZengSong)
			print("总共充值:", MiniCoin, " 其中赠送 : ", ZengSong)

			if MessageBox ~= nil and ZengSong and ZengSong > 0 then
				MessageBox(4, "总共充值迷你币:" .. MiniCoin .. " 其中赠送迷你币:" .. ZengSong)
			end

			local code = self:data_update()

			if code == ErrorCode.OK then
				self:trigger("postMiniBeanChange")
				self:trigger("postMiniCoinChange")
				self:trigger("postPokedexChange")
			end

			print("leveldb", self.account and self.account.leveldb)
		end)
		service:listento("punisher.warning", function (datas)
			if VoiceWarnningCallback then
				VoiceWarnningCallback(datas)
			end
		end)
		service:listento("punisher.mute", function (datas)
			if VoiceMuteCallback then
				VoiceMuteCallback(datas)
			end
		end)
		service:listentoAccountConn("countryauthpi.update", function (tb)
			if self.account then
				self.account:update_countryauthpi(tb.countryauthstatus, tb.countryauthpi)

				if tb.countryauthstatus == 0 then
					if HideIdentityNameAuthFrame then
						HideIdentityNameAuthFrame(true)
					end

					self:do_data_update(true)
					self:policy_limit_login_check_log()
				end
			end
		end)
		service:listento("team", function (tb)
			print("get team websock msg")

			local teamServer = GetInst("TeamupService")

			if teamServer and teamServer.MsgHandler then
				teamServer:MsgHandler(tb.type, tb)
			end
		end)
		service:listento("creator", function (tb)
			local creationCenterServer = GetInst("CreationCenterHomeService")

			if creationCenterServer and creationCenterServer.MsgHandler then
				creationCenterServer:MsgHandler(tb.type, tb)
			end
		end)
		service:listentoAccountConn("sys.resetnick.update", function (tb)
			print("get sys.resetnick.update")

			if tb.active180 then
				local contentText = ""
				contentText = tonumber(tb.active180) == 1 and "亲爱的冒险家：由于迷你世界用户昵称规则升级，你的昵称不符合最新规则，已被系统自动重置。可前往邮箱查看并领取我们赠送的改名卡。" or "亲爱的冒险家：由于迷你世界用户昵称规则升级，你的昵称不符合最新规则，已被系统自动重置。可前往邮箱查看"

				MessageBoxFrame2:Open(5, "昵称重置通知", contentText)
			end
		end)
		service:listentoAccountConn("realname_auth.check", function (tb)
			print("get realname_auth.check0")

			if tb.status == 0 then
				print("get realname_auth.check1")

				local contentText = "亲爱的冒险家：经迷你世界官方检测，您的迷你号认证的实名信息存在违规情况，您将需要在下次登录时重新实名认证，谢谢您的支持和理解！"

				MessageBoxFrame2:Open(5, "实名认证提示", contentText)
			elseif tb.status == 1 then
				print("get realname_auth.check2")
				self:do_data_update(true)
				ShowIdentityNameAuthFrame()
			end
		end)
		service:listentoAccountConn("jh.version_too_low", function (apiid)
			print("get jh.version_too_low", apiid)

			local apiid_name = ""

			if apiid and apiid > 0 then
				apiid_name = GetS(5000 + apiid)
			end

			local contentText = "游戏版本已更新，请升级到" .. apiid_name .. "最新版本操作!"

			MessageBoxFrame2:Open(5, "新版本用户提示", contentText)
		end)
		service:listentoAccountConn("pass_modify_quit", function (tb)
			print("force quit msg", tb)

			if self.force_quit_game then
				self:force_quit_game(tb.code)
			end
		end)
		service:listentoAccountConn("fraudauth.check", function (tb)
			print("fraudauth.check", tb.status or 0)
			threadpool:wait(1)

			if tb.status == 1 then
				local contentText = "亲爱的冒险家：经迷你世界官方核查，您的实名认证信息存在异常，在下次登录时您需要再次填写实名信息，认证通过后才可以进入游戏，谢谢您的支持和理解。"

				MessageBoxFrame2:Open(5, "二次实名认证认证通知", contentText)
			elseif tb.status == 2 then
				self:do_data_update(true)
				ShowIdentityNameAuthFrame()
			end
		end)
		service:listento("report.log", function (datas)
			datas.uin = AccountManager:getUin()

			LoginManager:NotifyUploadGameLog(datas)
		end)
	end,
	destroy = function (self)
		print("AccountManager:destroy", tostring(self))

		if self.account then
			self.account:destroy()
		end

		self.origin = nil
		self.account = nil
		self.service = nil
	end,
	accountDirty = function (self)
		if self.account then
			self.account:OnAccountDirty()
		end
	end,
	oplog = function (self, action, ...)
		if type(action) == "string" and (action == "ingame" or action == "outgame" or action == "inteam" or action == "outteam") then
			if not self.chatpushconn or not self.chatpushconn.isopen then
				self:chatpush_rpc("buddysvr", "report_status", {
					action,
					...
				})
			else
				self.cluster.buddysvr.report_status(action, ...)
			end
		end
	end,
	GetCurGameBiddingPlanID = function (self)
		if GetInst and GetInst("ReportGameDataManager") and GetInst("ReportGameDataManager").GetCurGameBiddingPlanID then
			return GetInst("ReportGameDataManager"):GetCurGameBiddingPlanID()
		end

		return nil
	end,
	isJuheAccount = function (self)
		local ownFlag = self.juhe_info and self.juhe_info.ownFlag

		if ownFlag then
			return ownFlag == 1
		end

		return self.account and self.account.leveldb and self.account.leveldb.is_jh_uin
	end,
	setJuheInfo = function (self, datas)
		local info = datas or {}
		self.juhe_info.juhe_l_phone = info.phone and info.phone ~= "" and info.phone or nil
		self.juhe_info.juhe_v_phone = info.securePhone and info.securePhone ~= "" and info.securePhone or nil
		self.juhe_info.juhe_email = info.secureEmail and info.secureEmail ~= "" and info.secureEmail or nil
		self.juhe_info.juhe_pwd_modify_time = info.pwdLastUpdateTime
		self.juhe_info.juhe_has_pwd = info and info.hasPwd and info.hasPwd == "Y"
		self.juhe_info.ownFlag = info.ownFlag and tonumber(info.ownFlag)

		print("self.juhe_info.", self.juhe_info)

		return self.juhe_info
	end,
	updateJuheInfo = function (self)
		local is_jh_uin = self.account and self.account.leveldb and self.account.leveldb.is_jh_uin

		if is_jh_uin and self:isJuheAccountEmpty() and self:client_ready() then
			if LoginManager:GetSwitchCfg():IsJuheLogin() then
				NewAccountService:UpdateAccDatas()
			else
				local reqData = {}
				local Uin = self.account and self.account.Uin or 0
				reqData.uin = Uin
				reqData.cmd = "queryAccount"
				reqData.token = self.conn and self.conn.token
				local ret = self:http_login("juhe", "clicall", reqData)

				if ret and ret.code == ErrorCode.OK and ret.data then
					self:setJuheInfo(ret.data)
				end
			end
		end

		return self.juhe_info
	end,
	isJuheAccountEmpty = function (self)
		if self.juhe_info and next(self.juhe_info) then
			return false
		end

		return true
	end,
	resetJuheAccount = function (self)
		self.juhe_info = {}
	end,
	getJuhePwdModifyTime = function (self)
		if self:isJuheAccountEmpty() then
			self:updateJuheInfo()
		end

		return tonumber(self.juhe_info.juhe_pwd_modify_time or 0)
	end,
	getJuheHasPwd = function (self)
		if self:isJuheAccountEmpty() then
			self:updateJuheInfo()
		end

		return self.juhe_info.juhe_has_pwd or false
	end,
	getJuheBindLoginPhone = function (self)
		if self:isJuheAccountEmpty() then
			self:updateJuheInfo()
		end

		return self.juhe_info.juhe_l_phone
	end,
	getJuheBindVerifyPhone = function (self)
		if self:isJuheAccountEmpty() then
			self:updateJuheInfo()
		end

		return self.juhe_info.juhe_v_phone
	end,
	getJuheBindingEmail = function (self)
		if self:isJuheAccountEmpty() then
			self:updateJuheInfo()
		end

		return self.juhe_info.juhe_email
	end,
	getMiBindLoginPhone = function (self)
		local phone = self.account and self.account.leveldb and self.account.leveldb.bindphone and self.account.leveldb.bindphone.lphone

		return phone
	end,
	getMiBindVerifyPhone = function (self)
		local phone = self.account and self.account.leveldb and self.account.leveldb.bindphone and self.account.leveldb.bindphone.vphone

		return phone
	end,
	getMiBindingEmail = function (self)
		local email = self.account and self.account.Account and self.account.Account.Email

		return email
	end,
	getMiPwdModifyTime = function (self)
		local pwdChangeTime = self.account and self.account.Account and self.account.Account.AccountBindTime or 0

		return pwdChangeTime
	end,
	getBindingPhone = function (self)
		return self:getBindVerifyPhone()
	end,
	getBindLoginPhone = function (self)
		if self:isJuheAccount() then
			return self:getJuheBindLoginPhone()
		end

		return self:getMiBindLoginPhone()
	end,
	getBindVerifyPhone = function (self)
		if self:isJuheAccount() then
			return self:getJuheBindVerifyPhone()
		end

		return self:getMiBindVerifyPhone()
	end,
	getBindingEmail = function (self)
		if self:isJuheAccount() then
			return self:getJuheBindingEmail()
		end

		return self:getMiBindingEmail()
	end,
	getAccountModifyTime = function (self)
		if self:isJuheAccount() then
			return self:getJuhePwdModifyTime() or 0
		end

		return self:getMiPwdModifyTime() or 0
	end,
	encryptPhone = function (self, phone)
		if not phone then
			return "****"
		end

		if phone == "" then
			return "****"
		end

		return string.sub(phone, 1, 3) .. "****" .. string.sub(phone, 8, #phone)
	end,
	encryptEmail = function (self, email)
		if not email then
			return "****"
		end

		if email == "" then
			return "****"
		end

		local name, domain = email:match("^(.+)@(.+)$")

		if not name or not domain then
			return "****"
		end

		local len = #name

		if len <= 1 then
			return email
		end

		local halfIdx = math.floor(len / 2)
		local start = math.min(halfIdx, 4)
		local first = name:sub(1, start)

		return first .. string.rep("*", len - start) .. "@" .. domain
	end,
	hasBindedPhone = function (self)
		local Phone = self:getBindVerifyPhone()

		if not Phone then
			return -1
		end

		if Phone == "" then
			return 0
		end

		return 1
	end,
	getBindedPhoneWithEncryption = function (self)
		local Phone = self:getBindVerifyPhone()

		return self:encryptPhone(Phone)
	end,
	hasBindedEmail = function (self)
		local Email = self:getBindingEmail()

		if not Email then
			return -1
		end

		if Email == "" then
			return 0
		end

		return 1
	end,
	getBindedEmailWithEncryption = function (self)
		local Email = self:getBindingEmail()

		return self:encryptEmail(Email)
	end,
	hasBindedFacebook = function (self)
		local account = self.account

		return account:check_bind_facebook() and 1 or 0
	end,
	getBindedFaceBookWithEncryption = function (self)
		local account = self.account
		local leveldb = account.leveldb
		local facebook = leveldb and leveldb.extra and leveldb.extra.facebook

		return facebook and facebook.id or "", facebook and facebook.nickname or ""
	end,
	getNickModify = function (self)
		local account = self.account
		local Account = account.Account

		return Account and Account.BillDataSvr and Account.BillDataSvr.RenameTimes or 0
	end,
	getNickModifyCost = function (self)
		local account = self.account
		local Account = account.Account
		local account_def = account.account_def
		local MiniCoinCost = account_def.RenameCostDef[1].Cost
		local RenameTimes = Account and Account.BillDataSvr and Account.BillDataSvr.RenameTimes or 0

		if RenameTimes > 0 then
			return MiniCoinCost
		else
			return 0
		end
	end,
	getAccountData = function (self)
		local origin = self.origin

		if not self.accountdata then
			local origin_accountdata = origin:getAccountData()
			self.accountdata = setmetatable({
				origin = origin_accountdata
			}, {
				__index = function (t, k)
					local amfunc = self[k]

					if type(amfunc) == "function" then
						return function (tt, ...)
							local a = {
								pcall(amfunc, self, ...)
							}

							if not a[1] then
								print("ERROR:", a[2])
							else
								return unpack(a, 2)
							end
						end
					end

					local account = self.account
					local hook = account and account[k]

					if hook ~= nil then
						if type(hook) == "function" then
							return function (tt, ...)
								local a = {
									pcall(hook, account, ...)
								}

								if not a[1] then
									print("ERROR", a[2])
								else
									return unpack(a, 2)
								end
							end
						else
							return hook
						end
					else
						local v = origin_accountdata[k]

						if type(v) == "function" then
							return function (tt, ...)
								local a = {
									...
								}
								local s = "Call C++ AccountManager:getAccountData():" .. k .. "("

								if #a == 0 then
									s = s .. ")"
								end

								for ii, vv in ipairs(a) do
									if type(vv) == "nil" then
										vv = nil
									end

									if ii == #a then
										s = s .. tostring(vv) .. ")"
									else
										s = s .. tostring(vv) .. ","
									end
								end

								local ok, result = pcall(v, origin_accountdata, ...)
								s = s .. "=>" .. tostring(result)

								print(s)

								if not ok then
									print(result)
								else
									return result
								end
							end
						else
							return v
						end
					end
				end,
				__newindex = function (t, k, v)
					assert(false)
				end
			})
		end

		return self.accountdata or origin:getAccountData()
	end,
	getRoleModel = function (self)
		local account = self.account

		if not account then
			return 2
		end

		local Account = account.Account
		local RoleInfo = Account.RoleInfo
		local Model = RoleInfo.Model

		if Model == 0 then
			Model = 2
		end

		return Model
	end,
	getRoleSkinModel = function (self)
		local account = self.account
		local leveldb = account and account.leveldb
		local Account = account and account.Account
		local RoleInfo = Account and Account.RoleInfo
		local RoleSkinID = leveldb and leveldb.RoleSkinID or RoleInfo and RoleInfo.SkinID or 0

		if LuaInterface:getCltVersion() < 70144 and RoleSkinID >= 257 and RoleSkinID <= 266 then
			return 0
		end

		return RoleSkinID or 0
	end,
	getUin = function (self)
		local account = self.account

		if account and account.Account then
			return account.Account.Uin
		else
			return LuaInterface:getUin() or -1
		end
	end,
	getmmsum = function (self)
		local account = self.account
		local svrinfo = account and account.svrinfo
		local mmsum = svrinfo and svrinfo.mmsum

		return mmsum or ""
	end,
	getNickName = function (self)
		local custom_review = self:get_custom_nickname_flag()

		if custom_review and custom_review == 0 then
			return self:get_new_nickname()
		end

		local account = self.account

		if not account then
			return ""
		end

		local Account = account.Account
		local RoleInfo = Account.RoleInfo

		return RoleInfo.NickName
	end,
	getAccountName = function (self)
		local account = self.account

		if not account then
			return ""
		end

		local Account = account.Account

		return Account.AccountName
	end,
	getActive = function (self)
		local account = self.account
		local Account = account and account.Account

		return Account and Account.Active
	end,
	getSvrTime = function (self)
		return self.conn.svrtime
	end,
	isLogin = function (self)
		local account = self.account

		return account and account.islogin or false
	end,
	getFansNum = function (self)
		local account = self.account

		return account and account.Buddy and account.Buddy.FansNum or 0
	end,
	getBuddyNum = function (self)
		local account = self.account
		local Buddy = account.Buddy

		return Buddy and Buddy.BuddyList and Buddy.BuddyList.BuddyNum or 0
	end,
	getBlueVipIconStr = function (self, Uin)
		local apiId = GetClientInfo():GetAppId()

		if isQQGame() == false then
			return ""
		end

		local account = self.account
		local vipInfo = nil

		if Uin == AccountManager:getUin() then
			vipInfo = account:getVipInfo()
		elseif account:isBuddy(Uin) then
			local BuddyDetail = account:getBuddyDetailByUin(Uin)

			if BuddyDetail then
				vipInfo = BuddyDetail.vipinfo
			end
		else
			local fansInfo = self.getFansInfo()

			if fansInfo then
				vipInfo = fansInfo.vipinfo
			elseif ClientCurGame:isInGame() and AccountManager:getMultiPlayer() > 0 then
				local briefInfo = ClientCurGame and ClientCurGame.findPlayerInfoByUin and ClientCurGame:findPlayerInfoByUin(Uin)

				if briefInfo then
					vipInfo = briefInfo.vipinfo
				end
			end
		end

		if vipInfo and vipInfo.vipType ~= VIP_NONE then
			local str = ""

			if isQQGame() then
				if vipInfo.vipType == VIP_QQ_BLUE or vipInfo.vipType == VIP_QQ_BLUE_YEARLY then
					str = string.format("#A%03d", vipInfo.vipLevel)
				elseif vipInfo.vipType == VIP_QQ_BLUEDELUXE or vipInfo.vipType == VIP_QQ_BLUEDELUXE_YEARLY then
					str = string.format("#A%03d", vipInfo.vipLevel + 8)
				end

				if vipInfo.vipType == VIP_QQ_BLUE_YEARLY or vipInfo.vipType == VIP_QQ_BLUEDELUXE_YEARLY then
					str = str .. "#A017"
				end
			elseif apiId == 109 then
				if vipInfo.vipType == VIP_QQ_YELLOW or vipInfo.vipType == VIP_QQ_YELLOW_YEARLY then
					str = string.format("#A%03d", vipInfo.vipLevel + 17)
				elseif vipInfo.vipType == VIP_QQ_YELLOWDELUXE or vipInfo.vipType == VIP_QQ_YELLOWDELUXE_YEARLY then
					str = string.format("#A%03d", vipInfo.vipLevel + 25)
				end

				if vipInfo.vipType == VIP_QQ_YELLOW_YEARLY or vipInfo.vipType == VIP_QQ_YELLOWDELUXE_YEARLY then
					str = str .. "#A034"
				end
			end

			return str
		else
			return ""
		end
	end,
	getWater = function (self, Uin)
		local account = self.account

		if friendservice and friendservice.enabled and GetMyFriendHomeInfo then
			local homeinfo = GetMyFriendHomeInfo(Uin)

			if homeinfo then
				return homeinfo.water
			else
				return 0
			end
		else
			local BuddyDetail = account:getBuddyDetailByUin(Uin)

			if BuddyDetail then
				return BuddyDetail.chest.water or 0
			end

			return 0
		end
	end,
	getWorms = function (self, Uin)
		local account = self.account

		if friendservice and friendservice.enabled and GetMyFriendHomeInfo then
			local homeinfo = GetMyFriendHomeInfo(Uin)

			if homeinfo then
				return homeinfo.worms
			else
				return 0
			end
		else
			local BuddyDetail = account:getBuddyDetailByUin(Uin)

			if BuddyDetail then
				return BuddyDetail.chest.worms or 0
			end

			return 0
		end
	end,
	removeFans = function (self, Uin)
		return BuddyManager:removeFans(Uin)
	end,
	getFansInfo = function (self, idx, Uin)
		return BuddyManager:getFansInfo(idx, Uin)
	end,
	getFansMsgNum = function (self)
		return BuddyManager:getFansMsgNum()
	end,
	isSameWeek = function (self, t1, t2)
		return utils.IsSameWeek(t1, t2)
	end,
	isSameDay = function (self, t1, t2)
		return utils.IsSameDay(t1, t2)
	end,
	isMiBindAccount = function (self)
		local account = self.account

		if not account then
			return false
		end

		local const = account.const
		local Account = account.Account
		local bit = account.bit
		local UinFlag = Account.UinFlag

		return bit.band(UinFlag, const.UIN_FLAG_BIND) ~= 0
	end,
	isJuheBindAccount = function (self)
		return self:getJuheHasPwd()
	end,
	isBindAccount = function (self)
		if self:isJuheAccount() then
			return self:isJuheBindAccount()
		end

		return self:isMiBindAccount()
	end,
	getActivityGiftTime = function (self)
		local account = self.account
		local svrinfo = account and account.svrinfo
		local ActivityGift = svrinfo and svrinfo.ActivityGift

		return ActivityGift and ActivityGift.LastGetTime or 0
	end,
	getActivityGift = function (self)
		local account = self.account
		local svrinfo = account and account.svrinfo
		local ActivityGift = svrinfo and svrinfo.ActivityGift

		return ActivityGift and ActivityGift.GiftID or 0
	end,
	isItemSeriesAward = function (self, groupid)
		return self.account:awardflag_check(groupid)
	end,
	reset_account_data_for_cpp = function (self)
		local AccountData = AccountManager:getAccountData()

		if AccountData and type(AccountData.clearAccountData) == "function" then
			AccountData:clearAccountData()

			local account = self.account
			local Account = account and account.Account

			if Account then
				local BillDataSvr = Account.BillDataSvr
				local ItemInfo = account.ItemInfo

				if ItemInfo then
					for i, v in ipairs(ItemInfo) do
						AccountData:OperationAccountItem(v.ItemID, v.Num)
					end
				end

				local UnlockRoleInfo = BillDataSvr.UnlockRoleInfo
				local UnlockRoleInfoNum = BillDataSvr.UnlockRoleInfoNum

				for i = 1, UnlockRoleInfoNum do
					local info = UnlockRoleInfo[i]

					if info then
						AccountData:OperationUnlockRole(info.Model, info.GenuisLV)
					end
				end

				local UnlockRiderInfoNum = BillDataSvr.UnlockRiderInfoNum
				local UnlockRiderInfo = BillDataSvr.UnlockRiderInfo

				for i = 1, UnlockRiderInfoNum do
					local info = UnlockRiderInfo[i]

					if info then
						AccountData:OperationUnlockHorse(info.RiderID, info.RiderLevel)
					end
				end

				local ItemUnlock = BillDataSvr.ItemUnlock
				local FlagIntNum = ItemUnlock.FlagIntNum
				local FlagInt = ItemUnlock.FlagInt

				for i = 1, FlagIntNum do
					local flag = FlagInt[i]

					if flag then
						AccountData:OperationUnlockItemFlag(flag)
					end
				end

				local vipinfo = account:getVipInfo()

				if vipinfo then
					AccountData:OperationVipInfo(vipinfo.vipType, vipinfo.vipLevel, vipinfo.vipExp)
				end
			end
		end
	end,
	get_account_create_time = function (self)
		local account = self.account

		return account and account.Account and account.Account.AccountCreateTime or 0
	end,
	get_rename_review = function (self)
		if self.account and self.account.leveldb and self.account.leveldb.rename_review then
			return self.account.leveldb.rename_review
		end

		return 0
	end,
	get_custom_nickname_flag = function (self)
		if self.account and self.account.leveldb and self.account.leveldb.custom_review then
			return self.account.leveldb.custom_review
		end

		return nil
	end,
	get_new_nickname = function (self)
		if self.account and self.account.leveldb and self.account.leveldb.rename_new_name then
			return self.account.leveldb.rename_new_name
		end

		return nil
	end,
	get_time_since_create = function (self)
		local now = self:getSvrTime()
		local createtime = self:get_account_create_time()
		local time = now - createtime

		print(" ============= time since create = ", time, " day = ", math.ceil(time / 86400), " ===========")

		return time
	end,
	check_login_reward = function (self)
		local account = self.account

		return account and account:precheck("login_reward") == ErrorCode.OK
	end,
	my_developerflag = function (self)
		local account = self.account
		local leveldb = account and account.leveldb
		local isdeveloper = leveldb and leveldb.isdeveloper

		print("my_developerflag=", leveldb and leveldb.isdeveloper)

		if not isdeveloper then
			return false
		end

		return true
	end,
	is_ever_recharge = function (self)
		local account = self.account

		if not account then
			return false
		end

		local minicoin = account:recharge_minicoin_total()

		return minicoin and minicoin > 0 or false
	end,
	recharge_minicoin_total = function (self)
		local account = self.account

		if not account then
			return 0
		end

		return math.floor(account:recharge_minicoin_total() / 10)
	end,
	get_account_info = function (self, Uin)
		local code, result = self:super("ManagerBase", "get_account_info", Uin)
		local account = self.account

		if account then
			BuddyManager:loadOfflineChat(Uin)

			local spy = {
				["Account.MiniBean"] = function ()
					self:trigger("postMiniBeanChange")
				end,
				["leveldb.MiniBean"] = function ()
					self:trigger("postMiniBeanChange")
				end,
				["Account.MiniCoin"] = function ()
					self:trigger("postMiniCoinChange")
				end,
				["leveldb.MiniCoin"] = function ()
					self:trigger("postMiniCoinChange")
				end,
				["Account.BillDataSvr"] = function ()
					self:trigger("postPokedexChange")
				end,
				["leveldb.ItemInfo"] = function ()
					self:trigger("postPokedexChange")
				end,
				["Chest.ChestTreeInfo.Exp"] = function ()
					local level = account.Chest.ChestTreeInfo.Level
					local exp = account.Chest.ChestTreeInfo.Exp
					local newlevel = account:exp2treelevel(exp)

					print("Chest Exp发生变化了", exp, " level", level, " -> ", newlevel)

					if level < newlevel then
						print("Chest Exp, 应该升级了")
						self:trigger("chest_need_update")
					end
				end
			}

			account:plant_spy(function (path, old, new)
				local f = spy[path]

				if f then
					pcall(f, old, new)
				end
			end)
		end

		return code, result
	end,
	login = function (self, Uin, Passwd)
		print("login start ...", Uin, Passwd)

		if not self:version_check_login() then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		local standalone = self.container.cfg.standalone
		local conn = self.conn

		conn:start()

		if not conn.other then
			conn:heartbeat()
		end

		local current = self:load_from_file("current")
		Uin = Uin or current and current.Uin or LuaInterface:getUin() or 1
		local Passwd_tmp = Passwd or nil

		if type(Uin) == "number" and Uin <= 1 then
			Uin = 1

			print("do not has local data of account")

			if ReportMgr and ReportMgr.sendStatistics then
				ReportMgr:sendStatistics()
			end

			return self:reg(Passwd)
		end

		if standalone == true then
			return self:get_account_info(Uin)
		else
			if current and current.authinfo and type(current.authinfo) == "table" and (current.authinfo.appid or current.authinfo.openid_type) and not Passwd_tmp then
				local _islogin = true

				if current.authinfo.openid_type and current.authinfo.openid_type == "kuaishou" then
					_islogin = false
				end

				if _islogin then
					if ReportMgr and ReportMgr.setLoginType then
						ReportMgr:setLoginType(tostring(current.authinfo.openid_type))
					end

					local code, datas, msg = self:unionid_login(current.authinfo, false)

					if code ~= ErrorCode.OK then
						self:msgbox("微信/QQ登录授权已过期，请重新授权登录游戏")
						self:get_account_info(Uin)

						local up_code, errinfos = self:data_update(true)
						local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " unionid_login error"

						self:oplog_login_error(Uin, "login", error_report)
					end

					return code, datas, msg
				end
			end

			local function do_login()
				local ok = false

				if ok == false and type(current) == "table" and not Passwd_tmp then
					local question = current.question

					if type(question) == "table" and type(question[1]) == "string" and type(question[2]) == "string" then
						conn:set_auth_func(function ()
							local code, info = self:http_rpc("passwd", "question_verify", {
								Uin = Uin,
								key = question[1],
								value = question[2],
								apiid = LuaInterface:getApiId(),
								DeviceID = type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget"
							})
							conn.errorcode = code

							if code == ErrorCode.QUESTION_NOT_SET then
								local h = self:load_from_file("history")

								if type(h) == "table" and #h > 0 then
									local history_num = #h

									for i = history_num, 1, -1 do
										local history_one = h[i]

										if type(history_one) == "table" and history_one.Uin == Uin and not history_one.question then
											self:save_to_file("current", history_one)

											return code, info and info.datas, info and info.msg
										end
									end
								end
							else
								local authinfo = type(info) == "table" and info.authinfo

								if code == ErrorCode.OK and authinfo then
									local account = self.account
									conn.authed = false
									conn.token = authinfo.token
									conn.errorcode = nil
									conn.errorinfo = nil
									local code = conn:heartbeat()
									conn.errorcode = code

									if code == ErrorCode.OK then
										conn.authed = true
										conn.token = authinfo.token

										if conn.sign then
											authinfo.sign = conn.sign
										else
											conn.sign = authinfo.sign
										end

										conn.other = authinfo.other
										self.account.islogin = true

										account:setuin(authinfo.Uin)

										conn.isnewuser = authinfo.isnewuser

										self:oplog_login_check_connect(authinfo.Uin, "login question")
									else
										conn.authed = false
										conn.token = nil
										conn.other = nil
										conn.errorcode = code
										conn.errorinfo = info
										local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " question login error"

										self:oplog_login_error(Uin, "login", error_report)
									end
								else
									conn.authed = false
									conn.token = nil
									conn.sign = nil
									conn.other = nil
									local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " question login 2 error"

									self:oplog_login_error(Uin, "login", error_report)
								end
							end
						end)

						ok = true
					end
				end

				if ok == false and not Passwd_tmp then
					local authinfo = current and current.authinfo

					if type(authinfo) == "table" and (authinfo.appid or authinfo.openid_type) then
						return self:unionid_login(authinfo, false)
					elseif type(authinfo) == "table" and authinfo.Uin == Uin and authinfo.token and authinfo.sign then
						conn:set_auth_func(function ()
							local account = self.account
							conn.authed = false
							conn.token = authinfo.token
							conn.errorcode = nil
							conn.errorinfo = nil
							local code = conn:heartbeat()

							if code == ErrorCode.ACCOUNT_AUTHINFO_NOT_OK then
								local ret = self:channel_login_retry_xianmi(Uin)

								print("login,channel_login_retry_xianmi", Uin)

								if type(ret) == "table" and ret.code == ErrorCode.OK then
									conn.token = ret.data.token
									conn.sign = ret.data.sign
									code = conn:heartbeat()
								end
							end

							conn.errorcode = code

							if code == ErrorCode.OK then
								conn.authed = true
								conn.token = authinfo.token

								if conn.sign then
									authinfo.sign = conn.sign
								else
									conn.sign = authinfo.sign
								end

								conn.other = authinfo.other
								self.account.islogin = true

								account:setuin(authinfo.Uin)

								conn.isnewuser = authinfo.isnewuser

								self:oplog_login_check_connect(authinfo.Uin, "login authinfo")
							else
								local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " authinfo login error"

								self:oplog_login_error(Uin, "login", error_report)

								conn.authed = false
								conn.token = nil
								conn.sign = nil
								conn.other = nil
							end
						end)

						ok = true
					end
				end

				if ok == false then
					Passwd = Passwd or current and current.Passwd or LuaInterface:getPasswd()

					local function try_passwd(to_try)
						conn.errorcode = nil
						conn.errorinfo = nil
						local code, authinfo = self.cluster.login.auth({
							Uin = Uin,
							Passwd = to_try,
							ApiId = LuaInterface:getApiId(),
							CltVersion = LuaInterface:getCltVersion(),
							DeviceID = GetClientInfo():getDeviceID() or "cantget",
							Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil
						})
						conn.errorcode = code
						conn.errorinfo = authinfo

						if code == ErrorCode.OK then
							Passwd = to_try
							conn.authed = true
							conn.token = authinfo.token
							conn.sign = authinfo.sign
							conn.other = authinfo.other
							self.account.islogin = true

							self.account:setuin(authinfo.Uin)

							conn.isnewuser = authinfo.isnewuser

							self:save_to_file("current", {
								Uin = Uin,
								Passwd = Passwd
							})

							self.pwd_wrong = nil

							self:oplog_login_check_connect(authinfo.Uin, "login try_passwd")
						else
							local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " Passwd login error"

							self:oplog_login_error(Uin, "login", error_report)
						end

						return code, authinfo, authinfo and authinfo.reason
					end

					conn:set_auth_func(function ()
						if self.pwd_wrong and GetPEGuidanceHappened then
							if GetPEGuidanceHappened() then
								return ErrorCode.OK
							else
								PasswordErrorGuidance()

								return ErrorCode.OK
							end
						end

						conn.errorcode = nil
						conn.errorinfo = nil
						local code, authinfo = self.cluster.login.auth({
							Uin = Uin,
							Passwd = Passwd,
							ApiId = LuaInterface:getApiId(),
							CltVersion = LuaInterface:getCltVersion(),
							DeviceID = GetClientInfo():getDeviceID() or "cantget",
							Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil
						})
						conn.errorcode = code
						conn.errorinfo = authinfo

						print("login.auth return code", code)

						if code == ErrorCode.OK then
							self.pwd_wrong = nil
							conn.authed = true
							conn.token = authinfo.token
							conn.sign = authinfo.sign
							conn.other = authinfo.other
							self.account.islogin = true

							self.account:setuin(authinfo.Uin)

							conn.isnewuser = authinfo.isnewuser

							self:save_to_file("current", {
								Uin = Uin,
								Passwd = Passwd
							})
							self:oplog_login_check_connect(authinfo.Uin, "login passwd auth")
						else
							if code == ErrorCode.ACCOUNT_PASSWD_NOT_OK then
								local already_try = {
									[Passwd] = true
								}
								local history = self:load_from_file("history")

								if type(history) == "table" and table.getn(history) then
									local trylist = table.clone(history)

									for i, v in ipairs(trylist) do
										if type(v) == "table" and Uin == v.Uin then
											if type(v.Passwd) == "string" and not already_try[v.Passwd] then
												already_try[v.Passwd] = true
												local try_code = try_passwd(v.Passwd)

												if try_code == ErrorCode.OK then
													return ErrorCode.OK
												end
											end

											if type(v.OldPasswd) == "string" and not already_try[v.OldPasswd] then
												already_try[v.OldPasswd] = true
												local try_code = try_passwd(v.OldPasswd)

												if try_code == ErrorCode.OK then
													return ErrorCode.OK
												end
											end
										end
									end
								end
							end

							if code ~= ErrorCode.PRECHECK_ACCOUNT_IS_WRITTEN_OFF then
								self.pwd_wrong = true
							end

							conn.authed = false
							conn.token = nil
							conn.sign = nil
							conn.other = nil
							local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " Passwd login 2 error"

							self:oplog_login_error(Uin, "login", error_report)
						end
					end)

					ok = true
				end
			end

			pcall(do_login)
			self:get_account_info(Uin)
			ShowNoTransparentLoadLoop()

			local code, errinfos = self:data_update(true)

			if code == ErrorCode.QUESTION_NOT_SET then
				current = self:load_from_file("current")
				Uin = Uin or current and current.Uin or LuaInterface:getUin() or 1

				pcall(do_login)

				code, errinfos = self:data_update(true)

				print("QUESTION_NOT_SET code = ", code)

				local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " Passwd login data_update QUESTION_NOT_SET error"

				self:oplog_login_error(Uin, "login", error_report)
			end

			HideNoTransparentLoadLoop()

			if ErrorCode.OK ~= code then
				local error_report = "Uin:" .. Uin .. " passwd:" .. (Passwd or "null") .. " Passwd login data_update error code" .. (code or -1)

				self:oplog_login_error(Uin, "login", error_report)

				return code, errinfos, errinfos and errinfos.reason
			end

			print("data_update code = ", code)

			if code == ErrorCode.ACCOUNT_PASSWD_NOT_OK then
				self.pwd_wrong = true

				return code, errinfos, errinfos and errinfos.reason
			end

			print("game_env", GetIWorldConfig():getGameData("game_env"))

			if GetIWorldConfig():getGameData("game_env") == 2 or GetIWorldConfig():getGameData("game_env") == 12 then
				return code, errinfos, errinfos and errinfos.reason
			end

			if self:getloginsafeverify() then
				return ErrorCode.OK
			end

			return ErrorCode.OK
		end
	end,
	channel_login_retry_xianmi = function (self, Uin)
		if LuaInterface:getApiId() ~= 12 then
			return ErrorCode.FAILED
		end

		print("channel_login_retry_xianmi:1", Uin)

		local ret_code, sdkinfo = self:sdkv2_get_sdkInfo()

		print("channel_login_retry_xianmi:2", ret_code, sdkinfo)

		if ErrorCode.OK ~= ret_code or not sdkinfo or sdkinfo.apiid ~= 12 then
			return ErrorCode.FAILED
		end

		sdkinfo.Uin = Uin
		local ret = self:http_login("login", "openid_check", sdkinfo)

		print("channel_login_retry_xianmi:3", ret)

		return ret
	end,
	request_send_sms_verifycode = function (self, phonenum, iType)
		local code, msg = self:http_rpc("login", "send_sms_verifycode", {
			phonenum = phonenum,
			type = iType
		})

		return code, msg
	end,
	phone_check = function (self, phonenum)
		local code, info = self:http_rpc("login", "phone_check", {
			phonenum = phonenum
		})

		return code, info
	end,
	phone_unbind = function (self, phonenum, verifycode)
		local code, info = self:http_rpc("login", "phone_unbind", {
			phonenum = phonenum,
			verifycode = verifycode
		})

		return code, info
	end,
	uin_history = function (self)
		local map = {}
		local history = self:load_from_file("history")
		local list = {}
		local list_history = {}
		local list_hostory_client = {}

		if type(history) == "table" then
			for i = #history, 1, -1 do
				local Uin = type(history[i]) == "table" and history[i].Uin

				if Uin then
					if history[i].Passwd then
						if not list_history[Uin] then
							list_history[Uin] = delegate(function ()
								local t = {
									loginType = "Passwd",
									Uin = Uin,
									Passwd = history[i].Passwd
								}
								local local_data = self:load_from_file("account_" .. Uin)
								local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
								t.NickName = RoleInfo and RoleInfo.NickName or ""

								return t
							end)

							table.insert(list_hostory_client, list_history[Uin])
						end
					elseif history[i].question then
						if not list_history[Uin] then
							list_history[Uin] = delegate(function ()
								local t = {
									loginType = "question",
									Uin = Uin,
									question = history[i].question
								}
								local local_data = self:load_from_file("account_" .. Uin)
								local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
								t.NickName = RoleInfo and RoleInfo.NickName or ""

								return t
							end)

							table.insert(list_hostory_client, list_history[Uin])
						end
					elseif history[i].authinfo then
						if history[i].authinfo.openid_type == "wechat" then
							if not list_history[Uin] then
								list_history[Uin] = delegate(function ()
									local t = {
										loginType = "wechat",
										Uin = Uin,
										authinfo = {}
									}
									local local_data = self:load_from_file("account_" .. Uin)
									local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
									t.NickName = RoleInfo and RoleInfo.NickName or ""

									return t
								end)

								table.insert(list_hostory_client, list_history[Uin])
							end
						elseif history[i].authinfo.openid_type == "qq" then
							if not list_history[Uin] then
								list_history[Uin] = delegate(function ()
									local t = {
										loginType = "qq",
										Uin = Uin,
										authinfo = {}
									}
									local local_data = self:load_from_file("account_" .. Uin)
									local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
									t.NickName = RoleInfo and RoleInfo.NickName or ""

									return t
								end)

								table.insert(list_hostory_client, list_history[Uin])
							end
						elseif history[i].authinfo.openid_type == "kuaishou" then
							if not list_history[Uin] then
								list_history[Uin] = delegate(function ()
									local t = {
										loginType = "kuaishou",
										Uin = Uin,
										authinfo = {}
									}
									local local_data = self:load_from_file("account_" .. Uin)
									local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
									t.NickName = RoleInfo and RoleInfo.NickName or ""

									return t
								end)

								table.insert(list_hostory_client, list_history[Uin])
							end
						elseif history[i].openid_type == "channel" then
							if not list_history[Uin] then
								list_history[Uin] = delegate(function ()
									local t = {
										loginType = "channel",
										Uin = Uin,
										authinfo = history[i].authinfo
									}
									local local_data = self:load_from_file("account_" .. Uin)
									local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
									t.NickName = RoleInfo and RoleInfo.NickName or ""

									return t
								end)

								table.insert(list_hostory_client, list_history[Uin])
							end
						elseif history[i].phone and not list_history[Uin] then
							list_history[Uin] = delegate(function ()
								local t = {
									loginType = "phone",
									Uin = Uin,
									phone = history[i].phone,
									authinfo = history[i].authinfo
								}
								local local_data = self:load_from_file("account_" .. Uin)
								local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
								t.NickName = RoleInfo and RoleInfo.NickName or ""

								return t
							end)

							table.insert(list_hostory_client, list_history[Uin])
						end
					end
				end
			end
		end

		list.history = list_hostory_client
		list.last_login = self:load_from_file("current")

		return list
	end,
	del_uin_history = function (self, uin)
		local history = self:load_from_file("history") or {}

		for i = #history, 1, -1 do
			if history[i].Uin and history[i].Uin == uin then
				table.remove(history, i)
			end
		end

		self:save_to_file("history", history)
		self:delete_file("account_" .. uin)
		self:delete_file("groupchat_member_" .. uin)
		self:delete_file("search_backpack_" .. uin)

		local current = self:load_from_file("current")

		if current and current.Uin == uin then
			self:delete_file("current")
		end

		if LuaInterface.removeAccAndHistoryArchiveByUin then
			LuaInterface:removeAccAndHistoryArchiveByUin(uin)
		end
	end,
	get_local_account = function (self, uin)
		return self:load_from_file("account_" .. uin)
	end,
	get_recharge_curmoth = function (self)
		local account = self.account
		local leveldb = account and account.leveldb

		return leveldb and leveldb.recharge_curmoth or {}
	end,
	auth_set = function (self, list)
		if type(list) ~= "table" then
			return ErrorCode.PRECHECK_ERROR
		end

		if not list[1] then
			return ErrorCode.PRECHECK_ERROR
		end

		local passwd = nil

		for i, v in ipairs(list) do
			if v[1] == 1 or v[1] == 2 then
				if v[2] and v[3] then
					v[2] = tostring(v[2])
					v[3] = tostring(v[3])
					v[3] = g_recharge_md5_related.md5sum(v[3], #v[3])
				else
					return ErrorCode.PRECHECK_ERROR
				end
			elseif v[1] == 0 then
				if v[2] then
					v[2] = tostring(v[2])
					passwd = tostring(v[2])
				else
					return ErrorCode.PRECHECK_ERROR
				end
			end
		end

		local code = self:remote_call("baseinfo", "auth_set", list)

		if code == ErrorCode.OK and passwd then
			local conn = self.conn

			conn:close()

			local chatpushconn = self.chatpushconn

			chatpushconn:close()

			local code = self:login(Uin, passwd)

			return code
		end

		return code
	end,
	set_noviceGuideFlag = function (self, val)
		return self:remote_call("baseinfo", "set_noviceGuideFlag", val)
	end,
	get_noviceGuideFlag = function (self)
		return self.account and self.account:get_noviceGuideFlag()
	end,
	set_noviceGuideFlagEx = function (self, key, value)
		return self:remote_call("baseinfo", "set_noviceGuideFlagEx", key, value)
	end,
	get_noviceGuideFlagEx = function (self)
		return self.account and self.account.leveldb and self.account.leveldb.noviceGuideFlagEx or {}
	end,
	set_createRoleStep = function (self, val)
		return self:remote_call("baseinfo", "set_createRoleStep", val)
	end,
	get_createRoleStep = function (self)
		return self.account and self.account:get_createRoleStep()
	end,
	role_lock = function (self)
		return self:remote_call("baseinfo", "role_lock")
	end,
	role_unlock = function (self)
		return self:remote_call("baseinfo", "role_unlock")
	end,
	check_role_unlock = function (self)
		local account = self.account
		local info = account:role_lock_info()

		return info and true or false
	end,
	role_lock_info = function (self)
		local account = self.account

		return account and account:role_lock_info()
	end,
	other_role_lock_info = function (self, Uin)
		return self:remote_call("baseinfo", "other_role_lock_info", Uin)
	end,
	reg_close_realname_dialog_box = function (self)
		if RealNameModule:HitChannelPriorityAuth() then
			self.account.close_rolename_tips = true
		end
	end,
	check_reg_realname_dialog_box = function (self)
		if RealNameModule:HitChannelPriorityAuth() then
			local state = AccountManager:realname_state()

			if state ~= 1 then
				self:channel_real_name()
			end

			state = AccountManager:realname_state()

			if state ~= 1 then
				print("check_reg_realname_dialog_box", state)

				self.account.close_rolename_tips = false

				ShowIdentityNameAuthFrame()
			end
		end
	end,
	reg = function (self, Passwd)
		if not self:version_check_login("reg") then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		if LoginManager:CheckRegistChannnelForceLogin(true) then
			-- Nothing
		end

		local standalone = self.container.cfg.standalone
		local conn = self.conn

		if RealNameModule:HitLimitRuleChannel() then
			RealNameModule:PreSetAuthInfo()

			local code, isrealname = self:is_realname_channel_sdk()

			print("reg is_realname_channel_sdk", code, isrealname)

			if code ~= ErrorCode.OK or isrealname ~= true then
				local tips = "亲爱的冒险家，根据渠道的要求，必须登录渠道账号和实名以后才能进入游戏，请登录渠道账号和完成实名认证"

				AntiAddictionModule:HideAccountGameModelFrame()
				MessageBox(14, tips)
				threadpool:wait(30)
				LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)

				return ErrorCode.FAILED
			end
		end

		print("reg start ... ")

		local info = {
			Latitude = 0,
			Longitude = 0,
			DeviceID = type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget",
			ApiId = LuaInterface:getApiId(),
			AccountName = LuaInterface:getAccountName(),
			CltVersion = LuaInterface:getCltVersion(),
			CltType = LuaInterface:getCltTye(),
			OpenString = LuaInterface:getOpenString(),
			Passwd = Passwd or LuaInterface:getPasswd(),
			Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil
		}

		if info.Passwd == "0" then
			local now_ = getServerNow()
			local auth_ = gFunc_getmd5(now_)
			info.Passwd = string.sub(auth_, 2, 9)
		end

		print("reg info =", info)

		if standalone == true then
			print("单机模式注册")

			local sample = loadwwwcache("sample")
			local Uin = sample.mysql.Account.Uin

			self:save_to_file("account_" .. Uin, sample)
			self:save_to_file("current", {
				Uin = Uin,
				Passwd = Passwd
			})

			return self:get_account_info(Uin), "first_login"
		end

		conn:set_auth_func(function ()
			local account = self.account

			if account.Uin <= 1 then
				conn.errorcode = nil
				conn.errorinfo = nil

				self:reg_close_realname_dialog_box()

				local code, authinfo = self.cluster.login.reg(info, account.Account.RoleInfo)

				print("注册返回 ", code, authinfo)

				conn.errorcode = code
				conn.errorinfo = authinfo

				if code == ErrorCode.PRECHECK_REG_OVERLOAD then
					local isneedCheck = check_apiid_ver_conditions(ns_version.check_reg_overload)

					if isneedCheck then
						MessageBox(14, GetS(35500))

						_G.IgnoreEsc = true
					end
				end

				if code == ErrorCode.OK then
					conn.authed = true
					conn.token = authinfo.token
					conn.sign = authinfo.sign
					conn.other = authinfo.other
					self.account.islogin = true

					self.account:setuin(authinfo.Uin)

					conn.isnewuser = authinfo.isnewuser

					self:save_to_file("current", {
						Uin = authinfo.Uin,
						Passwd = info.Passwd
					})
					account:setuin(authinfo.Uin)
					self:oplog_login_check_connect(authinfo.Uin, "reg")
				else
					conn.authed = false
					conn.token = nil
					conn.sign = nil
					conn.other = nil
					local error_report = " reg error code" .. code

					self:oplog_login_error("", "reg", error_report)
				end
			else
				conn.errorcode = nil
				conn.errorinfo = nil
				local code, authinfo = self.cluster.login.auth({
					Uin = self.account.Uin,
					Passwd = Passwd,
					ApiId = LuaInterface:getApiId(),
					CltVersion = LuaInterface:getCltVersion(),
					DeviceID = type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget",
					Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil
				})
				conn.errorcode = code
				conn.errorinfo = authinfo

				print("登录返回", code, authinfo)

				if code == ErrorCode.OK then
					conn.authed = true
					conn.token = authinfo.token
					conn.sign = authinfo.sign
					conn.other = authinfo.other
					account.islogin = true
					self.account.islogin = true

					self.account:setuin(authinfo.Uin)

					conn.isnewuser = authinfo.isnewuser

					self:save_to_file("current", {
						Uin = authinfo.Uin,
						Passwd = info.Passwd
					})
					self:oplog_login_check_connect(authinfo.Uin, "reg auth")
				else
					conn.authed = false
					conn.token = nil
					conn.sign = nil
					conn.other = nil
					local error_report = " reg login error code" .. code

					self:oplog_login_error("", "reg", error_report, {
						authinfo = authinfo
					})
				end
			end
		end)
		self:get_account_info(1)
		ShowNoTransparentLoadLoop()

		local code, errinfos = self:data_update(true)

		if code == ErrorCode.OK then
			self:channel_real_name()
			self:check_reg_realname_dialog_box()
		else
			self:oplog_login_error("", "client.reg", "self:data_update return not ok.", code)
		end

		HideNoTransparentLoadLoop()

		errinfos = errinfos or {}
		errinfos.isFirstLogin = "first_login"

		return code, errinfos, errinfos.reason
	end,
	on_room_enter = function (self)
		local conn = self.conn

		if not conn.authed then
			conn:auth()
		end
	end,
	hit_appid = function (self, srcTb, value)
		if srcTb and type(srcTb) == "table" and value then
			for index = 1, #srcTb do
				if value == srcTb[index] then
					return true
				end
			end
		end

		return false
	end,
	getLoginByOpenStringAppids = function (self)
		local appids = {
			60,
			56,
			47,
			121,
			122,
			123,
			124,
			125,
			126,
			127,
			102,
			128,
			402,
			129
		}
		local ApiID = LuaInterface:getApiId()

		return self:hit_appid(appids, ApiID) or GetClientInfo():isQQGamePcApi(ApiID)
	end,
	getLoginByAuthinfoAppids = function (self)
		local appids = {
			410,
			411
		}
		local ApiID = LuaInterface:getApiId()

		return self:hit_appid(appids, ApiID)
	end,
	getLoginOpenString = function (self)
		local ApiID = LuaInterface:getApiId()

		if ApiID == 102 and GetClientInfo():getEnterParam("rail_session_ticket") == "" then
			if GetClientInfo().update_rail_session_ticket then
				GetClientInfo():update_rail_session_ticket()
			end

			for i = 1, 300 do
				if GetClientInfo().getEnterParam and GetClientInfo():getEnterParam("rail_session_ticket") ~= "" then
					break
				end

				threadpool:wait(0.1)
			end
		end

		if ApiID == 402 then
			if GetClientInfo():getEnterParam("ticket") == "" then
				print("call AuthSessionTicketFromServer")

				if GetClientInfo().AuthSessionTicketFromServer then
					GetClientInfo():AuthSessionTicketFromServer()
				end

				for i = 1, 300 do
					if GetClientInfo():getEnterParam("ticket") ~= "" then
						break
					end

					threadpool:wait(0.1)
				end
			end

			print("steam tick = ", GetClientInfo():getEnterParam("ticket"))
		end

		local accountname = SdkManager:getTpLoginAccount()
		local openstring = SdkManager:getTpLoginAccountParams()

		local function GetOpenstringFunc()
			for i = 1, 300 do
				if not openstring or openstring == "" then
					openstring = SdkManager:getTpLoginAccountParams()
				else
					accountname = SdkManager:getTpLoginAccount()

					break
				end

				threadpool:wait(0.1)
			end
		end

		if ApiID == 129 then
			if GetClientInfo().GetFunnyCoreLoginAccountInfo then
				for i = 1, 300 do
					if not openstring or openstring == "" then
						GetClientInfo():GetFunnyCoreLoginAccountInfo()
					else
						break
					end

					threadpool:wait(0.1)

					openstring = SdkManager:getTpLoginAccountParams()
				end
			end
		else
			GetOpenstringFunc()
		end

		return accountname, openstring
	end,
	getLoginByAuthinfo = function (self)
		local s = SdkManager:getTpLoginAccountParams()

		if s then
			local logininfo = {}

			for k in s:gmatch("[^&]+") do
				local key, value = k:match("([^=]+)=([^=]+)")

				if key and value then
					logininfo[key] = tonumber(value) or value
				end
			end

			return logininfo
		end

		return nil
	end,
	requestEnterGame = function (self)
		if not self:version_check_login("requestEnterGame") then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		local ApiID = LuaInterface:getApiId()
		local ispc = LuaInterface:ispc()

		print("Hook Method requestEnterGame", ApiID, ispc)

		local current = self:load_from_file("current")

		print("requestEnterGame current", current)

		if current then
			local extra = current.extra
			local platform = extra and extra.platform

			if platform and platform == "facebook" then
				local authinfo = extra.authinfo

				if authinfo then
					return self:requestEnterGameWithAuthInfo(authinfo)
				end
			end
		end

		if self:getLoginByOpenStringAppids() then
			local accountname, openstring = self:getLoginOpenString()

			print("login openstring = ", accountname, openstring)

			if not openstring or openstring == "" then
				return ErrorCode.FAILED, {}, "openstring empty"
			end

			return self:requestEnterGameByOpenstring(accountname, openstring)
		elseif self:getLoginByAuthinfoAppids() then
			local authinfo = self:getLoginByAuthinfo()

			print("login authinfo = ", authinfo)

			if authinfo then
				return self:requestEnterGameWithAuthInfo(authinfo)
			end

			return ErrorCode.FAILED
		else
			local code, datas, msg = self:login()

			print("login code = ", code, datas, msg)

			return code, datas, msg
		end
	end,
	requestEnterGameByOpenstring = function (self, accountname, openstring)
		if not self:version_check_login("requestEnterGameByOpenstring") then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		print("requestEnterGameByOpenstring", accountname, openstring)

		local conn = self.conn

		conn:start()

		local current = self:load_from_file("current")
		local Uin = current and current.Uin or 0

		if type(Uin) == "number" and Uin <= 0 then
			Uin = 1
		end

		if current and current.AccountName ~= accountname then
			Uin = 1
		end

		conn:set_auth_func(function ()
			local account = self.account
			local RoleInfo = self:load_from_file("tmp1")
			conn.errorcode = nil
			conn.errorinfo = nil
			local code, authinfo = self.cluster.login.auth({
				Latitude = 0,
				Longitude = 0,
				AccountName = accountname,
				OpenString = openstring,
				ApiId = LuaInterface:getApiId(),
				CltVersion = LuaInterface:getCltVersion(),
				RoleInfo = account.Account.RoleInfo,
				DeviceID = GetClientInfo():getDeviceID() or "cantget",
				CltType = LuaInterface:getCltTye(),
				Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil,
				extra = extra
			})
			conn.errorcode = code
			conn.errorinfo = authinfo

			if code == ErrorCode.OK then
				conn.authed = true
				conn.token = authinfo.token
				conn.sign = authinfo.sign
				conn.other = authinfo.other
				self.account.islogin = true

				account:setuin(authinfo.Uin)

				conn.isnewuser = authinfo.isnewuser

				if extra then
					extra.authinfo = authinfo
				end

				self:save_to_file("current", {
					Uin = authinfo.Uin,
					AccountName = accountname,
					extra = extra
				})
				self:oplog_login_check_connect(authinfo.Uin, "requestEnterGameByOpenstring")
			else
				conn.authed = false
				conn.token = nil
				conn.sign = nil
				conn.other = nil
				local error_report = " requestEnterGameByOpenstring no ok" .. code

				self:oplog_login_error(Uin, "requestEnterGameByOpenstring", error_report)
			end
		end)
		self:get_account_info(Uin)
		ShowNoTransparentLoadLoop()

		local code, errinfos = self:data_update(true)

		HideNoTransparentLoadLoop()
		print("requestEnterGameByOpenstring return", code)

		errinfos = errinfos or {}
		errinfos.isFirstLogin = conn.isnewuser and "first_login"
		errinfos.isSdkLogin = true

		return code, errinfos, errinfos.reason
	end,
	requestEnterGameWithAuthInfo = function (self, authinfo, bNotSaveCurrent)
		print(" request enter game with authinfo", authinfo)

		local conn = self.conn

		conn:start()

		local Uin = authinfo.Uin

		if not Uin or Uin < 1000 then
			return ErrorCode.FAILED, "Uin is less thant 1000"
		end

		if not self:version_check_login("requestEnterGameWithAuthInfo" .. Uin) then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		conn:set_auth_func(function ()
			local account = self.account
			conn.authed = false
			conn.token = authinfo.token
			conn.errorcode = nil
			conn.errorinfo = nil
			local code = conn:heartbeat()
			conn.errorcode = code

			if code == ErrorCode.OK then
				self.pwd_wrong = false
				conn.authed = true
				conn.token = authinfo.token

				if conn.sign then
					authinfo.sign = conn.sign
				else
					conn.sign = authinfo.sign
				end

				conn.other = authinfo.other
				self.account.islogin = true

				account:setuin(authinfo.Uin)

				conn.isnewuser = authinfo.isnewuser

				self:oplog_login_check_connect(authinfo.Uin, "requestEnterGameWithAuthInfo")
			else
				conn.authed = false
				conn.token = nil
				conn.sign = nil
				conn.other = nil
				local error_report = "Uin:" .. Uin .. " requestEnterGameWithAuthInfo no ok" .. code

				self:oplog_login_error(Uin, "requestEnterGameWithAuthInfo", error_report)
			end
		end)
		self:get_account_info(Uin)
		ShowNoTransparentLoadLoop()

		local code, errinfos = self:data_update(true)

		HideNoTransparentLoadLoop()
		print("after update:", code)

		if code == ErrorCode.PRECHECK_ACCOUNT_IS_FREEZED or code == ErrorCode.PRECHECK_ACCOUNT_IS_WRITTEN_OFF then
			return code, errinfos, errinfos.reason
		end

		if not bNotSaveCurrent then
			self:save_to_file("current", {
				Uin = Uin,
				authinfo = authinfo
			})
		end

		errinfos = errinfos or {}

		self:getloginsafeverify()

		errinfos.isFirstLogin = authinfo.isnewuser and "first_login"

		return code, errinfos, errinfos.reason
	end,
	logout = function (self)
		local account = self.account

		if account then
			account.islogin = false
		end

		self:StopAccountActive("logout")

		local conn = self.conn

		if conn then
			conn:set_auth_func(nil)

			conn.authed = false
			conn.token = nil
			conn.sign = nil
			conn.other = nil

			conn:close()
		end

		local chatpushconn = self.chatpushconn

		if chatpushconn then
			chatpushconn:close()
		end

		if SandboxLua and SandboxLua.eventDispatcher then
			SandboxLua.eventDispatcher:Emit(nil, "AccountLoginOut", MNSandbox.SandboxContext())
		elseif LoginManager and LoginManager.OnAccountLogout then
			LoginManager:OnAccountLogout()
		end
	end,
	setAccountPasswd = function (self, string_of_uin, Passwd, code)
		MiniLog("start setAccountPasswd")

		if not self:version_check_login("setAccountPasswd" .. string_of_uin) then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		self.pwd_wrong = false
		local findhistory = false
		local datadef = AccountManager:get_account_history_list()
		local mininum = #datadef

		for i = 1, mininum do
			if datadef[i].Uin ~= nil then
				local stringuin = tostring(datadef[i].Uin) or ""

				if string_of_uin == stringuin then
					print("setAccountPasswd history find true ")

					findhistory = true

					break
				end
			end
		end

		if not findhistory and (Passwd == "0" or Passwd == 0) then
			print("setAccountPasswd can not login ")

			local error_report = " setAccountPasswd Passwd:" .. Passwd

			self:oplog_login_error(string_of_uin, "setAccountPasswd", error_report)

			return ErrorCode.ACCOUNT_PASSWD_NOT_OK
		end

		if CSMgr and CSMgr.beforeSwitchAccount then
			CSMgr:beforeSwitchAccount()
		end

		local origin_account = self.account

		if origin_account then
			origin_account:flush()
		end

		local origin_active = self:GetAccountActiveState()
		local Uin = type(string_of_uin) == "string" and string_of_uin:match("@") and string_of_uin or tonumber(string_of_uin)
		local conn = self.conn
		local origin_conninfo = {
			authed = conn.authed,
			token = conn.token,
			other = conn.other,
			sign = conn.sign
		}

		conn:close()

		local chatpushconn = self.chatpushconn

		chatpushconn:close()

		local origin_auth_func = conn:get_auth_func()

		conn:set_auth_func(function ()
			conn.errorcode = nil
			conn.errorinfo = nil
			local code, authinfo = self.cluster.login.auth({
				isswitch = true,
				Uin = Uin,
				Passwd = Passwd,
				ApiId = LuaInterface:getApiId(),
				CltVersion = LuaInterface:getCltVersion(),
				DeviceID = type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget",
				Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil
			})
			conn.errorcode = code
			conn.errorinfo = authinfo

			if code == ErrorCode.OK then
				conn.authed = true
				conn.token = authinfo.token
				conn.sign = authinfo.sign
				conn.other = authinfo.other
				self.account.islogin = true

				self.account:setuin(authinfo.Uin)

				conn.isnewuser = authinfo.isnewuser

				self:oplog_login_check_connect(authinfo.Uin, "setAccountPasswd")
			else
				conn.authed = false
				conn.token = nil
				conn.sign = nil
				conn.other = nil
				local error_report = "uin:" .. string_of_uin .. "Passwd:" .. (Passwd or "nil") .. " setAccountPasswd code:" .. code

				self:oplog_login_error(string_of_uin, "setAccountPasswd", error_report)

				if code == ErrorCode.PRECHECK_APIID_NOT_OK then
					local ApiID_Svr = authinfo and authinfo.ApiID

					if ApiID_Svr then
						ShowTipsLoginFailByApiId(ApiID_Svr)
					end
				end
			end
		end)

		client_M.eventcache = {}

		self:get_account_info(type(Uin) == "number" and Uin or 1)
		ShowNoTransparentLoadLoop()

		local code, errinfos = self:data_update(true)

		HideNoTransparentLoadLoop()

		if code == ErrorCode.OK then
			self:save_to_file("current", {
				Uin = Uin,
				Passwd = Passwd
			})
			self.account:OnBuddyDirty()
			self.account:OnAccountDirty()
			BuddyManager:on_switch_account()
			self.cluster.avatar.rpc_cache_clear()

			local account = self.account
			local isFirstLogin = nil

			if account then
				local Account = account.Account
				local leveldb = account.leveldb
				local RoleInfo = Account.RoleInfo
				local RoleSkinID = leveldb.RoleSkinID or RoleInfo.SkinID or 0

				if LuaInterface.setRoleInfoWithAvatarSkin and account.avatar_seat_current then
					local seatid = account:avatar_seat_current()

					LuaInterface:setRoleInfoWithAvatarSkin(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin, seatid and tostring(seatid) or "")
				else
					LuaInterface:setRoleInfo(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin)
				end

				if conn.isnewuser or RoleInfo.NickName and RoleInfo.NickName == "" then
					isFirstLogin = "first_login"
				end
			end

			if AccountGameModeClass and AccountGameModeClass.showTimerNum then
				AccountGameModeClass.showTimerNum = 0
			end

			errinfos = errinfos or {}
			errinfos.isFirstLogin = isFirstLogin

			return code, errinfos, errinfos.reason
		else
			print("回滚 到原来帐号 ", code)

			self.account = origin_account

			conn:set_auth_func(origin_auth_func)

			for k, v in pairs(origin_conninfo) do
				conn[k] = v
			end

			if origin_account then
				self:RestoreAccountActiveState(origin_active)

				conn.authed = false

				ShowNoTransparentLoadLoop()
				self:data_update(true)
				HideNoTransparentLoadLoop()

				return code, errinfos, errinfos.reason
			else
				self:StopAccountActive("switch_account_failed_no_origin")

				local conn = self.conn

				if conn then
					conn:close()
				end

				local chatpushconn = self.chatpushconn

				if chatpushconn then
					chatpushconn:close()
				end

				return code, errinfos, errinfos.reason
			end
		end
	end,
	setAccountAuth_MiniCode = function (self, string_of_uin, token)
		if not isEducationalVersion then
			return
		end

		if CSMgr and CSMgr.beforeSwitchAccount then
			CSMgr:beforeSwitchAccount()
		end

		local Uin = type(string_of_uin) == "string" and string_of_uin:match("@") and string_of_uin or tonumber(string_of_uin)
		local conn = self.conn

		print("断开老链接")
		conn:close()

		local chatpushconn = self.chatpushconn

		chatpushconn:close()

		conn.authed = false
		conn.connectting = false

		conn:set_auth_func(function ()
			local account = self.account
			conn.authed = false
			conn.token = token
			conn.errorcode = nil
			conn.errorinfo = nil
			local code = conn:heartbeat()
			conn.errorcode = code

			if code == ErrorCode.OK then
				self.account.islogin = true
			end
		end)

		client_M.eventcache = {}

		self:get_account_info(type(Uin) == "number" and Uin or 1)

		local code = self:data_update()
		local codeDevInfo, _, cfg = AccountManager:dev_developer_info(Uin)
		local DeltaArchiveNum = 0
		local BoughtArchiveNum = 0

		if codeDevInfo == ErrorCode.OK and cfg then
			DeltaArchiveNum = cfg.DeltaArchiveNum or 0
		end

		local seq = gen_gid()
		local url = mapservice.getserver() .. "/miniw/map/?act=search_user_maps&ctype=0&op_uin=" .. Uin
		url = UrlAddAuth(url)

		ns_http.func.rpc(url, function (ret)
			threadpool:notify(seq, ErrorCode.OK, ret)
		end, Uin, nil, ns_http.SecurityTypeHigh)

		local codeMapInfo, http_result = threadpool:wait(seq, 3, tick)

		if codeMapInfo == ErrorCode.OK and http_result and http_result.unlock_cells then
			BoughtArchiveNum = http_result.unlock_cells
		end

		return code, DeltaArchiveNum + BoughtArchiveNum
	end,
	switchAccountByOpenString = function (self, accountname, openstring)
		print("switchAccountByOpenString ", accountname, openstring)

		if CSMgr and CSMgr.beforeSwitchAccount then
			CSMgr:beforeSwitchAccount()
		end

		local origin_account = self.account

		if origin_account then
			origin_account:flush()
		end

		local origin_active = self:GetAccountActiveState()
		local conn = self.conn

		conn:close()

		local chatpushconn = self.chatpushconn

		chatpushconn:close()

		local origin_auth_func = conn:get_auth_func()
		local extra = nil

		conn:set_auth_func(function ()
			local account = self.account
			local RoleInfo = self:load_from_file("tmp1")
			conn.errorcode = nil
			conn.errorinfo = nil
			local code, authinfo = self.cluster.login.auth({
				Latitude = 0,
				Longitude = 0,
				AccountName = accountname,
				OpenString = openstring,
				ApiId = LuaInterface:getApiId(),
				CltVersion = LuaInterface:getCltVersion(),
				RoleInfo = account.Account.RoleInfo,
				DeviceID = type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget",
				CltType = LuaInterface:getCltTye(),
				Country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or nil,
				extra = extra
			})

			print("xxxxx 使用openid切换帐号", code, authinfo)

			conn.errorcode = code
			conn.errorinfo = authinfo

			if code == ErrorCode.OK then
				conn.authed = true
				conn.token = authinfo.token
				conn.sign = authinfo.sign
				conn.other = authinfo.other
				self.account.islogin = true

				account:setuin(authinfo.Uin)

				conn.isnewuser = authinfo.isnewuser

				if extra then
					extra.authinfo = authinfo
				end

				self:save_to_file("current", {
					Uin = authinfo.Uin,
					AccountName = accountname,
					extra = extra
				})
				self:oplog_login_check_connect(authinfo.Uin, "switchAccountByOpenString")
			else
				conn.authed = false
				conn.token = nil
				conn.sign = nil
				conn.other = nil
				local error_report = " switchAccountByOpenString code:" .. code

				self:oplog_login_error("", "switchAccountByOpenString", error_report, {
					accountname = accountname,
					openstring = openstring
				})
			end
		end)

		client_M.eventcache = {}

		self:get_account_info(1)
		ShowNoTransparentLoadLoop()

		local code = self:data_update()

		HideNoTransparentLoadLoop()

		if code == ErrorCode.OK then
			self.account:OnBuddyDirty()
			self.account:OnAccountDirty()
			BuddyManager:on_switch_account()

			local account = self.account
			local isFirstLogin = nil

			if account then
				local Account = account.Account
				local leveldb = account.leveldb
				local RoleInfo = Account.RoleInfo
				local RoleSkinID = leveldb.RoleSkinID or RoleInfo.SkinID or 0

				if LuaInterface.setRoleInfoWithAvatarSkin and account.avatar_seat_current then
					local seatid = account:avatar_seat_current()

					LuaInterface:setRoleInfoWithAvatarSkin(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin, seatid and tostring(seatid) or "")
				else
					LuaInterface:setRoleInfo(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin)
				end

				if conn.isnewuser or RoleInfo.NickName and RoleInfo.NickName == "" then
					isFirstLogin = "first_login"
				end
			end

			return true, code, isFirstLogin
		else
			print("回滚 到原来帐号 code = ", code)

			self.account = origin_account

			conn:set_auth_func(origin_auth_func)

			if origin_account then
				self:RestoreAccountActiveState(origin_active)

				conn.authed = false

				ShowNoTransparentLoadLoop()
				self:data_update(true)
				HideNoTransparentLoadLoop()
			else
				self:StopAccountActive("switch_account_failed_no_origin")

				local conn = self.conn

				if conn then
					conn:close()
				end

				local chatpushconn = self.chatpushconn

				if chatpushconn then
					chatpushconn:close()
				end
			end

			return false, code
		end
	end,
	switchAccountByAuthInfo = function (self, authinfo)
		if not self:version_check_login("switchAccountByAuthInfo") then
			return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
		end

		print("switchAccountByAuthInfo ")

		if CSMgr and CSMgr.beforeSwitchAccount then
			CSMgr:beforeSwitchAccount()
		end

		local origin_account = self.account

		if origin_account then
			origin_account:flush()
		end

		local origin_active = self:GetAccountActiveState()
		local conn = self.conn

		conn:close()

		local chatpushconn = self.chatpushconn

		chatpushconn:close()

		local origin_auth_func = conn:get_auth_func()

		conn:set_auth_func(function ()
			local account = self.account
			conn.authed = false
			conn.token = authinfo.token
			conn.errorcode = nil
			conn.errorinfo = nil
			local code = conn:heartbeat()

			if code == ErrorCode.ACCOUNT_AUTHINFO_NOT_OK then
				local ret = self:channel_login_retry_xianmi(authinfo.Uin)

				print("switchAccountByAuthInfo,channel_login_retry_xianmi", authinfo.Uin)

				if type(ret) == "table" and ret.code == ErrorCode.OK then
					conn.token = ret.data.token
					conn.sign = ret.data.sign
					code = conn:heartbeat()
				end
			end

			conn.errorcode = code

			if code == ErrorCode.OK then
				conn.authed = true
				conn.token = authinfo.token

				if conn.sign then
					authinfo.sign = conn.sign
				else
					conn.sign = authinfo.sign
				end

				conn.other = authinfo.other
				self.account.islogin = true

				account:setuin(authinfo.Uin)

				conn.isnewuser = authinfo.isnewuser

				self:oplog_login_check_connect(authinfo.Uin, "switchAccountByAuthInfo")
			else
				local error_report = " switchAccountByAuthInfo code:" .. code

				self:oplog_login_error("", "switchAccountByAuthInfo", error_report, {
					authinfo = authinfo
				})

				conn.authed = false
				conn.token = nil
				conn.sign = nil
				conn.other = nil
			end
		end)

		client_M.eventcache = {}

		self:get_account_info(1)
		ShowNoTransparentLoadLoop()
		print("switchAccountByAuthInfo   state = ", conn.state, ",conn.other = ", type(conn.other))

		local code, errinfos = self:data_update()

		HideNoTransparentLoadLoop()

		if code == ErrorCode.OK and conn.authed == true then
			self.account:OnBuddyDirty()
			self.account:OnAccountDirty()
			BuddyManager:on_switch_account()

			local account = self.account
			local isFirstLogin = nil

			if account then
				local Account = account.Account
				local leveldb = account.leveldb
				local RoleInfo = Account.RoleInfo
				local RoleSkinID = leveldb.RoleSkinID or RoleInfo.SkinID or 0

				if LuaInterface.setRoleInfoWithAvatarSkin and account.avatar_seat_current then
					local seatid = account:avatar_seat_current()

					LuaInterface:setRoleInfoWithAvatarSkin(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin, seatid and tostring(seatid) or "")
				else
					LuaInterface:setRoleInfo(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin)
				end

				if conn.isnewuser or RoleInfo.NickName and RoleInfo.NickName == "" then
					isFirstLogin = "first_login"
				end
			end

			errinfos = errinfos or {}
			errinfos.isFirstLogin = isFirstLogin

			return code, errinfos, errinfos.reason
		else
			print("回滚 到原来帐号 code = ", code)

			self.account = origin_account

			conn:set_auth_func(origin_auth_func)

			if origin_account then
				self:RestoreAccountActiveState(origin_active)

				conn.authed = false

				ShowNoTransparentLoadLoop()
				self:data_update(true)
				HideNoTransparentLoadLoop()
			else
				self:StopAccountActive("switch_account_failed_no_origin")

				local conn = self.conn

				if conn then
					conn:close()
				end

				local chatpushconn = self.chatpushconn

				if chatpushconn then
					chatpushconn:close()
				end
			end

			return code or ErrorCode.ACCOUNT_AUTHINFO_NOT_OK, errinfos, errinfos and errinfos.reason
		end
	end,
	switchAccountByAuthInfo_reg = function (self, authinfo, reg, no_load)
		print("switchAccountByAuthInfo", authinfo, reg, no_load)

		if CSMgr and CSMgr.beforeSwitchAccount then
			CSMgr:beforeSwitchAccount()
		end

		local origin_account = self.account

		if origin_account then
			origin_account:flush()
		end

		local origin_active = self:GetAccountActiveState()
		local conn = self.conn
		local origin_conn_token = conn.token

		conn:close()

		local chatpushconn = self.chatpushconn

		chatpushconn:close()

		local origin_auth_func = conn:get_auth_func()

		conn:set_auth_func(function ()
			local account = self.account
			conn.authed = false
			conn.token = authinfo.token
			conn.errorcode = nil
			conn.errorinfo = nil
			local code = conn:heartbeat()
			conn.errorcode = code

			print("switchAccountByAuthInfo_reg auth", code)

			if code == ErrorCode.OK then
				self.pwd_wrong = false
				conn.authed = true
				conn.token = authinfo.token

				if conn.sign then
					authinfo.sign = conn.sign
				else
					conn.sign = authinfo.sign
				end

				conn.other = authinfo.other
				self.account.islogin = true

				account:setuin(authinfo.Uin)

				conn.isnewuser = authinfo.isnewuser

				self:oplog_login_check_connect(authinfo.Uin, "switchAccountByAuthInfo_reg")
			else
				self:oplog_login_error("", "switchAccountByAuthInfo_reg", "conn:heartbeat() return not OK.", {
					authinfo = authinfo,
					code = code
				})

				conn.authed = false
				conn.token = nil
				conn.sign = nil
				conn.other = nil
			end
		end)

		client_M.eventcache = {}

		self:get_account_info(1)

		if not no_load then
			ShowNoTransparentLoadLoop()
		end

		print("switchAccountByAuthInfo   state = ", conn.state, ",conn.other = ", type(conn.other))

		local code, errinfos = self:data_update(true)

		if not no_load then
			HideNoTransparentLoadLoop()
		end

		print("switchAccountByAuthInfo   code ", code, conn.authed, errinfos)

		if code == ErrorCode.OK and conn.authed == true then
			if not reg then
				self.account:OnBuddyDirty()
				BuddyManager:on_switch_account()

				local account = self.account

				if account then
					local Account = account.Account
					local leveldb = account.leveldb
					local RoleInfo = Account.RoleInfo
					local RoleSkinID = leveldb.RoleSkinID or RoleInfo.SkinID or 0

					if LuaInterface.setRoleInfoWithAvatarSkin and account.avatar_seat_current then
						local seatid = account:avatar_seat_current()

						LuaInterface:setRoleInfoWithAvatarSkin(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin, seatid and tostring(seatid) or "")
					else
						LuaInterface:setRoleInfo(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin)
					end
				end
			end

			return code, errinfos, errinfos.reason
		else
			print("回滚 到原来帐号 code = ", code)

			self.account = origin_account

			conn:set_auth_func(origin_auth_func)

			if origin_account then
				self:RestoreAccountActiveState(origin_active)

				conn.authed = false
				conn.token = origin_conn_token

				ShowNoTransparentLoadLoop()
				self:data_update(true)
				HideNoTransparentLoadLoop()
			else
				self:StopAccountActive("switch_account_failed_no_origin")

				local conn = self.conn

				if conn then
					conn:close()
				end

				local chatpushconn = self.chatpushconn

				if chatpushconn then
					chatpushconn:close()
				end
			end

			return code, errinfos, errinfos.reason
		end
	end,
	requestMobileVerificationCode = function (self, phonenum, checktype)
		if checktype == nil then
			checktype = 1
		end

		print("AccountManager requestMobileVerificationCode", checktype)

		return self:remote_call("baseinfo", "smscode", phonenum, checktype)
	end,
	requestMobileVerifyCode = function (self, phonenum, verify_code, checktype)
		if checktype == nil then
			checktype = 1
		end

		local code = self:remote_call("baseinfo", "verify_phone_code", phonenum, verify_code, checktype, GetClientInfo():getDeviceID())

		print("AccountManager requestMobileVerifyCode", checktype, " code:", code)

		if code == ErrorCode.OK and checktype == 2 then
			local account = self.account
			local Account = account.Account

			print("AccountManager requestMobileVerifyCode Account", Account)
			print("AccountManager requestMobileVerifyCode Account.Email", Account.Email)

			if Account and Account.Email == nil then
				self:setloginsafeverify(false)
			end

			if Account and type(Account.Email) == "string" and Account.Email == "" then
				self:setloginsafeverify(false)
			end
		end

		if code == ErrorCode.OK and checktype == 4 then
			self:setloginsafeverify(not self:getloginsafeverify())
		end

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
			self:data_update()
		end

		return code
	end,
	requestBindingMobile = function (self, phonenum, verify_code)
		local code = self:remote_call("baseinfo", "bindphone", phonenum, verify_code)

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		return code
	end,
	requestVerifyPhone = function (self, phonenum, verify_code, type)
		local code = self:remote_call("baseinfo", "verify_phone_code", phonenum, verify_code, type)

		print("AccountManager requestVerifyPhone", type, " code ", code)

		if code == ErrorCode.OK and type == 2 then
			local account = self.account
			local Account = account.Account

			if Account and Account.Email == nil then
				self:setloginsafeverify(false)
			end

			if Account and type(Account.Email) == "string" and Account.Email == "" then
				self:setloginsafeverify(false)
			end
		end

		if code == ErrorCode.OK and type == 4 then
			self:setloginsafeverify(not self:getloginsafeverify())
		end

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		return code
	end,
	requestEmailVerificationCode = function (self, email, checktype)
		local lang = get_game_lang and get_game_lang() or nil

		if checktype == nil then
			checktype = 1
		end

		print("lang = ", lang)

		return self:remote_call("baseinfo", "emailcode", email, lang, checktype)
	end,
	requestVerifyEmail = function (self, email, verify_code, checktype)
		if checktype == nil then
			checktype = 1
		end

		local code = self:remote_call("baseinfo", "verify_email_code", email, verify_code, checktype)

		print("AccountManager requestVerifyEmail ", checktype, " code ", code)

		if code == ErrorCode.OK and checktype == 2 then
			local Phone = self:getBindLoginPhone() or self:getBindVerifyPhone()

			if not Phone or Phone == "" then
				self:setloginsafeverify(false)
			end
		end

		if code == ErrorCode.OK and checktype == 4 then
			self:setloginsafeverify(not self:getloginsafeverify())
		end

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		return code
	end,
	requestBindingEmail = function (self, email, verify_code)
		local code = self:remote_call("baseinfo", "bindemail", email, verify_code)

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		return code
	end,
	sdkv2_get_sdkInfo = function (self)
		local channel_auth_info = RealNameModule:GetChannelAuthorInfo()

		if not channel_auth_info then
			print("sdkv2_get_sdkInfo:GetChannelAuthorInfo() return nil")

			return ErrorCode.FAILED, {}
		end

		print("sdkv2_get_sdkInfo:", channel_auth_info)

		local info = {
			mac = channel_auth_info.mac,
			imei = channel_auth_info.imei,
			model = ns_http.func.url_encode(channel_auth_info.model),
			udid = channel_auth_info.udid,
			unifiedToken = channel_auth_info.unifiedToken,
			isauth = tonumber(channel_auth_info.channel_isRealName or 0) or 0,
			age = tonumber(channel_auth_info.channel_age or 0) or 0,
			channel_nickname = channel_auth_info.channel_nickname,
			isadult = 0
		}

		if info.age >= 18 then
			info.isadult = 1
		end

		info.DeviceID = type(GetClientInfo().getDeviceID) == "function" and GetClientInfo():getDeviceID() or "cantget"
		info.apiid = LuaInterface:getApiId() or ""
		info.cltversion = LuaInterface:getCltVersion()
		info.clttype = LuaInterface:getCltTye()

		if not info.unifiedToken or info.unifiedToken == "" then
			self:oplog_login_error("", "sdkv2_get_sdkInfo", "unifiedToken is invalid", info)

			return ErrorCode.FAILED, info
		end

		return ErrorCode.OK, info
	end,
	sdkv2_get_login_infos = function (self, sdkInfo, info)
		self:LLog("sdkv2_get_login_infos:info", info)

		sdkInfo = sdkInfo or {}
		info = info or {}
		sdkInfo.flag_reg = info.flag_reg
		sdkInfo.appid = info.appid
		sdkInfo.code = info.code
		sdkInfo.token = info.token
		sdkInfo.access_token = info.access_token

		if info.authinfo then
			sdkInfo.token = info.authinfo.token
		elseif info.Passwd then
			sdkInfo.Passwd = tostring(info.Passwd)
		elseif info.question then
			sdkInfo.question_key = tostring(info.question[1])
			local value = tostring(info.question[2])
			sdkInfo.question_value = value

			if not info.bEnryptPw then
				sdkInfo.question_value = g_recharge_md5_related.md5sum(value, #value)
			end
		end

		self:LLog("sdkv2_get_login_infos:sdkInfo", sdkInfo)

		return sdkInfo
	end,
	sdkv2_bind = function (self, info)
		self:LLog("sdkv2_bind info", info)

		if not info then
			self:oplog_login_error("", "sdkv2_bind", "", "info is nil")

			return ErrorCode.FAILED, "参数错误"
		end

		local code, sdkInfo = self:sdkv2_get_sdkInfo()

		if code ~= ErrorCode.OK then
			local error_report = " sdkv2_get_sdkInfo error code" .. (code or "")

			self:oplog_login_error(info.Uin or "", "sdkv2_bind", error_report, "sdkv2_get_sdkInfo return not ok")

			return code, "获取渠道信息错误"
		end

		sdkInfo.uin = tonumber(info.Uin)

		self:sdkv2_get_login_infos(sdkInfo, info)

		local ret = self:http_login("login", "sdkv2_bind", sdkInfo)

		self:LLog("sdkv2_bind ret", ret)

		if not ret then
			self:oplog_login_error(sdkInfo.uin, "sdkv2_bind", "sdkv2_bind return nil")

			return ErrorCode.FAILED, "绑定失败"
		end

		if ret.code ~= ErrorCode.OK then
			local error_report = "sdkv2_bind error code:" .. (tostring(ret.code) or "") .. ",msg:" .. (tostring(ret.msg) or "")

			self:oplog_login_error(sdkInfo.uin, "sdkv2_bind", error_report, sdkInfo)
		end

		return ret.code, ret.msg, ret.data
	end,
	sdkv2_query = function (self)
		local code, sdkInfo = self:sdkv2_get_sdkInfo()

		if code ~= ErrorCode.OK then
			print("sdkv2_query", code, "获取渠道信息失败。")

			local channel_auth_info = RealNameModule:GetChannelAuthorInfo()

			self:oplog_login_error("", "sdkv2_query", table2json(channel_auth_info) or "", "sdkv2_get_sdkInfo return not ok")

			return code
		end

		local ret = self:http_login("login", "sdkv2_query", sdkInfo)

		print("sdkv2_query123", ret)

		if not ret then
			self:oplog_login_error("", "sdkv2_query", "sdkv2_query return not ok", {
				sdkInfo = sdkInfo,
				ret = ret
			})

			return ErrorCode.FAILED, "查询失败"
		end

		return ret.code, ret.msg, ret.data
	end,
	sdkv2_query_uins = function (self, uins)
		local szUins = ""

		for i, uin in ipairs(uins) do
			if szUins ~= "" then
				szUins = szUins .. "|" .. uin
			else
				szUins = "" .. uin
			end
		end

		local code, sdkInfo = self:sdkv2_get_sdkInfo()

		if code ~= ErrorCode.OK then
			return code, "获取渠道信息失败"
		end

		sdkInfo.uins = szUins
		local ret = self:http_login("login", "sdkv2_query_uins", sdkInfo)

		print("sdkv2_query_uins", ret)

		if not ret then
			return ErrorCode.FAILED, "查询失败"
		end

		local data = {}

		if ret.data and type(ret.data) == "table" then
			for i, item in pairs(ret.data) do
				data[item.uin] = item
			end
		end

		return ret.code, ret.msg, data
	end,
	sdkv2_get_nickname_info = function (self, uin)
		if not uin then
			return {}
		end

		local para = {
			uin = uin
		}

		print("sdkv2_get_nickname_info", para)

		local ret = self:http_login("login", "query_nickname_and_iconurl_cli", para)

		print("sdkv2_get_nickname_info", ret)

		return ret
	end,
	LLog = function (self, key, ...)
		LoginManager:Log(key, ...)
	end,
	sdkv2_convert_flag = function (self, status)
		local result = {}

		if type(status) == "table" then
			for k, v in pairs(status) do
				if k ~= "status" then
					result[k] = v
				elseif type(v) == "number" then
					if v == 1 then
						result.bindCur = true
					elseif v == 2 then
						result.bindOther = true
					end
				end
			end
		end

		self:LLog("sdkv2_convert_flag status:", status, result)

		return result
	end,
	get_last_login_time = function (self, uin)
		if not uin then
			return ErrorCode.FAILED
		end

		local para = {
			Uin = uin
		}

		print("get_last_login_time", para)

		local ret = self:http_login("login", "sdkv2_get_last_login_time", para)

		print("get_last_login_time", ret)

		if not ret or not ret.code then
			return ErrorCode.FAILED, 0
		end

		return ret.code, ret.lastlogintime
	end,
	change_phone_send_verify_code_unbind_old = function (self)
		local code1, code2 = self:remote_call("baseinfo", "change_phone_send_verify_code_unbind_old")

		return code2
	end,
	change_phone_send_verify_code_bind_new = function (self, phonenum_new)
		local code1, code2 = self:remote_call("baseinfo", "change_phone_send_verify_code_bind_new", phonenum_new)

		return code2
	end,
	change_phone_verify_code = function (self, phonenum, verify_code)
		return self:remote_call("baseinfo", "change_phone_verify_code", phonenum, verify_code)
	end,
	bind_phone_new = function (self, phonenum, verifycode)
		local code = self:remote_call("baseinfo", "bind_phone_new", phonenum, verifycode)

		return code
	end,
	change_bind_phone = function (self, verify_code_old, phonenum_new, verify_code_new)
		local code = self:remote_call("baseinfo", "change_bind_phone", verify_code_old, phonenum_new, verify_code_new)

		return code
	end,
	email_bind_status_check = function (self, email)
		local code1, result1 = self:email_bind_uin_check(email)

		if ErrorCode.PRECHECK_EMAIL_HAS_ALREADY_BEAN_BOUND == result1 then
			local code2, result2 = self:email_bind_unique_check(email)

			if result2 == ErrorCode.FAILED then
				return ErrorCode.PRECHECK_EMAIL_NOT_BOUND
			end

			return result2
		else
			return result1
		end
	end,
	email_bind_uin_check = function (self, email)
		return self:remote_call("baseinfo", "email_bind_uin_check", email)
	end,
	email_bind_unique_check = function (self, email)
		return self:remote_call("baseinfo", "email_bind_unique_check", email)
	end,
	change_email_send_verify_code_unbind_old = function (self)
		local code1, code2 = self:remote_call("baseinfo", "change_email_send_verify_code_unbind_old")

		return code2
	end,
	change_email_send_verify_code_bind_new = function (self, email_new)
		local code1, code2 = self:remote_call("baseinfo", "change_email_send_verify_code_bind_new", email_new)

		return code2
	end,
	change_email_verify_code = function (self, email, verify_code)
		return self:remote_call("baseinfo", "change_email_verify_code", email, verify_code)
	end,
	bind_email_new = function (self, email, verifycode)
		local code = self:remote_call("baseinfo", "bind_email_new", email, verifycode)

		return code
	end,
	change_bind_email = function (self, verify_code_old, email_new, verify_code_new)
		local code = self:remote_call("baseinfo", "change_bind_email", verify_code_old, email_new, verify_code_new)

		return code
	end,
	requestMobileCodeResetPassword = function (self, phonenum, uin)
		local code, binduin = self:http_rpc("passwd", "smsreset", {
			phonenum = phonenum,
			lang = get_game_lang and get_game_lang() or 0
		})

		return code, binduin
	end,
	checkResetPasswordCode = function (self, phonenum, verify_code, uin)
		local code = self:http_rpc("passwd", "smsverify", {
			phonenum = phonenum,
			code = verify_code,
			lang = get_game_lang and get_game_lang() or nil
		})

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		if code == ErrorCode.OK then
			return true
		else
			return false
		end
	end,
	passwd_by_code_send = function (self, phone_or_email, function_type)
		return self:http_rpc("passwd", "passwd_by_code_send", {
			phone_or_email = phone_or_email,
			lang = get_game_lang and get_game_lang() or nil,
			function_type = function_type
		})
	end,
	passwd_by_code_verify = function (self, phone_or_email, verify_code, function_type)
		local login_uin = self.account and self.account.Uin or 0

		return self:http_rpc("passwd", "passwd_by_code_verify", {
			function_type,
			phone_or_email = phone_or_email,
			verify_code = verify_code,
			login_uin = login_uin
		})
	end,
	passwd_by_code = function (self, uin, phone_or_email, verify_code, passwd, key, value)
		local login_uin = self.account and self.account.Uin or 0
		local code = self:http_rpc("passwd", "passwd_by_code", {
			login_uin = login_uin,
			Uin = uin,
			phone_or_email = phone_or_email,
			verify_code = verify_code,
			passwd = passwd or "",
			key = key or "",
			value = value or ""
		})

		return code
	end,
	acc_set_login_safeverify = function (self, bFlag)
		print("acc_set_login_safeverify", bFlag)

		if self:client_ready() then
			self:setloginsafeverify(bFlag)
		end
	end,
	acc_set_deviceID = function (self, deviceId)
		print("acc_set_deviceID", deviceId)

		if self:client_ready() then
			self:setDeviceID(deviceId)
		end
	end,
	acc_send_common_verify_code = function (self, phone_or_email, params)
		print("acc_send_common_verify_code", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "send_sms", params or {}, true)
		else
			return self:http_rpc("email", "send_code", params or {}, true)
		end
	end,
	acc_passwd_by_code_for_l_tag = function (self, phone_or_email, params)
		print("acc_passwd_by_code_for_l_tag", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "l_passwd", params or {}, true)
		end
	end,
	acc_passwd_by_code_for_v_tag = function (self, phone_or_email, params)
		print("acc_passwd_by_code_for_v_tag", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "v_passwd", params or {}, true)
		end
	end,
	acc_bind_by_code_for_v_tag = function (self, phone_or_email, params)
		print("acc_bind_by_code_for_v_tag", phone_or_email, params)

		if phone_or_email then
			params.token = self.conn and self.conn.token

			return self:http_rpc("phone", "v_bind", params or {}, true)
		end
	end,
	acc_unbind_by_code_for_v_tag = function (self, phone_or_email, params)
		print("acc_unbind_by_code_for_v_tag", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "v_unbind", params or {}, true)
		end
	end,
	acc_query_by_code = function (self, phone_or_email, params)
		print("acc_query_by_code", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "find", params or {}, true)
		end
	end,
	acc_exchange_by_code_unbind = function (self, phone_or_email, params)
		print("acc_exchange_by_code_unbind", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "exchange_old", params or {}, true)
		end
	end,
	acc_exchange_by_code_bind = function (self, phone_or_email, params)
		print("acc_exchange_by_code_bind", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "exchange", params or {}, true)
		end
	end,
	acc_find_by_code = function (self, phone_or_email, params)
		print("acc_find_by_code", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "getbackuin", params or {}, true)
		end
	end,
	acc_verify_code = function (self, phone_or_email, params)
		print("acc_verify_code", phone_or_email, params)

		if phone_or_email then
			return self:http_rpc("phone", "ver_sms", params or {}, true)
		else
			return self:http_rpc("email", "ver_code", params or {}, true)
		end
	end,
	lg_get_rebot_infos = function (self, params)
		print("lg_get_rebot_infos", params)

		return self:http_rpc("man_machine", "session", params, true)
	end,
	lg_refresh_rebot_infos = function (self, params)
		print("lg_refresh_rebot_infos", params)

		return self:http_rpc("man_machine", "refresh", params, true)
	end,
	lg_query_rebot_infos = function (self, params)
		print("lg_query_rebot_infos", params)

		return self:http_rpc("man_machine", "bind_query", params, true)
	end,
	lg_rebot_data_save = function (self, params, resp)
		params = params or {}
		local loginType = params.loginType
		resp = resp or {}

		if loginType == LoginManager.WAY_QQ or loginType == LoginManager.WAY_WECHAT then
			self:save_to_file("current", {
				Uin = resp.baseinfo and resp.baseinfo.Uin,
				authinfo = resp.authinfo
			})
		elseif params.Password then
			self:save_to_file("current", {
				Uin = resp.baseinfo and resp.baseinfo.Uin,
				Passwd = params.Password
			})
		elseif params.AccountName then
			self:save_to_file("current", {
				Uin = resp.baseinfo and resp.baseinfo.Uin,
				AccountName = params.AccountName
			})
		elseif params.question_key then
			self:save_to_file("current", {
				Uin = resp.baseinfo and resp.baseinfo.Uin,
				question = {
					params.question_key,
					params.question_value
				}
			})
		elseif params.phone then
			self:save_to_file("current", {
				Uin = resp.baseinfo and resp.baseinfo.Uin,
				phone = params.phone,
				authinfo = resp.authinfo
			})
		end
	end,
	lg_rebot_login = function (self, params)
		print("lg_rebot_login", params)

		local code, resp = self:http_rpc("man_machine", "login", params, true)

		return code, resp
	end,
	lg_man_machine = function (self, method, params, extra_param)
		print("lg_man_machine", method, params, extra_param)

		local code = ErrorCode.FAILED
		local resp = {}
		local ret = self:http_login("man_machine", method, params, true, extra_param)

		if type(ret) == "table" then
			code = ret.code

			if ret.code then
				ret.code = nil
			end

			resp = ret
		end

		code = AccountManager:code2num(code)

		return code, resp
	end,
	acc_query_write_off_type = function (self, params)
		print("acc_query_write_off_type", params)

		local infos = params or {}
		local account = self.account

		if not account then
			self:oplog_login_error("", "acc_query_write_off_type", "account is wrong")

			return ErrorCode.PRECHECK_ERROR
		end

		local conn = self.conn

		if not conn then
			self:oplog_login_error("", "acc_query_write_off_type", "conn is wrong")

			return ErrorCode.PRECHECK_ERROR
		end

		infos.uin = account.Uin
		infos.token = conn.token
		local ret = self:http_login("login", "query_write_off_type", infos)
		ret = ret or {}

		return ret.code or ErrorCode.FAILED, ret.data or {}, ret.msg
	end,
	acc_write_off_auth_new = function (self, params)
		print("acc_write_off_auth_new", params)

		local infos = params or {}
		local account = self.account

		if not account then
			self:oplog_login_error("", "acc_write_off_auth_new", "account is wrong")

			return ErrorCode.PRECHECK_ERROR
		end

		local conn = self.conn

		if not conn then
			self:oplog_login_error("", "write_off_auth_new", "conn is wrong")

			return ErrorCode.PRECHECK_ERROR
		end

		infos.uin = account.Uin
		infos.token = conn.token
		local ret = self:http_login("login", "write_off_auth_new", infos)
		ret = ret or {}

		return ret.code or ErrorCode.FAILED, ret.data or {}, ret.msg
	end,
	acc_confirm_write_off = function (self, params)
		print("acc_confirm_write_off", params)

		local infos = params or {}
		local account = self.account

		if not account then
			self:oplog_login_error("", "acc_confirm_write_off", "account is wrong")

			return ErrorCode.PRECHECK_ERROR
		end

		local conn = self.conn

		if not conn then
			self:oplog_login_error("", "acc_confirm_write_off", "conn is wrong")

			return ErrorCode.PRECHECK_ERROR
		end

		infos.uin = account.Uin
		infos.token = conn.token
		local ret = self:http_login("login", "confirm_write_off", infos)
		ret = ret or {}

		return ret.code or ErrorCode.FAILED, ret.data or {}, ret.msg
	end,
	acc_query_cancle_write_off = function (self, params)
		print("acc_query_cancle_write_off", params)

		local infos = params or {}
		local ret = self:http_login("login", "query_cancle_write_off", infos)
		ret = ret or {}

		return ret.code or ErrorCode.FAILED, ret.data or {}, ret.msg
	end,
	acc_cancle_write_off = function (self, params)
		print("acc_cancle_write_off", params)

		local infos = params or {}
		local ret = self:http_login("login", "cancle_write_off", infos)
		ret = ret or {}

		return ret.code or ErrorCode.FAILED, ret.data or {}, ret.msg
	end,
	acc_keychain_history = function (self, cond)
		local history = {}
		local all_accounts_json = GetClientInfo():getAllAccountInfos()

		if all_accounts_json then
			local ok, json = pcall(JSON.decode, JSON, all_accounts_json)

			if ok and type(json) == "table" then
				local url = LuaInterface:geturl()

				for i, v in ipairs(json) do
					if type(v) == "string" then
						local ret, datas = pcall(JSON.decode, JSON, v)

						if ret and type(datas) == "table" and url == datas.url and (type(cond) == "boolean" and cond or type(cond) == "function" and cond(datas.data)) then
							history[#history + 1] = datas.data
						end
					end
				end
			end
		end

		print("acc_keychain_history", cond, history)

		return history
	end,
	force_quit_game = function (self, code)
		local bNeedQuit = false

		if not self:client_ready() then
			return bNeedQuit
		end

		bNeedQuit = true
		local bModifyQuit = ns_version and ns_version.new_account_manager and ns_version.new_account_manager.pass_modify_switch
		bNeedQuit = bNeedQuit and bModifyQuit

		if NewAccountService.SvrNotifyLogout then
			NewAccountService:SvrNotifyLogout(code)
		elseif code and code == ErrorCode.FORCE_QUIT_CODE_PASS_MODIFY and bModifyQuit and not GetInst("MiniUIManager"):IsShown("MessageBoxFrame2AutoGen") then
			MessageBoxFrame2:Open(6, GetS(120198), ns_version.new_account_manager and ns_version.new_account_manager.pass_modify_quit_tips or "", function (btn)
				if GetClientInfo():isPC() then
					GameExit()
				else
					LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
					threadpool:delay(1, function ()
						OpenAlertFailLoginPopDlg(LoginManager.WAY_PASSWD, {
							LoginManager.WAY_PASSWD,
							LoginManager.WAY_QUESTION
						}, {
							mini = AccountManager:getUin()
						})
					end)
				end
			end)
		end

		return bNeedQuit
	end,
	passwd_set = function (self, passwd, key, value)
		return self:remote_call("baseinfo", "passwd_set", passwd, key, value)
	end,
	send_email_verify_code = function (self, email)
		local code, binduin = self:http_rpc("passwd", "emailreset", {
			email = email,
			lang = get_game_lang and get_game_lang() or nil
		})

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		return code, binduin
	end,
	check_email_verify_code = function (self, email, verify_code)
		local code = self:http_rpc("passwd", "emailverify", {
			email = email,
			code = verify_code,
			lang = get_game_lang and get_game_lang() or nil
		})

		if code == ErrorCode.OK then
			self:setDeviceID(GetClientInfo():getDeviceID())
		end

		if code == ErrorCode.OK then
			return true
		else
			return false
		end
	end,
	requestCheckNickname = function (self, newname)
		return true
	end,
	requestModifyRole = function (self, name, model, skinmodel, createNewOw, birthday, forfree, useChangeCard, params)
		local account = self.account

		if not account then
			return false, ErrorCode.NOT_EXIST
		end

		local Account = account.Account
		local leveldb = account.leveldb
		local RoleInfo = Account.RoleInfo
		local RoleSkinID = leveldb.RoleSkinID or RoleInfo.SkinID or 0
		local Model = RoleInfo and RoleInfo.Model

		if not Model or Model == 0 then
			Model = 2
		end

		local custom_nickname_flag = params and params.custom_nickname_flag

		if createNewOw == false and skinmodel == RoleSkinID and model == Model then
			print("改名")

			local code = self:remote_call("baseinfo", "rename", name, forfree, useChangeCard)

			if code == ErrorCode.OK then
				LoginManager:UpdateLoginInfo()
			end

			return code == ErrorCode.OK, code
		else
			ShowNoTransparentLoadLoop()

			if account.Uin <= 1 then
				self:save_to_file("tmp1", account.Account.RoleInfo)
			end

			local req_params = {}

			if custom_nickname_flag then
				req_params.custom_nickname = name
			else
				req_params.system_nickname = name
			end

			local code, infos = self:remote_call("baseinfo", "set_name", req_params)

			print("创建角色 set_name ", req_params, code, infos)

			if code == ErrorCode.OK then
				account.birthday = birthday
				account.Account.RoleInfo = {
					NickName = name,
					Model = model,
					SkinID = skinmodel
				}

				account:OnAccountDirty()
				LoginManager:UpdateLoginInfo()

				code = self:data_update(true)
			end

			if code ~= ErrorCode.OK then
				AccountManager:delete_file("tmp1")
				HideNoTransparentLoadLoop()

				return false, code
			end

			self:check_reg_realname_dialog_box()
			HideNoTransparentLoadLoop()
			self:oplog_login_check(1, 1)

			local bFlag = false

			if GetClientInfo() and GetClientInfo().clientVersion and GetClientInfo().clientVersionFromStr then
				local version_base_ = GetClientInfo():clientVersionFromStr("1.0.5")
				local version_now_ = GetClientInfo():GetClientVersion()

				if version_base_ <= version_now_ then
					bFlag = true
				end
			end

			if bFlag then
				if NewbieGuideManager and NewbieGuideManager:IsSwitch() then
					self.origin:createNewbieWorld(model, NewbieWorldId2)
				else
					self.origin:createNewbieWorld(model)
				end
			else
				self.origin:createNewbieWorld(model)
			end

			return true, code
		end
	end,
	notifyServerAddNickModify = function (self, minicoin)
		return 0
	end,
	notifyServerConsumeMiniCoin = function (self, star_num)
		local code = self:remote_call("shopsvr", "exchange_star", star_num)

		if code ~= ErrorCode.OK then
			-- Nothing
		end

		return code
	end,
	convertStarRemoteCallback = function (self, ret)
		MiniLog("lsj call convertStarCallback", ret)
		MiniLog(FormatPrint(2, content, "ret"))

		local uin = AccountManager:getUin()

		if ret and ret.ret == 0 and ret.data and ret.data.token then
			MiniLog("lsj call convertStarCallback2", ret.data.token)
			SandboxLuaMsg.sendToHost(_G.SANDBOX_LUAMSG_NAME.GLOBAL.COIN_CONVERT_STAR_TOHOST, {
				order_id = ret.data.token
			})

			return true
		end

		self:onConvertStartRet(false)
		MiniLog("[ERROR]convertStarCallback failed! ", ret)

		return false
	end,
	onConvertStartRet = function (self, success)
		MiniLog("lsj call onConvertStartRet", success)
		MiniLog("call onConvertStartRet", success)

		self.convertStaring = false

		if self.convertStar_UserCallback then
			local fun = self.convertStar_UserCallback
			self.convertStar_UserCallback = nil

			pcall(fun, success)
		end
	end,
	coinConvertStar = function (self, coin_num, callback)
		if self.convertStaring then
			return false
		end

		self.convertStaring = true
		self.convertStar_UserCallback = callback

		if AccountManager:getMultiPlayer() == 0 or IsRoomOwner() then
			local success = self:notifyServerConsumeMiniCoin(coin_num)

			if success == 0 then
				ClientCurGame:getMainPlayer():starConvert(coin_num * MiniCoin_Star_Ratio)
			end

			self:onConvertStartRet(success == 0)

			return success == 0
		else
			local url = g_http_root .. "miniw/mall?"
			local reqParams = {
				get_type = 2,
				act = "coin_convert_star",
				item_id = 14001,
				item_num = coin_num
			}
			local paramStr, md5 = http_getParamMD5(reqParams)
			url = table.concat({
				url,
				paramStr,
				"&md5=",
				md5
			})

			MiniLog("lsj coinConvertStar call remote", url)
			MiniLog("coinConvertStar call remote", url)
			ns_http.func.rpc(url, function (ret)
				self:convertStarRemoteCallback(ret)
			end, nil, nil, true, true)

			return true
		end

		self:onConvertStartRet(false)

		return false
	end,
	notifyServerActivationCodeReward = function (self, apiid, cdkey)
		local code, cdkeytype, list = self:remote_call("shopsvr", "cdkey", cdkey)

		if code == ErrorCode.OK then
			local ret = {}
			local result = self:ctxpop("cdkey.result")

			if result then
				local e = LuaInterface:postUseStashPrepare()

				for i, v in ipairs(result) do
					LuaInterface:postUseStashSetItem(e, v[1], v[2])
				end

				LuaInterface:postUseStashExec(e)

				ret.itemlist = result
			end

			local skinlist = self:ctxpop("cdkey.skinlist")

			if skinlist then
				ret.skinlist = skinlist
			end

			return code, ret
		else
			return code
		end
	end,
	notifyServerSignReward = function (self)
		local code = self:remote_call("shopsvr", "login_reward")

		if code == ErrorCode.OK then
			self:trigger("postSignInChange")

			return 0
		else
			return -1
		end
	end,
	requestShareGiftInfo = function (self)
		local code, info = self:remote_call("shopsvr", "share_info")

		if code == ErrorCode.OK then
			if LuaInterface:getApiId() == 2 then
				info.url = info.url .. "2/"
			end

			self.eventcache.postShareGiftInfo = info

			self:trigger("postShareGiftInfo", 0, info.DayShareTimes, info.DayGetTimes, info.WeekGetTimes, info.MiniBean, info.Multiple, info.DayGetMax)

			return true
		else
			ShowLoadLoopFrame(false)

			return false
		end
	end,
	requestShareGift = function (self)
		local code = self:remote_call("shopsvr", "share_gift")

		if code ~= ErrorCode.OK then
			-- Nothing
		end

		return code
	end,
	notifyServerOpItemReclaim = function (self, itemid, itemnum)
		return self:remote_call("shopsvr", "item_reclaim", itemid, itemnum)
	end,
	notifyServerOpUnlockAward = function (self, groupid)
		self:msgbox(GetS(158))

		return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
	end,
	notifyServerUnlockRole = function (self, model, lv)
		print("激活天赋", model, lv)

		return self:remote_call("shopsvr", "role_upgrade", model, lv)
	end,
	notifyServerUnlockHorse = function (self, riderid, lv)
		local ret, info = self:remote_call("shopsvr", "rider_upgrade_v2", riderid)

		if ret == ErrorCode.OK then
			self:data_update()
			self:trigger("postPokedexChange")
			uploadHorseInfo()
		end

		return ret, info
	end,
	notifyServerSetHorseCommon = function (self, riderid, status)
		return self:remote_call("shopsvr", "set_rider_frequently_use_status", riderid, status)
	end,
	notifyServerConverOldRider = function (self)
		local ret, info = self:remote_call("shopsvr", "auto_convert_old_rider")

		if ret == ErrorCode.OK then
			self:data_update()
		end

		return ret, info
	end,
	notifyServerConvertOldRiderFragment = function (self)
		local ret, info = self:remote_call("shopsvr", "auto_convert_old_rider_fragment")

		if ret == ErrorCode.OK then
			self:data_update()
			self:trigger("postPokedexChange")
		end

		return ret, info
	end,
	getServerHorseCommonData = function (self)
		local ret, data = self:remote_call("shopsvr", "get_rider_frequently_use_status")

		return ret, data
	end,
	notifyServerConvertHorse = function (self, itemids)
		return self:remote_call("shopsvr", "rider_convert", itemids)
	end,
	notifyServerBuySkin = function (self, skinid, buytype)
		return self:remote_call("shopsvr", "skin_buy", skinid, buytype + 1)
	end,
	notifyServerBuyItem = function (self, productid, cnt)
		local cfg = DefMgr:getStorePropByID(productid)
		cnt = cnt or 1

		return self:remote_call("shopsvr", "item_buy", cfg and cfg.ID or 0, cnt * (cfg and cfg.Num or 0))
	end,
	notifyServerBuyItemID = function (self, itemid, itemnum)
		return self:remote_call("shopsvr", "item_buy", itemid or 0, itemnum or 0)
	end,
	notifyServerBuyItemsCapacity = function (self)
		return self:remote_call("shopsvr", "items_capacity_buy")
	end,
	useRoleModel = function (self, roleid)
		return self:remote_call("shopsvr", "role_use", roleid)
	end,
	useRoleSkinModel = function (self, skinid)
		if skinid > 0 then
			return self:remote_call("shopsvr", "skin_use", skinid, self.now) == ErrorCode.OK
		elseif skinid == 0 then
			return self:remote_call("shopsvr", "skin_takeoff") == ErrorCode.OK
		else
			return false
		end
	end,
	send_skin_present = function (self, target_Uin, itemidlist, greeting, send_type)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(itemidlist) ~= "table" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(greeting) ~= "string" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if send_type == nil then
			send_type = 0
		end

		if type(send_type) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "send_skin_present", target_Uin, itemidlist, greeting, send_type)
	end,
	send_avatar_present = function (self, target_Uin, itemidlist, greeting)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(itemidlist) ~= "table" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(greeting) ~= "string" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "send_avatar_present", target_Uin, itemidlist, greeting)
	end,
	send_item_present = function (self, target_Uin, itemidlist, greeting)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(itemidlist) ~= "table" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(greeting) ~= "string" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "send_item_present", target_Uin, itemidlist, greeting)
	end,
	check_can_send_present = function (self, target_Uin, itemidlist, is_tiem, greeting, send_type)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(itemidlist) ~= "table" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(is_tiem) ~= "boolean" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if type(greeting) ~= "string" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		if send_type == nil then
			send_type = 0
		end

		if type(send_type) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "check_can_send_present", target_Uin, itemidlist, is_tiem, greeting, send_type)
	end,
	other_query_skin_all = function (self, target_Uin)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "other_query_skin_all", target_Uin)
	end,
	other_query_avatar_all = function (self, target_Uin)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "other_query_avatar_all", target_Uin)
	end,
	other_query_rider_all = function (self, target_Uin)
		if type(target_Uin) ~= "number" then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		return self:remote_call("shopsvr", "other_query_rider_all", target_Uin)
	end,
	notifyServerUseAccountItem = function (self, itemid, itemnum)
		local code = self:remote_call("shopsvr", "item_use", itemid, itemnum or 1)

		if code == ErrorCode.OK then
			local list = self.account:ctxpop("item_use.list")

			print("item_use list = ", list)

			local info = {}

			if list then
				for i, v in ipairs(list) do
					table.insert(info, {
						id = v[1],
						num = v[2]
					})
				end
			end

			local ItemUseSkinDef = self.account.ItemUseSkinDef
			local cfg = ItemUseSkinDef[itemid]

			return code, info, cfg
		else
			return code
		end
	end,
	notifyServerUnlockItem = function (self, chipid, unlockid)
		self:msgbox(GetS(158))

		return ErrorCode.PRECHECK_SMS_VERSION_TOO_LOW
	end,
	notifyServerConsumeItem = function (self, itemid, num)
		return self:remote_call("shopsvr", "item_consume", itemid, num)
	end,
	notifyServerConsumeItem_manor = function (self, itemid, num)
		return self:remote_call("shopsvr", "item_consume_manor", itemid, num)
	end,
	notifyServerConvertMiniBean = function (self, minicoin)
		local code = self:remote_call("shopsvr", "exchange", minicoin)

		if code ~= ErrorCode.OK then
			ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)

			return 1
		else
			return 0
		end
	end,
	notifyServerConvertMiniItem = function (self, minicoin, itemid)
		local code, ismail = self:remote_call("shopsvr", "exchange_item", minicoin, itemid)

		if code ~= ErrorCode.OK then
			ShowGameTipsWithoutFilter(GetS(t_ErrorCodeToString[code]), 3)

			return 1
		else
			return 0, ismail
		end
	end,
	notifyServerReceiveAward = function (self, taskid, randomidx)
		local code, itemmap, avatar_skin_to_minibean = self:remote_call("shopsvr", "task_reward", taskid, randomidx or -1)

		if code == ErrorCode.OK then
			return 0, avatar_skin_to_minibean, itemmap
		else
			return -1
		end
	end,
	recharge_retry = function (self)
		print("========== recharge_retry ========")

		local account = self.account
		local Uin = account and account.Uin

		if not Uin then
			return ErrorCode.FAILED, "未登录成功吧"
		end

		local minicoin = account.MiniCoin

		print("========== recharge_retry ======== ", minicoin)

		local filename = "recharge_" .. Uin
		local orderhistroy = self:load_from_file(filename)

		print("======== recharge_retry 重试订单 ========== ", orderhistroy)

		if orderhistroy and #orderhistroy > 0 then
			local l = {}

			for i, one in ipairs(orderhistroy) do
				if i <= 3 then
					local code = self:remote_call("shopsvr", "order_notify", unpack(one.args))

					if code == ErrorCode.OK or code == ErrorCode.PRECHECK_ORDER_CANCEL then
						self:data_update()
						print("充值重试返回 ", ErrorCode[code])
					elseif code == ErrorCode.PAY_VERIFY_FAILED then
						print("校验失败,无效的订单")
					else
						one.count = (one.count or 0) + 1

						if one.count <= 10 then
							table.insert(l, one)
						end
					end
				else
					table.insert(l, one)
				end
			end

			self:save_to_file(filename, l)
		end

		return ErrorCode.OK, account.MiniCoin - minicoin
	end,
	loadOrderInfo = function (self, orderID, minicoins, productid, tradeid, apiid)
		local ts = self.now
		local tk = gFunc_getmd5(string.format("%s%d_%s", orderID, ts, "01c13e71f95db3bf60483a98a23d5327"))
		local url = string.format("https://notice.mini1.cn/query_order.php?orderID=%s&time=%d&token=%s", orderID, ts, tk)

		ns_http.func.rpc_string_raw(url, function (retstr, data)
			local self = data.self
			local ret = JSON:decode(retstr)
			self.account.order_info = ret

			self:notifyServerCharge(data.minicoins, data.productid, data.tradeid, data.apiid)
		end, {
			self = self,
			minicoins = minicoins,
			productid = productid,
			tradeid = tradeid,
			apiid = apiid
		})
	end,
	notifyServerCharge = function (self, minicoins, productid, tradeid, apiid)
		local account = self.account
		local order_info = account.order_info
		local client_version = LuaInterface:getCltVersion()

		if apiid == 7 and client_version >= 65538 then
			local t_tradeid = tradeid
			local t_list = utils.split(tradeid, "_")

			if #t_list == 2 then
				local orderID = t_list[1]
				tradeid = t_list[2]

				if order_info == nil then
					self:loadOrderInfo(orderID, minicoins, productid, t_tradeid, apiid)

					return 0
				end
			end
		end

		if not order_info then
			return -1
		end

		local order = order_info.order

		if not order then
			return -1
		end

		print("XXXXXXXXXX", SdkManager.getApplePayTransactId)
		print("XXXXXXXXX notifyServerCharge XXXXXXX", minicoins, productid, tradeid, apiid, SdkManager.getApplePayTransactId and SdkManager:getApplePayTransactId() or "")

		local order_notify_params = {
			order.OrderID,
			SdkManager.getApplePayTransactId and SdkManager:getApplePayTransactId() or "",
			productid or "",
			tradeid or "",
			apiid or 0,
			client_version
		}
		order_info.notify_params = order_notify_params
		local Uin = account.Uin
		local filename = "recharge_" .. Uin
		local orderhistroy = self:load_from_file(filename) or {}

		if table.getn(orderhistroy) >= 100 then
			table.remove(orderhistroy, 1)
		end

		local ok = false

		for i, v in ipairs(orderhistroy) do
			if v.args and v.args[1] == order.OrderID then
				ok = true
			end
		end

		if ok == false then
			table.insert(orderhistroy, {
				count = 0,
				args = order_notify_params,
				code = ErrorCode.FAILED,
				ts = threadpool:now()
			})
		end

		self:save_to_file(filename, orderhistroy)
		ShowNoTransparentLoadLoop()

		local code = self:remote_call("shopsvr", "order_notify", unpack(order_notify_params))

		HideNoTransparentLoadLoop()

		if code == ErrorCode.PRECHECK_ORDER_CANCEL or code == ErrorCode.PAY_VERIFY_FAILED then
			local Uin = account.Uin
			local filename = "recharge_" .. Uin
			local orderhistroy = self:load_from_file(filename) or {}

			for i, v in ipairs(orderhistroy) do
				if v.args and v.args[1] == order.OrderID then
					table.remove(orderhistroy, i)

					break
				end
			end

			self:save_to_file(filename, orderhistroy)

			return code
		end

		if code ~= ErrorCode.OK then
			threadpool:wait(3)
			ShowNoTransparentLoadLoop()

			code = self:remote_call("shopsvr", "order_notify", unpack(order_notify_params))

			HideNoTransparentLoadLoop()
		end

		if code == ErrorCode.OK then
			self:trigger("postMiniCoinChange")

			account.order_info = nil

			threadpool:notify(client_M.recharge_event_id, ErrorCode.OK)

			local Uin = account.Uin
			local filename = "recharge_" .. Uin
			local orderhistroy = self:load_from_file(filename) or {}

			for i, v in ipairs(orderhistroy) do
				if v.args and v.args[1] == order.OrderID then
					table.remove(orderhistroy, i)

					break
				end
			end

			self:save_to_file(filename, orderhistroy)
		end

		if code == ErrorCode.PRECHECK_GET_SHOP_ORDER_FROM_MYSQL_FAILED then
			code = 12
		elseif code == ErrorCode.PRECHECK_SHOP_ORDER_NOT_COMPLETE then
			if apiid == 45 then
				account.order_info = nil

				return 0
			end

			code = 11
		end

		return code
	end,
	notifyServerClearCharge = function (self)
		local account = self.account

		if account then
			account.order_info = nil
		end
	end,
	notifyServerOpChestTreeGift = function (self, type)
		return ErrorCode.OK
	end,
	buddyNotifyChat = function (self, msg, Uin)
		local now = self.now

		self.cluster.buddysvr.speekto(Uin, now, msg)
		BuddyManager:addOfflineChat(Uin, self.Uin, now, msg)
	end,
	addMyChat = function (self, Uin, msg)
		if Uin == 1000 then
			local now = self.now

			BuddyManager:addOfflineChat(Uin, Uin, now, msg)
		end
	end,
	requestFeedBackReq = function (self, msg, qq, phone)
		local code = self:remote_call("baseinfo", "bug", msg, qq, phone)

		if code ~= ErrorCode.OK then
			-- Nothing
		end

		return code == ErrorCode.OK
	end,
	requestMailItems = function (self, mailid)
		local code, list, reallist = self:remote_call("shopsvr", "mail_items", mailid)

		return code, reallist or list
	end,
	bindcheck = function (self, AccountName)
		local code = self:http_rpc("bind", "check", {
			ApiID = LuaInterface:getApiId(),
			AccountName = AccountName
		})

		return code == ErrorCode.OK
	end,
	check_chest_bonus = function (self)
		local account = self.account

		return account and account:check_chest_bonus() or false
	end,
	chest_bonus = function (self)
		local code = self:remote_call("homesvr", "chest_bonus", cdkey)

		if code == ErrorCode.OK then
			local result = self:ctxpop("chest.bonus")

			if result then
				local const = self.const
				local m = {
					ItemList = {},
					Type = const.CHEST_TYPE_GOLDEN
				}

				for i, v in ipairs(result) do
					table.insert(m.ItemList, {
						ItemID = v[1],
						ItemNum = v[2]
					})
				end

				self.eventcache.postOpenChest = m

				self:trigger("postOpenChest", const.CHEST_OP_GIFT)

				if false then
					local e = LuaInterface:postUseStashPrepare()

					for i, v in ipairs(result) do
						LuaInterface:postUseStashSetItem(e, v[1], v[2])
					end

					LuaInterface:postUseStashExec(e)
				end
			end

			return code
		else
			return code
		end
	end,
	get_chest_baoxianginfo = function (self)
		return self.account and self.account:get_chest_baoxianginfo()
	end,
	get_chest_baoxiang_statics_id = function (self)
		local account = self.account

		return account and account:ctxpop("chest.baoxiang") or nil
	end,
	chest_lingqu_baoxiang = function (self)
		local code = self:remote_call("homesvr", "chest_lingqu_baoxiang")

		if code == ErrorCode.OK then
			return code
		else
			return code
		end
	end,
	get_chest_trader_statics_id = function (self)
		local account = self.account

		return account and account:ctxpop("chest.trader") or nil
	end,
	get_chest_trader_info = function (self)
		local account = self.account

		return account and account:get_chest_trader_info() or {
			ShowTime = 0,
			list = {}
		}
	end,
	get_chest_traderdef = function (self)
		local account = self.account

		return account and account:get_chest_traderdef() or nil
	end,
	chest_trader_buy = function (self, itemid, itemnum)
		return self:remote_call("homesvr", "chest_trader_buy", itemid, itemnum)
	end,
	get_homeharvestupdef = function (self)
		local account = self.account

		return account and account:get_homeharvestupdef()
	end,
	ad_position_info = function (self, position_id)
		position_id = tostring(position_id)
		local const = self.const
		local account = self.account

		if not account then
			print("======= ad_position_info ===== account is nil !!! ", position_id)

			return nil
		end

		local info = account:ad_info_by_position_id(position_id)

		if not info or not info.valid or info.valid ~= 1 then
			print("======= ad_position_info ===== valid ~= 1, info = ", info)

			return nil
		end

		local finish_count = info and info.finish and info.finish.count or 0

		if AccountManager:check_ad_version() then
			local platform_id = info and info.platform_id

			print("======= ad_position_info ===== client_M.already_init_ad_platform_map ", client_M.already_init_ad_platform_map)

			if not platform_id or not client_M.already_init_ad_platform_map[platform_id] then
				print("还没有初始化", position_id)

				return nil
			end
		elseif client_M.ad_init_flag == false then
			print("======= ad_position_info ===== client_M.ad_init_flag = false")

			return nil
		end

		return {
			position_id = position_id,
			platform_id = info and info.platform_id or nil,
			type = info and info.type or nil,
			finish = {
				count = finish_count,
				ts = info and info.finish and info.finish.ts or 0
			},
			show = {
				count = info and info.show and info.show.count or 0,
				ts = info and info.show and info.show.ts or 0
			},
			probability = info.probability or 0,
			num_total = info.num_total or 0,
			trigger_priority = info.trigger_priority,
			AD_URL = info.AD_URL,
			extra = delegate(function ()
				local bonus = info.bonus

				if bonus and tonumber(bonus.reward_num_add) then
					local ApiID = account.Account.ApiID
					local channel_id = bonus.channel_id or 0
					local reward_num_add = 0

					if type(channel_id) == "number" then
						if channel_id == 0 or channel_id == ApiID then
							reward_num_add = (bonus and bonus.reward_num_add or 0) * finish_count
						end
					elseif type(channel_id) == "string" then
						local utils = account.utils
						local list = utils.split(channel_id, ",")

						print("list ==== ", list, "bonus = ", bonus, " finish_count", finish_count)

						if list and #list > 0 then
							for i, v in ipairs(list) do
								if v == tostring(ApiID) then
									reward_num_add = (bonus and bonus.reward_num_add or 0) * finish_count

									break
								end
							end
						end
					end

					print("reward_num_add === ", reward_num_add)

					local reward_num = bonus.reward_num + reward_num_add
					local adsense_effect = bonus.adsense_effect

					if adsense_effect then
						if adsense_effect == 1 then
							return {
								type = 2,
								value = reward_num,
								condition = bonus.reward_try_times or 0,
								reward_id = bonus.reward_id or 0
							}
						elseif adsense_effect == 2 then
							if bonus.reward_name == "星星" then
								return {
									type = 1,
									value = reward_num,
									condition = bonus.reward_try_times or 0,
									reward_id = bonus.reward_id or 0
								}
							elseif bonus.reward_id == const.ITEM_ID_MINI_BEAN then
								return {
									type = 3,
									value = reward_num,
									condition = bonus.reward_try_times or 0,
									reward_id = bonus.reward_id or 0
								}
							end
						end
					end

					local position2type = {
						["105"] = 4,
						["2"] = 4,
						["3"] = 5,
						["4"] = 1,
						["5"] = 2,
						["6"] = 3,
						["7"] = 6
					}

					return {
						condition = 0,
						value = 0,
						type = position2type[position_id] or 0,
						reward_id = bonus and bonus.reward_id or 0
					}
				else
					return info and info.extra or {
						type = 0,
						condition = 0,
						value = 0,
						reward_id = bonus and bonus.reward_id or 0
					}
				end
			end),
			iscoding = account:ad_check_colding(position_id)
		}
	end,
	ad_position_info2 = function (self, position_id)
		position_id = tostring(position_id)
		local const = self.const
		local account = self.account

		if not account then
			print("======= ad_position_info ===== account is nil !!! ", position_id)

			return nil
		end

		local info = account:ad_info_by_position_id2(position_id)

		if not info then
			print("======= ad_position_info ===== valid ~= 1, info = ", info)

			return nil
		end

		local finish_count = info and info.finish and info.finish.count or 0

		if AccountManager:check_ad_version() then
			local platform_id = info and info.platform_id

			print("======= ad_position_info ===== client_M.already_init_ad_platform_map ", client_M.already_init_ad_platform_map)

			if not platform_id or not client_M.already_init_ad_platform_map[platform_id] then
				print("还没有初始化", position_id)

				return nil
			end
		elseif client_M.ad_init_flag == false then
			print("======= ad_position_info ===== client_M.ad_init_flag = false")

			return nil
		end

		return {
			position_id = position_id,
			platform_id = info and info.platform_id or nil,
			type = info and info.type or nil,
			finish = {
				count = finish_count,
				ts = info and info.finish and info.finish.ts or 0
			},
			show = {
				count = info and info.show and info.show.count or 0,
				ts = info and info.show and info.show.ts or 0
			},
			probability = info.probability or 0,
			num_total = info.num_total or 0,
			trigger_priority = info.trigger_priority,
			AD_URL = info.AD_URL,
			extra = delegate(function ()
				local bonus = info.bonus

				if bonus and tonumber(bonus.reward_num_add) then
					local ApiID = account.Account.ApiID
					local channel_id = bonus.channel_id or 0
					local reward_num_add = 0

					if type(channel_id) == "number" then
						if channel_id == 0 or channel_id == ApiID then
							reward_num_add = (bonus and bonus.reward_num_add or 0) * finish_count
						end
					elseif type(channel_id) == "string" then
						local utils = account.utils
						local list = utils.split(channel_id, ",")

						print("list ==== ", list, "bonus = ", bonus, " finish_count", finish_count)

						if list and #list > 0 then
							for i, v in ipairs(list) do
								if v == tostring(ApiID) then
									reward_num_add = (bonus and bonus.reward_num_add or 0) * finish_count

									break
								end
							end
						end
					end

					print("reward_num_add === ", reward_num_add)

					local reward_num = bonus.reward_num + reward_num_add
					local adsense_effect = bonus.adsense_effect

					if adsense_effect then
						if adsense_effect == 1 then
							return {
								type = 2,
								value = reward_num,
								condition = bonus.reward_try_times or 0,
								reward_id = bonus.reward_id or 0
							}
						elseif adsense_effect == 2 then
							if bonus.reward_name == "星星" then
								return {
									type = 1,
									value = reward_num,
									condition = bonus.reward_try_times or 0,
									reward_id = bonus.reward_id or 0
								}
							elseif bonus.reward_id == const.ITEM_ID_MINI_BEAN then
								return {
									type = 3,
									value = reward_num,
									condition = bonus.reward_try_times or 0,
									reward_id = bonus.reward_id or 0
								}
							end
						end
					end

					local position2type = {
						["105"] = 4,
						["2"] = 4,
						["3"] = 5,
						["4"] = 1,
						["5"] = 2,
						["6"] = 3,
						["7"] = 6
					}

					return {
						condition = 0,
						value = 0,
						type = position2type[position_id] or 0,
						reward_id = bonus and bonus.reward_id or 0
					}
				else
					return info and info.extra or {
						type = 0,
						condition = 0,
						value = 0,
						reward_id = bonus and bonus.reward_id or 0
					}
				end
			end),
			iscoding = account:ad_check_colding(position_id)
		}
	end,
	ad_show = function (self, position_id)
		position_id = tostring(position_id)

		print("广告展示, 位置 ", position_id)
		self.cluster.shopsvr.ad_show(position_id)
	end,
	ad_finish = function (self, position_id, other)
		threadpool:wait(0.01)

		position_id = tostring(position_id)
		local PlanID = self:GetCurGameBiddingPlanID()
		local gameSessionId = nil

		if get_game_session_id then
			gameSessionId = get_game_session_id()
		end

		if other == nil then
			other = {}
		end

		if type(other) == "table" then
			if PlanID then
				other.PlanID = PlanID
			end

			if gameSessionId then
				other.game_session_id = gameSessionId
			end
		end

		local result = {}
		local code = self:remote_call("shopsvr", "ad_finish", position_id, other or {}, {
			ApiID = LuaInterface:getApiId(),
			CltVersion = LuaInterface:getCltVersion(),
			platform_id = client_M.ad_platform_id
		})

		if code == ErrorCode.OK then
			result = self:ctxpop("ad.finish.itemlist")

			if result then
				local e = LuaInterface:postUseStashPrepare()

				for i, v in ipairs(result) do
					LuaInterface:postUseStashSetItem(e, v[1], v[2])
				end

				LuaInterface:postUseStashExec(e)
			end
		end

		if AccountManager:check_ad_version() then
			threadpool:notify("ad.info.update")
		elseif client_M.ad_platform_id and client_M.ad_platform_id > 0 then
			local first_req = self.account and self.account.is_ad_firstreq or false

			self:remote_call("shopsvr", "ad_info", {
				ApiID = LuaInterface:getApiId(),
				CltVersion = LuaInterface:getCltVersion(),
				platform_id = client_M.ad_platform_id,
				first_req = first_req
			})

			if self.account then
				self.account.is_ad_firstreq = false
			end
		end

		return code, result
	end,
	check_ad_version = function (self)
		local container = self.container
		local cfg = container and container.cfg
		local ad_version = cfg and cfg.ad_version or 0

		return ad_version == 1
	end,
	check_standalone = function (self)
		if self.container and self.container.cfg then
			return self.container.cfg.standalone or false
		end

		return false
	end,
	change_standalone = function (self, status)
		if self.container and self.container.cfg then
			self.container.cfg.standalone = status
		end
	end,
	ad_loop2 = function (self)
		local function nop()
		end

		local isTestEnv = utils.env == 1
		local log = (isTestEnv or _G.printflag) and function (...)
			print("ad_loop2", ...)
		end or nop
		local logfmt = (isTestEnv or _G.printflag) and function (...)
			print("ad_loop2", string.format(...))
		end or nop

		while true do
			if self:client_ready() then
				break
			end

			threadpool:wait(0.1)
		end

		local CltVersion = LuaInterface:getCltVersion()
		local ApiID = LuaInterface:getApiId()

		if not AccountManager:check_ad_version() then
			logfmt("不是广告版本: %s, %s", CltVersion, ApiID)

			return
		end

		if not GetClientInfo().InitAdvertisementsSDK or not GetClientInfo().AdvertisementsLoadStatus or not GetClientInfo().AdvertisementsPreLoad then
			logfmt("预加载广告版本不对: %s, %s", CltVersion, ApiID)

			return
		end

		local function ipairs_cond(array, pred)
			if not array or type(array) ~= "table" then
				return nop
			end

			if #array == 0 or type(pred) ~= "function" then
				return ipairs(array)
			end

			return coroutine.wrap(function ()
				for i, elem in ipairs(array) do
					if pred(elem) then
						coroutine.yield(i, elem)
					end
				end
			end)
		end

		local function valid_ad(elem)
			if not elem then
				return false
			end

			local platform_id = tonumber(elem.platform_id)

			if not platform_id or platform_id <= 0 then
				return false
			end

			local position_id = tonumber(elem.position_id)

			if not position_id or position_id == 0 or position_id == 9 then
				return false
			end

			local ad_type = tonumber(elem.type)

			if not ad_type or ad_type ~= 6 then
				return false
			end

			return true
		end

		local function ad_info_list(account)
			local list = {}
			local info = account and account.today and account.today:get("ad.position.info")

			if info then
				for k, v in pairs(info) do
					if type(v) == "table" and v.platform_id then
						table.insert(list, {
							position_id = k,
							platform_id = v.platform_id,
							type = v.type,
							cycling_range = v.cycling_range,
							cycling_range_count = v.cycling_range_count
						})
					end
				end
			end

			return list
		end

		local THREAD_EXIT_CODE = nil
		local inited_platforms_shared = {}
		local update_count_shared = 0

		local function newTerminateChecker()
			local current_update_count = update_count_shared

			return function (...)
				if current_update_count ~= update_count_shared then
					if select("#", ...) > 0 then
						logfmt(...)
					end

					return true
				end
			end
		end

		log("ad load start")

		while true do
			for _, config in ipairs_cond(ad_info_list(self.account), valid_ad) do
				local platform_id = tonumber(config.platform_id)
				local position_id = tonumber(config.position_id)
				local ad_type = tonumber(config.type)
				local cycling_range = tonumber(config.cycling_range) or 120
				local cycling_range_count = tonumber(config.cycling_range_count) or 1

				if cycling_range <= 0 then
					cycling_range = 0
				end

				if cycling_range_count <= 0 then
					cycling_range_count = math.huge or cycling_range_count
				end

				logfmt("<<== platform_id:%s, position_id:%s, ad_type:%s", platform_id, position_id, ad_type)
				logfmt("<<== cycling_range_count:%s, cycling_range:%s", cycling_range_count, cycling_range)
				threadpool:work(function ()
					local shouldTerminate = newTerminateChecker()

					if not inited_platforms_shared[platform_id] then
						for max_try = 1, 10 do
							if inited_platforms_shared[platform_id] then
								break
							elseif GetClientInfo():InitAdvertisementsSDK(platform_id) then
								inited_platforms_shared[platform_id] = true

								break
							end

							if shouldTerminate("init ad TERMINATED, platform_id:%s", platform_id) then
								return THREAD_EXIT_CODE
							end

							threadpool:wait(1)
						end
					end

					if not inited_platforms_shared[platform_id] then
						logfmt("init ad FAILED, platform_id:%s", platform_id)

						return THREAD_EXIT_CODE
					else
						logfmt("init ad SUCCESS, platform_id:%s", platform_id)
					end

					if not GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) then
						for max_try = 1, cycling_range_count do
							logfmt("preload ad times:%s, platform_id:%s, position_id:%s", max_try, platform_id, position_id)
							GetClientInfo():AdvertisementsPreLoad(platform_id, position_id)
							statisticsGameEvent(1303, "%d", platform_id, "%d", position_id)

							if GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) then
								break
							end

							if shouldTerminate("preload ad TERMINATED 2, platform_id:%s, position_id:%s", platform_id, position_id) then
								return THREAD_EXIT_CODE
							end

							threadpool:wait("ad.info.loadresult", 40)

							if GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) then
								break
							end

							if shouldTerminate("preload ad TERMINATED 3, platform_id:%s, position_id:%s", platform_id, position_id) then
								return THREAD_EXIT_CODE
							end

							threadpool:wait(cycling_range)

							if GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) then
								break
							end
						end
					end

					if not GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) then
						logfmt("preload ad FAILED, platform_id:%s, position_id:%s", platform_id, position_id)
					else
						logfmt("preload ad SUCCESS, platform_id:%s, position_id:%s", platform_id, position_id)
					end
				end)
			end

			threadpool:wait("ad.info.update", 3600)
			logfmt("update_count_shared = %s", update_count_shared)

			update_count_shared = update_count_shared + 1
		end
	end,
	client_ready = function (self)
		local conn = self.conn

		if not conn or not conn.authed then
			return false
		end

		if not self.account or not self.account.svrinfo then
			return false
		end

		return true
	end,
	ad_loop = function (self)
		local printflag = _G.printflag or false

		if utils.env == 1 then
			printflag = true
		end

		while true do
			if self:client_ready() then
				break
			end

			threadpool:wait(0.1)
		end

		local waitconfig = {
			[13] = {
				1,
				1,
				600
			}
		}
		local preload_statics = {}
		local CltVersion = LuaInterface:getCltVersion()
		local ApiID = LuaInterface:getApiId()

		local function log(...)
			if printflag then
				print("ad_loop ", ...)
			end
		end

		local update_fuli_count = 0

		local function preload(platform_id, position_id)
			log("广告预加载 platform_id:", platform_id, " position_id:", position_id)

			local key = string.format("%s.%s.%s", tostring(ApiID), tostring(platform_id), tostring(position_id))

			if GetClientInfo().InitAdvertisementsSDK and GetClientInfo().AdvertisementsLoadStatus and GetClientInfo().AdvertisementsPreLoad then
				if GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) == false then
					log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " 尚未预加载成功 ")

					if position_id == 0 and (ApiID == 303 or ApiID == 307 or ApiID == 310 or ApiID == 313 or ApiID == 336 or ApiID == 399) and CltVersion == 8707 then
						GetClientInfo():AdvertisementsPreLoad(platform_id, 2)
					else
						GetClientInfo():AdvertisementsPreLoad(platform_id, position_id)
					end

					statisticsGameEvent(1303, "%d", platform_id, "%d", position_id)

					preload_statics[key] = (preload_statics[key] or 0) + 1

					log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " 预加载计数:", preload_statics[key])

					local ok = false

					for i = 1, 10 do
						if GetClientInfo():AdvertisementsLoadStatus(platform_id, position_id) then
							ok = true

							log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " ", i, "秒后预加载成功了.")

							break
						end

						threadpool:wait(1)
					end

					if not ok then
						local n = preload_statics[key] or 0
						local c = waitconfig[ApiID]
						local sec = c and c[(n - 1) % #c + 1] or 10

						log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " 10秒后秒判断预加载失败了,  预加载次数统计:", n, " wait:", sec)
						threadpool:wait(sec)
					else
						log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " 预加载成功了, 等1秒再查看")
						threadpool:wait(1)

						local platform = 0

						if CltVersion > 13569 then
							platform = GetClientInfo():getPlatform()
						end

						if platform ~= 3 then
							GetClientInfo():setBrowserAdCanShow(t_ad_data.canShow(20))
						end
					end

					return ok, ok and (tostring(position_id) == "9" or tostring(position_id) == "0") and "refresh_fuli" or "no_refresh_fuli"
				else
					log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " 预加载本来就已经成功了, 等1秒再查看")
					threadpool:wait(1)

					local platform = 0

					if CltVersion > 13569 then
						platform = GetClientInfo():getPlatform()
					end

					if platform ~= 3 then
						GetClientInfo():setBrowserAdCanShow(t_ad_data.canShow(20))
					end

					if update_fuli_count > 3 then
						return true, "no_refresh_fuli"
					elseif tostring(position_id) == "9" or tostring(position_id) == "0" then
						return true, "refresh_fuli"
					else
						return true, "no_refresh_fuli"
					end
				end
			else
				log("广告预加载 platform_id:", platform_id, " position_id:", position_id, " 版本肯定不对 ", CltVersion)
				threadpool:wait(1)

				return true, "no_refresh_fuli"
			end
		end

		if AccountManager:check_ad_version() then
			if GetClientInfo().InitAdvertisementsSDK and GetClientInfo().AdvertisementsLoadStatus then
				local update_count = 0

				while true do
					if self:client_ready() then
						local account = self.account
						local CltVersion = LuaInterface:getCltVersion()
						local ApiID = LuaInterface:getApiId()
						local code = self:remote_call("shopsvr", "ad_info_update", {
							ApiID = ApiID,
							CltVersion = CltVersion,
							first_req = account.is_ad_firstreq
						})

						if self.account then
							self.account.is_ad_firstreq = false
						end

						print("ad_loop ad_info_update code =  ", ErrorCode[code or ErrorCode.FAILED])

						if code ~= ErrorCode.OK then
							break
						end

						local load_by_pos_apiids = {
							[36.0] = true,
							[13.0] = true
						}

						if CltVersion >= 10752 then
							load_by_pos_apiids = {
								[3.0] = true,
								[21.0] = true,
								[11.0] = true,
								[12.0] = true,
								[13.0] = true,
								[34.0] = true
							}
						end

						if CltVersion >= 12800 then
							load_by_pos_apiids[13] = false
						end

						if CltVersion >= 13312 then
							load_by_pos_apiids[3] = false
							load_by_pos_apiids[34] = false
							load_by_pos_apiids[21] = false
							load_by_pos_apiids[11] = false
							load_by_pos_apiids[12] = false
						end

						if load_by_pos_apiids[ApiID] then
							local ad_platform_id_and_position_id_list = account:ad_platform_id_and_position_id_list()

							print("ad_loop ad_platform_id_and_position_id_list ", ad_platform_id_and_position_id_list)

							if ad_platform_id_and_position_id_list and #ad_platform_id_and_position_id_list > 0 then
								for i, v in ipairs(ad_platform_id_and_position_id_list) do
									local platform_id = v.platform_id
									local position_id = v.position_id and tonumber(v.position_id)

									if type(platform_id) == "number" and platform_id > 0 and type(position_id) == "number" then
										threadpool:work(function ()
											print("ad_loop platform_id : ", platform_id, " loop start update_count ", update_count)

											local myupdate_count = update_count

											while myupdate_count == update_count do
												if client_M.already_init_ad_platform_map[platform_id] ~= true then
													delegate(function ()
														for x = 1, 10 do
															if myupdate_count ~= update_count then
																return
															end

															local init_ok = GetClientInfo():InitAdvertisementsSDK(platform_id)

															print("ad_loop 初始化广告返回 platform_id : ", platform_id, " ok? ", init_ok)

															if init_ok then
																client_M.already_init_ad_platform_map[platform_id] = true

																return
															end

															threadpool:wait(1)
														end

														print("ad_loop 初始化广告平台10次,都没有成功")
													end)
												end

												if myupdate_count ~= update_count then
													print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)

													return
												end

												print("ad_loop XXXXXXXXX 广告初始化完成")

												if client_M.already_init_ad_platform_map[platform_id] == true then
													while myupdate_count == update_count do
														local apiid = LuaInterface:getApiId()

														if apiid == 3 then
															print("ad_loop UC 和官方平台要求只预加载广告 3次 platform_id : ", platform_id, myupdate_count, " -> ", update_count)

															local cycling_range_count = 3

															if v.cycling_range_count and v.cycling_range_count > 0 then
																cycling_range_count = v.cycling_range_count
															end

															for x = 1, cycling_range_count do
																if myupdate_count ~= update_count then
																	return
																end

																preload(platform_id, position_id)
															end

															print("ad_loop UC 和官方预加载广告结束了platform_id : ", platform_id, myupdate_count, " -> ", update_count)
														else
															while myupdate_count == update_count do
																local load_ok, refresh_fuli_flag = preload(platform_id, position_id)

																if load_ok and refresh_fuli_flag and refresh_fuli_flag == "refresh_fuli" then
																	print("ad_loop GetClientInfo():AdvertisementsLoadStatus platform_id", platform_id, " position_id", position_id, " true")

																	local cycling_range_count = 3

																	if v.cycling_range_count and v.cycling_range_count > 0 then
																		cycling_range_count = v.cycling_range_count
																	end

																	if update_fuli_count <= cycling_range_count then
																		if ActivityMainCtrl and ActivityMainCtrl.RequestWelfareRewardData then
																			print("ad_loop 刷新福利界面 ", platform_id, " position_id ", position_id)
																			ActivityMainCtrl:RequestWelfareRewardData("loop=1")
																		elseif ns_ma and ns_ma.func and ns_ma.func.MarketActivityFrame_get_reward_list then
																			print("ad_loop 刷新福利界面 ", platform_id, " position_id ", position_id)
																			ns_ma.func.MarketActivityFrame_get_reward_list()
																		end

																		update_fuli_count = update_fuli_count + 1
																	end
																end
															end

															print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)
														end
													end

													print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)
												else
													print("ad_loop 初始化广告平台失败了, 10秒后会尝试下一次初始化")
												end

												local cycling_range = 60

												if v.cycling_range and v.cycling_range > 0 then
													cycling_range = v.cycling_range
												end

												threadpool:wait(cycling_range)

												update_fuli_count = 0
											end

											print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)
											print("ad_loop platform_id : ", platform_id, " loop finish update_count ", update_count)
										end)
									end
								end
							end
						else
							local ad_platform_id_list, platform_id_info = account:ad_platform_id_list()

							if ad_platform_id_list and #ad_platform_id_list > 0 then
								for i, platform_id in ipairs(ad_platform_id_list) do
									if type(platform_id) == "number" and platform_id > 0 then
										local v = platform_id_info[platform_id] or {}

										threadpool:work(function ()
											print("ad_loop platform_id : ", platform_id, " loop start update_count ", update_count)

											local myupdate_count = update_count

											while myupdate_count == update_count do
												if client_M.already_init_ad_platform_map[platform_id] ~= true then
													delegate(function ()
														for x = 1, 10 do
															if myupdate_count ~= update_count then
																return
															end

															local init_ok = GetClientInfo():InitAdvertisementsSDK(platform_id)

															print("ad_loop 初始化广告返回 platform_id : ", platform_id, " ok? ", init_ok)

															if init_ok then
																client_M.already_init_ad_platform_map[platform_id] = true

																return
															end

															threadpool:wait(1)
														end

														print("ad_loop 初始化广告平台10次,都没有成功")
													end)
												end

												if myupdate_count ~= update_count then
													print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)

													return
												end

												print("XXXXXXXXX 广告初始化完成")

												if client_M.already_init_ad_platform_map[platform_id] == true then
													while myupdate_count == update_count do
														local apiid = LuaInterface:getApiId()

														if apiid == 3 then
															print("ad_loop UC 和官方平台要求只预加载广告 3次 platform_id : ", platform_id, myupdate_count, " -> ", update_count)

															for x = 1, 3 do
																if myupdate_count ~= update_count then
																	return
																end

																preload(platform_id, 0)
															end

															print("ad_loop UC 和官方预加载广告结束了platform_id : ", platform_id, myupdate_count, " -> ", update_count)
														else
															while myupdate_count == update_count do
																if ApiID == 303 or ApiID == 310 or ApiID == 313 then
																	preload(platform_id, 10)
																end

																local load_ok, refresh_fuli_flag = preload(platform_id, 0)

																if load_ok and refresh_fuli_flag and refresh_fuli_flag == "refresh_fuli" then
																	local cycling_range_count = 3

																	if v.cycling_range_count and v.cycling_range_count > 0 then
																		cycling_range_count = v.cycling_range_count
																	end

																	if update_fuli_count <= cycling_range_count then
																		if ActivityMainCtrl and ActivityMainCtrl.RequestWelfareRewardData then
																			print("ad_loop 刷新福利界面 1", platform_id, " position_id ", position_id)
																			ActivityMainCtrl:RequestWelfareRewardData("loop=1")
																		elseif ns_ma and ns_ma.func and ns_ma.func.MarketActivityFrame_get_reward_list then
																			print("ad_loop 刷新福利界面 2", platform_id, " position_id ", position_id)
																			ns_ma.func.MarketActivityFrame_get_reward_list()
																		end

																		update_fuli_count = update_fuli_count + 1
																	end

																	print("ad_loop 预加载广告OK platform_id : ", platform_id, myupdate_count, " -> ", update_count)
																end

																threadpool:wait(60)

																update_fuli_count = 0
															end

															print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)
														end
													end

													print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)
												else
													print("ad_loop 初始化广告平台失败了, 10秒后会尝试下一次初始化")
												end

												local cycling_range = 10

												if v.cycling_range and v.cycling_range > 0 then
													cycling_range = v.cycling_range
												end

												threadpool:wait(cycling_range)
											end

											print("ad_loop 这次执行应该是被中断了 platform_id : ", platform_id, myupdate_count, " -> ", update_count)
											print("ad_loop platform_id : ", platform_id, " loop finish update_count ", update_count)
										end)
									end
								end
							end
						end
					end

					threadpool:wait("ad.info.update", math.random(1200, 2400))

					preload_statics = {}

					print(" update_count = ", update_count)

					update_count = update_count + 1
				end
			end
		else
			for i = 1, 120 do
				local code, platform_id = self:remote_call("shopsvr", "ad_platform_id", {
					ApiID = LuaInterface:getApiId(),
					CltVersion = LuaInterface:getCltVersion()
				})

				print("广告平台 code=", ErrorCode[code], " 平台id=", platform_id)

				if code == ErrorCode.OK then
					if GetClientInfo().InitAdvertisementsSDK and GetClientInfo().AdvertisementsLoadStatus then
						if type(platform_id) == "number" and platform_id > 0 then
							for ii = 1, 60 do
								local init_ok = GetClientInfo():InitAdvertisementsSDK(platform_id)

								if init_ok then
									client_M.ad_platform_id = platform_id
									client_M.ad_init_flag = true

									break
								end

								threadpool:wait(3)
							end
						end

						break
					end

					if type(platform_id) == "number" and platform_id > 0 then
						client_M.ad_platform_id = ad_platform_id
						client_M.ad_init_flag = true
					end

					break
				end

				threadpool:wait(60)
			end

			if client_M.ad_init_flag == false then
				return
			end

			if GetClientInfo().AdvertisementsPreLoad and GetClientInfo().AdvertisementsLoadStatus and type(client_M.ad_platform_id) == "number" and client_M.ad_platform_id > 0 then
				threadpool:work(function ()
					local apiid = LuaInterface:getApiId()

					if apiid == 3 or self:is_official_or_cps(apiid) then
						for i = 1, 3 do
							if GetClientInfo():AdvertisementsLoadStatus(client_M.ad_platform_id, 0) == false then
								statisticsGameEvent(1303, "%d", platform_id, "%d", 0)
								GetClientInfo():AdvertisementsPreLoad(client_M.ad_platform_id, 0)
							end

							threadpool:wait(10)
						end
					else
						while true do
							if GetClientInfo():AdvertisementsLoadStatus(client_M.ad_platform_id, 0) == false then
								statisticsGameEvent(1303, "%d", platform_id, "%d", 0)
								GetClientInfo():AdvertisementsPreLoad(client_M.ad_platform_id, 0)
							end

							threadpool:wait(10)
						end
					end
				end)
			end

			while true do
				pcall(function ()
					local conn = self.conn

					print("ad loop ", conn and conn.authed, " ========= ")

					if conn and conn.authed and client_M.ad_platform_id and client_M.ad_platform_id > 0 then
						local first_req = self.account and self.account.is_ad_firstreq or false
						local code = self:remote_call("shopsvr", "ad_info", {
							ApiID = LuaInterface:getApiId(),
							CltVersion = LuaInterface:getCltVersion(),
							platform_id = client_M.ad_platform_id,
							first_req = first_req
						})

						if self.account then
							self.account.is_ad_firstreq = false
						end

						if code == ErrorCode.OK then
							print(" ========= get ad info ok ===== ")
						else
							print("====== get ad info failed code = ", code)
						end
					end
				end)
				threadpool:wait(math.random(1200, 2400))
			end
		end
	end,
	is_official_or_cps = function (self, apiid)
		if apiid == 1 then
			return true
		end

		local ApiDef = client_M.account_def.ApiDef
		local def = ApiDef and ApiDef[apiid]

		return def and def.Tag == "cps" or false
	end,
	getApiName = function (self, apiid)
		local def = client_M.antiaddiction

		return def and def[apiid] and def[apiid].Name
	end,
	get_rolename_flag = function (self)
		return self.account and self.account.close_rolename_tips
	end,
	get_antiaddiction_def = function (self)
		local apiid = LuaInterface:getApiId()
		local account = self.account
		local svrinfo = account and account.svrinfo
		local needauthcity = svrinfo and svrinfo.needauthcity or nil

		if needauthcity and needauthcity.citycontrol == true and needauthcity.timelimit then
			local ForceAuth = 2
			local Auth = 1
			local AuthType = 2

			if needauthcity.Auth then
				Auth = needauthcity.Auth
			end

			if needauthcity.ForceAuth then
				ForceAuth = needauthcity.ForceAuth
			end

			if needauthcity.AuthType then
				AuthType = needauthcity.AuthType
			end

			local AccountCreateTime = self:get_account_create_time()

			if needauthcity.timelimit.starttime <= AccountCreateTime and AccountCreateTime <= needauthcity.timelimit.endtime then
				return {
					AntiAddiction = 1,
					ApiID = 0,
					Name = "defalut",
					Auth = Auth,
					ForceAuth = ForceAuth,
					AuthType = AuthType,
					AuthNum = math.huge
				}
			end
		end

		if account then
			return account:get_antiaddiction_def(apiid)
		end

		local ok, def = pcall(loadwwwcache, "res.antiaddiction")

		if ok and def then
			return def and apiid and def[apiid] or {
				Auth = 1,
				ForceAuth = 2,
				AntiAddiction = 1,
				AuthType = 2,
				ApiID = 0,
				Name = "defalut",
				AuthNum = math.huge
			}
		end

		return {
			Auth = 1,
			ForceAuth = 2,
			AntiAddiction = 1,
			AuthType = 2,
			ApiID = 0,
			Name = "defalut",
			AuthNum = math.huge
		}
	end,
	realname_hideall = function (self)
		if HideIdentityNameAuthFrame then
			HideIdentityNameAuthFrame()
		end

		if t_allFrame then
			for i, v in ipairs(t_allFrame) do
				local ui = getglobal(v)

				if ui and ui:IsShown() then
					ui:Hide()
				end
			end
		end
	end,
	realname_msgbox = function (self, msgname)
		self:realname_hideall()

		local Config = loadwwwcache("res.Config")
		local RealName = Config and Config.RealName
		local msg = string.gsub(RealName[msgname or "string3"], "%$([%w_]+)", {
			age = RealName.age,
			time = RealName.time
		})
		local code, btn = self:msgbox(msg, 29)

		if code == ErrorCode.OK and btn then
			if btn == "left" then
				local adsType = RealNameModule:isShowIdentityNameAuth(8)

				ShowIdentityNameAuthFrame(nil, nil, nil, nil, nil, adsType)
			elseif GameExit then
				return GameExit()
			else
				return GetClientApp():GameExit()
			end
		end
	end,
	realname_quit = function (self, msgname)
		self:realname_hideall()

		local Config = loadwwwcache("res.Config")
		local RealName = Config and Config.RealName
		local msg = string.gsub(RealName[msgname or "string4"], "%$([%w_]+)", {
			age = RealName.age,
			time = RealName.time
		})
		local code, btn = self:msgbox(msg, 26)

		if code == ErrorCode.OK and btn == "center" then
			if GameExit then
				return GameExit()
			else
				return GetClientApp():GameExit()
			end
		end
	end,
	realname_later = function (self, msgname)
		self:realname_hideall()

		local Config = loadwwwcache("res.Config")
		local RealName = Config and Config.RealName
		local msg = string.gsub(RealName[msgname or "string3"], "%$([%w_]+)", {
			age = RealName.age,
			time = RealName.time
		})
		local code, btn = self:msgbox(msg, 30)

		if code == ErrorCode.OK and btn then
			if btn == "left" then
				-- Nothing
			elseif GameExit then
				return GameExit()
			else
				return GetClientApp():GameExit()
			end
		end
	end,
	realname_loop = function (self)
		print("====== 进入主游戏 =========")

		local Config = loadwwwcache("res.Config")
		local RealName = Config and Config.RealName
		local timeout1 = RealName.timeout1
		local timeout2 = RealName.timeout2
		local firsttime = true

		if not MessageBox then
			return
		end

		local starttime = threadpool:now()
		local time2wait = 0
		local isnewuser = false
		local createtime = AccountManager:get_account_create_time()
		local now = threadpool:now()

		if now - createtime < 86400 then
			isnewuser = true
			time2wait = 300
		end

		print("======= realname_loop ====== isnewuser : ", isnewuser, " time2wait : ")
		threadpool:wait(time2wait)

		local t_type = nil

		for i = 1, 100 do
			local name, value = debug.getupvalue(MessageBox, i)

			if name == "t_type" then
				t_type = value

				break
			end
		end

		if not t_type then
			return
		end

		if #t_type < 28 then
			return
		end

		t_type[29] = t_type[29] or {
			leftNameId = 4836,
			rightNameId = 3862,
			iconPath = "ui/mobile/ui2.png",
			uv = {
				y = 449,
				x = 885,
				w = 61,
				h = 61
			}
		}

		while true do
			local isswitchuser = threadpool:wait("account.switch", firsttime and 0 or 300) == ErrorCode.OK

			print("======= realname_loop ====== isnewuser : ", isnewuser, " time2wait : ", time2wait, " firsttime :", firsttime, " isswitchuser : ", isswitchuser)

			if isswitchuser then
				print("===== 切换帐号了 =====")

				return
			end

			local intime, timeout = self:realname_check_in_limit_time()

			print("======= realname_loop ====== intime : ", intime, " timeout : ", timeout)

			if intime then
				if isnewuser then
					timeout = threadpool:now() - starttime

					if timeout < 0 then
						timeout = 0
					end
				end

				local code, info = self:realname_get_age()

				print("======= realname_loop ====== intime : ", intime, " timeout : ", timeout, " code:", code, "info:", info)

				if code == ErrorCode.OK and info then
					if isnewuser and info.status == "not_auth_yet" then
						print("======= realname_loop ====== intime : ", " 新用户 未认证")

						if timeout1 <= timeout then
							self:realname_quit("string3")
						elseif timeout2 <= timeout then
							self:realname_msgbox("string2")
						else
							self:realname_msgbox("string2")
						end
					else
						print("======= realname_loop ====== intime : ", " 老用户 ")

						if info.status == "not_auth_yet" then
							if firsttime then
								print("======= realname_loop ====== intime : ", " 老用户 ", " 限定时间内进入游戏 ")
								self:realname_quit("string1")
							else
								print("======= realname_loop ====== intime : ", " 老用户 ", " 非限定时间内进入游戏, 定时检查,检查到进入限定时间了  ")

								if timeout1 <= timeout then
									self:realname_quit("string3")
								elseif timeout2 <= timeout then
									self:realname_msgbox("string4")
								else
									self:realname_msgbox("string4")
								end
							end
						elseif info.age < RealName.age then
							if firsttime then
								self:realname_quit("string1")
							elseif timeout1 <= timeout then
								self:realname_quit("string3")
							elseif timeout2 <= timeout then
								self:realname_later("string3")
							else
								self:realname_later("string3")
							end
						end
					end
				else
					print("未获取玩家的年龄信息")
				end
			end

			firsttime = false
		end
	end,
	check_vacation = function (self)
		if not self.Vacation then
			self.Vacation = loadwwwcache("res.Vacation")
		end

		if not self.Vacation then
			return true
		end

		local date = os.date("*t", self.now)
		local today = string.format("%04d-%02d-%02d", date.year, date.month, date.day)

		return self.Vacation and self.Vacation[today] or false
	end,
	children_protect_quit = function (self, msg, timeout)
		self:realname_hideall()

		msg = msg or GetS(20502)
		_G.IgnoreEsc = true

		if MessageBox then
			MessageBox(4, msg, function (btn)
				if btn == "center" then
					_G.IgnoreEsc = false

					if GameExit then
						return GameExit()
					else
						return GetClientApp():GameExit()
					end
				end
			end)
		end
	end,
	children_protect = function (self)
		local printflag = _G.printflag or false
		local Uin = self.account and self.account.Uin or 0
		local firsttime = true
		local raise_unfrozen_msg = self:getcfg("raise_unfrozen_msg") or 0
		local raise_5_min_msg = false

		while true do
			local UinNow = self.account and self.account.Uin or 0

			if UinNow ~= Uin then
				return printflag and "children_protect : 切换帐号了"
			end

			if not self:children_protect_check() then
				return printflag and print("不开启未成年人保护")
			end

			local account = self.account

			if not account then
				return "children_protect : 帐号数据是空"
			end

			if account:children_check_frozen() then
				self:savecfg("raise_unfrozen_msg", 0)

				return self:children_protect_quit()
			end

			local adult = self:check_adult()

			if self:check_vacation() then
				return printflag and print(" children_protect : 节假日, 不受限制 ")
			end

			local GameTime = account:children_gametime_get()

			if printflag then
				print(" 游戏时间 ", GameTime)
			end

			local GameTimeToday = self:statics_for_today_get("gametime")

			if GameTimeToday < GameTime and GameTime - GameTimeToday <= 300 and raise_5_min_msg == false then
				raise_5_min_msg = true

				if printflag then
					print("children_protect 今天的游戏时间剩余不足5分钟了 ")
				end

				self:realname_hideall()
				self:msgbox(GetS(20508))
			end

			if GameTime <= GameTimeToday then
				if printflag then
					print("children_protect 今天的游戏时间到了")
				end

				return self:children_protect_quit(GetS(20501), 86400)
			end

			threadpool:wait(1)

			firsttime = false
		end
	end,
	check_stringid = function (self, stringid)
		local s = DefMgr and DefMgr.getStringDef and DefMgr:getStringDef(stringid)

		return type(s) == "string" and #s > 0 or false
	end,
	children_protect_check = function (self)
		local CltVersion = LuaInterface:getCltVersion()

		if CltVersion <= 7683 then
			return false, print("版本号过低, 不开启未成年人保护")
		end

		local ApiID = LuaInterface:getApiId()

		if ApiID > 100 and ApiID ~= 999 and ApiID ~= 299 and ApiID ~= 500 then
			return false, print("海外版本, 不开窍未成年人保护")
		end

		if not self:check_stringid(20502) or not self:check_stringid(20503) or not self:check_stringid(20501) or not self:check_stringid(20508) then
			return false, print("弹窗的文本没有配置, 不开启未成年人保护")
		end

		return true
	end,
	children_protect_loop = function (self)
		while true do
			if isInMainGame then
				break
			end

			threadpool:wait(0)
		end

		self.gametime = self.gametime or {}

		threadpool:work(function ()
			local timeout = 60

			while true do
				local Uin = self.account and self.account.Uin or 0
				self.gametime[Uin] = (self.gametime[Uin] or 0) + timeout

				if self.account and self.account:children_gametime_hasset() then
					self:statics_for_today_dot("gametime", timeout)
				end

				threadpool:wait(timeout)
			end
		end)

		while true do
			self:children_protect()
			threadpool:wait(1)
		end
	end,
	update_SkinCostDef = function (self)
		local index = 1

		while true do
			if ns_version and ns_version.shop_config and ns_version.shop_config == true and ns_shop_config and ns_shop_config.skinList and AccountManager.skin_can_show then
				print(" get server")

				client_M.account_def.SkinCostDef = ns_shop_config.skinList
				local CltVersion = LuaInterface:getCltVersion()

				for _, v in pairs(client_M.account_def.SkinCostDef) do
					if type(v) == "table" then
						for ExpireTimeType, vv in pairs(v) do
							if type(vv) == "table" and vv.SkinID and vv.ExpireTimeType and vv.CltVersion <= CltVersion and ExpireTimeType > 0 then
								local def = DefMgr:getRoleSkinDef(vv.SkinID)

								if def then
									if CltVersion >= 6144 then
										local CostType = vv.CostType

										if CostType and CostType > 0 then
											def.MoneyType[vv.ExpireTimeType - 1] = CostType
										end

										if vv.ExpireTime == -1 then
											def.UseDays[vv.ExpireTimeType - 1] = -1
										else
											def.UseDays[vv.ExpireTimeType - 1] = math.floor(vv.ExpireTime / 86400)
										end

										if vv.ItemID > 0 then
											def.Price[vv.ExpireTimeType - 1] = vv.Num
										else
											def.Price[vv.ExpireTimeType - 1] = vv.Cost
										end

										if def.ItemID then
											def.ItemID[vv.ExpireTimeType - 1] = vv.ItemID
										end

										def.LimitBeginTime = vv.SellBeginTime
										def.LimitEndTime = vv.SellEndTime
										def.ActBeginTime = tonumber(vv.ActBeginTime)
										def.ActEndTime = tonumber(vv.ActEndTime)
										def.OpenApiId = vv.ApiID
										def.Tag = vv.Tag or 0
										def.GifLogo = vv.GifLogo
									else
										if vv.ExpireTime == -1 then
											def.UseDays[vv.ExpireTimeType - 1] = -1
										else
											def.UseDays[vv.ExpireTimeType - 1] = math.floor(vv.ExpireTime / 86400)
										end

										def.MoneyType[vv.ExpireTimeType - 1] = vv.ItemID

										if vv.ItemID > 0 then
											def.Price[vv.ExpireTimeType - 1] = vv.Num
										else
											def.Price[vv.ExpireTimeType - 1] = vv.Cost
										end

										def.LimitBeginTime = vv.SellBeginTime
										def.LimitEndTime = vv.SellEndTime
										def.ActBeginTime = tonumber(vv.ActBeginTime)
										def.ActEndTime = tonumber(vv.ActEndTime)
										def.OpenApiId = vv.ApiID
										def.Tag = vv.Tag or 0
									end
								end
							end
						end
					end
				end

				if GetInst("ShopDataManager") and GetInst("ShopDataManager").InitSkinDefs then
					GetInst("ShopDataManager"):InitSkinDefs()
				end

				print("ShopDataManager InitSkinDefs done")

				return true
			end

			threadpool:wait(15)
		end
	end,
	idcard_loop = function (self)
		while true do
			if isInMainGame and self:client_ready() then
				break
			end

			threadpool:wait(0.1)
		end

		threadpool:work(function ()
			while true do
				if not IsOverseasVer() and not isEducationalVersion and AccountManager:isLogin() and ns_version and ns_version.LoginControl then
					local LoginControl = ns_version and ns_version.LoginControl
					local unRealname = LoginControl.unRealname or 0
					local day_begin = LoginControl.day_begin or -1
					local day_end = LoginControl.day_end or -1
					local needcheck = false
					local idCardInfo = AccountManager:idcard_info()

					if unRealname == 1 and not idCardInfo then
						needcheck = true
					elseif idCardInfo and idCardInfo.age and idCardInfo.age < 18 then
						needcheck = true
					end

					print("LoginControl=", LoginControl, " needcheck=", needcheck, "unRealname=", unRealname, "idCardInfo.age=", idCardInfo and idCardInfo.age or "nil")

					if needcheck and LoginControl and LoginControl.day_begin > 0 and LoginControl.day_end > 0 then
						local hour = tonumber(os.date("%H", os.time()))

						print("LoginControl=", LoginControl, " hour=", hour)

						if LoginControl.day_begin <= hour and hour > LoginControl.day_end then
							-- Nothing
						end
					end
				end

				threadpool:wait(120)
			end
		end)
		threadpool:work(function ()
			local Uin = self.account and self.account.Uin or 0

			while true do
				local UinNow = self.account and self.account.Uin or 0

				if Uin ~= UinNow and self:client_ready() then
					threadpool:notify("account.switch", ErrorCode.OK, Uin, UinNow)

					Uin = UinNow
				end

				threadpool:wait(1)
			end
		end)

		while true do
			self.online_start_time = self:getSvrTime()

			if self:realname_check_loop() then
				self:realname_loop()
			else
				while true do
					local code = threadpool:wait("account.switch", 3600)

					if code == ErrorCode.OK then
						break
					end
				end
			end

			threadpool:wait(1)
		end
	end,
	chatpush_loop = function (self)
		local tick = 1
		local connecttime = 0
		local heartbeat = 0
		local heartbeatticknum = 5
		local heartbeatfailnum = 0
		local defaultlburl = ""
		local env = utils.env

		if env == 1 then
			defaultlburl = "http://120.24.64.132:19601"
		elseif env == 0 then
			defaultlburl = "https://chatpush.mini1.cn:19602"
		elseif env == 2 then
			defaultlburl = "http://211.159.183.137:19601"
		elseif env == 11 then
			defaultlburl = "http://shequ.miniworldplus.com:19090"
		elseif env == 10 then
			defaultlburl = "http://chatpush.miniworldgame.com:19601"
		end

		while true do
			local chatpushconn = container and container.chatpushconn

			if chatpushconn.valid then
				local Uin = AccountManager:getUin()

				if not chatpushconn.isopen then
					connecttime = connecttime + tick

					if connecttime >= 2 then
						connecttime = 0
						heartbeatticknum = 5
						heartbeatfailnum = 0
						local lburl = defaultlburl

						if ns_version.pushchat and ns_version.pushchat.pushlb and type(ns_version.pushchat.pushlb) == "string" then
							local pushlb = utils.split(ns_version.pushchat.pushlb, ",")

							if #pushlb > 0 then
								lburl = pushlb[math.random(#pushlb)]
							end
						end

						if lburl and lburl ~= "" and Uin then
							chatpushconn:connect(Uin, lburl)
						else
							print("chatpushconn get lburl error")
						end
					end
				elseif Uin and chatpushconn.uin and tonumber(chatpushconn.uin) == tonumber(Uin) then
					heartbeat = heartbeat + tick

					if heartbeatticknum <= heartbeat then
						heartbeat = 0

						chatpushconn:heartbeat()
					end
				else
					print("Uin not same, chatpushconn.close", Uin, chatpushconn.uin)
					chatpushconn:close()
				end
			else
				print("chatpushconn.disable - wait")

				while true do
					if self:client_ready() then
						break
					end

					threadpool:wait(0.1)
				end

				local Uin = AccountManager:getUin()

				print("chatpushconn.disable - start ", Uin)
				chatpushconn:start()

				if not chatpushconn.isopen then
					print("not chatpushconn.isopen " .. Uin)

					local lburl = defaultlburl

					if ns_version.pushchat and ns_version.pushchat.pushlb and type(ns_version.pushchat.pushlb) == "string" then
						local pushlb = utils.split(ns_version.pushchat.pushlb, ",")

						if #pushlb > 0 then
							lburl = pushlb[math.random(#pushlb)]
						end
					end

					if lburl and lburl ~= "" then
						chatpushconn:connect(Uin, lburl)
					else
						print("chatpushconn get lburl error")
					end
				else
					print("chatpushconn.isopen " .. Uin)
				end
			end

			threadpool:wait(tick)
		end
	end,
	device_multi_online_loop = function (self)
		local version_base_ = GetClientInfo():clientVersionFromStr("0.53.5")
		local version_now_ = GetClientInfo():GetClientVersion()

		if version_base_ <= version_now_ then
			while true do
				local account = self.account
				local svrinfo = account and account.svrinfo

				if svrinfo and svrinfo.multi_device_flag and not IsShowVerifyBox and isInMainGame then
					svrinfo.multi_device_flag = false

					if ShowVerifyBox then
						ShowVerifyBox()
					end
				end

				threadpool:wait(10)
			end
		end
	end,
	minicoin_use_limit = function (self)
		local account = self.account
		local env = utils.env or 0
		local info = account:get_idcard_info()
		local url = nil
		local limit = false
		local svrinfo = account and account.svrinfo
		local city = svrinfo and svrinfo.city

		if env == 1 then
			url = "http://120.24.64.132:8087/miniw/profile?act=tourist_isminicoin&CreateTime=%d&uin=%d&city=%s&json=1&apiids=%d"
		elseif env == 0 then
			url = "https://shequ.mini1.cn:8081/miniw/profile?act=tourist_isminicoin&CreateTime=%d&uin=%d&city=%s&json=1&apiids=%d"
		end

		if city and city ~= "" and url and not info then
			local Sec = self.now
			local apiid = LuaInterface and LuaInterface.getApiId and LuaInterface:getApiId() or 0
			local query = string.format(url, self:get_account_create_time(), account.Uin or 0, city, apiid)
			local seq = gen_gid()

			ns_http.func.rpc_string_raw(query, function (ret)
				threadpool:notify(seq, ErrorCode.OK, ret)
			end, nil, 2)

			local code, msg = threadpool:wait(seq, timeout)

			print("minicoin_use_limit code=", code, " msg=", msg, " city=", city)

			if code == ErrorCode.OK and msg and type(msg) == "string" then
				local ok, ret_msg = pcall(JSON.decode, JSON, msg)

				print("ret_msg=", ret_msg)

				if ok and type(ret_msg) == "table" and ret_msg.ret and ret_msg.ret == 0 and ret_msg.data and ret_msg.data.limit == 1 then
					limit = true
				end
			end
		end

		print("minicoin_rm limit=", limit)

		if limit then
			return ErrorCode.ACCOUNT_VISITOR_CANT_USE_MINICOIN
		end

		return ErrorCode.OK
	end,
	idcard_auth = function (self, idcard_number, name, idcard_type, popupscene, manualConfig)
		idcard_type = idcard_type or 1
		local def = self:get_antiaddiction_def()

		if not def then
			return ErrorCode.PRECHECK_CFG_NOT_FOUND
		end

		local info = self:idcard_info()

		if info and info.id == idcard_number and info.name == name and self:realname_state() == 1 then
			return ErrorCode.OK, info.age
		end

		local Uin = self.account and self.account.Uin or 0
		local statics = self:load_from_file("statics_" .. Uin) or {}

		local function convertCertTo18Num(certCode)
			local tmpCertCode = tostring(certCode)

			if string.len(certCode) == 15 then
				local factor = {
					7,
					9,
					10,
					5,
					8,
					4,
					2,
					1,
					6,
					3,
					7,
					9,
					10,
					5,
					8,
					4,
					2
				}
				local code = {
					"1",
					"0",
					"X",
					"9",
					"8",
					"7",
					"6",
					"5",
					"4",
					"3",
					"2"
				}
				local preCert = string.format("%s19%s", string.sub(tmpCertCode, 1, 6), string.sub(tmpCertCode, 7, 15))
				local num = 0

				if preCert then
					for i = 1, 17 do
						local sub_num = string.sub(preCert, i, i)

						if sub_num then
							num = num + tonumber(sub_num) * factor[i]
						end
					end

					local x = math.mod(num, 11) or 0
					local endCh = code[x + 1]
					tmpCertCode = preCert .. endCh
				end
			end

			return tmpCertCode
		end

		idcard_number = convertCertTo18Num(idcard_number)
		local code, _, resps = self:remote_call("baseinfo", "idcard_auth_country", idcard_number, name, LuaInterface:getApiId(), idcard_type, {
			popupscene = popupscene,
			manualConfig = manualConfig
		})

		print("idcard_auth_country code=", code, " resps=", resps)

		if def and (def.AuthType == 2 or def.AuthType == "2") then
			local count = resps and type(resps) == "table" and resps.count and type(resps.count) == "number" and resps.count

			if code ~= ErrorCode.OK then
				self:statics_for_today_dot("idcard.auth", count, count and type(count) == "number")
			end
		end

		if code == ErrorCode.OK then
			local info = self:idcard_info()

			if ns_version.opennewauth == 1 then
				self:data_update()
			end

			self:policy_limit_login_check_log()

			return code, info and info.age or 0
		elseif code == ErrorCode.PRECHECK_IDCARD_AUTHED_OK then
			self:data_update()

			local info = self:idcard_info()

			self:policy_limit_login_check_log()

			return ErrorCode.OK, info and info.age or 0
		else
			return code
		end
	end,
	sync_idcard_auth_count_from_server = function (self)
		local account = self.account
		local leveldb = account and account.leveldb
		local uin = account and account.Uin or 0
		local auth_limit = leveldb and leveldb.idcard and leveldb.idcard.auth_limit or {}
		local count = auth_limit.count or 0
		local auth_day = auth_limit.auth_day or ""
		local t = os.date("*t", getServerTime())
		local today = string.format("%d_%d_%d", t.year, t.month, t.day)

		if auth_day ~= today then
			count = 0
		end

		local local_count = self:statics_for_today_get("idcard.auth")

		print("sync_idcard_auth_count_from_server ", uin, count, local_count, auth_day, today)

		if count ~= local_count then
			self:statics_for_today_dot("idcard.auth", count, true)
		end
	end,
	get_idcard_auth_count_for_today = function (self)
		local left = 5 - (self:statics_for_today_get("idcard.auth") or 0)

		if left <= 0 then
			left = 0
		end

		return left
	end,
	idcard_info = function (self)
		local account = self.account

		return account and account:get_idcard_info()
	end,
	check_adult = function (self)
		local account = self.account
		local info = account and account:get_idcard_info()

		return type(info) == "table" and type(info.age) == "number" and info.age >= 18 or false
	end,
	get_time_since_online = function (self)
		local account = self.account
		local Uin = account and account.Uin or 0
		local time = self.gametime and self.gametime[Uin] or 0

		return time
	end,
	get_time_since_offline = function (self)
		local account = self.account
		local svrinfo = account and account.svrinfo
		local time = svrinfo and svrinfo.offline_ts and self:getSvrTime() - svrinfo.offline_ts or 0

		if time <= 0 then
			time = 0
		end

		return time
	end,
	get_skincostdef = function (self)
		return client_M.account_def.SkinCostDef
	end,
	skin_can_show = function (self, SkinID)
		print("skin_can_show ========= ", SkinID)

		local CltVersion = LuaInterface:getCltVersion()

		if CltVersion < 13578 and SkinID == 114 then
			return false
		end

		local find = string.find
		local concat = table.concat
		local account = self.account

		if account and account:skin_has(SkinID) then
			return true
		end

		local previous_def = nil
		local previous_def_list = client_M.account_def.SkinCostDef[SkinID]

		if previous_def_list then
			for k, v in pairs(previous_def_list) do
				if type(v) == "table" and v.SkinID == SkinID then
					previous_def = v

					break
				end
			end
		end

		local BeginTime = type(previous_def) == "table" and type(previous_def.BeginTime) == "number" and previous_def.BeginTime or 0
		local EndTime = type(previous_def) == "table" and type(previous_def.EndTime) == "number" and previous_def.EndTime or math.huge
		local now = self.now

		if now < BeginTime or EndTime < now then
			return false
		end

		local env = utils.env
		local def = self:get_skincostdef()

		if not def or not def[SkinID] then
			return true
		end

		local cfg = def[SkinID]
		local flag = true

		for k, v in pairs(cfg) do
			if type(k) == "number" and type(v) == "table" and v.OpenService and not find("," .. tostring(v.OpenService) .. ",", concat({
				",",
				env,
				","
			}), 1, true) then
				flag = false

				break
			end
		end

		if flag == false then
			print(" OpenService 没有配置开发 ")

			return false
		end

		if not cfg.CloseEnv then
			for k, v in pairs(cfg) do
				if type(v) == "table" then
					local CloseEnv = v.CloseEnv

					if CloseEnv and CloseEnv == (env or 0) then
						return false
					end
				end
			end
		end

		if not cfg.CloseEnv or cfg.CloseEnv == -1 then
			return true
		end

		env = utils.env

		if env == cfg.CloseEnv then
			return false
		end

		return true
	end,
	skin_has = function (self, SkinID)
		local account = self.account

		return SkinID and account and account:skin_has(SkinID) or false
	end,
	baseinfo_check = function (self, Uin, queryinfo)
		if type(Uin) == "number" and Uin > 0 and Uin <= client_M.__UINT32__ and type(queryinfo) == "table" then
			local code, ok = self:remote_call("baseinfo", "other_baseinfo_check", Uin, queryinfo)

			return ErrorCode.OK == code and ok == "ok" or false
		else
			return false
		end
	end,
	other_baseinfo = function (self, Uin)
		local account = self.account

		if not account then
			return ErrorCode.FAILED
		end

		if Uin == account.Uin then
			return ErrorCode.OK, account.baseinfo
		end

		return self:remote_call("baseinfo", "other_baseinfo", Uin)
	end,
	update_openid = function (self, openid)
		return self:remote_call("baseinfo", "update_baseinfo", {
			extra = {
				openid = openid
			}
		})
	end,
	wegame_loop = function (self)
		local ApiID = LuaInterface:getApiId()

		if ApiID ~= 102 then
			return
		end

		while true do
			if self:client_ready() then
				break
			end

			threadpool:wait(0.1)
		end

		while GetClientInfo().getWeGameQueryOrderString and GetClientInfo().getWeGameFinishOrderString and GetClientInfo().getWeGamePayformentResult and GetClientInfo().WeGamePayComplete do
			if GetClientInfo():getWeGamePayformentResult() == true then
				local queryString = GetClientInfo():getWeGameQueryOrderString()
				local finishString = GetClientInfo():getWeGameFinishOrderString()

				if queryString and finishString and queryString ~= "" and finishString ~= "" then
					local code = AccountManager:wegame_order_finish(queryString, finishString)

					if code == ErrorCode.OK then
						GetClientInfo():WeGamePayComplete()
					end
				end
			end

			threadpool:wait(1)
		end
	end,
	wegame_order_new = function (self, openstring)
		if SdkManager:check_realname_auth() == false then
			return
		end

		self.cluster.shopsvr.wegame_order_new(openstring)
	end,
	wegame_order_finish = function (self, query_string, finish_string)
		return self:remote_call("shopsvr", "wegame_order_finish", query_string, finish_string)
	end,
	steam_loop = function (self)
		local ApiID = LuaInterface:getApiId()

		if ApiID ~= 402 then
			return
		end

		while true do
			if self:client_ready() then
				break
			end

			threadpool:wait(0.1)
		end

		while GetClientInfo().getSteamQueryOrderString and GetClientInfo().getSteamFinishOrderString and GetClientInfo().SteamAuthorizeResult and GetClientInfo().SteamPayComplete do
			if GetClientInfo():SteamAuthorizeResult() == true then
				local queryString = GetClientInfo():getSteamQueryOrderString()
				local finishString = GetClientInfo():getSteamFinishOrderString()

				if queryString and finishString and queryString ~= "" and finishString ~= "" then
					for i = 1, 3 do
						local code = AccountManager:steam_order_finish(queryString, finishString)

						print("steam_order_finish ret ", code)

						if code == ErrorCode.OK then
							break
						end

						threadpool:wait(1)
					end

					GetClientInfo():SteamPayComplete()
				end
			end

			threadpool:wait(1)
		end
	end,
	steam_order_new = function (self, openstring)
		if SdkManager:check_realname_auth() == false then
			return false
		end

		local code = self:remote_call("shopsvr", "steam_order_new", openstring)

		print("steam_order_new ret ", code)

		return code == ErrorCode.OK
	end,
	steam_order_finish = function (self, query_string, finish_string)
		return self:remote_call("shopsvr", "steam_order_finish", query_string, finish_string)
	end,
	get_token_for_app = function (self)
		local conn = self.conn
		local account = self.account

		if account and conn and conn.sign and #conn.sign > 10 then
			return JSON:encode({
				Uin = account.Uin,
				sign = conn.sign,
				code = ErrorCode[ErrorCode.OK],
				token = conn.token
			})
		else
			return JSON:encode({
				code = ErrorCode[conn and conn.errorcode or ErrorCode.FAILED]
			})
		end
	end,
	get_outer_ip_and_delay = function (self)
		local conn = self.conn

		return conn and conn.other and conn.other[1] and conn.other[1].ip or "0.0.0.0", conn and conn.delay or 0
	end,
	on_network_status_calllback = function (self, tbl)
		self.cluster.baseinfo.network_report(tbl)
	end,
	get_country_code = function (self)
		local conn = self.conn

		return conn and conn.other and conn.other[1] and conn.other[1].country or ""
	end,
	mobileqq_notify = function (self, b, msg)
		self.cluster.baseinfo.mobileqq_notify(b, msg)
	end,
	mobileqq_msglist = function (self)
		local code, list = self:remote_call("baseinfo", "mobileqq_msglist")

		if code == ErrorCode.LEVELDB_NO_SUCH_DATA then
			return ErrorCode.OK, {}
		else
			return code, list
		end
	end,
	mobileqq_delmsg = function (self, key)
		return self:remote_call("baseinfo", "mobileqq_delmsg", key)
	end,
	mobileqq_vip_info = function (self, openid)
		local code, info = self:remote_call("baseinfo", "mobileqq_vip_info", openid)

		if code == ErrorCode.OK and info and info.vip then
			local data = JSON:decode(info.vip.data)

			if data and data.msg_time then
				local msg_time = tonumber(data.msg_time)
				local ts = self.now

				if ts - msg_time <= 300 then
					return true
				else
					return false
				end
			else
				return false
			end
		else
			return false
		end
	end,
	statics_loop = function (self)
		while statisticsGameEvent do
			threadpool:wait(60)

			local account = self.account

			if StatisticsTools and StatisticsTools.send then
				StatisticsTools:send(true, false)
			else
				GetClientInfo():sendStatistics(true, false)
			end

			print("statics_loop ", 8009, "%d", 60, "%d", account and account.IsBinding and 1 or 0)
		end
	end,
	bind_facebook = function (self, facebook_id, facebook_token, facebook_nickname)
		print("xxxxxxxxxxxxx bind_facebook xxxxxxxxxxx ", facebook_id, facebook_token)

		return self:remote_call("baseinfo", "bind_facebook", {
			id = facebook_id,
			token = facebook_token,
			nickname = facebook_nickname
		})
	end,
	check_facebook_login = function (self)
		return false
	end,
	get_active_days = function (self)
		local account = self.account
		local leveldb = account and account.leveldb
		local today = leveldb and leveldb.today

		return today and today.num or 0
	end,
	itemlist_can_add = function (self, list)
		local account = self.account

		return account and account:itemlist_can_add(list) or false
	end,
	is_iteminfo_full = function (self)
		local account = self.account

		return account and account:is_iteminfo_full()
	end,
	item_reclaim_onestep = function (self)
		return self:remote_call("shopsvr", "item_reclaim_onestep")
	end,
	get_item_reclaim_onestep_value = function (self)
		local account = self.account

		return account and account:get_item_reclaim_onestep_value()
	end,
	get_item_reclaim_onestep_list = function (self)
		local account = self.account
		local list = account and account:get_item_reclaim_onestep_list() or {}
		local n = #list

		for i = n, 1, -1 do
			if list[i][2] <= 0 then
				table.remove(list, i)
			end
		end

		return list
	end,
	get_network_delay = function (self)
		local conn = self.conn

		return conn and conn.delay or 0
	end,
	avatar_skin_buy = function (self, Uin, ModelID)
		return self.cluster.avatar.skin_buy(Uin, ModelID)
	end,
	avatar_skin_buy_list = function (self, list)
		return self.cluster.avatar.skin_buy_list(list)
	end,
	avatar_skin_info_page = function (self, Part, Min, Max)
		return self.cluster.avatar.skin_info_page(Part, Min, Max)
	end,
	avatar_skin_cfg_page = function (self, Part, Min, Max)
		return self.cluster.avatar.skin_cfg_page(Part, Min, Max)
	end,
	avatar_seat_unlock = function (self, seatid)
		return self.cluster.avatar.seat_unlock(seatid)
	end,
	avatar_seat_info = function (self, seatid)
		local code, seatDef = self.cluster.avatar.seat_info(seatid)

		if seatDef and type(seatDef) == "table" and type(seatDef.skin) == "table" then
			for k, v in pairs(seatDef.skin or {}) do
				if v.skin and v.skin.ModelID == 679 then
					seatDef.skin[k].skin.Data = nil

					break
				end
			end
		end

		return code, seatDef
	end,
	avatar_other_seat_info = function (self, Uin, seatid)
		if self.other_avatar_req_lock then
			return ErrorCode.PRECHECK_SLOWDOWN_PLEASE
		end

		self.other_avatar_req_lock = true
		local ret = {
			self.cluster.avatar.other_seat_info(Uin, seatid)
		}
		self.other_avatar_req_lock = false

		return unpack(ret)
	end,
	avatar_seat_save = function (self, seatid, info)
		for k, v in pairs(info.skin) do
			if v.skin and v.skin.ModelID == 679 then
				info.skin[k].skin.Data = nil

				break
			end
		end

		return self.cluster.avatar.seat_save(seatid, info)
	end,
	avatar_seat_reset = function (self, seatid)
		return self.cluster.avatar.seat_reset(seatid)
	end,
	avatar_seat_list = function (self, include_vip)
		local account = self.account

		if not account then
			return ErrorCode.FAILED
		end

		local list = account:avatar_seat_list(include_vip)

		print("avatar_seat_list", list)

		for i = #list, 0, -1 do
			self.cluster.avatar.seat_info(list[i])
		end

		if list and #list > 0 then
			return ErrorCode.OK, list
		end

		local code = self:remote_call("shopsvr", "avatar_seat_init")

		if code ~= ErrorCode.OK then
			return code
		end

		account:avatar_seat_init_vip()

		return ErrorCode.OK, account:avatar_seat_list(include_vip)
	end,
	avatar_free_seat_list = function (self, include_vip)
		local account = self.account

		if not account then
			return ErrorCode.FAILED
		end

		local list = account:avatar_free_seat_list(include_vip)

		if list and #list > 0 then
			return ErrorCode.OK, list
		end

		local code = self:remote_call("shopsvr", "avatar_seat_init")

		if code ~= ErrorCode.OK then
			return code
		end

		account:avatar_seat_init_vip()

		return ErrorCode.OK, account:avatar_free_seat_list(include_vip)
	end,
	avatar_seat_current = function (self)
		local account = self.account

		if not account then
			return 0
		end

		local seatid = account:avatar_seat_current()

		if not seatid then
			return 0
		end

		return seatid
	end,
	avatar_seat_count_info = function (self)
		local code, ret = self:remote_call("shopsvr", "avatar_seat_count_info")

		return ret
	end,
	avatar_seat_takeoff = function (self)
		return self:remote_call("shopsvr", "avatar_seat_takeoff")
	end,
	avatar_seat_use = function (self, seatid)
		return self:remote_call("shopsvr", "avatar_seat_use", seatid)
	end,
	avatar_seat_cfg = function (self, seatid)
		local AvatarSeat = loadwwwcache("res.AvatarSeat")

		if seatid then
			return AvatarSeat and AvatarSeat[tonumber(seatid)] or nil
		else
			return AvatarSeat
		end
	end,
	avatar_default_cfg_list = function (self)
		local account = self.account
		local leveldb = account and account.leveldb

		return leveldb and leveldb.avatar and leveldb.avatar.default or nil
	end,
	avatar_official_skin_cfg_list = function (self)
		if self.cluster.avatar.official_skin_cfg_list then
			local code, list = self.cluster.avatar.official_skin_cfg_list()

			if code == ErrorCode.OK then
				return list
			else
				return {}
			end
		else
			return {}
		end
	end,
	avatar_skin_info_list = function (self, cfglist)
		local ret = {
			self.cluster.avatar.skin_info_list(cfglist)
		}

		return unpack(ret)
	end,
	avatar_skin_count = function (self)
		if self.cluster.avatar.avatar_skin_count then
			local code, count = self.cluster.avatar.avatar_skin_count()

			if code == ErrorCode.OK then
				return count
			end
		end

		return 0
	end,
	avatar_had_list = function (self)
		if self.cluster.avatar.avatar_had_list then
			local code, list = self.cluster.avatar.avatar_had_list()

			if code == ErrorCode.OK then
				return list
			end
		end

		return {}
	end,
	avatar_wish_list = function (self)
		local account = self.account

		return table.clone(account and account:avatar_wish_list())
	end,
	avatar_wish_add = function (self, id)
		return self.cluster.avatar.wish_add(id)
	end,
	avatar_wish_rm = function (self, id)
		return self.cluster.avatar.wish_rm(id)
	end,
	write_off_verify = function (self, infos)
		if not infos or not next(infos) or not infos.type then
			local error_report = "infos is wrong" .. tostring(infos)

			self:oplog_login_error("", "write_off_verify", error_report)

			return ErrorCode.ERROR_PARAMS
		end

		local account = self.account

		if not account then
			local error_report = "account is wrong"

			self:oplog_login_error("", "write_off_verify", error_report)

			return ErrorCode.PRECHECK_ERROR
		end

		local conn = self.conn

		if not conn then
			local error_report = "conn is wrong"

			self:oplog_login_error("", "write_off_verify", error_report)

			return ErrorCode.PRECHECK_ERROR
		end

		infos.uin = account.Uin
		infos.token = conn.token
		local ret = self:http_login("login", "write_off_auth", infos)

		if ret and ret.code then
			return ret.code
		end

		return ErrorCode.FAILED
	end,
	write_off = function (self, info)
		local account = self.account

		if not account then
			return ErrorCode.FAILED
		end

		local Uin = account.Uin

		if not Uin then
			return ErrorCode.FAILED
		end

		local code = self:remote_call("baseinfo", "write_off", info)

		if code == ErrorCode.OK then
			account:setuin(0)
			account:OnAccountDirty()

			local conn = self.conn

			conn:close()

			local chatpushconn = self.chatpushconn

			chatpushconn:close()
		end

		return code
	end,
	check_written_off = function (self)
		local account = self.account

		return account and account:check_written_off() or false
	end,
	order_loop = function (self)
		while true do
			pcall(function ()
				local account = self.account
				local order_info = account and account.order_info
				local order = order_info and order_info.order
				local OrderID = order and order.OrderID
				local OrderTime = order and order.OrderTime
				local order_notify_params = order_info and order_info.notify_params
				local now = self.now

				if type(OrderID) == "number" and type(OrderTime) == "number" and now - OrderTime >= 60 then
					if type(order_notify_params) == "table" then
						local code = self:remote_call("shopsvr", "order_notify", unpack(order_notify_params))

						if code == ErrorCode.OK or code == ErrorCode.PRECHECK_ORDER_CANCEL or code == ErrorCode.PAY_VERIFY_FAILED then
							account.order_info = nil

							return print("check order, notify order code = ", code)
						end
					end

					local code = self:remote_call("shopsvr", "order_check", OrderID)

					if code == ErrorCode.OK or code == ErrorCode.PRECHECK_ORDER_CANCEL or code == ErrorCode.PAY_VERIFY_FAILED then
						account.order_info = nil

						return print("check order code = ", code)
					end

					self.diffTime = 30 - (300 - (now - OrderTime)) % 30

					if now - OrderTime > 300 then
						account.order_info = nil

						return print("check order timeout ", now - OrderTime, " OrderID", OrderID)
					end
				end
			end)
			threadpool:wait(30)
		end
	end,
	get_account_history_list = function (self)
		local map = {}
		local history = self:load_from_file("history")

		if not history then
			local all_accounts_json = GetClientInfo():getAllAccountInfos()

			if all_accounts_json then
				local json = JSON:decode(all_accounts_json)

				if json and type(json) == "table" then
					history = {}

					for i, v in ipairs(json) do
						if type(v) == "string" then
							local data = JSON:decode(v)

							table.insert(history, data.data)
						end
					end

					self:save_to_file("history", history)
				end
			end
		end

		if type(history) == "table" then
			for i, v in ipairs(history) do
				local Uin = type(v) == "table" and v.Uin

				if Uin then
					map[Uin] = map[Uin] or delegate(function ()
						local PasswdLength = v.Passwd and #v.Passwd or 0
						local t = {
							Uin = Uin,
							Order = i,
							PasswdLength = PasswdLength
						}
						local local_data = self:load_from_file("account_" .. Uin)
						local RoleInfo = local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.RoleInfo
						t.NickName = RoleInfo and RoleInfo.NickName or ""

						return t
					end)
				end
			end
		end

		local list = {}

		for k, v in pairs(map) do
			table.insert(list, v)
		end

		table.sort(list, function (a, b)
			return b.Order < a.Order
		end)

		for i, v in ipairs(list) do
			v.Order = nil
		end

		return list
	end,
	get_account_list = function (self)
		local map = {}
		local history = self:load_from_file("history")

		if type(history) == "table" then
			for i, v in ipairs(history) do
				local Uin = type(v) == "table" and v.Uin

				if Uin then
					map[Uin] = true
				end
			end
		end

		local current = self:load_from_file("current")
		local Uin = current and current.Uin

		if type(Uin) == "number" and Uin > 1000 then
			map[Uin] = true
		end

		local account = self.account
		local Uin = account and account.Uin

		if type(Uin) == "number" and Uin > 1000 then
			map[Uin] = true
		end

		local list = {}

		for k, v in pairs(map) do
			table.insert(list, k)
		end

		return list
	end,
	get_user_birthday = function (self)
		return {
			year = 1980,
			month = 1
		}
	end,
	check_older_than_13 = function (self)
		local env = utils.env or 0

		if env ~= 1 and env < 10 then
			return true
		end

		local limit = ns_version and ns_version.hw_age or 13
		local birthday = self:get_user_birthday()

		if birthday then
			local year = birthday.year
			local month = birthday.month
			local now = self.now
			local date = os.date("*t", now)

			return date.year * 12 + date.month - (year * 12 + month) >= limit * 12
		else
			return false
		end
	end,
	set_user_birthday = function (self, birthday)
		local env = utils.env

		if env ~= 1 and env < 10 then
			return ErrorCode.OK
		end

		local account = self.account

		if account then
			print("set_user_birthday ", birthday)

			if type(birthday) == "table" and type(birthday.year) == "number" and type(birthday.month) == "number" then
				account.birthday = birthday
			else
				print("birthday 格式不对")
			end

			return self:data_update(true)
		end

		return ErrorCode.FAILED
	end,
	dev_mapstore_get_itemlist = function (self, Uin, MapID, Force)
		if Uin ~= tonumber(MapID) % client_M.__UINT32__ then
			return ErrorCode.NONE, {}
		end

		return self.cluster.developer.mapstore_get_itemlist(Uin, tostring(MapID), Force)
	end,
	dev_mapstore_set_item_info = function (self, Uin, MapID, Info)
		assert(Uin == tonumber(MapID) % client_M.__UINT32__)

		return self.cluster.developer.mapstore_set_iteminfo(Uin, tostring(MapID), Info)
	end,
	dev_mapstore_set_iteminfo_list = function (self, Uin, MapID, List)
		assert(Uin == tonumber(MapID) % client_M.__UINT32__)

		local ret = {
			self.cluster.developer.mapstore_set_iteminfo_list(Uin, tostring(MapID), List)
		}

		if ret[1] ~= ErrorCode.OK then
			self:show_errormsg(ret[1])
		end

		return unpack(ret)
	end,
	dev_mapstore_rm_iteminfo = function (self, Uin, MapID, ItemID)
		assert(Uin == tonumber(MapID) % client_M.__UINT32__)

		return self.cluster.developer.mapstore_rm_iteminfo(Uin, tostring(MapID), ItemID)
	end,
	dev_mapstore_rm_iteminfo_list = function (self, Uin, MapID, ItemIDList)
		assert(Uin == tonumber(MapID) % client_M.__UINT32__)

		local ret = {
			self.cluster.developer.mapstore_rm_iteminfo_list(Uin, tostring(MapID), ItemIDList)
		}

		if ret[1] ~= ErrorCode.OK then
			self:show_errormsg(ret[1])
		end

		return unpack(ret)
	end,
	dev_mapstore_get_itemgroup_list = function (self, Uin, MapID, Force)
		assert(Uin == tonumber(MapID) % client_M.__UINT32__)

		return self.cluster.developer.mapstore_get_itemgroup_list(Uin, tostring(MapID), Force)
	end,
	dev_mapstore_add_itemgroup = function (self, Uin, MapID, Info)
		assert(Uin == tonumber(MapID) % client_M.__UINT32__)

		return self.cluster.developer.mapstore_add_itemgroup(Uin, tostring(MapID), Info)
	end,
	dev_mapstore_set_itemgroup_list = function (self, Uin, MapID, List)
		assert(Uin == tonumber(MapID) % math.pow(2, 32))

		local ret = {
			self.cluster.developer.mapstore_set_itemgroup_list(Uin, tostring(MapID), List)
		}

		if ret[1] ~= ErrorCode.OK then
			self:show_errormsg(ret[1])
		end

		return unpack(ret)
	end,
	dev_mapstore_rm_itemgroup = function (self, Uin, MapID, ItemGroupID)
		assert(Uin == tonumber(MapID) % math.pow(2, 32))

		return self.cluster.developer.mapstore_rm_itemgroup(Uin, tostring(MapID), ItemGroupID)
	end,
	dev_mapstore_rm_itemgroup_list = function (self, Uin, MapID, ItemGroupList)
		assert(Uin == tonumber(MapID) % math.pow(2, 32))

		local ret = {
			self.cluster.developer.mapstore_rm_itemgroup_list(Uin, tostring(MapID), ItemGroupList)
		}

		if ret[1] ~= ErrorCode.OK then
			self:show_errormsg(ret[1])
		end

		return unpack(ret)
	end,
	dev_mapstore_check_locked = function (self, Uin, MapID, force)
		return self.cluster.developer.mapstore_check_locked(Uin, MapID, force)
	end,
	dev_mapbag_get_itemlist = function (self, AuthorUin, MapID, Force)
		return self.cluster.developer.mapbag_get_itemlist(AuthorUin, tostring(MapID), Force)
	end,
	dev_mapbag_buy_item = function (self, HostUin, AuthorUin, MapID, ItemID, ItemNum, RoomID, extend_data)
		local gameSessionId = nil

		if get_game_session_id then
			gameSessionId = get_game_session_id()
		end

		local code, other = self.cluster.developer.mapbag_buy_item(HostUin, AuthorUin, tostring(MapID), ItemID, ItemNum, RoomID, extend_data, self:GetCurGameBiddingPlanID(), gameSessionId)

		if code == ErrorCode.DEV_MAPSTORE_CHEST_LEVEL_NOT_ENOUGH then
			-- Nothing
		end

		return code
	end,
	dev_mapbag_ad_add_item_by_order = function (self, order_id)
		local code = self.cluster.developer.mapbag_dev_ad_add_item_by_order(order_id)

		return code
	end,
	dev_mapbag_ad_buy_item_order = function (self, HostUin, AuthorUin, MapID, ItemID, ItemNum, ItemDesc, AD_PosID, RoomID, extend_data)
		local PlanID = self:GetCurGameBiddingPlanID()

		if PlanID then
			if extend_data == nil then
				extend_data = {}
			end

			if type(extend_data) == "table" then
				extend_data.PlanID = PlanID
			end
		end

		local code, other = self.cluster.developer.mapbag_dev_ad_buy_item_order(HostUin, AuthorUin, tostring(MapID), ItemID, ItemNum, ItemDesc, AD_PosID, RoomID, extend_data)

		if code == ErrorCode.DEV_MAPSTORE_CHEST_LEVEL_NOT_ENOUGH then
			-- Nothing
		end

		return code, other
	end,
	dev_mapbag_dev_ad_buy_item = function (self, HostUin, AuthorUin, MapID, ItemID, ItemNum, ItemDesc, AD_PosID, RoomID, extend_data)
		local PlanID = self:GetCurGameBiddingPlanID()

		if PlanID then
			if extend_data == nil then
				extend_data = {}
			end

			if type(extend_data) == "table" then
				extend_data.PlanID = PlanID
			end
		end

		local code, other = self.cluster.developer.mapbag_dev_ad_buy_item(HostUin, AuthorUin, tostring(MapID), ItemID, ItemNum, ItemDesc, AD_PosID, RoomID, extend_data)

		if code == ErrorCode.DEV_MAPSTORE_CHEST_LEVEL_NOT_ENOUGH then
			-- Nothing
		end

		return code
	end,
	dev_mapbag_dev_adpoint_buy_item = function (self, HostUin, AuthorUin, MapID, ItemID, ItemNum, ItemDesc, RoomID, extend_data, reportInfo)
		local PlanID = self:GetCurGameBiddingPlanID()
		local gameSessionId = nil

		if get_game_session_id then
			gameSessionId = get_game_session_id()
		end

		local code, other = self.cluster.developer.mapbag_dev_adpoint_buy_item(HostUin, AuthorUin, tostring(MapID), ItemID, ItemNum, ItemDesc, RoomID, extend_data, reportInfo, PlanID, gameSessionId)

		if code == ErrorCode.DEV_MAPSTORE_CHEST_LEVEL_NOT_ENOUGH then
			-- Nothing
		end

		return code
	end,
	dev_mapbag_consume_item = function (self, HostUin, AuthorUin, MapID, ItemID, ItemNum)
		return self.cluster.developer.mapbag_consume_item(HostUin, AuthorUin, tostring(MapID), ItemID, ItemNum)
	end,
	dev_developer_info = function (self, Uin)
		print("dev_developer_infodev_developer_info")

		if self.developerCode ~= nil and self.developerCode == ErrorCode.OK then
			return self.developerCode, self.developerInfo, self.developerCfg
		end

		local ret = {
			self.cluster.developer.developer_info(Uin)
		}
		local code, info, cfg = unpack(ret)

		if code == ErrorCode.OK then
			self.developerCode = code
			self.developerInfo = info
			self.developerCfg = cfg
		end

		self.developerInfo = unpack(ret)

		return unpack(ret)
	end,
	reset_dev_developer_info = function (self)
		self.developerCode = nil
		self.developerInfo = nil
		self.developerCfg = nil
	end,
	realname_check_loop = function (self)
		local ApiID = LuaInterface:getApiId()
		local CltVersion = LuaInterface:getCltVersion()
		local env = utils.env
		local Config = loadwwwcache("res.Config")
		local RealName = Config and Config.RealName

		if not RealName then
			return false
		end

		local closeenv = RealName.closeenv
		closeenv = tostring(closeenv)

		if closeenv ~= "" and closeenv ~= "nil" then
			local l = utils.split(closeenv, ",")

			for i, v in ipairs(l) do
				if tostring(env) == v then
					print(" 当前环境不开启realname_loop env = ", env, " ", v)

					return false
				end
			end
		end

		if env == 1 then
			local in_whitelist = false
			local current = container and container:load_from_file("current")
			local Uin = current and current.Uin or 0

			if Uin and Uin > 1000 then
				local uinlist = RealName.uinlist
				uinlist = tostring(uinlist)

				if uinlist ~= "" and uinlist ~= "nil" then
					local l = utils.split(uinlist, ",")

					for i, v in ipairs(l) do
						if tostring(Uin) == v then
							print("命中了uin白名单")

							in_whitelist = true

							break
						end
					end
				end
			end

			if in_whitelist == false then
				return false
			end
		end

		if env == 1 and ApiID == 999 then
			return true
		end

		if ApiID >= 100 then
			return false
		end

		if CltVersion <= 7683 then
			return false
		end

		return true
	end,
	realname_check_in_limit_time = function (self)
		local Config = loadwwwcache("res.Config")
		local RealName = Config and Config.RealName

		if not RealName then
			return false
		end

		local in_time = false
		local timeout = 0
		local now = threadpool:now()
		local date = os.date("*t", now)
		local hour = date.hour
		local min = date.min
		local timelist = RealName.timelist

		for i, v in ipairs(timelist) do
			if v[1] <= hour * 60 + min and hour * 60 + min <= v[2] then
				in_time = true
				timeout = (hour * 60 + min - v[1]) * 60

				break
			end
		end

		if in_time == false then
			return false
		end

		return true, timeout
	end,
	realname_get_age = function (self)
		local account = self.account
		local leveldb = account and account.leveldb
		local Uin = account and account.Uin

		if not leveldb then
			local current = container:load_from_file("current")
			Uin = current and current.Uin

			if type(Uin) ~= "number" or Uin < 1000 then
				return ErrorCode.FAILED
			end

			local local_data = container:load_from_file("account_" .. Uin)
			leveldb = local_data and local_data.leveldb
		end

		if type(Uin) ~= "number" or Uin < 1000 then
			return ErrorCode.FAILED
		end

		local idcard_info = leveldb and leveldb.idcard
		local age = 0
		local countryauthpi = 0
		local birthday = ""

		if self:realname_state() == 1 then
			if idcard_info.age then
				age = idcard_info.age
				countryauthpi = idcard_info.countryauthpi or 0
				birthday = idcard_info.birth
			elseif idcard_info.channelauth and idcard_info.channelauth.isauth == 1 then
				age = idcard_info.channelauth.age
			end

			return ErrorCode.OK, {
				status = "authed",
				Uin = Uin,
				age = age,
				countryauthpi = countryauthpi,
				birthday = birthday
			}
		else
			return ErrorCode.OK, {
				status = "not_auth_yet",
				Uin = Uin
			}
		end

		return ErrorCode.FAILED
	end,
	realname_state = function (self)
		local account = self.account
		local leveldb = account and account.leveldb
		local idcard_info = leveldb and leveldb.idcard

		print("idcard info", idcard_info)

		if AccountManager:isLogin() and RealNameModule:HitChannelAuth() then
			local authState = idcard_info and idcard_info.channelauth

			if authState and authState.isauth == 1 then
				return 1
			end
		end

		if AccountManager:isLogin() and RealNameModule:HitChannelPriorityAuth() then
			local authState = idcard_info and idcard_info.channelauth

			if authState and authState.isauth == 1 then
				return 1
			end
		end

		if ns_version.opennewauth == 1 then
			local authState = leveldb and leveldb.countryauthstatus
			local pi = idcard_info and idcard_info.countryauthpi or nil

			if pi and string.len(pi) == 38 then
				return 1
			elseif pi and pi == "authing" or authState == 1 then
				return 3
			elseif pi and pi == "authfail" or authState == 2 then
				return 2
			elseif type(idcard_info) == "table" and type(idcard_info.authed) == "table" and idcard_info.authed["1"] and idcard_info.authed["1"] == "ok" and idcard_info.authed["2"] and idcard_info.authed["2"] == "ok" then
				return 1
			else
				return 0
			end
		elseif type(idcard_info) == "table" and type(idcard_info.authed) == "table" and (idcard_info.authed["1"] and idcard_info.authed["1"] == "ok" or idcard_info.authed["2"] and idcard_info.authed["2"] == "ok") then
			return 1
		else
			return 0
		end
	end,
	ar_cdkey = function (self, cdkey)
		local code, cdkeytype, list = self:remote_call("shopsvr", "ar_cdkey", cdkey)

		if code == ErrorCode.OK then
			local ret = {}
			local result = self:ctxpop("cdkey.result")

			if result then
				ret.itemlist = result
			end

			local skinlist = self:ctxpop("cdkey.skinlist")

			if skinlist then
				ret.skinlist = skinlist
			end

			print("ar_cdkey code:", code, " ret:", ret)

			return code, ret
		else
			print("ar_cdkey code:", code)

			return code
		end
	end,
	can_water = function (self, Uin)
		local account = self.account

		if not account then
			return false
		end

		if not Uin or Uin == account.Uin then
			return account:precheck("water_self") == ErrorCode.OK
		else
			return account:precheck("water_other", Uin) == ErrorCode.OK
		end
	end,
	can_bug = function (self, Uin)
		local account = self.account

		if not account then
			return false
		end

		if not Uin or Uin == account.Uin then
			return false
		else
			return account:precheck("bug_other", Uin) == ErrorCode.OK
		end
	end,
	getloginsafeverify = function (self)
		if self.account and self.account.leveldb and self.account.leveldb.isloginsafeverify then
			return self.account.leveldb.isloginsafeverify
		end

		return false
	end,
	get_uploadmap_flag = function (self)
		local DeviceID = GetClientInfo():getDeviceID() or "cantget"

		if self.account and self.account.leveldb and self.account.leveldb.uploadmap_sms then
			for k, v in pairs(self.account.leveldb.uploadmap_sms) do
				if v.DeviceID == DeviceID and threadpool:now() - v.time < 15552000 then
					return false
				end
			end
		end

		return true
	end,
	setloginsafeverify = function (self, state)
		return self:remote_call("baseinfo", "set_loginsafeverify", state)
	end,
	setDeviceID = function (self, DeviceID)
		if self.account then
			return self:remote_call("baseinfo", "set_DeviceID", DeviceID)
		end
	end,
	set_guest = function (self, flag)
		return self:remote_call("baseinfo", "set_guest", flag)
	end,
	bindopenid = function (self, type, openid)
		return self:remote_call("baseinfo", "bindopenid", type, openid)
	end,
	unbindopenid = function (self, uin, type, openid)
		return self:remote_call("baseinfo", "unbindopenid", uin, type, openid)
	end,
	isbindopenid = function (self, type)
		if AccountManager:isLogin() == false then
			return false
		end

		local openid = self.account and self.account.leveldb and self.account.leveldb.openid

		if openid and openid[type] and #openid[type] > 0 then
			return true
		end

		return false
	end,
	is_bind_qq = function (self)
		local current = AccountManager:load_from_file("current")

		if current and current.authinfo and current.authinfo.openid_type and current.authinfo.openid_type == "qq" then
			return true
		end

		return false
	end,
	is_bind_wechat = function (self)
		local current = AccountManager:load_from_file("current")

		if current and current.authinfo and current.authinfo.openid_type and current.authinfo.openid_type == "wechat" then
			return true
		end

		return false
	end,
	bind_unionid = function (self, info)
		local account = self.account
		local Uin = account.Uin
		local conn = self.conn

		if not info.code and not info.access_token then
			return ErrorCode.FAILED, "is no code or access_token"
		end

		info.uin = Uin
		info.bind = 1
		info.token = conn.token
		local ret = self:http_login("login", "bind_openid", info)

		if ret and ret.code == 0 then
			self:data_update(true)

			ret.code = "OK"
		end

		return ret
	end,
	unbind_unionid = function (self, info)
		local account = self.account
		local Uin = account.Uin

		if not info.code and not info.access_token then
			return ErrorCode.FAILED, "is no code or access_token"
		end

		info.uin = Uin
		info.bind = 0
		local conn = self.conn
		info.token = conn.token
		local ret = self:http_login("login", "bind_openid", info)

		if ret and ret.code == 0 then
			self:data_update(true)

			ret.code = "OK"
		end

		return ret
	end,
	code2num = function (self, code)
		if type(code) == "string" then
			return ErrorCode[code] or code
		else
			return code
		end
	end,
	unionid_login = function (self, info, switch)
		local first_login = nil
		local ret = {}

		if info and info.appid then
			ret = self:http_login("login", "openid_login", info)

			print("unionid_login", ret)

			ret = ret or {}
			ret.code = self:code2num(ret.code) or ErrorCode.FAILED

			if ret.code == ErrorCode.OK then
				container:save_to_file("current", {
					Uin = ret.baseinfo.Uin,
					authinfo = ret.authinfo
				})

				if ret.baseinfo.RoleInfo.NickName and ret.baseinfo.RoleInfo.NickName == "" then
					first_login = "first_login"
				end

				local history = self:load_from_file("history")

				if history then
					table.insert(history, {
						Uin = ret.baseinfo.Uin,
						authinfo = ret.authinfo
					})
					self:save_to_file("history", history)
				else
					history = {}

					table.insert(history, {
						Uin = ret.baseinfo.Uin,
						authinfo = ret.authinfo
					})
					self:save_to_file("history", history)
				end
			else
				return ret.code, ret.datas, ret.msg
			end
		elseif info and info.token then
			local token = info.token
			local appid = info.appid
			local Uin = info.Uin

			if not Uin and not token and not appid then
				return self:code2num(ret.code) or ErrorCode.INVALID_ARG, ret.datas, ret.msg or GetS(16314)
			end

			local info_token = {
				appid = appid,
				token = token,
				source = info.source or 3
			}
			ret = self:http_login("login", "openid_login", info_token)
			ret = ret or {}
			ret.code = self:code2num(ret.code) or ErrorCode.FAILED

			if ret.code == ErrorCode.OK then
				container:save_to_file("current", {
					Uin = ret.baseinfo.Uin,
					authinfo = ret.authinfo
				})

				if ret.baseinfo.RoleInfo.NickName and ret.baseinfo.RoleInfo.NickName == "" then
					first_login = "first_login"
				end

				local history = self:load_from_file("history")

				if history then
					table.insert(history, {
						Uin = ret.baseinfo.Uin,
						authinfo = ret.authinfo
					})
					self:save_to_file("history", history)
				else
					history = {}

					table.insert(history, {
						Uin = ret.baseinfo.Uin,
						authinfo = ret.authinfo
					})
					self:save_to_file("history", history)
				end
			else
				return ret.code, ret.datas, ret.msg
			end
		end

		local code = ErrorCode.FAILED
		local datas = {}
		local msg = nil

		if switch then
			code, datas, msg = self:switchAccountByAuthInfo_reg(ret.authinfo, first_login)
		else
			code, datas, msg = self:requestEnterGameWithAuthInfo(ret.authinfo)
		end

		if ErrorCode.OK == code then
			self.account:flush()

			if ReportMgr and ReportMgr.setLoginType then
				ReportMgr:setLoginType(tostring(ret.authinfo and ret.authinfo.openid_type))
			end
		else
			if ReportMgr and ReportMgr.setLoginType then
				ReportMgr:setLoginType("")
			end

			return code, datas, msg or "进入游戏失败"
		end

		datas.first_login = first_login

		return code, datas, msg
	end,
	unionid_reg_bind_login_kuaishou = function (self, info, switch)
		print("unionid_reg_bind_login_kuaishou", ret)

		local ret = self:http_login("login", "reg_bind_login_kuaishou", info)
		ret = ret or {}
		ret.code = self:code2num(ret.code) or ErrorCode.FAILED

		if ret.code == ErrorCode.OK then
			container:save_to_file("current", {
				Uin = ret.baseinfo.Uin,
				authinfo = ret.authinfo
			})
		else
			return ret.code, ret.datas, ret.msg
		end

		local code = ErrorCode.FAILED
		local datas = {}
		local msg, first_login = nil
		ret.authinfo.isnewuser = true

		if switch then
			code, datas, msg = self:switchAccountByAuthInfo_reg(ret.authinfo, true)
		else
			code, datas, msg = self:requestEnterGameWithAuthInfo(ret.authinfo)
		end

		if ErrorCode.OK == code then
			first_login = "first_login"

			self.account:flush()
		end

		datas.first_login = first_login

		return code, datas, msg
	end,
	unionid_bind_login_kuaishou = function (self, info, switch)
		local ret = self:http_login("login", "openid_bind_login_kuaishou", info)

		print("unionid_bind_login_kuaishou", ret)

		ret = ret or {}
		ret.code = self:code2num(ret.code) or ErrorCode.FAILED

		if ret.code == ErrorCode.OK then
			container:save_to_file("current", {
				Uin = ret.baseinfo.Uin,
				authinfo = ret.authinfo
			})
		else
			return ret.code, ret.datas, ret.msg
		end

		local code = ErrorCode.FAILED
		local datas = {}
		local msg = nil

		if switch then
			code, datas, msg = self:switchAccountByAuthInfo_reg(ret.authinfo)
		else
			code, datas, msg = self:requestEnterGameWithAuthInfo(ret.authinfo)
		end

		if ErrorCode.OK == code then
			self.account:flush()
		else
			return code, datas, msg or "进入游戏失败"
		end

		return code, datas, msg
	end,
	unionid_login_kuaishou = function (self, info, switch)
		local first_login = nil
		local ret = {}
		local selfswitch = false

		if switch then
			local current = self:load_from_file("current")
			local Uin = current and current.Uin
			local authinfo = current and current.authinfo

			if info and info.Uin and Uin and Uin == info.Uin and authinfo then
				selfswitch = true
			end
		end

		if not selfswitch then
			ret = self:http_login("login", "openid_login_kuaishou", info)

			print("unionid_login_kuaishou", ret)

			ret = ret or {}
			ret.code = self:code2num(ret.code) or ErrorCode.FAILED

			if ret.code == ErrorCode.OK then
				container:save_to_file("current", {
					Uin = ret.baseinfo.Uin,
					authinfo = ret.authinfo
				})

				if ret.baseinfo.RoleInfo.NickName and ret.baseinfo.RoleInfo.NickName == "" then
					first_login = "first_login"
				end

				local history = self:load_from_file("history")

				if history then
					table.insert(history, {
						Uin = ret.baseinfo.Uin,
						authinfo = ret.authinfo
					})
					self:save_to_file("history", history)
				else
					history = {}

					table.insert(history, {
						Uin = ret.baseinfo.Uin,
						authinfo = ret.authinfo
					})
					self:save_to_file("history", history)
				end
			else
				return ret.code, ret.datas, ret.msg
			end
		else
			local current = self:load_from_file("current")
			ret.authinfo = current.authinfo
		end

		local code = ErrorCode.FAILED
		local datas = {}
		local msg = nil

		if switch then
			code, datas, msg = self:switchAccountByAuthInfo_reg(ret.authinfo, first_login)
		else
			code, datas, msg = self:requestEnterGameWithAuthInfo(ret.authinfo)
		end

		if ErrorCode.OK == code then
			self.account:flush()

			if ReportMgr and ReportMgr.setLoginType then
				ReportMgr:setLoginType(tostring(ret.authinfo and ret.authinfo.openid_type))
			end
		else
			if ReportMgr and ReportMgr.setLoginType then
				ReportMgr:setLoginType("")
			end

			return code, datas, msg or "进入游戏失败"
		end

		datas.first_login = first_login

		return code, datas, msg
	end,
	unionid_bind_login_dycloud = function (self, info)
		local ret = self:http_login_post("login", "unionid_bind_login_dycloud", info)

		print("unionid_bind_login_dycloud", ret)

		if ret and ret.code == "OK" then
			container:save_to_file("current", {
				Uin = ret.baseinfo.Uin,
				authinfo = ret.authinfo
			})
		else
			return ErrorCode.NONE, ret and ret.datas, ret and ret.msg or ""
		end

		local ret_code, ret_datas, ret_msg = self:requestEnterGameWithAuthInfo(ret.authinfo)

		if ErrorCode.OK == ret_code then
			self.account:flush()
		end

		return ret_code, ret_datas, ret_msg
	end,
	get_week_day = function (self, wday)
		if wday then
			if wday == 7 then
				return 6
			elseif wday == 6 then
				return 5
			elseif wday == 5 then
				return 4
			elseif wday == 4 then
				return 3
			elseif wday == 3 then
				return 2
			elseif wday == 2 then
				return 1
			elseif wday == 1 then
				return 7
			end
		end

		return 0
	end,
	oplog_login_check = function (self, is_realname_conf, is_realname_pass)
		local url = "https://tj3.mini1.cn/miniworld"
		local env = utils.env or 0

		if env == 1 then
			url = "http://120.24.64.132:8080/miniworld"
		end

		local account = self.account
		local code, info = self:realname_get_age()
		local age = 0
		local realname_auth = 0
		local birthday = ""

		if code == ErrorCode.OK and info then
			if info.status == "authed" then
				age = info.age or 0
				realname_auth = 1
				birthday = info.birthday
			elseif info.status == "not_auth_yet" then
				-- Nothing
			end
		end

		local is_adult = 0

		if age >= 18 then
			is_adult = 1
		end

		local json3 = {
			{
				log = "login_check",
				id = 66000,
				channel_age = 0,
				channel_isrealname = 0,
				is_channel_realname_pass = 0,
				uin = self.Uin,
				apiid = account and account.Account and account.Account.ApiID or 0,
				cltapiid = LuaInterface:getApiId(),
				cltversion = LuaInterface:getCltVersion(),
				country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or "null",
				language = get_game_lang and get_game_lang() or 0,
				ip = self:get_outer_ip_and_delay(),
				ts = getServerTime(),
				device_id = GetClientInfo():getDeviceID(),
				is_realname_conf = is_realname_conf or 0,
				is_realname_pass = is_realname_pass or 0,
				countryauthpi = info and info.countryauthpi or 0,
				is_real_neme = realname_auth,
				birthday = birthday,
				is_adult = is_adult,
				age = age,
				env = env
			}
		}
		local data = "json3=" .. table2json(json3)

		ns_http.func.rpc_do_http_post(url, nil, nil, data)
	end,
	oplog_login_check_connect = function (self, uin, msg)
		local url = "https://tj3.mini1.cn/miniworld"
		local env = utils.env or 0

		if env == 1 then
			url = "http://120.24.64.132:8080/miniworld"
		end

		local account = self.account
		local conn = self.conn
		local json3 = {
			{
				log = "login_check_connect",
				is_adult = 0,
				id = 66000,
				channel_age = 0,
				age = 0,
				is_real_neme = 0,
				channel_isrealname = 0,
				is_channel_realname_pass = 0,
				birthday = 0,
				uin = uin,
				apiid = account and account.Account and account.Account.ApiID or 0,
				cltapiid = LuaInterface:getApiId(),
				cltversion = LuaInterface:getCltVersion(),
				country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or "null",
				language = get_game_lang and get_game_lang() or 0,
				ip = self:get_outer_ip_and_delay(),
				ts = getServerTime(),
				device_id = GetClientInfo():getDeviceID(),
				is_realname_conf = is_realname_conf or 0,
				is_realname_pass = is_realname_pass or 0,
				countryauthpi = (msg or "null") .. "###" .. self.conn.token or "tokennill",
				env = env
			}
		}
		local data = "json3=" .. table2json(json3)

		ns_http.func.rpc_do_http_post(url, nil, nil, data)
	end,
	oplog_login_error = function (self, uin, fun, error, msg)
		local url = "https://tj3.mini1.cn/miniworld"
		local env = utils.env or 0

		if env == 1 then
			url = "http://120.24.64.132:8080/miniworld"
		end

		local urlpath = LuaInterface:geturl():gsub("/$", ""):gsub("/", "_"):gsub(":", "_") .. "/"
		local prefix = client_M.StdioRoot .. "data/account/" .. urlpath
		local current, history = nil
		local ff = io.open(prefix .. "current.data2tmp", "r")

		if ff then
			current = ff:read("*a")

			ff:close()
		end

		local hh = io.open(prefix .. "history.data2tmp", "r")

		if hh then
			history = hh:read("*a")

			hh:close()
		end

		local json3 = {
			{
				log = "login_error",
				id = 66001,
				uin = uin,
				cltapiid = LuaInterface:getApiId(),
				cltversion = LuaInterface:getCltVersion(),
				country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or "null",
				language = get_game_lang and get_game_lang() or 0,
				ip = self:get_outer_ip_and_delay(),
				ts = getServerTime(),
				device_id = GetClientInfo():getDeviceID(),
				error = error,
				fun = fun,
				current = current and ns_http.func.url_encode(current) or "null",
				history = history and ns_http.func.url_encode(history) or "null",
				msg = msg or "null",
				env = env
			}
		}
		local data = "json3=" .. table2json(json3)
		local a = ns_http.func.rpc_do_http_post(url, nil, nil, data)
	end,
	oplog_login_error_version = function (self, uin, fun, error, msg)
		local url = "http://139.159.177.132/miniworld"
		local env = utils.env or 0

		if env == 1 then
			url = "http://120.24.64.132:8080/miniworld"
		end

		local urlpath = LuaInterface:geturl():gsub("/$", ""):gsub("/", "_"):gsub(":", "_") .. "/"
		local prefix = client_M.StdioRoot .. "data/account/" .. urlpath
		local current, history = nil
		local ff = io.open(prefix .. "current.data2tmp", "r")

		if ff then
			current = ff:read("*a")

			ff:close()
		end

		local hh = io.open(prefix .. "history.data2tmp", "r")

		if hh then
			history = hh:read("*a")

			hh:close()
		end

		local json3 = {
			{
				log = "login_error",
				id = 66001,
				uin = uin,
				cltapiid = LuaInterface:getApiId(),
				cltversion = LuaInterface:getCltVersion(),
				country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or "null",
				language = get_game_lang and get_game_lang() or 0,
				ip = self:get_outer_ip_and_delay(),
				ts = getServerTime(),
				device_id = GetClientInfo():getDeviceID(),
				error = error,
				fun = fun,
				current = current and ns_http.func.url_encode(current) or "null",
				history = history and ns_http.func.url_encode(history) or "null",
				msg = msg or "null",
				env = env
			}
		}
		local data = "json3=" .. table2json(json3)
		local a = ns_http.func.rpc_do_http_post(url, nil, nil, data)
	end,
	disconnect_check_login = function (self)
		local Disconnect_net_num = 0
		local Disconn_net_num = 0

		while true do
			local netstate = GetClientInfo():getNetworkState() or 1

			if netstate == 0 then
				Disconnect_net_num = Disconnect_net_num + 1

				if Disconnect_net_num >= 4 then
					local conn = self.conn

					conn:close()

					if ShowGameTipsWithoutFilter then
						ShowGameTipsWithoutFilter(GetS(35206))
					end

					threadpool:wait(5)
					LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
				end
			else
				Disconnect_net_num = 0
			end

			if ns_version and ns_version.disconnect_check and ns_version.disconnect_check == true then
				local conn = self.conn

				print("disconnect_check_login check", Disconn_net_num, conn.authed)

				if not conn.authed then
					print("disconnect_check_login", Disconn_net_num)

					Disconn_net_num = Disconn_net_num + 1

					if Disconn_net_num >= 3 then
						threadpool:wait(5)
						LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
					end
				else
					Disconn_net_num = 0
				end
			end

			threadpool:wait(10)
		end
	end,
	disconnect_check_server = function (self)
		self.disconnect_check_server_flag = true

		while self.disconnect_check_server_flag do
			local Disconn_server_num = 0
			local conn = self.conn

			if isInMainGame and (not conn or not conn.is_doing_rpc) then
				local os_time = os.time()
				local recv_time = conn.recv_msg_time or 0

				print("循环检测", os.date("%Y-%m-%d %H:%M:%S", os_time), os.date("%Y-%m-%d %H:%M:%S", recv_time), "间隔时间", os_time - recv_time)

				if os_time - recv_time > 180 then
					print("超过3分钟未收到服务器消息")

					local code = conn:heartbeat()

					if code ~= ErrorCode.OK then
						Disconn_server_num = Disconn_server_num + 1
					else
						Disconn_server_num = 0
					end
				else
					print("3分钟之内有收到服务器消息")

					Disconn_server_num = 0
				end
			else
				Disconn_server_num = 0
			end

			if Disconn_server_num > 3 then
				Disconn_server_num = 0
				local url = "http://139.159.177.132/miniworld"
				local env = utils.env or 0

				if env == 1 then
					url = "http://120.24.64.132:8080/miniworld"
				end

				local account = self.account
				local uin = account and account.Uin or 0
				local json3 = {
					{
						log = "disconnect_check_server",
						id = 66003,
						uin = uin,
						apiid = account and account.Account and account.Account.ApiID or 0,
						cltapiid = LuaInterface:getApiId(),
						cltversion = LuaInterface:getCltVersion(),
						country = type(gFunc_getCountry) == "function" and gFunc_getCountry() or "null",
						language = get_game_lang and get_game_lang() or 0,
						ts = getServerTime(),
						device_id = GetClientInfo():getDeviceID(),
						env = env,
						Disconn_server_num = Disconn_server_num,
						token = conn.token,
						sign = conn.sign
					}
				}
				local data = "json3=" .. table2json(json3)

				ns_http.func.rpc_do_http_post(url, nil, nil, data)
			end

			threadpool:wait(120)
		end
	end,
	online_report_loop = function (self)
		local space_time = 60

		while true do
			threadpool:wait(space_time)
			print("online_report_loop", self.conn.authed)

			if self.account and self.account.online_report_flag then
				print("online_report_flag", self.account.online_report_flag)
				self:remote_call("baseinfo", "online_report", space_time)
			end
		end
	end,
	version_check_login = function (self, uin)
		RealNameModule:PreSetAuthInfo()

		self.is_real_login = false
		local ApiID = LuaInterface:getApiId()
		local version = LuaInterface:getCltVersion() or 66561
		local loginflag = false
		local tips_msg = "版本过低，请前往应用商店升级至最新版本"
		local wait_time = 0

		while true do
			if not ns_version or not ns_version.limit_rule_login_open then
				if WWW_file_download and wait_time == 0 then
					WWW_file_download("version")
				end

				if wait_time > 2 then
					if not ns_version then
						local error_report = "ns_version is null"

						self:oplog_login_error(uin, "version_check_login", error_report)
					else
						local file_name_, download_ = getLuaConfigFileInfo("version")
						local md5_ = ns_data.cf_md5s.version
						local error_report = ""

						if md5_ then
							error_report = "ns_version limit_rule_login_open is null file_name_:" .. file_name_ .. " download_:" .. download_ .. "ns_data:" .. md5_

							if not ifNetworkStateOK() then
								error_report = error_report .. " net state false"
							elseif gFunc_isStdioFileExist(download_) then
								local check_md5_ = string.sub(gFunc_getSmallFileMd5(download_, ns_http.sec), 1, #md5_)

								if check_md5_ == md5_ then
									error_report = error_report .. " find md5"
								elseif #md5_ > 0 and ns_data.cf_md5s and ns_data.cf_md5s.cdn then
									local function cb_func_(ret_)
										if ret_ then
											error_report = error_report .. " cdn success"
										else
											error_report = error_report .. " cdn failed"
										end
									end

									local cdn_url = ns_data.cf_md5s.cdn .. md5_

									ns_http.func.private_cb_downloadLuaConfig(cdn_url, download_, md5_, cb_func_)

									error_report = error_report .. " diff md5 down cdn" .. cdn_url
								else
									error_report = error_report .. " diff md5 down url"
								end
							elseif #md5_ > 0 and ns_data.cf_md5s and ns_data.cf_md5s.cdn then
								error_report = error_report .. " down cdn"
							else
								error_report = error_report .. " down url"
							end
						end

						local prefix = client_M.StdioRoot .. "iworld.cfg"
						local iworld = nil
						local ff = io.open(prefix, "r")
						local DnsCacheinfo = ""

						if ff then
							iworld = ff:read("*a")

							ff:close()

							local pos1 = string.find(iworld, "DnsCache", 1)
							local pos2 = string.find(iworld, "/DnsCache", 1)

							if pos1 and pos2 then
								DnsCacheinfo = " DnsCache: " .. string.sub(iworld, pos1, pos2)
							end
						end

						error_report = error_report .. "iworld:" .. DnsCacheinfo
						local socket1 = require("luascript.socket.lua")

						if socket1 then
							if socket1.dns then
								function getAdd(hostname)
									local ip, resolved = socket1.dns.toip(hostname)
									local ListTab = {}

									if resolved and type(resolved) == "table" and resolved.ip and type(resolved.ip) == "table" then
										for k, v in ipairs(resolved.ip) do
											table.insert(ListTab, v)
										end
									end

									return ListTab
								end

								error_report = error_report .. "dns operate.mini1.cn:" .. table.tostring(getAdd("operate.mini1.cn"))
								error_report = error_report .. "openroom.mini1.cn:" .. table.tostring(getAdd("openroom.mini1.cn"))
								error_report = error_report .. "wskacchm.mini1.cn:" .. table.tostring(getAdd("wskacchm.mini1.cn"))
								error_report = error_report .. "baidu.com:" .. table.tostring(getAdd("baidu.com"))
								error_report = error_report .. "shequ.mini1.cn:" .. table.tostring(getAdd("shequ.mini1.cn"))
								error_report = error_report .. "cdn-operate2.mini1.cn:" .. table.tostring(getAdd("cdn-operate2.mini1.cn"))
								error_report = error_report .. "getNetworkState:" .. GetClientInfo():getNetworkState() or ""
								error_report = error_report .. socket1.dns.gethostname() .. "ip:" .. table.tostring(getAdd(socket1.dns.gethostname()))
							else
								error_report = error_report .. "socket1.dns fail"
							end
						else
							error_report = error_report .. "socket1 fail"
						end

						self:oplog_login_error_version(uin, "version_check_login", error_report)
					end

					tips_msg = "当前DNS不可用，请切换网络或稍后重试"

					MessageBox(4, tips_msg)

					return loginflag
				end

				tips_msg = "正在更新服务器配置,请稍后."

				ShowGameTipsWithoutFilter(tips_msg)

				wait_time = wait_time + 1

				threadpool:wait(5)
			else
				break
			end
		end

		if RealNameModule:IsLimitRuleOpen() then
			local version_rule = RealNameModule:GetLimitRuleLoginCfg("version_rule")

			if version_rule then
				if version_rule then
					tips_msg = version_rule.tips_msg or tips_msg
				end

				local appoint_apiid = version_rule.appoint_apiid or {}

				if appoint_apiid[ApiID] then
					local ver_min = GetClientInfo():clientVersionFromStr(appoint_apiid[ApiID])

					if ver_min < version then
						loginflag = true
					end
				else
					local min_version = version_rule and version_rule.min_version
					local ver_min = GetClientInfo():clientVersionFromStr(min_version)

					if ver_min < version then
						loginflag = true
					end
				end
			end
		else
			loginflag = true
		end

		if loginflag == false then
			local conn = self.conn

			conn:close()

			_G.IgnoreEsc = true

			if ClientCurGame and ClientCurGame.setOperateUI then
				ClientCurGame:setOperateUI(true)
			end

			AntiAddictionModule:HideAccountGameModelFrame()
			MessageBox(14, tips_msg)
			self:oplog_login_error("", "version_pull_fail_direct", getPullVersionFailReportData and getPullVersionFailReportData() or "")
			threadpool:wait(10)
			LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
		end

		return loginflag
	end,
	policy_limit_login_check_tips = function (self, tips)
		tips = tips or RealNameModule:GetLimitRuleLoginCfg("tips_msg") or "亲爱的冒险家，根据国家游戏防沉迷规定，18岁以下的未成年人仅能在法定节假日和每周五、周六、周日20:00 ~ 21:00玩游戏。"
		self.anti_addiction_uin = nil
		local conn = self.conn

		conn:close()

		self.conn.authed = false
		self.conn.token = nil
		self.conn.sign = nil
		self.conn.other = nil
		_G.IgnoreEsc = true

		if ClientCurGame and ClientCurGame.setOperateUI then
			ClientCurGame:setOperateUI(true)
		end

		if AntiAddictionModule:OpenAntiAddictionBox() then
			threadpool:wait(30)
			LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)
		end
	end,
	policy_limit_login_check_log = function (self)
		if AntiAddictionModule:HitLimitRuleLoginServer() then
			self:login_limit()
		end

		if not self:client_ready() then
			return
		end

		local code, login_check_form, off_time = self:policy_limit_login_check()

		print("off_time", code, login_check_form, off_time or "no")

		if code == ErrorCode.OK then
			if off_time and off_time > 0 then
				threadpool:work(function ()
					local flag = false

					while true do
						local curTime = AccountManager:getSvrTime() or os.time()
						local tb = os.date("*t", curTime)
						local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
						local last_on_time = off_time - curT

						print("last_on_time", last_on_time, off_time, curT)

						if last_on_time < 600 and flag == false then
							flag = true
							local tips = "亲爱的冒险家，根据国家最新的游戏防沉迷规定，10分钟后你将无法继续游戏，请合理安排时间"

							MessageBox(4, tips)
						end

						if last_on_time < 0 then
							self.anti_addiction_uin = nil

							self:oplog_login_check(1, 0)
							self:policy_limit_login_check_tips(login_check_form.tips)

							return
						end

						threadpool:wait(60)
					end
				end)
			end

			self.anti_addiction_uin = self.account and self.account.Uin

			self:oplog_login_check(1, 1)
		else
			self.anti_addiction_uin = nil

			self:oplog_login_check(1, 0)

			if login_check_form.is_channel_pass == 0 then
				self.anti_addiction_uin = nil

				AntiAddictionModule:HideAccountGameModelFrame()
				MessageBox(14, login_check_form.tips)
				threadpool:wait(30)
				LoginManager:NotifyCustomEvent(LoginManager.EVENT_FLOATLOGIN_DLG_BACK_LOGIN_VIEW)

				return code
			end

			threadpool:work(function ()
				self:policy_limit_login_check_tips(login_check_form.tips)
			end)

			return code
		end

		self:parents_guard_limit_login_check()

		return code
	end,
	parents_guard_limit_login_check = function (self)
		AntiAddictionModule:CloseParentsGuardTips()

		local parents_guard_code, parents_guard_time_time, limit_conf, total_time = self:parents_guard_limit_login()

		if parents_guard_code == false then
			self:oplog_login_check(1, 0)

			self.anti_addiction_uin = nil
			local tips = self:get_parents_guard_tips(limit_conf)

			AntiAddictionModule:OpenParentsGuardFrame(tips, true)

			local conn = self.conn

			conn:close()

			self.conn.authed = false
			self.conn.token = nil
			self.conn.sign = nil
			self.conn.other = nil

			return ErrorCode.FAILED
		end

		print("parents_guard_limit_login res", parents_guard_code, parents_guard_time_time, total_time, limit_conf)

		if parents_guard_time_time and parents_guard_time_time > 0 then
			self.account.online_report_flag = true
			local flag = false

			AntiAddictionModule:LoopWork("parents_guard_limit_login_check_1", function ()
				local curTime = AccountManager:getSvrTime() or os.time()
				local tb = os.date("*t", curTime)
				local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
				local last_on_time = parents_guard_time_time - curT

				print("parents_guard_limit_login limit", parents_guard_time_time, curT, flag, math.ceil(last_on_time / 60))

				if last_on_time < 600 and flag == false then
					flag = true

					AntiAddictionModule:OpenParentsGuardTips(last_on_time, true)
				end

				if last_on_time < 0 then
					self.anti_addiction_uin = nil
					local tips = self:get_parents_guard_tips(limit_conf)
					local conn = self.conn

					conn:close()

					self.conn.authed = false
					self.conn.token = nil
					self.conn.sign = nil
					self.conn.other = nil

					self:oplog_login_check(1, 0)
					print("last_on_time 60 limit ", last_on_time, tips)
					AntiAddictionModule:OpenParentsGuardFrame(tips, true)

					return ErrorCode.FAILED
				end

				threadpool:wait(60)
			end)

			local flag2 = false

			AntiAddictionModule:LoopWork("parents_guard_limit_login_check_2", function ()
				local curTime = AccountManager:getSvrTime() or os.time()
				local tb = os.date("*t", curTime)
				local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
				local last_on_time = parents_guard_time_time - curT

				if last_on_time < 90 and flag2 == false then
					flag2 = true

					AntiAddictionModule:OpenParentsGuardTips(90, false, true)
				end

				if last_on_time < 0 then
					self.anti_addiction_uin = nil
					local conn = self.conn

					conn:close()

					self.conn.authed = false
					self.conn.token = nil
					self.conn.sign = nil
					self.conn.other = nil

					self:oplog_login_check(1, 0)

					local tips = self:get_parents_guard_tips(limit_conf)

					print("last_on_time 10 limit ", last_on_time, tips)
					AntiAddictionModule:OpenParentsGuardFrame(tips, true)

					return ErrorCode.FAILED
				end

				threadpool:wait(10)
			end)
		end

		if total_time and total_time > 0 then
			AntiAddictionModule:LoopWork("parents_guard_limit_login_check_3", function ()
				local code, online_time = self:remote_call("baseinfo", "get_online_report")

				print("total_time res", code, online_time, total_time)

				if code == ErrorCode.OK and total_time < online_time then
					self.anti_addiction_uin = nil
					local conn = self.conn

					conn:close()

					self.conn.authed = false
					self.conn.token = nil
					self.conn.sign = nil
					self.conn.other = nil

					self:oplog_login_check(1, 0)

					local tips = self:get_parents_guard_tips(limit_conf)

					print("total limit ", online_time, total_time, tips)
					AntiAddictionModule:OpenParentsGuardFrame(tips, true)
					print("total limit end", online_time, total_time, tips)

					return ErrorCode.FAILED
				end

				threadpool:wait(60)
			end)
		end

		local flag, end_time = self:parents_guard_rule(limit_conf)

		print("parents_guard_rule", flag, end_time)

		if flag == false then
			self:oplog_login_check(1, 0)

			self.anti_addiction_uin = nil
			local tips = self:get_parents_guard_rule_tips(limit_conf)

			AntiAddictionModule:OpenParentsGuardFrame(tips, true)

			local conn = self.conn

			conn:close()

			self.conn.authed = false
			self.conn.token = nil
			self.conn.sign = nil
			self.conn.other = nil

			return ErrorCode.FAILED
		elseif end_time and end_time > 0 then
			local curTime = AccountManager:getSvrTime() or os.time()
			local tb = os.date("*t", curTime)
			local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
			self.account.online_report_flag = true

			if end_time > 86300 then
				self.parents_guard_rule_flag = true

				return
			end

			local flag = false

			print("parents_guard_limit_login limit new", end_time, curT)
			AntiAddictionModule:LoopWork("parents_guard_limit_login_check_4", function ()
				local last_on_time = end_time - curT

				if last_on_time < 600 and flag == false then
					flag = true

					AntiAddictionModule:OpenParentsGuardTips(last_on_time, false, true)
				end

				if last_on_time < 0 then
					self.anti_addiction_uin = nil

					self:oplog_login_check(1, 0)

					local tips = self:get_parents_guard_rule_tips(limit_conf)

					print("last_on_time 60 limit new", last_on_time, tips)
					AntiAddictionModule:OpenParentsGuardFrame(tips, true)

					local conn = self.conn

					conn:close()

					self.conn.authed = false
					self.conn.token = nil
					self.conn.sign = nil
					self.conn.other = nil

					return ErrorCode.FAILED
				end

				curT = curT + 1

				threadpool:wait(1)
			end)
		end
	end,
	policy_limit_login_check = function (self)
		local off_time = nil
		local allow_login_flag = true
		local allow_login_time_flag = true
		local ApiID = LuaInterface:getApiId()
		local login_check_form = {
			is_channel_pass = 1,
			is_realname_pass = 0,
			is_realname_conf = 1,
			channel_age = 0,
			channel_isrealname = 0,
			is_channel_realname_pass = 0,
			tips = RealNameModule:GetLimitRuleChannelCfg("tips_msg") or "亲爱的冒险家，根据国家游戏防沉迷规定，18岁以下的未成年人仅能在法定节假日和每周五、周六、周日20:00 ~ 21:00玩游戏。"
		}

		if RealNameModule:HitChannelAuth() then
			print("limit_rule_channel 1")

			if RealNameModule:HitLimitRuleChannel() then
				RealNameModule:PreSetAuthInfo()

				local code, isrealname = self:is_realname_channel_sdk()

				print("is_realname_channel_sdk", code, isrealname)

				if code ~= ErrorCode.OK or isrealname ~= true then
					login_check_form.is_realname_pass = 0
					login_check_form.is_channel_realname_pass = 0
					login_check_form.tips = "亲爱的冒险家，根据渠道的要求，必须登录渠道账号和实名以后才能进入游戏，请登录渠道账号和完成实名认证"
					login_check_form.is_channel_pass = 0

					return ErrorCode.FAILED, login_check_form
				end
			end

			login_check_form.is_realname_pass = 1
			login_check_form.is_channel_realname_pass = 1

			return ErrorCode.OK, login_check_form
		end

		local code, info = self:realname_get_age()
		local login_age = 1

		if code ~= ErrorCode.OK then
			return ErrorCode.FAILED, login_check_form
		end

		if info.status == "authed" then
			login_age = info.age or 1
		elseif info.status == "not_auth_yet" then
			return ErrorCode.OK, "not_auth_yet"
		end

		if RealNameModule:IsLimitRuleOpen() then
			local limit_rule_list = RealNameModule:GetLimitRuleCfg()

			if limit_rule_list then
				local curTime = AccountManager:getSvrTime() or os.time()
				local tb = os.date("*t", curTime)
				local wday = self:get_week_day(tonumber(tb.wday))
				local cdate = os.date("%Y-%m-%d", curTime)
				local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)

				for irule = 1, #limit_rule_list do
					local login_min_age = limit_rule_list[irule]["login_min_age_" .. ApiID]

					if login_min_age and login_age <= login_min_age then
						login_check_form.tips = limit_rule_list[irule]["login_min_age_" .. ApiID .. "_tips"] or "亲爱的冒险家，根据国家法律规定，14岁以下未成年人玩游戏需经家长同意，祝开心生活，健康成长。"

						return ErrorCode.FAILED, login_check_form
					end

					if limit_rule_list[irule].age.min <= login_age and login_age <= limit_rule_list[irule].age.max then
						allow_login_flag = false
						allow_login_time_flag = false

						for iallow_week_day = 1, #limit_rule_list[irule].allow_week_day do
							if wday == limit_rule_list[irule].allow_week_day[iallow_week_day] then
								allow_login_flag = true

								break
							end
						end

						for iallow_day = 1, #limit_rule_list[irule].allow_day do
							if limit_rule_list[irule].allow_day[iallow_day] == cdate then
								allow_login_flag = true

								break
							end
						end

						for inot_allow_day = 1, #limit_rule_list[irule].not_allow_day do
							if limit_rule_list[irule].not_allow_day[inot_allow_day] == cdate then
								allow_login_flag = false

								break
							end
						end

						if allow_login_flag == true then
							for iallow_time = 1, #limit_rule_list[irule].allow_time do
								local allow_time_list = limit_rule_list[irule].allow_time[iallow_time]
								local minT = string.sub(allow_time_list.min, 1, 2) * 3600 + string.sub(allow_time_list.min, 4, 5) * 60
								local maxT = string.sub(allow_time_list.max, 1, 2) * 3600 + string.sub(allow_time_list.max, 4, 5) * 60

								if minT <= curT and curT <= maxT then
									allow_login_time_flag = true
									off_time = maxT
								end
							end
						end

						break
					else
						allow_login_flag = true
						allow_login_time_flag = true
					end
				end
			end

			if allow_login_flag == true and allow_login_time_flag == true then
				login_check_form.is_realname_pass = 0
				login_check_form.is_channel_realname_pass = 1

				return ErrorCode.OK, login_check_form, off_time
			else
				return ErrorCode.FAILED, login_check_form
			end
		else
			login_check_form.is_realname_pass = 1

			return ErrorCode.OK, login_check_form, off_time
		end
	end,
	get_parents_guard_tips = function (self, limit_config_time)
		local tips = [[
受到迷你守护监管，您无法在当前时段进行游戏

规则:
]]
		local total_time = ""
		local login_time = {}
		local login_time_tips = ""
		local wday_tips = ""
		local wday_tips_list = {}
		local wday_tips_list_sort = {}

		local function get_total_time(minute)
			local msg = ""
			local hour = math.floor(minute / 60)
			local lminute = minute % 60

			if hour > 0 then
				msg = msg .. hour .. "小时 "
			end

			if lminute > 0 then
				msg = msg .. lminute .. "分钟"
			end

			return msg
		end

		if limit_config_time then
			if limit_config_time.time_type == 2 then
				local wday_table_cn = {
					mon = {
						num = 1,
						msg = "周一"
					},
					tue = {
						num = 2,
						msg = "周二"
					},
					wed = {
						num = 3,
						msg = "周三"
					},
					thu = {
						num = 4,
						msg = "周四"
					},
					fri = {
						num = 5,
						msg = "周五"
					},
					sat = {
						num = 6,
						msg = "周六"
					},
					sun = {
						num = 7,
						msg = "周日"
					}
				}

				for k, v in pairs(limit_config_time.time) do
					table.insert(wday_tips_list, wday_table_cn[k])
				end

				for k, v in pairs(limit_config_time.time) do
					login_time = limit_config_time.time[k].section
					total_time = get_total_time(limit_config_time.time[k].total)

					break
				end

				for k, v in ipairs(wday_tips_list) do
					wday_tips_list_sort[v.num] = v.msg
				end

				for k, v in pairs(wday_tips_list_sort) do
					wday_tips = wday_tips .. v .. ","
				end

				wday_tips = string.sub(wday_tips, 1, #wday_tips - 1)

				for k, v in pairs(login_time) do
					login_time_tips = login_time_tips .. v .. "\n"
				end

				login_time_tips = string.sub(login_time_tips, 1, #login_time_tips - 1)
			end

			if limit_config_time.time_type == 1 then
				login_time = limit_config_time.time.day.section
				total_time = get_total_time(limit_config_time.time.day.total)
				wday_tips = "每日"

				for k, v in ipairs(login_time) do
					login_time_tips = login_time_tips .. v .. "\n"
				end

				login_time_tips = string.sub(login_time_tips, 1, #login_time_tips - 1)
			end
		end

		if login_time_tips == "" then
			login_time_tips = "00:00-24:00"
		end

		tips = tips .. wday_tips .. "可玩游戏时长" .. total_time .. "\n\n" .. "可登录时段:\n" .. login_time_tips .. "\n\n"

		return tips
	end,
	parents_guard_day_rule = function (self, total, status, section, online_time)
		local end_time = -1

		if status ~= 1 then
			return true, end_time
		end

		local curTime = AccountManager:getSvrTime() or os.time()
		local tb = os.date("*t", curTime)
		local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
		online_time = online_time or 0
		local sec_total = tonumber(total or 0) * 60

		if sec_total and sec_total >= 0 then
			if sec_total <= online_time then
				return false, end_time
			end

			if not section or #section == 0 then
				section = {
					"00:00-24:00"
				}
			end

			for i = 1, #section do
				local minT = string.sub(section[i], 1, 2) * 3600 + string.sub(section[i], 4, 5) * 60
				local maxT = string.sub(section[i], 7, 8) * 3600 + string.sub(section[i], 10, 11) * 60

				if minT <= curT and curT <= maxT then
					end_time = maxT

					if end_time >= sec_total - online_time + curT then
						end_time = sec_total + curT - (online_time or 0)
					end

					print("------------- ok ", end_time)

					return true, end_time
				end
			end
		end

		print("------------- failed ", end_time)

		return false, end_time
	end,
	get_parents_guard_rule_tips = function (self, condition_anti)
		local tips = [[
受到迷你守护监管，您无法在当前时段进行游戏

规则(可玩时间):
]]
		local tips_everyday = ""
		local tips_definedday = ""
		local tips_holiday = ""

		if condition_anti and type(condition_anti) == "table" then
			local function get_total_time(minute)
				local msg = ""
				local hour = math.floor(minute / 60)
				local lminute = minute % 60

				if hour > 0 then
					msg = msg .. hour .. "小时 "
				end

				if lminute > 0 then
					msg = msg .. lminute .. "分钟"
				end

				return msg
			end

			if condition_anti.everyday_anti and condition_anti.everyday_anti.status == 1 then
				tips_everyday = tips_everyday .. "周一至周日\n"

				if not condition_anti.everyday_anti.section or #condition_anti.everyday_anti.section == 0 then
					condition_anti.everyday_anti.section = {
						[1.0] = "00:00-24:00"
					}
				end

				for i, v in ipairs(condition_anti.everyday_anti.section) do
					tips_everyday = tips_everyday .. " " .. v
				end

				tips_everyday = tips_everyday .. "，每天可玩" .. get_total_time(condition_anti.everyday_anti.total) .. "\n"
			end

			if condition_anti.definedday_anti then
				local wday_table_cn = {
					tue = "周二",
					fri = "周五",
					mon = "周一",
					sat = "周六",
					thu = "周四",
					sun = "周日",
					wed = "周三"
				}

				for i, v in ipairs(condition_anti.definedday_anti) do
					if v.status == 1 then
						local length_week = #v.week

						for k, s in ipairs(v.week) do
							if wday_table_cn[s] then
								if k == length_week then
									tips_definedday = tips_definedday .. wday_table_cn[s] .. "："
								else
									tips_definedday = tips_definedday .. wday_table_cn[s] .. "、"
								end
							end
						end

						if not v.section or #v.section == 0 then
							v.section = {
								"00:00-24:00"
							}
						end

						local length_section = #v.section

						for k, s in ipairs(v.section) do
							if k == length_section then
								tips_definedday = tips_definedday .. s .. "，"
							else
								tips_definedday = tips_definedday .. s .. "、"
							end
						end

						tips_definedday = tips_definedday .. "每天可玩" .. get_total_time(v.total) .. "\n"
					end
				end
			end

			if condition_anti.holiday_anti and condition_anti.holiday_anti.status == 1 then
				tips_holiday = tips_holiday .. "法定节假日："

				if not condition_anti.holiday_anti.section or #condition_anti.holiday_anti.section == 0 then
					condition_anti.holiday_anti.section = {
						"00:00-24:00"
					}
				end

				local length_section = #condition_anti.holiday_anti.section

				for k, v in ipairs(condition_anti.holiday_anti.section) do
					if k == length_section then
						tips_holiday = tips_holiday .. v .. "，"
					else
						tips_holiday = tips_holiday .. v .. "、"
					end
				end

				tips_holiday = tips_holiday .. "每天可玩" .. get_total_time(condition_anti.holiday_anti.total) .. "\n"
			end
		end

		if tips_definedday ~= "" then
			tips = tips .. tips_definedday
		elseif tips_everyday ~= "" then
			tips = tips .. tips_everyday
		end

		tips = tips .. tips_holiday

		return tips
	end,
	parents_guard_rule = function (self, condition_anti)
		local curTime = AccountManager:getSvrTime() or os.time()
		local tb = os.date("*t", curTime)
		local wday = self:get_week_day(tonumber(tb.wday))
		local cdate = os.date("%Y-%m-%d", curTime)
		local code, online_time = self:remote_call("baseinfo", "get_online_report")

		print("parents_guard_rule", condition_anti, online_time)

		if condition_anti and type(condition_anti) == "table" then
			if condition_anti.holiday_anti then
				print("holiday_anti")

				local holiday_list = RealNameModule:GetLimitRuleCfg() or {}

				for i = 1, #holiday_list do
					for h = 1, #holiday_list[i].allow_day do
						if holiday_list[i].allow_day[h] == cdate and condition_anti.holiday_anti.status == 1 then
							local flag, end_time = self:parents_guard_day_rule(condition_anti.holiday_anti.total, condition_anti.holiday_anti.status, condition_anti.holiday_anti.section, online_time)

							return flag, end_time
						end
					end
				end
			end

			if condition_anti.definedday_anti then
				local wday_table = {
					"mon",
					"tue",
					"wed",
					"thu",
					"fri",
					"sat",
					"sun"
				}

				print("definedday_anti wday", wday, wday_table[wday])

				local definedday_anti_flag = false

				for i = 1, #condition_anti.definedday_anti do
					if condition_anti.definedday_anti[i].status == 1 then
						definedday_anti_flag = true

						for w = 1, #condition_anti.definedday_anti[i].week do
							if condition_anti.definedday_anti[i].week[w] == wday_table[wday] then
								print("definedday_anti ok ", condition_anti.definedday_anti[i].week[w], wday_table[wday], condition_anti.definedday_anti[i].status)

								local flag, end_time = self:parents_guard_day_rule(condition_anti.definedday_anti[i].total, condition_anti.definedday_anti[i].status, condition_anti.definedday_anti[i].section, online_time)

								return flag, end_time
							end
						end
					end
				end

				print("definedday_anti_flag", definedday_anti_flag)

				if definedday_anti_flag == true then
					return false, -1
				end
			end

			if condition_anti.everyday_anti then
				print("everyday_anti")

				if condition_anti.everyday_anti.status == 1 then
					local flag, end_time = self:parents_guard_day_rule(condition_anti.everyday_anti.total, condition_anti.everyday_anti.status, condition_anti.everyday_anti.section, online_time)

					return flag, end_time
				end
			end
		end

		return true, -1
	end,
	parents_guard_limit_login = function (self)
		local end_time = 0
		local tips = nil
		local seq = gen_gid()
		local limit_conf = {}
		local c_uin = self.Uin
		local url = mapservice.getserver() .. "/miniw/anti_addiction?act=get_anti_addiction_info&uin=" .. c_uin
		local curTime = AccountManager:getSvrTime() or os.time()
		url = "http://120.24.64.132:8087/miniw/anti_addiction?uin=" .. c_uin .. "&ver=" .. LuaInterface:getCltVersion() .. "&act=get_anti_addiction_info&json=1"

		if utils.env == 0 then
			url = mapservice.getserver() .. "/miniw/anti_addiction?uin=" .. self.Uin .. "&ver=" .. LuaInterface:getCltVersion() .. "&act=get_anti_addiction_info&json=1"
		end

		url = UrlAddAuth_Ex(url)

		if ns_version and ns_version.parents_guard and ns_version.parents_guard == true then
			while not ns_http do
				threadpool:wait(0)
			end

			ns_http.func.rpc_string_raw(url, function (ret)
				threadpool:notify(seq, ErrorCode.OK, ret)
			end, nil, 2)

			local code, http_result = threadpool:wait(seq, 5, tick)

			print("parents_guard url res", code, url, http_result)

			local ok, ret_msg = nil

			if not code or code == ErrorCode.TIMEOUT then
				self.parents_guard_rule_has_check = false
			else
				self.parents_guard_rule_has_check = true
			end

			if code == ErrorCode.OK then
				ok, ret_msg = pcall(JSON.decode, JSON, http_result)
			else
				return true, end_time, limit_conf
			end

			print("parents_guard url jiexi", ok, ret_msg)

			if ok and ret_msg and ret_msg.ret == 0 and ret_msg.data then
				limit_conf = ret_msg.data
				local curTime = AccountManager:getSvrTime() or os.time()
				local tb = os.date("*t", curTime)
				local wday = self:get_week_day(tonumber(tb.wday))
				local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)
				local wday_table = {
					"mon",
					"tue",
					"wed",
					"thu",
					"fri",
					"sat",
					"sun"
				}
				local wday_en = wday_table[wday]
				local limit_time = limit_conf.time or limit_conf.time_anti

				if not limit_conf.time then
					limit_conf.time = limit_conf.time_anti
				end

				if limit_conf.time_type == 2 and limit_time then
					local code, online_time = self:remote_call("baseinfo", "get_online_report")

					for k, v in pairs(limit_time) do
						if wday_en == k then
							if not limit_time[wday_en].section or #limit_time[wday_en].section == 0 then
								limit_time[wday_en].section = {
									"00:00-24:00"
								}
							end

							for i = 1, #limit_time[wday_en].section do
								local minT = string.sub(limit_time[wday_en].section[i], 1, 2) * 3600 + string.sub(limit_time[wday_en].section[i], 4, 5) * 60
								local maxT = string.sub(limit_time[wday_en].section[i], 7, 8) * 3600 + string.sub(limit_time[wday_en].section[i], 10, 11) * 60

								if minT <= curT and curT <= maxT then
									end_time = maxT

									if online_time >= tonumber(limit_time[wday_en].total) * 60 then
										end_time = curT
									end

									if end_time >= tonumber(limit_time[wday_en].total) * 60 - (online_time or 0) + curT then
										end_time = tonumber(limit_time[wday_en].total) * 60 + curT - (online_time or 0)
									end

									return true, end_time, limit_conf, tonumber(limit_time[wday_en].total) * 60
								end
							end

							return false, end_time, limit_conf
						end
					end

					return true, end_time, limit_conf
				end

				if limit_conf.time_type == 1 and limit_time then
					local code, online_time = self:remote_call("baseinfo", "get_online_report")

					if not limit_time.day.section or #limit_time.day.section == 0 then
						limit_time.day.section = {
							"00:00-24:00"
						}
					end

					for i = 1, #limit_time.day.section do
						local minT = string.sub(limit_time.day.section[i], 1, 2) * 3600 + string.sub(limit_time.day.section[i], 4, 5) * 60
						local maxT = string.sub(limit_time.day.section[i], 7, 8) * 3600 + string.sub(limit_time.day.section[i], 10, 11) * 60

						if minT <= curT and curT <= maxT then
							end_time = maxT

							if online_time >= tonumber(limit_time.day.total) * 60 then
								end_time = curT
							end

							if end_time >= tonumber(limit_time.day.total) * 60 - (online_time or 0) + curT then
								end_time = tonumber(limit_time.day.total) * 60 + curT - (online_time or 0)
							end

							return true, end_time, limit_conf, tonumber(limit_time.day.total) * 60
						end
					end

					return false, end_time, limit_conf
				end
			end
		end

		return true, end_time, limit_conf
	end,
	get_channel_realname_info = function (self)
		local ApiID = LuaInterface:getApiId()
		local ok, def = pcall(loadwwwcache, "res.antiaddiction")

		if not ok then
			def = {}
		end

		local account = self.account
		local leveldb = account and account.leveldb or {}
		local realname_info_res = {
			channel_name = "",
			use_channel_realname = false,
			isrealname = false
		}

		if RealNameModule:HitChannelAuth() then
			realname_info_res.use_channel_realname = true
			realname_info_res.isrealname = leveldb.idcard and leveldb.idcard.channelauth and leveldb.idcard.channelauth.isauth or false
			realname_info_res.channel_name = def and def[ApiID] and def[ApiID].Name or "defalut"
		else
			if self:realname_state() == 1 then
				realname_info_res.isrealname = true
			end

			realname_info_res.use_channel_realname = false
			realname_info_res.channel_name = def and def[ApiID].Name or "defalut"
		end

		RealNameModule:Log("get_channel_realname_info", realname_info_res)

		return realname_info_res
	end,
	anti_addiction_loop = function (self)
		self.report_channel_realname_uin = nil
		local time_count = 0

		while true do
			local Uin = self.account and self.account.Uin

			if self:client_ready() and Uin then
				time_count = time_count + 1

				if time_count == 5 then
					time_count = 0

					if self.report_channel_realname_uin ~= Uin then
						self:channel_real_name()

						self.report_channel_realname_uin = Uin
					end

					if isInMainGame then
						print("anti_addiction_loop", Uin, self.anti_addiction_uin)

						if self.anti_addiction_uin ~= Uin then
							self.parents_guard_rule_has_check = false

							self:policy_limit_login_check_log()
						end

						if self.parents_guard_rule_flag == true or not self.parents_guard_rule_has_check then
							print("parents_guard_rule_has_check start", self.parents_guard_rule_has_check)
							self:parents_guard_limit_login_check()
						end
					end
				end

				threadpool:wait(1)
			else
				time_count = 0
				self.anti_addiction_uin = nil
				self.report_channel_realname_uin = nil

				threadpool:wait(0)
			end
		end
	end,
	is_policy_limit_login = function (self)
		local info = self:idcard_info()

		if self.conn.authed == true and info and self:realname_state() == 1 and info.age and info.age < 18 then
			local curTime = AccountManager:getSvrTime() or os.time()
			local tb = os.date("*t", curTime)
			local wday = tonumber(tb.wday)
			local minT = 72000
			local maxT = 75600
			local minute_tip = maxT - 600
			local curT = tonumber(tb.hour) * 3600 + tonumber(tb.min) * 60 + tonumber(tb.sec)

			if wday ~= 6 and wday ~= 7 and wday ~= 1 or minT > curT or curT >= maxT then
				return false
			end
		end

		return true
	end,
	is_realname_channel_sdk = function (self)
		local apiid = GetClientInfo():GetAppId()

		if RealNameModule.GetChannelAuthorInfo then
			local authInfo = RealNameModule:GetChannelAuthorInfo()

			print("is_realname_channel_sdk", authInfo)

			if not authInfo then
				return ErrorCode.CHANNEL_AUTH_GET_NIL
			end

			if not authInfo.channel_isRealName then
				return ErrorCode.CHANNEL_AUTH_GET_NIL, false
			end

			if authInfo.channel_isRealName == "true" then
				return ErrorCode.OK, true
			end

			local isauth = tonumber(authInfo.channel_isRealName)

			if isauth == 1 then
				return ErrorCode.OK, true
			end

			return ErrorCode.CHANNEL_AUTH_GET_NIL, false
		end

		return ErrorCode.CHANNEL_AUTH_GET_NIL
	end,
	channel_real_name = function (self)
		print("channel_real_name start")

		local isauth = 0
		local apiid = GetClientInfo():GetAppId()
		local age = 0
		local isadult = 0
		local user_id = ""
		local unifiedToken = ""
		local mac = ""
		local imei = ""
		local model = ""
		local udid = ""

		if RealNameModule.GetChannelAuthorInfo then
			local authInfo = RealNameModule:GetChannelAuthorInfo()

			if not authInfo then
				return ErrorCode.CHANNEL_AUTH_GET_NIL
			end

			if type(authInfo.channel_isRealName) == "boolean" and authInfo.channel_isRealName then
				isauth = 1
			end

			if type(authInfo.channel_isRealName) == "number" and authInfo.channel_isRealName > 0 then
				isauth = 1
			end

			if type(authInfo.channel_isRealName) == "string" then
				local szReal = string.lower(authInfo.channel_isRealName)

				if szReal == "true" or szReal == "1" then
					isauth = 1
				end
			end

			if isauth == 1 then
				age = tonumber(authInfo.channel_age or 0) or 0

				print("authInfo.isadult", authInfo.isadult)

				if tonumber(authInfo.isadult or 0) == 1 then
					isadult = 1
				elseif age >= 18 then
					isadult = 1
				end
			end

			unifiedToken = authInfo.unifiedToken
			mac = authInfo.mac
			imei = authInfo.imei
			model = authInfo.model
			udid = authInfo.udid
		end

		if isauth == 1 then
			local params = {
				apiid = apiid,
				isauth = isauth,
				isadult = isadult,
				age = age,
				unifiedToken = unifiedToken,
				mac = mac,
				imei = imei,
				model = model,
				udid = udid,
				DeviceID = GetClientInfo():getDeviceID() or "cantget"
			}

			print("channel_real_name", params)

			local code = self:remote_call("baseinfo", "channel_real_name", params)

			print("channel_real_name code", code)

			if code == ErrorCode.OK then
				self:data_update(true)
			end

			if code == ErrorCode.OK and (RealNameModule:HitChannelAuth() or RealNameModule:HitChannelPriorityAuth()) and HideIdentityNameAuthFrame then
				HideIdentityNameAuthFrame(true)
			end
		end

		return ErrorCode.OK
	end,
	get_doing_safe_verify = function (self)
		return self.doing_safe_verify
	end,
	get_cmcc_pushid = function (self, params)
		return self:remote_call("baseinfo", "get_cmcc_pushid", params)
	end,
	qb_seat_save = function (self, seatList, seatData)
		if not seatList or not seatData then
			return ErrorCode.PRECHECK_TYPE_ERROR
		end

		local code, svrinfo = self:remote_call("baseinfo", "qb_seat_save", seatList, seatData)

		if code == ErrorCode.OK then
			self:data_update(true)
		end

		return code, svrinfo
	end,
	get_interactive_datas = function (self)
		local account = self.account
		local leveldb = account and account.leveldb or {}
		local ic_seat = leveldb.ic_seat

		return ic_seat
	end,
	set_interactive_data = function (self, id, params)
		local code = self:remote_call("baseinfo", "ic_seat_save", id, params)

		if code == ErrorCode.OK then
			self:data_update(true)
		end

		return code
	end,
	get_warehouse_guide_status = function (self)
		local account = self.account
		local leveldb = account and account.leveldb or {}

		return leveldb.red_flag and leveldb.red_flag.ic_flag
	end,
	get_action_main_guide_status = function (self)
		local account = self.account
		local leveldb = account and account.leveldb or {}

		return leveldb.red_flag and leveldb.red_flag.ic_flag_1
	end,
	get_main_interface_guide_status = function (self)
		local account = self.account
		local leveldb = account and account.leveldb or {}

		return leveldb.red_flag and leveldb.red_flag.ic_flag_2
	end,
	set_red_flag = function (self, flag)
		local code = self:remote_call("baseinfo", "red_flag_set", flag)

		if code == ErrorCode.OK then
			self:data_update(true)
		end

		return code
	end
}, class.ManagerBase)
