local class = _G.class

if not class then
	return
end

local container = _G.container

class.define("FansData", {
	constructor = function (self, info)
		self.info = info
		self.vipinfo = client_M:qqinfo2vipinfo(info and info)
	end,
	uin = {
		get = function (self)
			local info = self.info

			return info and info.Uin or 0
		end
	},
	nickname = {
		get = function (self)
			local info = self.info

			return info and info.RoleInfo and info.RoleInfo.NickName or ""
		end
	},
	model = {
		get = function (self)
			local info = self.info

			return info and info.RoleInfo and info.RoleInfo.Model or 0
		end
	},
	skin = {
		get = function (self)
			local info = self.info

			return info and info.RoleInfo and info.RoleInfo.SkinID or 0
		end
	},
	yvid = {
		get = function (self)
			local info = self.info

			return info and info.yayaid or 0
		end
	}
})
