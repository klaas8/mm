local class = _G.class

if not class then
	return
end

local container = _G.container

class.define("Account", {
	islogin = false,
	mismatch = false,
	isclient = true,
	online_report_flag = false,
	close_rolename_tips = false,
	issafeverify = false,
	is_ad_firstreq = true,
	BuddyDetail = {},
	const = {
		get = function (self)
			return cpp_const
		end
	},
	conn = {
		get = function (self)
			return container.conn
		end
	},
	istable = {
		get = function (self)
			return true
		end
	},
	account_def = {
		get = function (self)
			return client_M.account_def
		end
	},
	online_def = {
		get = function (self)
			return client_M.online_def
		end
	},
	AccountManager = {
		get = function (self)
			return self:GetAccountManager()
		end
	},
	ItemUseSkinDef = {
		get = function (self)
			return ItemUseSkinDef
		end
	},
	AvatarSeat = {
		get = function (self)
			return loadwwwcache("res.AvatarSeat")
		end
	},
	cluster = {
		get = function (self)
			return self.AccountManager.cluster
		end
	},
	ItemInfo = {
		get = function (self)
			local cache = self.cache

			if cache.Account and cache.Account.ItemInfo then
				return cache.Account.ItemInfo
			end

			cache.Account = cache.Account or {}
			cache.Account.ItemInfo = delegate(function ()
				local Account = self.Account
				local BillDataSvr = Account.BillDataSvr
				local ItemInfo = BillDataSvr.ItemInfo
				local ItemInfoNum = BillDataSvr.ItemInfoNum
				local items = {}
				local m = {}

				for i = 1, ItemInfoNum do
					local info = ItemInfo[i]

					if info then
						table.insert(items, {
							ItemID = info.ItemID,
							Num = info.Num
						})

						m[info.ItemID] = i
					end
				end

				local leveldb = self.leveldb

				if leveldb.ItemInfoNew then
					for i, v in ipairs(leveldb.ItemInfoNew) do
						local idx = m[v.ItemID]

						if idx then
							items[idx].Num = items[idx].Num + v.Num
						else
							table.insert(items, {
								ItemID = v.ItemID,
								Num = v.Num
							})

							if v.ItemID then
								m[v.ItemID] = #items
							end
						end
					end
				end

				if leveldb.ItemInfo then
					for i, v in ipairs(leveldb.ItemInfo) do
						local idx = m[v.ItemID]

						if idx then
							items[idx].Num = items[idx].Num + v.Num
						else
							table.insert(items, {
								ItemID = v.ItemID,
								Num = v.Num
							})
						end
					end
				end

				local CltVersion = LuaInterface and LuaInterface.getCltVersion and LuaInterface:getCltVersion() or 0

				if CltVersion and CltVersion < 68608 and leveldb.RiderFragment then
					for i, v in ipairs(leveldb.RiderFragment or {}) do
						local idx = m[v.ItemID]

						if idx then
							items[idx].Num = items[idx].Num + v.Num
						else
							table.insert(items, {
								ItemID = v.ItemID,
								Num = v.Num
							})
						end
					end
				end

				return items
			end)

			return cache.Account.ItemInfo
		end
	},
	IsBinding = {
		get = function (self)
			local Account = self.Account

			return Account and (type(Account.Phone) == "string" and Account.Phone ~= "" or type(Account.Email) == "string" and Account.Email ~= "") or false
		end
	},
	DefCache = {
		get = function (self)
			return client_M.DefCache
		end
	},
	HomeHarvestUpDef = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.HomeHarvestUp")

			if ok and def then
				return def
			end

			return nil
		end
	},
	HomeAwardDef = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.HomeAward")

			if ok and def then
				return def
			end

			return nil
		end
	},
	HomeLevelLoveDef = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.HomeLevelLove")

			if ok and def then
				return def
			end

			return nil
		end
	},
	HomeLevelLoveAddDef = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.HomeLevelLoveAdd")

			if ok and def then
				return def
			end

			return nil
		end
	},
	HomeTraderDef = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.HomeTrader")

			if ok and def then
				return def
			end

			return nil
		end
	},
	HomeTraderOptions = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.HomeTraderOptions")

			if ok and def then
				return def
			end

			return nil
		end
	},
	AntiAddictionDef = {
		get = function (self)
			local ok, def = pcall(loadwwwcache, "res.antiaddiction")

			if ok and def then
				return def
			end

			return nil
		end
	},
	SkinCostDef = {
		get = function (self)
			return client_M.account_def.SkinCostDef
		end
	},
	now = {
		get = function (self)
			return self.conn.svrtime
		end
	},
	utils = {
		get = function (self)
			return _G.utils
		end
	},
	constructor = function (self, Uin, AccountManager)
		self:init_packer_unpacker()
		self:randomseed(self.now)

		function self.GetAccountManager()
			return AccountManager
		end

		self.cache = {}
		self.ctx = {}
		local local_data = container:load_from_file("account_" .. Uin)

		if local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.Uin ~= Uin then
			local_data = nil
		end

		if local_data and local_data.mysql and local_data.mysql.Account and local_data.mysql.Account.Uin == Uin then
			table.merge(local_data, {
				mysql = {
					Account = {
						Uin = Uin
					},
					Chest = {
						Uin = Uin
					},
					Buddy = {
						Uin = Uin
					}
				}
			})
		else
			local_data = table.clone(loadwwwcache("sample"))

			table.merge(local_data, {
				mysql = {
					Account = {
						Uin = Uin
					},
					Chest = {
						Uin = Uin
					},
					Buddy = {
						Uin = Uin
					}
				}
			})

			if LuaInterface.getRoleInfo then
				local model, nickname, skinid, uin = LuaInterface:getRoleInfo(0, "", 0, 0)

				print("getRoleInfo ", model, nickname, skinid, uin)

				if uin == Uin then
					table.merge(local_data, {
						mysql = {
							Account = {
								RoleInfo = {
									Model = model,
									NickName = nickname,
									SkinID = skinid
								}
							}
						}
					})
				end
			end

			local tmp = container:load_from_file("tmp1")

			if tmp then
				table.merge(local_data, {
					mysql = {
						Account = {
							RoleInfo = tmp
						}
					}
				})
				print(local_data.mysql.Account)
			end
		end

		self.mysql = local_data and local_data.mysql or {}
		self.leveldb = local_data and local_data.leveldb or {}
		self.version = local_data and local_data.version or {}
		self.bit = {
			band = function (...)
				return LuaInterface:band(...)
			end,
			bor = function (...)
				return LuaInterface:bor(...)
			end,
			lshift = function (...)
				return LuaInterface:lshift(...)
			end,
			rshift = function (...)
				return LuaInterface:rshift(...)
			end
		}

		function self.spy(path, old, new)
		end

		self.pseudo = {
			item_use = function (self, itemid, itemnum)
				return ErrorCode.OK, self:randomseedgen()
			end,
			skin_buy = function (self, skinid, buytype)
				return ErrorCode.OK, self.now
			end,
			chest_update = function (self)
				return ErrorCode.OK, self:randomseedgen()
			end,
			chest_open = function (self, index)
				return ErrorCode.OK
			end,
			chest_speedup = function (self, index)
				return ErrorCode.OK, self:randomseedgen()
			end,
			chest_lot_one = function (self, index)
				return ErrorCode.OK, self:randomseedgen()
			end,
			chest_lot_ten = function (self)
				return ErrorCode.OK, self:randomseedgen()
			end,
			water_self = function (self)
				return ErrorCode.OK, self:randomseedgen()
			end,
			water_other = function (self, Uin)
				return ErrorCode.OK, self:randomseedgen()
			end,
			bug_other = function (self, Uin)
				return ErrorCode.OK, self:randomseedgen()
			end
		}
		self.today = class.Data4Today.new(self)
		self.week = class.Data4Week.new(self)
		self.timedata = class.TimeData.new(self)
	end,
	setuin = function (self, Uin)
		table.merge(self.mysql, {
			Account = {
				Uin = Uin
			},
			Chest = {
				Uin = Uin
			},
			Buddy = {
				Uin = Uin
			}
		})
	end,
	randomseed = function (self, seed)
		if seed then
			LuaInterface:randomseed(seed)
		end

		return seed
	end,
	random = function (self, min, max)
		return LuaInterface:random(min, max)
	end,
	randomseedgen = function (self)
		return LuaInterface:random(1, 100000000)
	end,
	ctxput = function (self, key, value)
		local ctx = self.ctx
		ctx[key] = ctx[key] or {}

		table.insert(ctx[key], value)
	end,
	ctxpop = function (self, key)
		local ctx = self.ctx

		return ctx and ctx[key] and table.remove(ctx[key]) or nil
	end,
	ctxclear = function (self, key)
		if key then
			self.ctx[key] = {}
		else
			self.ctx = {}
		end
	end,
	ctxget = function (self, key)
		return key and self.ctx and self.ctx[key] or nil
	end,
	ctxset = function (self, key, value)
		if key and value and self.ctx then
			self.ctx[key] = value
		end
	end,
	plant_spy = function (self, func)
		self.spy = func
	end,
	merge = function (self, tbl)
		local mysql = self.mysql
		local version = self.version
		local cache = self.cache

		if type(tbl) == "table" then
			if tbl.Account then
				cache.Account = nil

				table.merge(mysql.Account, tbl.Account, self.spy, "Account")

				version.Account = (version.Account or 0) + 1

				self:MarkAccountDirty()
			end

			if tbl.Chest then
				cache.Chest = nil

				table.merge(mysql.Chest, tbl.Chest, self.spy, "Chest")

				version.Chest = (version.Chest or 0) + 1
			end

			if tbl.Buddy then
				cache.Buddy = nil

				table.merge(mysql.Buddy, tbl.Buddy, self.spy, "Buddy")

				version.Buddy = (version.Buddy or 0) + 1

				self:MarkBuddyDirty()
			end

			if tbl.UinQQInfo then
				cache.UinQQInfo = nil

				table.merge(mysql.UinQQInfo, tbl.UinQQInfo, self.spy, "UinQQInfo")

				version.UinQQInfo = (version.UinQQInfo or 0) + 1
			end

			if tbl.leveldb then
				cache.leveldb = nil
				cache.Account = nil
				local leveldb = self.leveldb

				table.merge(leveldb, tbl.leveldb, self.spy, "leveldb")

				version.leveldb = (version.leveldb or 0) + 1

				if tbl.leveldb.avatar then
					self:MarkAccountDirty()
				end
			end
		end
	end,
	sync = function (self, data)
		local versionkeys = self.versionkeys
		local version_info = data[1]

		if version_info then
			local version = self.version

			for i, key in ipairs(versionkeys) do
				version[key] = version_info[i] or version[key]
			end
		end

		if data[2] then
			for k, v in pairs(data[2]) do
				print(k, v)

				local unpacker = self.unpacker and self.unpacker[k]

				if unpacker then
					self.mysql[k] = unpacker(v)
				else
					self.mysql[k] = v
				end
			end
		end

		if data[3] then
			self.leveldb = data[3]
			self.today.leveldb = self.leveldb
			self.week.leveldb = self.leveldb
			self.timedata.leveldb = self.leveldb

			if self.leveldb and AccountGameModeClass and type(AccountGameModeClass) == "table" and type(AccountGameModeClass.curReportUin) == "number" and AccountGameModeClass.curReportUin ~= self.Account.Uin then
				if AccountGameModeClass.curReportUin ~= 0 and not AccountGameModeClass.bReportOffLine and AccountGameModeClass.reportLeveldbCache and _G.next(AccountGameModeClass.reportLeveldbCache) then
					self:reportLoginAction(AccountGameModeClass.reportLeveldbCache, false, AccountGameModeClass.curReportUin)
					print("ReportOffLine onSwitch uin= ", AccountGameModeClass.curReportUin)
				end

				AccountGameModeClass.curReportUin = self.Account.Uin

				print("ReportOnLine uin= ", self.Account.Uin)

				AccountGameModeClass.bReportOffLine = false

				self:reportLoginAction(self.leveldb, true)

				if AccountGameModeClass.ReportOffLineOnTime then
					AccountGameModeClass:ReportOffLineOnTime()
				end

				AccountGameModeClass.reportLeveldbCache = {
					idcard = {},
					extra = {}
				}

				if self.leveldb.idcard then
					table.merge(AccountGameModeClass.reportLeveldbCache.idcard, self.leveldb.idcard)
				end

				if self.leveldb.extra then
					table.merge(AccountGameModeClass.reportLeveldbCache.extra, self.leveldb.extra)
				end
			end
		end
	end,
	flush = function (self)
		local Uin = self.Uin

		if Uin <= 1 then
			return
		end

		container:save_to_file("account_" .. Uin, {
			mysql = self.mysql,
			leveldb = self.leveldb,
			version = self.version
		})
	end,
	destroy = function (self)
		self:flush()

		self.version = nil
		self.mismatch = false

		self.today:destroy()
		self.week:destroy()
		self.timedata:destroy()

		self.today = nil
		self.week = nil
		self.timedata = nil
		self.GetAccountManager = nil
	end,
	markdirty = function (self, key)
		local version = self.version
		self.dirty = self.dirty or {}
		local dirty = self.dirty
		dirty[key] = true
		dirty.localdb = true
		version[key] = (version[key] or 0) + 1
	end,
	passwd = function (self, newpasswd)
		self:super("AccountForServerAndClient", "passwd", newpasswd)

		if AccountManager and AccountManager.save_to_file then
			local current = AccountManager:load_from_file("current")

			AccountManager:save_to_file("current", {
				Uin = self.Uin,
				Passwd = newpasswd,
				OldPasswd = current and current.Passwd or nil
			})
		else
			local current = container:load_from_file("current")

			container:save_to_file("current", {
				Uin = self.Uin,
				Passwd = newpasswd,
				OldPasswd = current and current.Passwd or nil
			})
		end

		return ErrorCode.OK
	end,
	passwd_by_sms = function (self, Uin, newpasswd)
		if Uin == self.Uin then
			self:passwd(newpasswd)
		end

		self:super("AccountForServerAndClient", "passwd_by_sms", Uin, newpasswd)

		return ErrorCode.OK
	end,
	passwd_by_email = function (self, Uin, newpasswd)
		if Uin == self.Uin then
			self:passwd(newpasswd)
		end

		self:super("AccountForServerAndClient", "passwd_by_email", Uin, newpasswd)

		return ErrorCode.OK
	end,
	OnAccountDirty = function (self)
		local Account = self.Account
		local leveldb = self.leveldb
		local RoleInfo = Account.RoleInfo
		local RoleSkinID = leveldb.RoleSkinID or RoleInfo.SkinID or 0

		print("windhe OnAccountDirty RoleSkinID", RoleInfo, leveldb.RoleSkinID, RoleSkinID, debug.traceback())

		if LuaInterface:getCltVersion() < 70144 and RoleSkinID and RoleSkinID >= 257 and RoleSkinID <= 266 then
			print("update OnAccountDirty", LuaInterface:getCltVersion())

			if leveldb.RoleSkinID then
				print("windhe leveldb.RoleSkinID is", leveldb.RoleSkinID)

				leveldb.RoleSkinID = 0
			end

			if RoleInfo.SkinID then
				print("windhe RoleInfo.SkinID is", RoleInfo.SkinID)

				RoleInfo.SkinID = 0
			end
		end

		print("windhe OnAccountDirty RoleSkinID end", RoleInfo.SkinID, leveldb.RoleSkinID, RoleInfo.SkinID)

		if LuaInterface.setRoleInfoWithAvatarSkin and self.avatar_seat_current then
			local seatid = self:avatar_seat_current()

			LuaInterface:setRoleInfoWithAvatarSkin(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin, seatid and tostring(seatid) or "")
		else
			LuaInterface:setRoleInfo(RoleInfo.Model, RoleInfo.NickName, RoleSkinID, Account.Uin)
		end

		if isEducationalVersion then
			MCodeManager._roleInfoWhenOnAccountDirty = MCodeManager._roleInfoWhenOnAccountDirty or {}
			MCodeManager._roleInfoWhenOnAccountDirty.Model = RoleInfo.Model
			MCodeManager._roleInfoWhenOnAccountDirty.RoleSkinID = RoleSkinID
		end

		AccountManager:reset_account_data_for_cpp()
	end,
	MarkAccountDirty = function (self)
		if self.torefresh then
			self.torefresh.OnAccountDirty = {}
		end
	end,
	SetExperimentVersion = function (self)
		self.isExperimentVersion = true
	end,
	item_add = function (self, itemid, itemnum, money_num)
		local ItemUseSkinDef = self.ItemUseSkinDef
		local item_use_skin_def = ItemUseSkinDef and ItemUseSkinDef[itemid]
		local Tag = item_use_skin_def and item_use_skin_def.Tag

		if self.isExperimentVersion then
			pcall(function ()
				if GetInst("ExperimentWarehouseManager") then
					GetInst("ExperimentWarehouseManager"):SaveGetItem(itemid)
				end
			end)
		end

		if Tag and Tag == 4 then
			self.cluster.avatar.rpc_cache_clear("skin", "cfg")

			return ErrorCode.OK
		else
			return self:super("AccountForServerAndClient", "item_add", itemid, itemnum, money_num)
		end
	end,
	task_reward = function (self, taskid, randomidx, itemmap, avatar_skin_to_minibean)
		local code = self:super("AccountForServerAndClient", "task_reward", taskid, randomidx, itemmap, avatar_skin_to_minibean)

		if avatar_skin_to_minibean then
			for i, v in ipairs(avatar_skin_to_minibean) do
				local itemid, minibean = unpack(v)

				self:minibean_add(minibean)
			end
		end

		return code, itemmap, avatar_skin_to_minibean
	end,
	pre_rpc = function (self)
		self.torefresh = {}
	end,
	post_rpc = function (self)
		if self.torefresh then
			for k, v in pairs(self.torefresh) do
				pcall(function ()
					self[k](self, unpack(v))
				end)
			end

			self.torefresh = {}
		end
	end,
	OnBuddyDirty = function (self)
		self:makeBuddyDetail()
	end,
	MarkBuddyDirty = function (self)
		if self.torefresh then
			self.torefresh.OnBuddyDirty = {}
		end
	end,
	makeBuddyDetail = function (self)
		local BuddyDetail = self.BuddyDetail
		local Buddy = self.Buddy
		local BuddyList = Buddy and Buddy.BuddyList
		local BuddyInfos = BuddyList and BuddyList.BuddyInfos
		local BuddyNum = BuddyList and BuddyList.BuddyNum or 0
		local n = #BuddyDetail
		local m = {}
		local c = {}

		for i = 1, n do
			local o = BuddyDetail[i]
			m[o.uin] = o.online
			c[o.uin] = o.chest
			BuddyDetail[i] = nil
		end

		for i = 1, BuddyNum do
			local BuddyInfo = BuddyInfos and BuddyInfos[i]
			BuddyDetail[i] = class.BuddyDetail.new(BuddyInfo, self)
			BuddyDetail[i].isonline = m[BuddyDetail[i].uin] or false
			BuddyDetail[i].chest = c[BuddyDetail[i].uin] or BuddyDetail[i].chest
		end

		print("makeBuddyDetail", self.BuddyDetail)
	end,
	getBuddyDetail = function (self, index)
		index = index + 1

		return self.BuddyDetail[index]
	end,
	getBuddyDetailByUin = function (self, Uin)
		local BuddyDetail = self.BuddyDetail

		for k, v in pairs(BuddyDetail) do
			if v.uin == Uin then
				return v
			end
		end
	end,
	getBuddyDetailByYvID = function (self, yvid)
		local BuddyDetail = self.BuddyDetail

		for k, v in pairs(BuddyDetail) do
			if v.yvid == yvid then
				return v
			end
		end
	end,
	getServerOrderId = function (self)
		local order_info = self.order_info
		local order = order_info and order_info.order

		return order and order.OrderID or 0
	end,
	isPaying = function (self)
		return self:getServerOrderId() ~= 0
	end,
	getSvrTime = function (self)
		return self.conn.svrtime
	end,
	getGenuisLv = function (self, model)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local UnlockRoleInfo = BillDataSvr.UnlockRoleInfo
		local UnlockRoleInfoNum = BillDataSvr.UnlockRoleInfoNum

		for i = 1, UnlockRoleInfoNum do
			if UnlockRoleInfo[i].Model == model then
				return UnlockRoleInfo[i].GenuisLV
			end
		end

		return -1
	end,
	getAccountItemNum = function (self, itemid)
		return self:item_num(itemid)
	end,
	getMiniCoin = function (self)
		return self.Account.MiniCoin + (self.leveldb.MiniCoin or 0) + (self.leveldb.MiniCoinCDKey or 0)
	end,
	getMiniCoinF = function (self)
		return self.Account.MiniCoin or 0
	end,
	getMiniCoinT = function (self)
		return (self.leveldb.MiniCoin or 0) + (self.leveldb.MiniCoinCDKey or 0)
	end,
	getADPoint = function (self)
		return self.leveldb.ADPoint or 0
	end,
	getMiniBean = function (self)
		return self.Account.MiniBean + (self.leveldb.MiniBean or 0)
	end,
	setMiniBean = function (self, num)
	end,
	isItemUnlock = function (self, itemflag)
		return self:flagpos_check(itemflag)
	end,
	is_move_actor_role = function (self)
		if self.leveldb then
			return self.leveldb.move_actor_role
		end
	end,
	getHorseLevel = function (self, riderid)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local UnlockRiderInfoNum = BillDataSvr.UnlockRiderInfoNum
		local UnlockRiderInfo = BillDataSvr.UnlockRiderInfo

		if UnlockRiderInfo then
			for i = 1, UnlockRiderInfoNum do
				if UnlockRiderInfo[i].RiderID == riderid then
					return UnlockRiderInfo[i].RiderLevel
				end
			end
		end

		local leveldb = self.leveldb
		local leveldbUnlockRiderInfo = leveldb.UnlockRiderInfo or {}

		for k, v in ipairs(leveldbUnlockRiderInfo) do
			if v.RiderID == riderid then
				return v.RiderLevel
			end
		end

		return -1
	end,
	getHorseLevel_all = function (self, riderid)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local UnlockRiderInfoNum = BillDataSvr.UnlockRiderInfoNum
		local UnlockRiderInfo = BillDataSvr.UnlockRiderInfo
		local AccountRiderInfo = {}

		if UnlockRiderInfo then
			for i = 1, UnlockRiderInfoNum do
				if UnlockRiderInfo[i].RiderID == riderid then
					table.insert(AccountRiderInfo, UnlockRiderInfo[i])
				end
			end
		end

		local leveldb = self.leveldb
		UnlockRiderInfo = leveldb.UnlockRiderInfo or {}

		for key, value in ipairs(UnlockRiderInfo) do
			if UnlockRiderInfo[key].RiderID == riderid and (self.now < UnlockRiderInfo[key].ExpireTime or UnlockRiderInfo[key].ExpireTime == -1) then
				table.insert(AccountRiderInfo, UnlockRiderInfo[key])
			end
		end

		return AccountRiderInfo
	end,
	getHorseNum = function (self)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local UnlockRiderInfoNum = BillDataSvr.UnlockRiderInfoNum
		local UnlockRiderInfo = BillDataSvr.UnlockRiderInfo

		if UnlockRiderInfo then
			for i = 1, UnlockRiderInfoNum do
				if isShapeShiftHorse and isShapeShiftHorse(UnlockRiderInfo[i].RiderID) or UnlockRiderInfo[i].RiderID == 3449 or UnlockRiderInfo[i].RiderID == 3451 then
					UnlockRiderInfoNum = UnlockRiderInfoNum - 1
				end
			end
		end

		local leveldb = self.leveldb
		local leveldbUnlockRiderInfo = leveldb.UnlockRiderInfo or {}

		return UnlockRiderInfoNum + #leveldbUnlockRiderInfo
	end,
	getHorseRealNum = function (self)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local UnlockRiderInfoNum = BillDataSvr.UnlockRiderInfoNum
		local leveldb = self.leveldb
		local AccountRiderInfo = {}
		local UnlockRiderInfo = leveldb.UnlockRiderInfo or {}

		for key, value in ipairs(UnlockRiderInfo) do
			if UnlockRiderInfo[key].ExpireTime == -1 or self.now < UnlockRiderInfo[key].ExpireTime then
				table.insert(AccountRiderInfo, UnlockRiderInfo[key])
			end
		end

		return UnlockRiderInfoNum + #AccountRiderInfo
	end,
	getHorse = function (self, index)
		index = index + 1
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local UnlockRiderInfo = BillDataSvr.UnlockRiderInfo
		local UnlockRiderInfoNum = BillDataSvr.UnlockRiderInfoNum
		local horse = UnlockRiderInfo and UnlockRiderInfo[index]

		if horse then
			return {
				horseId = horse.RiderID,
				level = horse.RiderLevel
			}
		else
			local leveldb = self.leveldb
			local leveldbUnlockRiderInfo = leveldb.UnlockRiderInfo or {}
			horse = leveldbUnlockRiderInfo[index - UnlockRiderInfoNum]

			if horse then
				return {
					horseId = horse.RiderID,
					level = horse.RiderLevel
				}
			end

			return {
				horseId = 0,
				level = 0
			}
		end
	end,
	getHorse_all = function (self)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr
		local horse = {}
		local AccountRiderInfo = BillDataSvr.UnlockRiderInfo or {}

		for key, value in ipairs(AccountRiderInfo) do
			table.insert(horse, AccountRiderInfo[key])
		end

		local leveldb = self.leveldb
		local UnlockRiderInfo = leveldb.UnlockRiderInfo or {}

		for key, value in ipairs(UnlockRiderInfo) do
			if UnlockRiderInfo[key].ExpireTime == nil or UnlockRiderInfo[key].ExpireTime == -1 or self.now < UnlockRiderInfo[key].ExpireTime then
				table.insert(horse, UnlockRiderInfo[key])
			end
		end

		return horse
	end,
	getHorseAutoConvertStatus = function (self, horseid)
		local leveldb = self.leveldb

		return leveldb.is_auto_convert_old_rider
	end,
	getRiderFragmentAll = function (self)
		local horse = {}
		local leveldb = self.leveldb
		local RiderFragment = leveldb.RiderFragment or {}

		for _, v in ipairs(RiderFragment) do
			table.insert(horse, {
				itemId = v.ItemID,
				num = v.Num
			})
		end

		return horse
	end,
	getRiderFragmentNum = function (self, id)
		local leveldb = self.leveldb
		local RiderFragment = leveldb.RiderFragment or {}

		for _, v in ipairs(RiderFragment) do
			if v.ItemID == id then
				return v.Num
			end
		end

		return 0
	end,
	getSkinTime = function (self, skinmodel, cacheSkins)
		local now = self.now
		local Account = self.Account
		local leveldb = self.leveldb
		local BillDataSvr = Account.BillDataSvr
		local RoleSkinNum = BillDataSvr.RoleSkinNum
		local RoleSkinInfo = BillDataSvr.RoleSkinInfo

		if cacheSkins and type(cacheSkins) == "table" then
			local rExpireTime = nil

			if cacheSkins[skinmodel] then
				local ExpireTime = cacheSkins[skinmodel].ExpireTime or 0

				if ExpireTime > 0 then
					if ExpireTime <= now then
						return 0
					else
						return ExpireTime
					end
				else
					return ExpireTime
				end
			else
				if RoleSkinNum > 0 then
					for i = 1, RoleSkinNum do
						if RoleSkinInfo[i].SkinID == skinmodel then
							local ExpireTime = RoleSkinInfo[i].ExpireTime

							if ExpireTime > 0 then
								if ExpireTime <= now then
									rExpireTime = 0
								else
									rExpireTime = ExpireTime
								end
							else
								rExpireTime = ExpireTime
							end
						end

						cacheSkins[RoleSkinInfo[i].SkinID] = RoleSkinInfo[i]
					end
				end

				local rExpireTime2 = nil
				local exRoleSkinInfo = leveldb.RoleSkinInfo

				if exRoleSkinInfo then
					for key, value in pairs(exRoleSkinInfo) do
						if value.SkinID == skinmodel then
							local ExpireTime = value.ExpireTime

							if ExpireTime > 0 then
								if ExpireTime <= now then
									rExpireTime2 = 0
								else
									rExpireTime2 = ExpireTime
								end
							else
								rExpireTime2 = ExpireTime
							end
						end

						if not cacheSkins[value.SkinID] then
							cacheSkins[value.SkinID] = value
						end
					end
				end

				if rExpireTime then
					return rExpireTime
				elseif rExpireTime2 then
					return rExpireTime2
				end
			end

			return 0
		else
			local now = self.now
			local Account = self.Account
			local leveldb = self.leveldb
			local BillDataSvr = Account.BillDataSvr
			local RoleSkinNum = BillDataSvr.RoleSkinNum
			local RoleSkinInfo = BillDataSvr.RoleSkinInfo

			if RoleSkinNum > 0 then
				for i = 1, RoleSkinNum do
					if RoleSkinInfo[i].SkinID == skinmodel then
						local ExpireTime = RoleSkinInfo[i].ExpireTime

						if ExpireTime > 0 then
							if ExpireTime <= now then
								return 0
							else
								return ExpireTime
							end
						else
							return ExpireTime
						end
					end
				end
			end

			local exRoleSkinInfo = leveldb.RoleSkinInfo

			if exRoleSkinInfo then
				for key, value in pairs(exRoleSkinInfo) do
					if value.SkinID == skinmodel then
						local ExpireTime = value.ExpireTime

						if ExpireTime > 0 then
							if ExpireTime <= now then
								return 0
							else
								return ExpireTime
							end
						else
							return ExpireTime
						end
					end
				end
			end

			return 0
		end
	end,
	qqinfo2vipinfo = function (self, qqinfo)
		return client_M:qqinfo2vipinfo(qqinfo or self.UinQQInfo or {})
	end,
	getVipInfo = function (self)
		local cache = self.cache

		if cache.UinQQInfo then
			return cache.UinQQInfo
		end

		cache.UinQQInfo = self:qqinfo2vipinfo()

		return cache.UinQQInfo
	end,
	getBagSize = function (self)
		local ItemInfo = self.ItemInfo or {}

		return #ItemInfo
	end,
	getBagMaxCap = function (self)
		return self:super("AccountForServerAndClient", "get_items_max")
	end,
	getAccountItem = function (self, idx)
		idx = idx + 1
		local ItemInfo = self.ItemInfo
		local Info = ItemInfo and ItemInfo[idx] or {}

		return {
			itemId = Info.ItemID or 0,
			num = Info.Num or 0
		}
	end,
	getAlreadyBuyNum = function (self, purchaseLimitId)
		local def = nil
		local apiid = LuaInterface:getApiId()

		if apiid == 45 then
			if not client_M.minicoindef_ios then
				client_M.minicoindef_ios = loadwwwcache("res.minicoin_ios")
			end

			def = client_M.minicoindef_ios
		elseif apiid == 345 or apiid == 346 then
			if not client_M.minicoindef_ios_en then
				client_M.minicoindef_ios_en = loadwwwcache("res.minicoin_ios_en")
			end

			def = client_M.minicoindef_ios_en
		elseif (apiid == 301 or apiid == 302 or apiid == 303 or apiid == 304 or apiid > 400) and apiid ~= 999 then
			if not client_M.minicoindef_google then
				client_M.minicoindef_google = loadwwwcache("res.minicoin_google")
			end

			def = client_M.minicoindef_google
		elseif apiid == 5 then
			if not client_M.minicoindef_wo then
				client_M.minicoindef_wo = loadwwwcache("res.minicoin_wo")
			end

			def = client_M.minicoindef_wo
		else
			if not client_M.minicoindef then
				client_M.minicoindef = loadwwwcache("res.minicoin")
			end

			def = client_M.minicoindef
		end

		local count = 0

		if def then
			for k, v in pairs(def) do
				if type(v) == "table" and type(v.PurchaseLimitID) == "number" and v.PurchaseLimitID == purchaseLimitId then
					local MiniCoin = v.Num or 0
					local leveldb = self.leveldb
					local recharge = leveldb and leveldb.recharge

					if MiniCoin and recharge then
						count = recharge[tostring(MiniCoin)] or count
					end
				end
			end
		end

		print("getAlreadyBuyNum : purchaseLimitId = ", purchaseLimitId, "num = ", count)

		return count
	end,
	isBuddy = function (self, Uin)
		return self:buddy_has(Uin)
	end,
	getFirstSeventDayGift = function (self)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr

		return BillDataSvr.FirstSevenDayGift
	end,
	getFirstSeventDayTimeGift = function (self)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr

		return BillDataSvr.FirstSevenDayGiftTime
	end,
	getSevenDayGiftFlag = function (self)
		local Account = self.Account
		local BillDataSvr = Account.BillDataSvr

		return BillDataSvr.SevenDayGiftFlag
	end,
	reportLoginAction = function (self, leveldb, on, uin)
		local idcard_info = leveldb.idcard

		if idcard_info and (idcard_info.serverauth or idcard_info.idcardtype and idcard_info.idcardtype > 1) then
			return
		end

		if leveldb and utils.env == 0 or utils.env == 1 then
			local tempDB = {
				idcard = leveldb.idcard or {},
				extra = leveldb.extra or {}
			}
			local appid = "509e243c05c74f9eb00e"
			local appsecret = "4167658d815d3595cfc30b91c6b21736"

			if tempDB.extra.CltApiID == 110 or tempDB.extra.CltApiID == 999 then
				appid = "2fb0c1128f814017954f"
				appsecret = "1942b40fab9856240d9e4525042e04fe"
			end

			local tmp = {
				ts = os.time(),
				uin = uin or self.Account.Uin
			}

			if on then
				self.loginActionSi = gFunc_getmd5(tmp.uin .. tmp.ts)
			end

			tmp.auth = gFunc_getmd5(appsecret .. tmp.ts .. tmp.uin)
			tmp.appid = appid
			tmp.si = self.loginActionSi
			tmp.bt = on and 1 or 0

			if not tempDB.idcard.countryauthpi or tempDB.idcard.countryauthpi == "" or tempDB.idcard.countryauthpi == "authing" or tempDB.idcard.countryauthpi == "authfail" then
				tmp.ct = 2
				tmp.pi = ""
				tmp.di = gFunc_getmd5(tempDB.extra.DeviceID)

				return
			else
				tmp.ct = 0
				tmp.pi = tempDB.idcard.countryauthpi
				tmp.di = ""
			end

			local urlTb = {
				"https://shequ.mini1.cn:8081/auth/loginout"
			}
			local paramTb = {}

			for k, v in pairs(tmp) do
				paramTb[#paramTb + 1] = k .. "=" .. v
			end

			math.randomseed(tostring(os.time()):reverse():sub(1, 7))

			local index = math.random(#urlTb)
			local url = urlTb[index] .. "?" .. table.concat(paramTb, "&")

			if utils.env == 1 then
				url = "http://120.24.64.132:19921/auth/loginout?" .. table.concat(paramTb, "&")
			end

			ns_http.func.rpc_string_raw(url, function (res)
				if utils.env == 0 then
					local ok, json = pcall(JSON.decode, JSON, res)

					if ok and type(json) == "table" and json.msg ~= "ok" then
						local index = index % #urlTb + 1
						local url = urlTb[index] .. "?" .. table.concat(paramTb, "&")

						ns_http.func.rpc_string_raw(url)
					end
				end
			end)
		end
	end,
	checkResetNickname = function (self)
		if self.now >= 1646582400 then
			return
		end

		if utils.env == 0 or utils.env == 1 then
			local strnow = os.date("%Y-%m-%d", self.now)
			local recordtime = getkv("resetnick." .. self.Account.Uin)

			if recordtime and strnow == recordtime then
				return
			end

			threadpool:wait(2)

			local appsecret = "9b42d0a3b016b1d154063c867041e763"
			local tmp = {
				time = self.now,
				uin = uin or self.Account.Uin
			}
			tmp.auth = gFunc_getmd5(appsecret .. tmp.time .. tmp.uin)
			local urlTb = {}

			if utils.env == 0 then
				urlTb = {
					"http://certification.mini1.cn:19895/reset/search",
					"http://certification.mini1.cn:19895/reset/search"
				}
			else
				urlTb = {
					"http://120.24.64.132:19895/reset/search"
				}
			end

			local paramTb = {}

			for k, v in pairs(tmp) do
				paramTb[#paramTb + 1] = k .. "=" .. v
			end

			local index = math.mod(self.Account.Uin, #urlTb) + 1

			if not urlTb[index] then
				return
			end

			local url = urlTb[index] .. "?" .. table.concat(paramTb, "&")

			ns_http.func.rpc_string_raw(url, function (res)
				local ok, json = pcall(JSON.decode, JSON, res)

				if ok and type(json) == "table" then
					setkv("resetnick." .. self.Account.Uin, strnow)

					if json.code and json.code == 0 and json.msg and json.msg == "ok" then
						local contentText = "亲爱的冒险家：由于迷你世界用户昵称规则升级，你的昵称不符合最新规则，系统将于近期对你的昵称进行自动重置，你可在系统重置后修改你的昵称，谢谢你的理解和支持！"

						MessageBoxFrame2:Open(5, "昵称重置提示", contentText)
					end
				end
			end)
		end
	end
}, class.AccountForServerAndClient)
