local class = _G.class

if not class then
	return
end

local container = _G.container

class.define("BuddyInfo", {
	m_diamond = 0,
	m_viplevel = 0,
	m_uin = 0,
	m_worldnum = 0,
	m_nickname = "",
	m_skinModel = 0,
	m_model = 1,
	m_achievementscore = 0,
	m_credit = 0,
	m_flower = 0,
	constructor = function (self, info)
		if info then
			self.m_model = info.RoleInfo.Model
			self.m_skinModel = info.RoleInfo.SkinID
			self.m_nickname = info.RoleInfo.NickName
			self.m_worldnum = 0
			self.m_uin = info.Uin
			self.m_viplevel = info.UinQQInfo and info.UinQQInfo.blue_vip_level or 0
			self.m_diamond = info.Diamond
			self.m_flower = info.Flower
			self.m_credit = info.Credit
			self.m_achievementscore = info.AchievementScore
		end
	end,
	getUin = function (self)
		return self.m_uin
	end,
	getModel = function (self)
		return self.m_model
	end,
	getSkinMode = function (self)
		return self.m_skinModel
	end,
	getNickName = function (self)
		return self.m_nickname
	end,
	getVipLevel = function (self)
		return self.m_viplevel
	end,
	getDiamond = function (self)
		return self.m_diamond
	end,
	getFlower = function (self)
		return self.m_flower
	end,
	getCredit = function (self)
		return self.m_credit
	end,
	getAchievementScore = function (self)
		return self.m_achievementscore
	end,
	addCredit = function (self)
		self.m_credit = self.m_credit + 1
	end,
	getWorldNum = function (self)
		return self.m_worldnum
	end
})
