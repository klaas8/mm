local class = _G.class

if not class then
	return
end

local container = _G.container

require("luascript.clientEx.ManagerBase")
class.define("HomeChestMgr", {
	account = {
		get = function (self)
			return self.service.AccountManager.account
		end
	},
	Chest = {
		get = function (self)
			return self.account.Chest
		end
	},
	constructor = function (self, service, origin)
		self.service = service
		self.origin = origin

		service:listento("chest", function (method, version_info, ...)
			local account = self.account
			local conn = self.conn

			while conn.is_doing_rpc do
				threadpool:wait(1)
			end

			local local_version_info = account:version_info()
			local same = true

			for i, v in ipairs(local_version_info) do
				if v ~= version_info[i] then
					same = false
				end
			end

			print("service:listento,chest:", method, version_info, ...)

			if same then
				return
			end

			local code = account:precheck(method, ...)

			if code ~= ErrorCode.OK then
				return
			end

			pcall(account[method], account, ...)
		end)
		threadpool:work(function ()
			self:loop()
		end)
	end,
	destroy = function (self)
		self.origin = nil
		self.client = nil
		self.valid = false
	end,
	getSelfChestTreeInfo = function (self)
		local Chest = self.Chest
		local leveldb = self.account.leveldb
		local ChestTreeInfo = Chest.ChestTreeInfo

		return {
			exp = ChestTreeInfo.Exp,
			level = ChestTreeInfo.Level,
			water = ChestTreeInfo.Water,
			chestNum = ChestTreeInfo.ChestNum,
			isLevelUp = ChestTreeInfo.IsLevelUp,
			addLevel = ChestTreeInfo.AddLevel,
			Viping = leveldb.Viping or false,
			FreeGoldenTime = leveldb.FreeGoldenTime or 0
		}
	end,
	afterGotChestTreeLevelUpBonus = function (self)
		print("升级之后")

		local Chest = self.Chest
		local ChestTreeInfo = Chest and Chest.ChestTreeInfo

		if ChestTreeInfo then
			ChestTreeInfo.AddLevel = 0
			ChestTreeInfo.IsLevelUp = 0
		end

		print("升级之后", self:getSelfChestTreeInfo())
	end,
	getSelfChestTreeLevel = function (self)
		local Chest = self.Chest

		return Chest and Chest.ChestTreeInfo and Chest.ChestTreeInfo.Level or 0
	end,
	getChestInfosNum = function (self)
		local Chest = self.Chest
		local ChestTreeInfo = Chest.ChestTreeInfo

		return ChestTreeInfo.ChestNum
	end,
	getChestInfo = function (self, idx)
		idx = idx + 1
		local cache = self.cache
		cache.Chest = cache.Chest or {}

		if not cache.Chest.ChestInfo then
			local Chest = self.Chest
			local ChestTreeInfo = Chest.ChestTreeInfo
			local ChestNum = ChestTreeInfo.ChestNum
			local info = {}

			for i = 1, ChestNum do
				info[i] = {
					type = ChestTreeInfo.ChestInfo[i].Type,
					time = ChestTreeInfo.ChestInfo[i].Time,
					state = ChestTreeInfo.ChestInfo[i].Status
				}
			end

			cache.Chest.ChestInfo = info

			print("cache ChestInfo for client")
		end

		return cache.Chest.ChestInfo[idx]
	end,
	getVisitInfosNum = function (self)
		local Chest = self.Chest
		local ChestTreeInfo = Chest.ChestTreeInfo
		local VisitLog = ChestTreeInfo.VisitLog

		return VisitLog.VisitNum
	end,
	getVisitInfo = function (self, idx)
		idx = idx + 1
		local Chest = self.Chest
		local ChestTreeInfo = Chest.ChestTreeInfo
		local VisitLog = ChestTreeInfo.VisitLog
		local VisitInfo = VisitLog.VisitInfo

		if VisitInfo then
			local info = VisitInfo[idx]

			if info then
				return {
					uin = info.Buddy.Uin,
					model = info.Buddy.RoleInfo.Model,
					skin = info.Buddy.RoleInfo.SkinID,
					nickName = info.Buddy.RoleInfo.NickName,
					action = info.Action
				}
			end
		end
	end,
	getBuddyChestTreeLevel = function (self)
		local cache = self.eventcache.postVisitBuddyChest

		return cache and cache.ChestTreeLevel or 0
	end,
	getBuddyChestTreeExp = function (self)
		local cache = self.eventcache.postVisitBuddyChest

		return cache and cache.info and cache.info.exp or 0
	end,
	getChestGiftInfo = function (self)
		local eventcache = self.eventcache
		local cache = eventcache.postOpenChest
		local const = self.const

		if cache then
			local Type = cache.Type
			local ItemList = cache.ItemList
			local MiniBean = 0
			local Exp = 0

			for i, v in ipairs(ItemList) do
				if v.ItemID == const.ITEM_ID_MINI_BEAN then
					MiniBean = MiniBean + v.ItemNum
				end

				if v.ItemID == const.ITEM_ID_TREE_EXP then
					Exp = Exp + v.ItemNum
				end
			end

			return {
				type = Type,
				minibean = MiniBean,
				exp = Exp
			}
		end
	end,
	getChestGiftItemsNum = function (self)
		local eventcache = self.eventcache
		local cache = eventcache.postOpenChest
		local const = self.const

		if cache then
			local Num = 0
			local ItemList = cache.ItemList

			for i, v in ipairs(ItemList) do
				if v.ItemID ~= const.ITEM_ID_MINI_BEAN and v.ItemID ~= const.ITEM_ID_TREE_EXP then
					Num = Num + 1
				end
			end

			return Num
		end

		return 0
	end,
	getChestGiftItem = function (self, index)
		index = index + 1
		local eventcache = self.eventcache
		local cache = eventcache.postOpenChest
		local const = self.const

		if cache then
			local Num = 0
			local ItemList = cache.ItemList

			for i, v in ipairs(ItemList) do
				if v.ItemID ~= const.ITEM_ID_MINI_BEAN and v.ItemID ~= const.ITEM_ID_TREE_EXP then
					Num = Num + 1

					if Num == index then
						return {
							itemID = v.ItemID,
							num = v.ItemNum
						}
					end
				end
			end
		end

		return nil
	end,
	requestChestTreeReq = function (self, Uin)
		local account = self.account

		if Uin == account.Uin then
			local code = self:remote_call("homesvr", "chest_update")

			self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)
		else
			print("刷新好友的 chest tree ")

			local PreBuddyChestTreeLevel = self:getBuddyChestTreeLevel()
			local code, ChestTreeLevel, extrainfo = self:remote_call("homesvr", "chest_visit", Uin)

			print("chest_visit code = ", code, "ChestTreeLevel = ", ChestTreeLevel, " PreBuddyChestTreeLevel = ", PreBuddyChestTreeLevel)

			if code == ErrorCode.OK then
				local BuddyDetail = account:getBuddyDetailByUin(Uin)

				if BuddyDetail then
					local chest = BuddyDetail.chest
					chest.ChestTreeLevel = ChestTreeLevel
				end

				self.eventcache.postVisitBuddyChest = {
					Uin = Uin,
					ChestTreeLevel = ChestTreeLevel,
					info = extrainfo
				}

				self:trigger("postVisitBuddyChest", PreBuddyChestTreeLevel, Uin)
			else
				self:trigger("postVisitBuddyChest", 0, 0)
			end
		end
	end,
	requestChestReq = function (self, optype, pos)
		print("XXXXXXXXXXX ", optype)

		local const = self.const
		local code = ErrorCode.FAILED
		local apiid = GetClientInfo():GetAppId() or 0
		local ver = GetClientInfo():GetClientVersion() or 0
		local lang = get_game_lang() or "nil"
		local country = get_game_country() or "nil"

		if optype == const.CHEST_OP_OPEN then
			code = self:remote_call("homesvr", "chest_open", pos, ver, apiid, lang, country)

			self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)
		elseif optype == const.CHEST_OP_SPEED then
			code = self:remote_call("homesvr", "chest_speedup", pos)

			self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)

			if code == ErrorCode.OK then
				self:trigger("postOpenChest", optype)

				self.eventcache.postOpenChest = self.account:ctxpop("chest.lot")
			end
		elseif optype == const.CHEST_OP_GIFT then
			code = self:remote_call("homesvr", "chest_lot_one", pos, ver, apiid, lang, country)

			self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)

			if code == ErrorCode.OK then
				self:trigger("postOpenChest", optype)

				self.eventcache.postOpenChest = self.account:ctxpop("chest.lot")
			end
		elseif optype == const.CHEST_OP_TEN_GIFT then
			code = self:remote_call("homesvr", "chest_lot_ten", ver, apiid, lang, country)

			self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)

			if code == ErrorCode.OK then
				local cache = self.account:ctxpop("chest.lot")
				local m = {}

				for i, v in ipairs(cache.ItemList) do
					m[v.ItemID] = (m[v.ItemID] or 0) + v.ItemNum
				end

				local hebing = {}

				for k, v in pairs(m) do
					table.insert(hebing, {
						ItemID = k,
						ItemNum = v
					})
				end

				cache.ItemList = hebing
				self.eventcache.postOpenChest = cache

				self:trigger("postOpenChest", optype)
			end
		else
			assert(false)
		end

		return code == ErrorCode.OK
	end,
	requestActionReq = function (self, Uin, action)
		local const = self.const
		local code = ErrorCode.FAILED
		local apiid = GetClientInfo():GetAppId() or 0
		local ver = GetClientInfo():GetClientVersion() or 0
		local lang = get_game_lang() or "nil"
		local country = get_game_country() or "nil"

		if action == const.CHEST_TREE_ACTION_WATER_SELF_ADD then
			code, seed, info = self:remote_call("homesvr", "water_self", ver, apiid, lang, country)

			self:trigger("postUpdateChestTree", code == ErrorCode.OK and 1 or code)
		elseif action == const.CHEST_TREE_ACTION_WATER_OTHER_ADD then
			code, seed, info = self:remote_call("homesvr", "water_other", Uin, ver, apiid, lang, country)

			if code == ErrorCode.OK then
				local account = self.account
				local BuddyDetail = account:getBuddyDetailByUin(Uin)

				if BuddyDetail and BuddyDetail.chest then
					BuddyDetail.chest.water = BuddyDetail.chest.water - 1

					self:trigger("postVisitBuddyChest", BuddyDetail.chest.ChestTreeLevel, Uin)
				end
			end
		elseif action == const.CHEST_TREE_ACTION_WATER_FULL then
			assert(false)
		elseif action == const.CHEST_TREE_ACTION_WATER_POOR then
			assert(false)
		elseif action == const.CHEST_TREE_ACTION_BUG then
			code, seed, info = self:remote_call("homesvr", "bug_other", Uin, ver, apiid, lang, country)

			if code == ErrorCode.OK then
				local account = self.account
				local BuddyDetail = account:getBuddyDetailByUin(Uin)

				if BuddyDetail and BuddyDetail.chest then
					BuddyDetail.chest.worms = BuddyDetail.chest.worms - 1

					self:trigger("postVisitBuddyChest", BuddyDetail.chest.ChestTreeLevel, Uin)
				end
			end
		elseif action == const.CHEST_TREE_ACTION_LEVEL_UP then
			assert(false)
		else
			assert(false)
		end

		return code and ErrorCode.OK == code or false, info
	end
}, class.ManagerBase)
