if not loadwwwcache then
	return
end

function _G.print(...)
	local a = {
		...
	}
	local info = debug.getinfo(2)

	if info then
		table.insert(a, 1, string.format("[%s:%d]", info.short_src or "", info.currentline or 0))
	end

	local m = string.format("[%s.%d][tick:%d][fps:%d]", os.date("%H:%M:%S", threadpool and threadpool:now() or sec), (threadpool and threadpool:msec() or starttime) % 1000, threadpool and threadpool.env and threadpool.env.c or 0, threadpool and threadpool.env and threadpool.env.fps or 0)

	for i, v in ipairs(a) do
		if type(v) == "table" then
			local ss = table.tostring and table.tostring(v) or tostring(v)

			if #ss > 8000 then
				ss = string.sub(ss, 1, 8000)
			end

			m = m .. ss .. " "
		else
			local ss = tostring(v)

			if #ss > 8000 then
				ss = string.sub(ss, 1, 8000)
			end

			m = m .. ss .. " "
		end
	end

	if #m >= 8192 then
		m = string.sub(m, 1, 8191)
	end

	if #a <= 0 then
		m = "nil"
	end

	LuaInterface:log(m)
end
