if not loadwwwcache then
	return
end

_G.printflag = true
local m = ""

local function log(...)
	local a = {
		...
	}

	for i, v in ipairs(a) do
		if type(v) == "table" then
			m = m .. " " .. table.tostring(v)
		else
			m = m .. " " .. tostring(v)
		end
	end

	m = m .. "\n"
end

local printting = false
local blockmsg = {
	"getAccountItemNum",
	"OperationAccountItem",
	"getSkinBody",
	"getRoleBody",
	"clientVersionToStr",
	"clientVersion",
	"isCollectUin",
	"getIthRoom"
}

for i, v in ipairs(blockmsg) do
	blockmsg[v] = true
end

_G.ttymsglist = _G.ttymsglist or {}
local old_print = _G.print

function _G.print(...)
	old_print(...)

	if printting == true then
		return
	end

	printting = true
	local ok, msg = pcall(function (...)
		local s = ""
		local isblock = false
		local a = {
			...
		}

		if #a > 0 then
			for i, v in ipairs(a) do
				if not isblock then
					if type(v) == "table" then
						local ss = table.tostring and table.tostring(v) or tostring(v)

						if #ss > 1000 then
							ss = string.sub(ss, 1, 1000)
						end

						s = s .. ss .. " "
					else
						local ss = tostring(v)

						for ii, vv in ipairs(blockmsg) do
							if ss:match(vv) then
								isblock = true

								break
							end
						end

						if isblock then
							break
						end

						if #ss > 1000 then
							ss = string.sub(ss, 1, 1000)
						end

						s = s .. ss .. " "
					end
				end
			end
		end

		if not isblock then
			if #s >= 1024 then
				s = string.sub(s, 1, 1023)
			end

			if #a <= 0 then
				table.insert(ttymsglist, " nil ")
			end

			if #ttymsglist <= 1000 then
				table.insert(ttymsglist, s)
			end
		end
	end, ...)

	if not ok and #ttymsglist <= 1000 then
		table.insert(ttymsglist, msg)
	end

	printting = false
end

local msgpack = loadwwwcache("MessagePack")

local function http_encode(data)
	local packdata = msgpack.pack(data)
	local s = xxtea.encrypt_zip(packdata, #packdata, "b64")
	s = s:gsub("+", "-"):gsub("/", "_"):gsub("=", ":")

	return s
end

local url = LuaInterface:geturl()
url = url:gsub("/$", "") .. "/tty/print?"

local function http_print(info)
	local query = "msg=" .. http_encode(info)

	ns_http.func.rpc_string(url .. query, function ()
	end)
end

_G.g_tty_loop = _G.g_tty_loop or delegate(function ()
	threadpool:work(function ()
		while true do
			local list = {}

			for i = 1, 10 do
				if #ttymsglist > 0 then
					table.insert(list, table.remove(ttymsglist, 1))
				else
					break
				end
			end

			if #list > 0 then
				http_print(list)
			end

			threadpool:wait(0.5)
		end
	end)

	return true
end)

log("test", threadpool.env.errorlist)
print("this ceshi165")
log("ceshi165", ttymsglist)

return m
