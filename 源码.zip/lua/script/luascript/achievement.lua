local GroupDefCache = {}

function GetAchievementOthenPlayState(objid, achievementDef)
	for i = 1, 4 do
		local frontId = achievementDef.FrontID[i - 1]
		local frontDef = AchievementMgr:getAchievementDef(frontId)

		if frontId > 0 and frontDef ~= nil and GetAchievementOthenPlayState(objid, frontDef) < 3 then
			if frontId == 1221 then
				local k = 8
			end

			return 0
		end
	end

	local ArryNum = AchievementMgr:getAchievementArryNum(objid, achievementDef.ID)

	if frontId == 1221 then
		local k = 9
	end

	if achievementDef.GoalNum <= ArryNum then
		if AchievementMgr:getAchievementRewardState(objid, achievementDef.ID) == REWARD_RECEIVED then
			if frontId == 1221 then
				local k = 9
			end

			return 3
		else
			if AchievementMgr:getAchievementRewardState(objid, achievementDef.ID) ~= REWARD_CAN_RECEIVE then
				AchievementMgr:setAchievementRewardState(objid, achievementDef.ID, 1)
			end

			if frontId == 1221 then
				local k = 9
			end

			return 22
		end
	else
		if frontId == 1222 or frontId == 1221 then
			local k = 9
		end

		return 2
	end
end

function GetTypeAchievemntTable(Group)
	local t_info = {}

	if GroupDefCache[Group] then
		return GroupDefCache[Group]
	end

	local strIDs = AchievementMgr:getAchievementIDsByGroup(Group)
	local t_Task = StringSplit(strIDs, ",")

	if type(t_Task) ~= "table" then
		return t_info
	end

	table.sort(t_Task, function (a, b)
		local numa = tonumber(a) or 999999999
		local numb = tonumber(b) or 999999999

		return numa < numb
	end)

	for i = 1, #t_Task do
		local achievementId = tonumber(t_Task[i]) or 0
		local achievementDef = AchievementMgr:getAchievementDef(achievementId)

		if achievementDef ~= nil and Group == achievementDef.Group then
			table.insert(t_info, achievementDef)
		end
	end

	GroupDefCache[Group] = t_info

	return t_info
end

function UpdateClientAchievementFrameById(objid, achiId)
	threadpool:work(function ()
		local achievementDef = AchievementMgr:getAchievementDef(achiId)

		if achievementDef ~= nil then
			local t_info = GetTypeAchievemntTable(achievementDef.Group)

			for k, v in pairs(t_info) do
				local lachievementDef = t_info[k]
				local frontState = AchievementMgr:getAchievementState(objid, lachievementDef.ID)
				local achievementState = GetAchievementOthenPlayState(objid, lachievementDef)

				if achievementState == 0 then
					-- Nothing
				elseif achievementState == 22 then
					achievementState = 2
				end

				if frontState ~= achievementState and achievementState ~= 0 then
					AchievementMgr:setAchievementState(objid, t_info[k].ID, achievementState)
				end
			end
		end
	end)
end
