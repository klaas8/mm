UrlPath = {
	GetPath = function (self, urlInfoTable, extPath)
		if urlInfoTable and urlInfoTable.path then
			if extPath then
				return urlInfoTable.path .. extPath
			end

			return urlInfoTable.path
		end

		return ""
	end,
	GetServerUrl = function (self, urlInfoTable)
		if urlInfoTable and urlInfoTable.serverListKey then
			return ClientUrl:GetUrlString(urlInfoTable.serverListKey)
		else
			return ""
		end
	end,
	GetAddress = function (self, urlInfoTable, extPath)
		local url = self:GetServerUrl(urlInfoTable)
		local path = self:GetPath(urlInfoTable)

		if extPath then
			path = path .. extPath
		end

		return string.format("%s%s", url, path)
	end,
	GetAddressByServerUrl = function (self, serverUrl, urlInfoTable)
		local path = self:GetPath(urlInfoTable)

		return string.format("%s%s", serverUrl, path)
	end,
	GetAddressByPath = function (self, path, urlInfoTable)
		local url = self:GetServerUrl(urlInfoTable)

		return string.format("%s%s", url, path)
	end
}
