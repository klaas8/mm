UrlPathConf = ClassList.UrlPathConf
UrlPathConf.CanViewNoticeNormal = {
	serverListKey = "NoticeUrl",
	path = "/popvc/announcement/queryListForClient",
	key = "CanViewNoticeNormal"
}
UrlPathConf.CanViewNoticeActivity = {
	serverListKey = "NoticeUrl",
	path = "/popvc/eventClient/query",
	key = "CanViewNoticeActivity"
}
