local UrlPathConf = Class("UrlPathConf")
UrlPathConf.CloudUrlQuery = {
	path = "v2/room/query",
	key = "CloudUrlQuery"
}
UrlPathConf.CloudUrlGet = {
	path = "v2/room/get",
	key = "CloudUrlGet"
}
UrlPathConf.CloudUrlCreate = {
	path = "/v2/room/create",
	key = "CloudUrlCreate"
}
UrlPathConf.CloudUrlBatchQuery = {
	path = "/v2/room/batch_query",
	key = "CloudUrlBatchQuery"
}
UrlPathConf.CloudUrlGetRent = {
	path = "/v2/rent_room/get",
	key = "CloudUrlGetRent"
}
UrlPathConf.CloudUrlCreatePersonal = {
	path = "/v2/personal_room/create",
	key = "CloudUrlCreatePersonal"
}
UrlPathConf.MATaskUpUrl = {
	serverListKey = "Http",
	path = "miniw/php_cmd?"
}
