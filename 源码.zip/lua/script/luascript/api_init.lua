require("ui/mobile/uicommon.lua")
GameUI:LoadXmlForLua("ui/mobile/cursor.xml")
GameUI:LoadXmlForLua("ui/mobile/Fonts.xml")

if GetClientInfo():isEditorMode() then
	require("ui/mobile/http.lua")
	GameUI:LoadXmlForLua("ui/mobile/loading.xml")
else
	require("ui/mobile/mvc/commonComp/http.lua")
	pcall(function ()
		if IsNewFguiFlag == nil then
			GameUI:LoadXmlForLua("ui/mobile/mvc/commonComp/loading.xml")
		end
	end)
end

require("luascript/init.lua")
