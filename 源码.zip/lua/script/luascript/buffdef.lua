function TicksOnPoint(ticks, point)
	if ticks > 0 and ticks % point == 0 then
		return true
	else
		return false
	end
end

function AddHPBuff_Start(actor, def)
end

function AddHPBuff_End(actor, def)
end

function AddHPBuff_Update(actor, def, ticks)
	actor:addHP(def.AttrValues[0])
end

function DamageBuff_Start(actor, def)
end

function DamageBuff_End(actor, def)
end

function DamageBuff_Update(actor, def, ticks)
	actor:attackedByBuff(def.AttrValues[0], def.AttrValues[1])
end

function StarveBuff_Start(actor, def)
end

function StarveBuff_End(actor, def)
end

function StarveBuff_Update(actor, def)
	actor:staminaUsed(def.AttrValues[0])
end
