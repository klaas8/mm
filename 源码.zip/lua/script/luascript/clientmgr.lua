return {
	getApiId = function (self)
		return GetClientInfo():GetAppId()
	end,
	WriteMemFile = function (self, strfile, skey)
		return GetClientInfo():ReadMemFile(strfile, skey)
	end,
	getUserAccountInfo = function (self)
		return GetClientInfo():getUserAccountInfo()
	end,
	readDocumentsFile = function (self, filename)
		return GetClientInfo():readDocumentsFile(filename)
	end,
	writeDocumentsFile = function (self, filename, content)
		return GetClientInfo():writeDocumentsFile(filename, content)
	end,
	saveUserAccountInfo = function (self, jsonstr)
		return GetClientInfo():saveUserAccountInfo(jsonstr)
	end,
	getGameData = function (self, gameenv)
		return GetIWorldConfig():getGameData(gameenv)
	end,
	getDeviceID = function (self)
		return GetClientInfo():getDeviceID()
	end,
	luaLoginCallback = function (self, num, uin)
		return GetClientInfo():luaLoginCallback(num, uin)
	end,
	getAllAccountInfos = function (self)
		return GetClientInfo():getAllAccountInfos()
	end,
	getEnterParam = function (self, ticket)
		return GetClientInfo():getEnterParam(ticket)
	end,
	GetFunnyCoreLoginAccountInfo = function (self)
		return SdkManager:GetFunnyCoreLoginAccountInfo()
	end,
	isPureServer = function (self)
		return GetClientInfo():isPureServer()
	end,
	clientVersion = function (self)
		return GetClientInfo():GetClientVersion()
	end,
	clientVersionFromStr = function (self, version_str)
		return GetClientInfo():clientVersionFromStr(version_str)
	end,
	getPlatform = function (self)
		return GetClientInfo():getPlatform()
	end,
	setBrowserAdCanShow = function (self, enable)
		return Advertisement:setBrowserAdEnable(enable)
	end,
	InitAdvertisementsSDK = function (self, platform_id)
		return Advertisement:init(platform_id)
	end,
	AdvertisementsPreLoad = function (self, platform_id, position_id)
		Advertisement:preload(platform_id, position_id)
	end,
	AdvertisementsLoadStatus = function (self, platform_id, position_id)
		Advertisement:hasLoaded(platform_id, position_id)
	end,
	gameExit = function (self)
		return GetClientApp():GameExit()
	end,
	setPayExtendParamsToSdk = function (self, num)
		return SdkManager:setPayExtendParamsToSdk(num)
	end,
	setPayExtendParamsByQQ = function (self, Prepay_id, Signature, strext)
		return SdkManager:setPayExtendParamsByQQ(Prepay_id, Signature, strext)
	end,
	mode = function (self)
		return nil
	end,
	isQQGamePcApi = function (self, ApiID)
		return GetClientInfo():isQQGamePcApi(ApiID)
	end,
	getDataTransferState = function (self)
		return GetClientInfo():getDataTransferState()
	end
}
