if not loadwwwcache then
	return
end

local config = loadwwwcache("config")

if LuaInterface and LuaInterface:ispc() and config and config.debugger then
	_G.pause = loadwwwcache("debugger")
end

local class = {}

local function __tostring(value, indent, vmap)
	local str = ""
	indent = indent or ""
	vmap = vmap or {}

	if type(value) ~= "table" then
		if type(value) == "string" then
			if string.byte(value, 1) == 91 then
				str = string.format("'%s'", value)
			elseif value:match("%[") then
				str = string.format("\"%s\"", value)
			else
				str = string.format("[[%s]]", value)
			end
		else
			str = tostring(value)
		end
	else
		if type(vmap) == "table" then
			if vmap[value] then
				return "(" .. tostring(value) .. ")"
			end

			vmap[value] = true
		end

		local auxTable = {}
		local iauxTable = {}
		local iiauxTable = {}

		for i, v in pairs(value) do
			if type(i) == "number" then
				if i == 0 then
					table.insert(iiauxTable, i)
				else
					table.insert(iauxTable, i)
				end
			else
				table.insert(auxTable, i)
			end
		end

		table.sort(iauxTable)

		str = str .. "{\n"
		local separator = ""
		local entry = "\n"
		local barray = true
		local kk, vv = nil

		for i, k in ipairs(iauxTable) do
			if i == k and barray then
				entry = __tostring(value[k], indent .. "    ", vmap)
				str = str .. separator .. indent .. "    " .. entry
				separator = ", \n"
			else
				barray = false

				table.insert(iiauxTable, k)
			end
		end

		for i, fieldName in ipairs(iiauxTable) do
			kk = tostring(fieldName)

			if type(fieldName) == "number" then
				kk = "[" .. kk .. "]"
			end

			if type(fieldName) == "string" and (fieldName:match("%.") or fieldName:match("-")) then
				kk = "[\"" .. kk .. "\"]"
			end

			entry = kk .. " = " .. __tostring(value[fieldName], indent .. "    ", vmap)
			str = str .. separator .. indent .. "    " .. entry
			separator = ", \n"
		end

		for i, fieldName in ipairs(auxTable) do
			kk = tostring(fieldName)

			if type(fieldName) == "number" then
				kk = "[" .. kk .. "]"
			end

			if type(fieldName) == "string" and (fieldName:match("%.") or fieldName:match("-")) then
				kk = "[\"" .. kk .. "\"]"
			end

			vv = value[fieldName]
			entry = kk .. " = " .. __tostring(value[fieldName], indent .. "    ", vmap)
			str = str .. separator .. indent .. "    " .. entry
			separator = ", \n"
		end

		str = str .. "\n" .. indent .. "}"
	end

	return str
end

table.tostring = __tostring

local function th_table_dup(ori_tab)
	if type(ori_tab) ~= "table" then
		return nil
	end

	local new_tab = {}

	for i, v in pairs(ori_tab) do
		local vtyp = type(v)

		if vtyp == "table" then
			new_tab[i] = th_table_dup(v)
		elseif vtyp == "thread" then
			new_tab[i] = v
		elseif vtyp == "userdata" then
			new_tab[i] = v
		else
			new_tab[i] = v
		end
	end

	return new_tab
end

table.clone = th_table_dup

local function th_table_merge(dest, src, cb, path)
	if type(dest) == "table" and type(src) == "table" then
		for k, v in pairs(src) do
			local tp = type(v)
			local origin = dest[k]

			if tp == "table" then
				dest[k] = dest[k] or {}

				th_table_merge(dest[k], v, cb, cb and (path and path .. "." .. k or k) or nil)
			elseif tp == "boolean" then
				dest[k] = v
			elseif tp == "string" then
				dest[k] = v
			elseif tp == "number" then
				dest[k] = v
			elseif tp == "userdata" then
				-- Nothing
			elseif tp == "cdata" then
				-- Nothing
			elseif tp == "thread" then
				-- Nothing
			elseif tp == "function" then
				dest[k] = v
			end

			if type(cb) == "function" then
				cb(path and path .. "." .. k or k, v, origin)
			end
		end
	end
end

table.merge = th_table_merge

local function th_table_equal(a, b)
	local ta = type(a)
	local tb = type(b)

	if ta ~= tb then
		return false
	end

	if ta == "table" then
		local n = 0

		for k, v in pairs(a) do
			n = n + 1
			local tp = type(v)

			if tp ~= type(b[k]) then
				return false
			end

			if tp == "string" then
				if v ~= b[k] then
					return false
				end
			elseif tp == "number" then
				if v ~= b[k] then
					return false
				end
			elseif tp == "table" then
				if th_table_equal(v, b[k]) == false then
					return false
				end
			else
				return false
			end
		end

		for k, v in pairs(b) do
			n = n - 1
		end

		if n ~= 0 then
			return false
		end

		return true
	elseif ta == "number" or ta == "string" or ta == "boolean" then
		if ta == "number" and math.floor(a) < a and math.floor(b) < b then
			if math.abs(a - b) > 1e-06 then
				return false
			end

			return true
		end

		return a == b
	else
		return false
	end
end

table.equal = th_table_equal
local ErrorCode = _G.ErrorCode
local keys = {}

if ErrorCode then
	for k, v in pairs(ErrorCode) do
		table.insert(keys, k)
	end

	for i, k in ipairs(keys) do
		ErrorCode[ErrorCode[k]] = k
	end
end

_G.utils = {}

if utils then
	utils.env = GetIWorldConfig():getGameData("game_env")
else
	utils.env = 0
end

function utils.get_value(tbl, ...)
	local t = tbl
	local n = select("#", ...)

	for i = 1, n do
		if type(t) == "table" then
			local a = select(i, ...)

			if a then
				t = t[a]
			end
		else
			break
		end
	end

	return t
end

function utils.set_value(tbl, data, ...)
	local r = tbl
	local n = select("#", ...)

	for i = 1, n do
		local v = select(i, ...)

		if i == n then
			r[v] = data

			return data
		end

		if type(r) == "table" then
			local d = nil
			d = r[v]

			if not d then
				d = {}
				r[v] = d
			end

			r = d
		else
			return
		end
	end
end

function utils.array2path(array)
	local path = nil

	for i, v in ipairs(array) do
		v = tostring(v)

		if not path then
			path = v
		else
			path = path .. "." .. v
		end
	end

	return path
end

function utils.split(str, mark)
	local a = {}

	for k in str:gmatch("[^" .. mark .. "]+") do
		table.insert(a, k)
	end

	return a
end

local path2array = {}
local path2array_cache_max = 1000
local path2array_cache_num = 0

function utils.path2array(path, istonumber)
	if path2array_cache_max < path2array_cache_num then
		path2array = {}
		path2array_cache_num = 0
	end

	if not path2array[path] then
		local array = {}

		if type(path) == "number" then
			array[1] = path
		elseif type(path) == "string" then
			for k in path:gmatch("[^%.]+") do
				if istonumber and k:match("^%[?-?%d+%]?$") then
					k = k:gsub("%[", ""):gsub("%]", "")
					k = tonumber(k)
				end

				table.insert(array, k)
			end
		else
			if pause then
				pause()
			end

			error("wrong type of path ")
		end

		path2array_cache_num = path2array_cache_num + 1
		path2array[path] = array
	end

	return path2array[path]
end

function utils.get_data_by_path(tbl, path, istonumber)
	assert(tbl and path)

	local a = utils.path2array(path, istonumber)
	local r = tbl

	for i, v in ipairs(a) do
		if type(r) == "table" then
			local d = nil
			d = r[v]

			if not d then
				d = {}
				r[v] = d
			end

			r = d
		else
			return nil
		end
	end

	return r
end

function utils.set_data_by_path(tbl, path, data, istonumber)
	assert(tbl and path)

	local a = utils.path2array(path, istonumber)
	local r = tbl

	for i, v in ipairs(a) do
		if type(r) ~= "table" then
			return
		end

		if i == #a then
			r[v] = data

			return data
		end

		if type(r) == "table" then
			local d = nil
			d = r[v]

			if not d then
				d = {}
				r[v] = d
			end

			r = d
		else
			return
		end
	end
end

local function get_timezone()
	local now = os.time()

	return os.difftime(now, os.time(os.date("!*t", now)))
end

utils.timezone = get_timezone()

function utils.ts2day(ts)
	return math.floor((ts - utils.time_2017_01_01) / 86400)
end

function utils.day2ts(day)
	return day * 86400 + utils.time_2017_01_01
end

function utils.day2date(day)
	return os.date("*t", day * 86400 + utils.time_2017_01_01)
end

function utils.day2month(day)
	return os.date("%Y%m", day * 86400 + utils.time_2017_01_01)
end

function utils.ts2month(ts)
	return os.date("%Y%m", ts)
end

if utils.env < 10 then
	utils.time_2017_01_01 = 1483200000
else
	utils.time_2017_01_01 = 1483228800
end

function utils.IsSameDay(t1, t2)
	t1 = t1 - 14400 - utils.time_2017_01_01
	t2 = t2 - 14400 - utils.time_2017_01_01
	local day = 86400

	return math.ceil(t1 / day) == math.ceil(t2 / day)
end

function utils.IsSameWeek(t1, t2)
	t1 = t1 - 14400 - utils.time_2017_01_01 - 86400
	t2 = t2 - 14400 - utils.time_2017_01_01 - 86400
	local week = 604800

	return math.ceil(t1 / week) == math.ceil(t2 / week)
end

function utils.hashtable(...)
	local t = {}
	local n = select("#", ...)

	for i = 1, n do
		t[select(i, ...)] = true
	end

	return t
end

local deep_copy = nil

function deep_copy(obj, b_tpl)
	if type(obj) == "table" then
		if obj.__cls__ == "class" then
			-- Nothing
		elseif type(obj.get) ~= "function" and type(obj.set) ~= "function" and not obj.pre and not obj.post or b_tpl then
			local ret = {}

			for k, v in pairs(obj) do
				if b_tpl then
					if k ~= "trace" and k ~= "pre" and k ~= "post" and k ~= "error_hock" then
						ret[k] = deep_copy(v)
					end
				else
					ret[k] = deep_copy(v)
				end
			end

			return ret
		end
	elseif type(obj) == "number" or type(obj) == "string" or type(obj) == "boolean" then
		return obj
	end
end

local deep_merge = nil

function deep_merge(src, dest)
	dest = dest or src

	if type(src) == "table" then
		if src.__cls__ ~= "class" then
			for k, v in pairs(src) do
				dest[k] = deep_merge(v, dest[k])
			end

			return dest
		end
	elseif type(src) == "number" or type(src) == "string" or type(src) == "boolean" or type(src) == "function" then
		return src
	end

	return dest
end

local function create_class(name, template)
	local setters = {}
	local getters = {}
	local objdecls = {}

	for pname, prop in pairs(template) do
		if type(prop) == "table" then
			if type(prop.set) == "function" or type(prop.get) == "function" then
				if type(prop.set) == "function" then
					setters[pname] = prop.set
				else
					setters[pname] = function ()
						error(pname .. " is readonly property!" .. debug.traceback())
					end
				end

				if type(prop.get) == "function" then
					getters[pname] = prop.get
				else
					getters[pname] = function ()
						error(pname .. " is not readable property!")
					end
				end
			elseif prop.__cls__ == "class" then
				objdecls[pname] = prop
				template[pname] = nil
			end
		end
	end

	local mt_index, mt_newindex = nil
	local mt = {
		__index = function (tbl, key)
			if getters[key] then
				return getters[key](tbl)
			elseif template[key] ~= nil then
				return template[key]
			elseif key == "__index" then
				return mt_index
			elseif key == "__newindex" then
				return mt_newindex
			elseif template.__index then
				return template.__index(tbl, key)
			end
		end,
		__newindex = function (tbl, key, val)
			if setters[key] then
				setters[key](tbl, val)
			else
				rawset(tbl, key, val)
			end
		end
	}
	mt_index = mt.__index
	mt_newindex = mt.__newindex
	local mm = {}

	local function new_func(...)
		local inc = deep_copy(template, true)
		inc.__cls__ = name
		local obj = setmetatable(inc, mt)

		if type(template.constructor) == "function" then
			template.constructor(obj, ...)
		end

		function obj.super(tbl, super_name, method_name, ...)
			method_name = method_name or "constructor"
			local f = mm[super_name] and mm[super_name][method_name]

			if type(f) ~= "function" then
				local super_cls = class[super_name]

				if type(super_cls) == "table" then
					local super_template = super_cls.template

					if type(super_template) == "table" then
						f = super_template[method_name]

						if type(f) == "function" then
							mm[super_name] = mm[super_name] or {}
							mm[super_name][method_name] = f
						end
					end
				end
			end

			if f then
				return f(obj, ...)
			end
		end

		return obj
	end

	local function cast_func(obj)
		setmetatable(obj, mt)

		for pname, cls in pairs(objdecls) do
			if type(obj[pname]) == "table" then
				cls.cast(obj[pname])
			end
		end

		obj.__cls__ = name

		function obj.super(tbl, super_name, method_name, ...)
			local f = mm[super_name] and mm[super_name][method_name]

			if type(f) ~= "function" then
				local super_cls = class[super_name]

				if type(super_cls) == "table" then
					local super_template = super_cls.template

					if super_template == "table" then
						local f = super_template[method_name]

						if type(f) == "function" then
							mm[super_name] = mm[super_name] or {}
							mm[super_name][method_name] = f
						end
					end
				end
			end

			if f then
				return f(obj, ...)
			end
		end

		return obj
	end

	return new_func, cast_func
end

function class.define(name, template, ...)
	if type(name) ~= "string" or type(template) ~= "table" then
		error("ERROR: class define error", name, template)
	end

	if class[name] then
		class.undefine(name)
	end

	local baselist = {
		...
	}

	if type(name) == "table" then
		baselist = {
			template
		}
		template = name
	end

	for i, base in ipairs(baselist) do
		if base.template then
			local b = table.clone(base.template)
			template = deep_merge(template, b)
		end
	end

	local new_func, cast_func = create_class(name, template)
	class[name] = {
		new = new_func,
		cast = cast_func,
		template = template
	}

	return class[name]
end

function class.undefine(name)
	class[name] = nil
end

function class.restore(obj)
	if type(obj) == "table" and obj.__cls__ then
		return class[obj.__cls__].cast(obj)
	else
		return obj
	end
end

function class.instanceof(obj, clsname)
	return obj.__cls__ == clsname
end

function class.cast(name, tbl)
	local cls = name and class[name]

	if cls and tbl and not getmetatable(tbl) then
		return cls.cast(tbl)
	end
end

_G.class = class

return class
