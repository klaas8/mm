local cur_gametime = 0
local circle_index = 0
local circle_state = 0
local prepare_time = 600
local circle_times = {
	{
		radius = 0.5,
		shrink = 1200,
		stable = 1200
	},
	{
		radius = 0.2,
		shrink = 1200,
		stable = 1200
	},
	{
		radius = 0.05,
		shrink = 1200,
		stable = 1200
	},
	{
		radius = 0,
		shrink = 1200,
		stable = 1200
	}
}
local chestgen_percent = 10
local chestgen_items = {
	[15003.0] = 100,
	[15004.0] = 10,
	[11015.0] = 10,
	[12051.0] = 50,
	[15006.0] = 10,
	[12241.0] = 10,
	[15001.0] = 20,
	[11025.0] = 10,
	[15000.0] = 10,
	[15002.0] = 10,
	[12553.0] = 20,
	[12050.0] = 10,
	[15005.0] = 10,
	[12561.0] = 30,
	[12005.0] = 10,
	[11005.0] = 10
}
local safe_shape = 0
local shrink_shape = 0
local safe_centerX = 0
local safe_centerZ = 0
local SafeRadius = 0
local shrink_centerX = 0
local shrink_centerZ = 0
local ShrinkRadius = 0

function wes_player_init(player)
	player:getLivingAttrib():addBuff(999, 1)

	return 1
end

function wes_gameload()
	WorldMgr:resetRandSeed()

	return 1
end

function wes_gamestart()
	cur_gametime = 0
	circle_index = 0
	circle_state = 0
	safe_shape = MapMarkMgr:newShape(MMARK_CIRCLE, false, 255, 255, 255)
	shrink_shape = MapMarkMgr:newShape(MMARK_CIRCLE, false, 255, 0, 0)

	GetGameInfo():SetMinimapRenderMode(1)

	return 1
end

wes_gamestart_client = wes_gamestart

function GetRandomItemFromTable(items)
	local sumprob = 0

	for k, v in pairs(items) do
		sumprob = sumprob + v
	end

	local prob = math.random(sumprob)
	sumprob = 0

	for k, v in pairs(items) do
		sumprob = sumprob + v

		if prob <= sumprob then
			return k
		end
	end

	return 0
end

function wes_on_chunkgen(chunkx, chunkz)
	if math.random(chestgen_percent) > 1 then
		return
	end

	if CurWorld == nil then
		return
	end

	local x, y, z = CurWorld:getChunkProperSpawnPos(chunkx, 0, chunkz)

	if y < 0 then
		return
	end

	local placedir = math.random(0, 3)

	CurWorld:setBlockAll(x, y, z, BLOCK_CHEST_WELL, placedir)

	local chest = CurWorld:getContainerMgr():getStorageBox(x, y, z)

	if chest then
		local nitemtype = 1

		if math.random(3) == 1 then
			nitemtype = nitemtype + 1

			if math.random(3) == 1 then
				nitemtype = nitemtype + 1
			end
		end

		for i = 1, nitemtype do
			local itemid = GetRandomItemFromTable(chestgen_items)

			if itemid == 15003 then
				chest:setItem(i - 1, itemid, math.random(50))
			elseif itemid == 12051 then
				chest:setItem(i - 1, itemid, math.random(30))
			else
				chest:setItem(i - 1, itemid, 1)
			end
		end
	end
end

function GetCircleState(gametime)
	local accumtime = 0

	for i = 1, #circle_times do
		local curcircle = circle_times[i]
		local new_accumtime = accumtime + curcircle.stable

		if gametime < new_accumtime then
			return i, 0, gametime - accumtime
		end

		accumtime = new_accumtime
		new_accumtime = accumtime + curcircle.shrink

		if gametime < new_accumtime then
			return i, 1, gametime - accumtime
		end

		accumtime = new_accumtime
	end

	return #circle_times, 1, 0
end

function GetSafeZoneRadius(index)
	local r = 1

	if index > 0 then
		r = circle_times[index].radius
	end

	local sx, sz, ex, ez = CurWorld:getRangeXZ(0, 0, 0, 0)
	local dist = math.sqrt((ex - sx) * (ex - sx) + (ez - sz) * (ez - sz))

	if dist == 0 then
		dist = 409600
	end

	return r * dist * 0.5
end

function wes_gamerun_client()
	if WorldMgr:getScriptVar(0) ~= circle_index or WorldMgr:getScriptVar(1) ~= circle_state then
		cur_gametime = 0
		circle_index = WorldMgr:getScriptVar(0)
		circle_state = WorldMgr:getScriptVar(1)
		ShrinkRadius = WorldMgr:getScriptVar(2)
		shrink_centerX = WorldMgr:getScriptVar(3)
		shrink_centerZ = WorldMgr:getScriptVar(4)
		SafeRadius = WorldMgr:getScriptVar(5)
		safe_centerX = WorldMgr:getScriptVar(6)
		safe_centerZ = WorldMgr:getScriptVar(7)

		MapMarkMgr:showShape(safe_shape, true)
		MapMarkMgr:showShape(shrink_shape, true)
	else
		cur_gametime = cur_gametime + 1
	end

	if circle_index == 0 then
		return 0
	end

	MapMarkMgr:updateCircle(safe_shape, safe_centerX, safe_centerZ, SafeRadius)

	local t = 0

	if circle_state > 0 then
		t = cur_gametime / circle_times[circle_index].shrink

		if t > 1 then
			t = 1
		end
	end

	local r = ShrinkRadius + (SafeRadius - ShrinkRadius) * t
	local cx = shrink_centerX + (safe_centerX - shrink_centerX) * t
	local cz = shrink_centerZ + (safe_centerZ - shrink_centerZ) * t

	MapMarkMgr:updateCircle(shrink_shape, cx, cz, r)
	ClientCurGame:clearTargetHint()

	if CurMainPlayer ~= nil then
		local x, y, z = CurMainPlayer:getPosition(0, 0, 0)

		if (x - safe_centerX) * (x - safe_centerX) + (z - safe_centerZ) * (z - safe_centerZ) > SafeRadius * SafeRadius then
			ClientCurGame:setTargetHint(safe_centerX, safe_centerZ)
		end
	end

	return 0
end

function wes_gamerun()
	cur_gametime = cur_gametime + 1

	if cur_gametime < prepare_time then
		return 0
	end

	if cur_gametime - 1 < prepare_time then
		MapMarkMgr:showShape(safe_shape, true)
		MapMarkMgr:showShape(shrink_shape, true)

		local sx, sz, ex, ez = CurWorld:getRangeXZ(0, 0, 0, 0)
		safe_centerX = (sx + ex) / 2
		safe_centerZ = (sz + ez) / 2
	end

	local newindex, newstate, newoffset = GetCircleState(cur_gametime - prepare_time)

	if circle_index < newindex then
		shrink_centerX = safe_centerX
		shrink_centerZ = safe_centerZ
		ShrinkRadius = GetSafeZoneRadius(circle_index)
		SafeRadius = GetSafeZoneRadius(newindex)
		local theta = math.rad(math.random() * 360)
		local r = math.random() * (ShrinkRadius - SafeRadius)
		safe_centerX = r * math.cos(theta) + shrink_centerX
		safe_centerZ = r * math.sin(theta) + shrink_centerZ

		ClientCurGame:sendChat(GetS(8021), 1)
	elseif circle_state < newstate then
		ClientCurGame:sendChat(GetS(8022), 1)
	end

	if newindex ~= circle_index or newstate ~= circle_state then
		WorldMgr:setScriptVar(0, newindex)
		WorldMgr:setScriptVar(1, newstate)
		WorldMgr:setScriptVar(2, ShrinkRadius)
		WorldMgr:setScriptVar(3, shrink_centerX)
		WorldMgr:setScriptVar(4, shrink_centerZ)
		WorldMgr:setScriptVar(5, SafeRadius)
		WorldMgr:setScriptVar(6, safe_centerX)
		WorldMgr:setScriptVar(7, safe_centerZ)
		WorldMgr:sendScriptVars2Client()
	end

	circle_index = newindex
	circle_state = newstate

	MapMarkMgr:updateCircle(safe_shape, safe_centerX, safe_centerZ, SafeRadius)

	local t = 0

	if circle_state > 0 then
		t = newoffset / circle_times[circle_index].shrink
	end

	local r = ShrinkRadius + (SafeRadius - ShrinkRadius) * t
	local cx = shrink_centerX + (safe_centerX - shrink_centerX) * t
	local cz = shrink_centerZ + (safe_centerZ - shrink_centerZ) * t

	MapMarkMgr:updateCircle(shrink_shape, cx, cz, r)

	if cur_gametime % 20 == 0 then
		local nplayers = ClientCurGame:requireArrayOfPlayers(-1, 1)

		for i = 1, nplayers do
			local player = ClientCurGame:getIthPlayerInArray(i - 1)
			local x, y, z = player:getPosition(0, 0, 0)

			if (x - cx) * (x - cx) + (z - cz) * (z - cz) > r * r then
				local playerattr = player:getLivingAttrib()

				if not playerattr:hasBuff(36) then
					playerattr:addBuff(36, 1)
				end

				playerattr:addHP(-1.5)
			end
		end
	end

	ClientCurGame:clearTargetHint()

	if CurMainPlayer ~= nil then
		local x, y, z = CurMainPlayer:getPosition(0, 0, 0)

		if (x - safe_centerX) * (x - safe_centerX) + (z - safe_centerZ) * (z - safe_centerZ) > SafeRadius * SafeRadius then
			ClientCurGame:setTargetHint(safe_centerX, safe_centerZ)
		end
	end

	return 0
end
