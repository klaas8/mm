local BTSendMsgToAi = ClassEx("BTSendMsgToAi")
local instance = nil

function BTSendMsgToAi:GetInst()
	if instance == nil then
		instance = ClassList.BTSendMsgToAi.instance()
	end

	return instance
end

function BTSendMsgToAi:Init()
end

function BTSendMsgToAi:SendMsgToAi(actor, NodeName, msg)
	if msg == nil or type(msg) == "string" and msg == "" or type(msg) == "table" and next(msg) == nil then
		return false
	end

	if not actor or not actor:alive() then
		return false
	end

	if not NodeName then
		return false
	end

	if not msg then
		return false
	end

	local dealmsg = self:DealMsg(NodeName, msg, actor)

	if dealmsg == "" then
		return false
	end

	AIFunctionMgr:SendToAi(actor, dealmsg)
end

local cjson = require("cjson")

local function GetItemInfo(itemid)
	if itemid == nil then
		return ""
	end

	local itemdef = ItemDefCsv:get(itemid)

	if itemdef then
		return itemdef.Name .. "(" .. itemid .. ")"
	end

	return ""
end

local function GetTargetInfo(actor, targetObjId)
	local targetActor = AIFunctionMgr:getActorByObjId(actor, targetObjId)

	if targetActor then
		local monsterdef = targetActor:getMonsterDef()

		if monsterdef then
			return monsterdef.Name .. "(" .. monsterdef.ID .. ")"
		elseif targetActor:isPlayer() then
			local player = tolua.cast(targetActor, "ClientPlayer")

			if player then
				return player:getNickname() .. "(" .. player:getObjId() .. ")"
			end
		end
	end

	return ""
end

local function DealUGCTask_CraftOnTheGoMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "paramErr" then
		if param.num ~= nil and param.itemid ~= nil then
			msginfo = string.format("合成道具%s失败：合成数量参数错误，合成个数:%d", GetItemInfo(param.itemid), param.num)
		end

		return msginfo
	elseif param.info == "paramErrItemNodef" then
		if param.itemid then
			msginfo = string.format("合成道具失败：物品定义不存在，物品ID:%d", param.itemid)
		end

		return msginfo
	elseif param.info == "unLock" then
		if param.itemid then
			msginfo = string.format("合成道具%s失败：物品未解锁，无法合成。", GetItemInfo(param.itemid))
		end

		return msginfo
	elseif param.info == "noCraft" then
		if param.itemid then
			msginfo = string.format("合成道具%s失败：目标物品没有配方，无法合成。", GetItemInfo(param.itemid))
		end

		return msginfo
	elseif param.info == "noCraftOnTheGo" then
		if param.itemid then
			msginfo = string.format("合成道具%s失败：目标物品无法随身合成，需要工匠台。", GetItemInfo(param.itemid))
		end

		return msginfo
	elseif param.info == "materialNotEnough" then
		if param.itemid and param.materialID and param.currentNum and param.needNum then
			msginfo = string.format("合成道具%s失败：材料不足, 还缺少%d个%s", GetItemInfo(param.itemid), param.needNum, GetItemInfo(param.materialID))
		end

		return msginfo
	elseif param.info == "craftSuccess" then
		if param.itemid and param.dropItemNum and param.addBagNum then
			local totalNum = param.addBagNum + param.dropItemNum

			if param.dropItemNum > 0 then
				msginfo = string.format("成功合成%d个%s道具！放入背包的数量:%d，因背包已满，合成后自动扔出去的数量:%d", totalNum, GetItemInfo(param.itemid), param.addBagNum, param.dropItemNum)
			else
				msginfo = string.format("成功合成%d个%s道具！", param.addBagNum, GetItemInfo(param.itemid))
			end
		end

		return msginfo
	end

	return msginfo
end

local function DealUGCTask_AttackMeleeMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "noAttackTag" then
		msginfo = "近战攻击失败 生物没有近战攻击标签"
	elseif param.info == "targetNoExit" then
		msginfo = "近战攻击失败：目标不存在"
	elseif param.info == "targetNotReachable" then
		msginfo = string.format("近战攻击%s失败：目标位置不可达，目标位置:(%d,%d,%d)", GetTargetInfo(actor, param.targetObjId), param.x, param.y, param.z)
	elseif param.info == "distanceTooFar" then
		msginfo = string.format("近战攻击%s失败：距离太远，你和目标之间的距离:%d，你的攻击距离是:%d", GetTargetInfo(actor, param.targetObjId), param.currentdistance, param.attackdistance)
	elseif param.info == "targetNotVisible" then
		msginfo = string.format("近战攻击%s失败：视野被阻挡", GetTargetInfo(actor, param.targetObjId))
	elseif param.info == "attackMeleeSuccess" then
		msginfo = ""
	end

	return msginfo
end

local function DealBTNTaskNewDigBlockMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "blockIdZero" then
		msginfo = string.format("挖方块失败：目标位置:(%d,%d,%d)上没有方块", param.x, param.y, param.z)
	elseif param.info == "selfnoLiving" then
		msginfo = "挖方块失败：你已经死了，无法挖方块，先去复活吧"
	elseif param.info == "noDestroyTag" then
		msginfo = "挖方块失败 生物没有破坏方块标签"
	elseif param.info == "noBlockDef" then
		msginfo = string.format("挖方块失败：目标位置:(%d,%d,%d)上的方块定义不存在", param.x, param.y, param.z)
	elseif param.info == "noLivingAttr" then
		msginfo = "挖方块失败 生物没有生命属性"
	elseif param.info == "noWeapon" then
		msginfo = "挖方块失败 生物没有武器格子"
	elseif param.info == "noBackpack" then
		msginfo = "挖方块失败 生物没有背包"
	elseif param.info == "targetNotReachable" then
		if param.x and param.y and param.z then
			local blockid = param.blockid or 0
			msginfo = string.format("挖方块失败：目标位置:(%d,%d,%d)不可达，方块ID:%d", param.x, param.y, param.z, blockid)
		end

		return msginfo
	elseif param.info == "blockChange" then
		msginfo = string.format("挖方块失败：目标位置:(%d,%d,%d)上的方块发生改变，改变前方块为:%s，改变后后方块为:%s", param.x, param.y, param.z, GetItemInfo(param.oldBlockId), GetItemInfo(param.newBlockId))
	end

	return msginfo
end

local function DealUGCTask_FollowTargetMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "noTarget" then
		msginfo = "跟随目标失败：参数中目标id为空"
	elseif param.info == "targetNoExit" then
		msginfo = "跟随目标失败：目标不存在"
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("跟随目标%s失败：目标位置(%d,%d,%d)不可达", GetTargetInfo(actor, param.targetObjId), param.x, param.y, param.z)
	end

	return msginfo
end

local function DealUGCTask_CraftAtWorkshopMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "paramErr" then
		if param.x ~= nil and param.y ~= nil and param.z ~= nil and param.blockid ~= nil then
			msginfo = string.format("在工匠台制作道具失败：参数中位置信息错误，目标位置:(%d,%d,%d)，方块id:%d", param.x, param.y, param.z, param.blockid)
		elseif param.num ~= nil and param.itemid ~= nil then
			msginfo = string.format("在工匠台制作道具%s失败：合成数量错误，合成个数:%d", GetItemInfo(param.itemid), param.num)
		end
	elseif param.info == "paramErrItemNodef" then
		if param.itemid then
			msginfo = string.format("在工匠台制作道具%s失败：要合成的物品不存在", GetItemInfo(param.itemid))
		end
	elseif param.info == "unLock" then
		if param.itemid then
			msginfo = string.format("在工匠台制作道具%s失败：要合成的物品未解锁", GetItemInfo(param.itemid))
		end
	elseif param.info == "noCraft" then
		if param.itemid then
			msginfo = string.format("在工匠台制作道具%s失败：要合成的物品没有配方", GetItemInfo(param.itemid))
		end
	elseif param.info == "materialNotEnough" then
		if param.itemid and param.materialID and param.currentNum and param.needNum then
			msginfo = string.format("在工匠台制作道具%s失败：材料不足，缺少%d个%s", GetItemInfo(param.itemid), param.needNum, GetItemInfo(param.materialID))
		end
	elseif param.info == "craftSuccess" then
		if param.itemid and param.dropItemNum and param.addBagNum then
			local totalNum = param.addBagNum + param.dropItemNum

			if param.dropItemNum > 0 then
				msginfo = string.format("成功合成%d个%s道具！放入背包的数量:%d，因背包已满，合成后自动扔出去的数量:%d", totalNum, GetItemInfo(param.itemid), param.addBagNum, param.dropItemNum)
			else
				msginfo = string.format("成功合成%d个%s道具！", param.addBagNum, GetItemInfo(param.itemid))
			end
		end
	elseif param.info == "noTargetReachable" then
		if param.x ~= nil and param.y ~= nil and param.z ~= nil then
			msginfo = string.format("在工匠台制作道具失败：位置不可达，位置:(%d,%d,%d)", param.x, param.y, param.z)
		end
	elseif param.info == "posnil" then
		msginfo = "在工匠台制作道具失败：参数中位置为空"
	elseif param.info == "numnil" then
		msginfo = "在工匠台制作道具失败：参数中数量为空"
	elseif param.info == "itemnil" then
		msginfo = "在工匠台制作道具失败：参数中要合成的物品为空"
	end

	return msginfo
end

local function DealUGCTask_ItemPickToBagsMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "noTarget" then
		msginfo = string.format("拾取周边%d格内%s道具到背包失败：周围没有这种掉落物", param.range, GetItemInfo(param.itemid))
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("拾取周边%d格内%s道具到背包失败：目标不可达，目标位置:(%d,%d,%d)", param.range, GetItemInfo(param.itemid), param.x, param.y, param.z)
	elseif param.info == "noPickItemTag" then
		msginfo = "拾取周边X格内道具到背包失败 生物没有拾取道具标签"
	elseif param.info == "noBagSpace" then
		msginfo = string.format("拾取周边%d格内%s道具到背包失败：背包空间不足", param.range, GetItemInfo(param.itemid))
	elseif param.info == "targetNoExit" then
		msginfo = "拾取周边X格内道具到背包失败 目标不存在了"
	end

	return msginfo
end

local function DealUGCTask_DropItemMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "itemnil" then
		msginfo = "扔出掉落物失败：参数中物品为空"
	elseif param.info == "numnil" then
		msginfo = "扔出掉落物失败：参数中数量为空"
	elseif param.info == "isCreatenil" then
		msginfo = "扔出掉落物失败：参数中是否创建为空"
	elseif param.info == "distancenil" then
		msginfo = "扔出掉落物失败：参数中距离为空"
	elseif param.info == "paramErr" then
		msginfo = string.format("扔出%s道具失败：参数错误，个数:%d", GetItemInfo(param.itemid), param.num)
	elseif param.info == "paramErrItemNodef" then
		msginfo = string.format("扔出道具%d失败：这个id对应的物品不存在", param.itemid)
	elseif param.info == "discardSuccess" then
		local discardnum = param.discardnum or param.num
		local creatnum = param.creatnum or 0

		if creatnum > 0 then
			msginfo = string.format("成功扔出%d个%s道具！其中%d个是凭空创建的", discardnum, GetItemInfo(param.itemid), creatnum)
		elseif discardnum ~= param.num then
			msginfo = string.format("成功扔出%d个%s道具！（请求%d个，实际扔出%d个）", discardnum, GetItemInfo(param.itemid), param.num, discardnum)
		else
			msginfo = string.format("成功扔出%d个%s道具！", discardnum, GetItemInfo(param.itemid))
		end

		return msginfo
	elseif param.info == "noBackpack" then
		msginfo = "扔出掉落物失败 没有背包"
	elseif param.info == "bagNoExitItem" then
		msginfo = string.format("扔出道具%s失败：背包不存在该物品", GetItemInfo(param.itemid))
	end

	return msginfo
end

local function DealUGCTask_EquipItemMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "itemnil" then
		msginfo = "装备道具失败 参数中物品为空值"
	elseif param.info == "paramErr" then
		msginfo = string.format("装备%s失败：参数错误", GetItemInfo(param.itemid))
	elseif param.info == "paramErrNoToolDef" then
		msginfo = string.format("装备道具失败 工具定义不存在，道具:%s", GetItemInfo(param.itemid))
	elseif param.info == "noEquip" then
		msginfo = string.format("穿上%s失败：该道具不是装备，不能穿戴", GetItemInfo(param.itemid))
	elseif param.info == "paramErrNoSlot" then
		msginfo = string.format("穿上%s失败：没有装备槽，装备槽位编号:%d", GetItemInfo(param.itemid), param.slot)
	elseif param.info == "noBackpack" then
		msginfo = "穿上道具失败：没有背包"
	elseif param.info == "backPackNoItem" then
		msginfo = string.format("穿上%s失败：背包中没有该物品", GetItemInfo(param.itemid))
	elseif param.info == "equipItemSuccess" then
		msginfo = string.format("成功穿上%s！", GetItemInfo(param.itemid))
	end

	return msginfo
end

local function DealUGCTask_UnequipItemToInventoryMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "paramErrNoSlot" then
		msginfo = string.format("脱下编号为%d的槽位上的装备失败：该槽位不存在", param.slot)
	elseif param.info == "paramErr" then
		msginfo = string.format("脱下编号为%d的槽位上的装备失败：参数错误", param.slot)
	elseif param.info == "noEquip" then
		msginfo = string.format("脱下编号为%d的槽位上的装备失败：该槽位上没有装备", param.slot)
	elseif param.info == "unequipSuccessInBackpack" then
		msginfo = string.format("成功脱下编号为%d的槽位上的装备", param.slot)
	elseif param.info == "unequipSuccessDropItem" then
		msginfo = string.format("成功脱下编号为%d的槽位上的装备，但背包已满，脱下的装备被扔出", param.slot)
	end

	return msginfo
end

local function DealUGCTask_EatFoodMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "noUseItemTag" then
		msginfo = "吃东西失败 生物没有使用道具标签"
	elseif param.info == "noBagItem" then
		msginfo = string.format("使用道具%s失败：背包中没有该道具", GetItemInfo(param.itemid))
	elseif param.info == "noFood" then
		msginfo = string.format("使用道具%s失败：该道具不是食物，不能食用", GetItemInfo(param.itemid))
	elseif param.info == "noWeapon" then
		msginfo = "吃东西失败 没有武器栏目"
	end

	return msginfo
end

local function DealUGCTask_GiveItemMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "toObjIdnil" then
		msginfo = "给予道具失败：目标对象id为空"
	elseif param.info == "numnil" then
		msginfo = "给予道具失败：数量为空"
	elseif param.info == "itemnil" then
		msginfo = "给予道具失败：物品为空"
	elseif param.info == "isCreatenil" then
		msginfo = "给予道具失败：是否创建为空"
	elseif param.info == "noTarget" then
		msginfo = "给予道具失败：目标不存在"
	elseif param.info == "paramErr" then
		msginfo = string.format("将%d个%s道具交给其他对象失败：参数错误", param.num, GetItemInfo(param.itemid))
	elseif param.info == "giveSuccess" then
		local givenum = param.givenum or 0
		local creatnum = param.creatnum or 0
		local totalGiven = givenum + creatnum

		if creatnum > 0 then
			if givenum > 0 then
				msginfo = string.format("成功给予%d个%s道具给%s！其中%d个从背包给予，%d个是凭空创建的", totalGiven, GetItemInfo(param.itemid), GetTargetInfo(actor, param.toObjId), givenum, creatnum)
			else
				msginfo = string.format("成功给予%d个%s道具给%s！（全部凭空创建）", creatnum, GetItemInfo(param.itemid), GetTargetInfo(actor, param.toObjId))
			end
		elseif givenum ~= param.num then
			msginfo = string.format("成功给予%d个%s道具给%s！（请求%d个，实际给予%d个）", givenum, GetItemInfo(param.itemid), GetTargetInfo(actor, param.toObjId), param.num, givenum)
		else
			msginfo = string.format("成功给予%d个%s道具给%s！", givenum, GetItemInfo(param.itemid), GetTargetInfo(actor, param.toObjId))
		end

		return msginfo
	elseif param.info == "bagFull" then
		msginfo = "道具给其它对象失败 对方背包满了"
	elseif param.info == "noBag" then
		msginfo = "道具给其它对象失败 对方没有背包"
	elseif param.info == "noItem" then
		msginfo = string.format("将%s交给%s失败：背包中没有该物品", GetItemInfo(param.itemid), GetTargetInfo(actor, param.toObjId))
	end

	return msginfo
end

local function DealUGCTask_SleepInBedMsg(msg)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "posnil" then
		msginfo = "睡觉失败：参数中目标位置为空"
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("睡觉失败：目标位置(%d,%d,%d)不可到达", param.x, param.y, param.z)
	elseif param.info == "noBed" then
		msginfo = string.format("睡觉失败：目标位置(%d,%d,%d)没有床", param.x, param.y, param.z)
	elseif param.info == "inSitting" then
		msginfo = "睡觉失败：你正坐在椅子上，无法睡觉"
	elseif param.info == "inSleeping" then
		msginfo = "睡觉失败：你已经在睡觉了"
	elseif param.info == "inDead" then
		msginfo = "睡觉失败：你已经死亡，无法睡觉，先去复活吧"
	elseif param.info == "noThere" then
		msginfo = "睡觉失败 这个地方不适合睡觉，目标位置:" .. param.x .. "," .. param.y .. "," .. param.z
	elseif param.info == "tooFar" then
		msginfo = string.format("睡觉失败：目标位置(%d,%d,%d)距离你太远", param.x, param.y, param.z)
	elseif param.info == "mobAttack" then
		msginfo = string.format("睡觉失败：目标位置(%d,%d,%d)周边有敌对生物，你无法安心睡觉", param.x, param.y, param.z)
	elseif param.info == "sleepSuccess" then
		msginfo = string.format("睡觉成功：你已经成功在目标位置(%d,%d,%d)入睡", param.x, param.y, param.z)
	elseif param.info == "bedOccupied" then
		msginfo = string.format("睡觉失败：目标位置(%d,%d,%d)上的床被其他玩家占用，无法睡觉", param.x, param.y, param.z)
	end

	return msginfo
end

local function DealUGCTask_WakeUpMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "wakeUpSuccess" then
		msginfo = "起床成功"
	elseif param.info == "noSleep" then
		msginfo = "起床失败：你现在没有在睡觉，无法起床"
	end

	return msginfo
end

local function DealUGCTask_TakeItemFromBoxMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "posnil" then
		msginfo = "从箱子中拿取道具失败：参数中目标位置为空"
	elseif param.info == "numnil" then
		msginfo = "从箱子中拿取道具失败：参数中数量为空"
	elseif param.info == "itemnil" then
		msginfo = "从箱子中拿取道具失败：参数中物品id为空"
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("从箱子中拿取道具失败：目标位置(%d,%d,%d)不可到达", param.x, param.y, param.z)
	elseif param.info == "paramErr" then
		msginfo = string.format("从箱子中拿取%d个%s道具失败：参数错误", param.num, GetItemInfo(param.itemid))
	elseif param.info == "noBackpack" then
		msginfo = "从箱子中拿取道具失败 没有背包"
	elseif param.info == "noStorage" then
		msginfo = string.format("从箱子中拿取道具失败：目标位置(%d,%d,%d)不是储物箱", param.x, param.y, param.z)
	elseif param.info == "noItem" then
		msginfo = string.format("从箱子中拿取道具失败：储物箱中没有%s道具", GetItemInfo(param.itemid))
	elseif param.info == "bagFull" then
		msginfo = "从箱子中拿取道具失败：你的背包已满"
	elseif param.info == "takeSuccess" then
		local takeNum = param.takeNum or param.num

		if takeNum ~= param.num then
			msginfo = string.format("成功从箱子中拿取%d个%s道具！（请求%d个，实际拿取%d个）", takeNum, GetItemInfo(param.itemid), param.num, takeNum)
		else
			msginfo = string.format("成功从箱子中拿取%d个%s道具!", takeNum, GetItemInfo(param.itemid))
		end

		return msginfo
	end

	return msginfo
end

local function DealUGCTask_ItemStoreToPosMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "targetPosErr" then
		msginfo = "将道具存放到指定位置失败：参数中目标位置错误"
	elseif param.info == "noItem" then
		msginfo = string.format("将道具存放到指定位置的箱子失败：背包中没有%s道具", GetItemInfo(param.itemid))
	elseif param.info == "paramErr" then
		msginfo = string.format("将%d个%s道具存放到指定位置的箱子失败：参数错误", param.num, GetItemInfo(param.itemid))
	elseif param.info == "noBackpack" then
		msginfo = "将道具存放到指定位置失败 没有背包"
	elseif param.info == "noStorage" then
		msginfo = string.format("将道具存放到指定位置失败：目标位置(%d,%d,%d)不是储物箱", param.x, param.y, param.z)
	elseif param.info == "bagNoItem" then
		msginfo = string.format("将道具存放到指定位置失败：背包中没有%s道具", GetItemInfo(param.itemid))
	elseif param.info == "bagFull" then
		msginfo = "将道具存放到指定位置失败：储物箱已满"
	elseif param.info == "storeSuccess" then
		local storeNum = param.num or 0
		local needNum = param.needNum or 0

		if storeNum ~= needNum and needNum > 0 then
			msginfo = string.format("成功将%d个道具存放到指定位置的箱子！（请求%d个，实际存储%d个）", storeNum, needNum, storeNum)
		else
			msginfo = string.format("成功将%d个道具存放到指定位置的箱子！", storeNum)
		end

		return msginfo
	end

	return msginfo
end

local function DealUGCTask_GetCampfireMeatMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "posnil" then
		msginfo = "从篝火上获取食物失败：参数中目标位置为空"
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("从篝火上获取食物失败：目标位置(%d,%d,%d)不可到达", param.x, param.y, param.z)
	elseif param.info == "noBonFire" then
		msginfo = string.format("从篝火上获取食物失败：目标位置(%d,%d,%d)不是篝火", param.x, param.y, param.z)
	elseif param.info == "noItem" then
		msginfo = "从篝火上获取食物失败：篝火上没有食物"
	elseif param.info == "bagFull" then
		msginfo = "从篝火上获取食物失败：你的背包已满"
	elseif param.info == "noBag" then
		msginfo = "从篝火上获取食物失败 没有背包"
	elseif param.info == "takeMeatSuccess" and param.items then
		msginfo = "从篝火上获取食物成功，获取了"
		local num = #param.items

		for i = 1, num do
			local item = param.items[i]
			msginfo = msginfo .. string.format(" %d个%s", item.num, GetItemInfo(item.itemid))
		end
	end

	return msginfo
end

local function DealUGCTask_GetStonePotFoodMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "posnil" then
		msginfo = "获取石锅中食物失败：参数中目标位置为空"
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("获取石锅中食物失败：目标位置(%d,%d,%d)不可到达", param.x, param.y, param.z)
	elseif param.info == "noPot" then
		msginfo = string.format("获取石锅中食物失败：目标位置(%d,%d,%d)不是石锅", param.x, param.y, param.z)
	elseif param.info == "noItem" then
		msginfo = "获取石锅中食物失败：石锅中没有食物"
	elseif param.info == "bagFull" then
		msginfo = "获取石锅中食物失败：你的背包已满"
	elseif param.info == "noBag" then
		msginfo = "获取石锅中食物失败：没有背包"
	elseif param.info == "takeFoodSuccess" then
		msginfo = string.format("获取石锅中食物成功，获取了%d个%s", param.num, GetItemInfo(param.itemid))
	end

	return msginfo
end

local function DealUGCTask_GetFurnaceProductMsg(msg, actor)
	local param = msg

	if type(param) == "string" then
		param = cjson.decode(param)
	end

	if not param then
		return ""
	end

	local msginfo = ""

	if param.info == "posnil" then
		msginfo = "获取熔炉产物失败：参数中目标位置为空"
	elseif param.info == "noTargetReachable" then
		msginfo = string.format("获取熔炉产物失败：目标位置(%d,%d,%d)不可到达", param.x, param.y, param.z)
	elseif param.info == "noFurnace" then
		msginfo = string.format("获取熔炉产物失败：目标位置(%d,%d,%d)不是熔炉", param.x, param.y, param.z)
	elseif param.info == "noItem" then
		msginfo = "获取熔炉产物失败：熔炉里面没有产物"
	elseif param.info == "bagFull" then
		msginfo = "获取熔炉产物失败：你的背包已满"
	elseif param.info == "noBag" then
		msginfo = "获取熔炉产物失败：没有背包"
	elseif param.info == "takeProductSuccess" and param.items then
		msginfo = "获取熔炉产物成功，获取了"
		local num = #param.items

		for i = 1, num do
			local item = param.items[i]
			msginfo = msginfo .. string.format(" %d个%s", item.num, GetItemInfo(item.itemid))
		end
	end

	return msginfo
end

local dealFuns = {
	UGCTask_CraftOnTheGo = DealUGCTask_CraftOnTheGoMsg,
	UGCTask_AttackMelee = DealUGCTask_AttackMeleeMsg,
	BTNTaskNewDigBlock = DealBTNTaskNewDigBlockMsg,
	UGCTask_FollowTarget = DealUGCTask_FollowTargetMsg,
	UGCTask_CraftAtWorkshop = DealUGCTask_CraftAtWorkshopMsg,
	UGCTask_ItemPickToBags = DealUGCTask_ItemPickToBagsMsg,
	UGCTask_DropItem = DealUGCTask_DropItemMsg,
	UGCTask_EquipItem = DealUGCTask_EquipItemMsg,
	UGCTask_UnequipItemToInventory = DealUGCTask_UnequipItemToInventoryMsg,
	UGCTask_EatFood = DealUGCTask_EatFoodMsg,
	UGCTask_GiveItem = DealUGCTask_GiveItemMsg,
	UGCTask_SleepInBed = DealUGCTask_SleepInBedMsg,
	UGCTask_WakeUp = DealUGCTask_WakeUpMsg,
	UGCTask_TakeItemFromBox = DealUGCTask_TakeItemFromBoxMsg,
	UGCTask_ItemStoreToPos = DealUGCTask_ItemStoreToPosMsg,
	UGCTask_GetCampfireMeat = DealUGCTask_GetCampfireMeatMsg,
	UGCTask_GetStonePotFood = DealUGCTask_GetStonePotFoodMsg,
	UGCTask_GetFurnaceProduct = DealUGCTask_GetFurnaceProductMsg
}

function BTSendMsgToAi:DealMsg(NodeName, msg, actor)
	if not dealFuns[NodeName] then
		return ""
	end

	return dealFuns[NodeName](msg, actor)
end

function BTNodeSendErrInfoToAi(NodeName, msg, actor)
	GetInst("BTSendMsgToAi"):SendMsgToAi(actor, NodeName, msg)
end
