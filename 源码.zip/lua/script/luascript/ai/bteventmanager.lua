local BTEventManager = ClassEx("BTEventManager")
local instance = nil

function BTEventManager:GetInst()
	if instance == nil then
		instance = ClassList.BTEventManager.instance()
	end

	return instance
end

local function initData(self)
	self.EventData = {}
	self.EventParam = {}
	self.RegEventInfo = {}
	self.TreeEventParam = {}
end

function BTEventManager:Init()
	initData(self)
end

function BTEventManager:clear()
	initData(self)
end

function BTEventManager:ClearTreeEventParam(treeid)
	self.TreeEventParam[treeid] = nil
end

function BTEventManager:RegCustomEvent(msg, nodeid, treeid, node)
	local info = {
		nodeid = nodeid,
		treeid = treeid,
		node = node
	}

	if not self.RegEventInfo[msg] then
		self.RegEventInfo[msg] = {}

		GameVM.ScriptSupportEvent:addAICustomEventFunc(msg, function (event)
			if type(event.customdata) == "string" then
				event.customdata = json2table(event.customdata)
			end

			local msgid = event.eventType or event.msgStr

			if self.RegEventInfo[msgid] then
				for i = 1, #self.RegEventInfo[msgid] do
					local eventInfo = self.RegEventInfo[msgid][i]

					BehaviorTreeLuaOneEventRun(eventInfo.nodeid, eventInfo.treeid, eventInfo.node, event)
				end
			end
		end)
	end

	table.insert(self.RegEventInfo[msg], info)
end

function BTEventManager:RegisterEvent(name)
	if not self.RegEventInfo[name] then
		self.RegEventInfo[name] = {}

		local function func(param)
		end

		GameVM.ScriptSupportEvent:registerEvent_NoError(name, func)
	end
end

function BTEventManager:RemoveCustomEvent(treeid)
	for key, value in pairs(self.RegEventInfo) do
		for i = #value, 1, -1 do
			if value[i].treeid == treeid then
				table.remove(value, i)
			end
		end
	end
end

function BTEventManager:AddEvent(eventid, param)
	if not self.EventData[eventid] then
		self.EventData[eventid] = {}
	end

	if param then
		self.EventData[eventid].param = param

		if type(param.customdata) == "string" then
			param.customdata = json2table(param.customdata)
		end
	end

	if WorldMgr and WorldMgr.getWorldTime then
		self.EventData[eventid].time = WorldMgr:getWorldTime()
	end
end

function BTEventManager:checkEventisExit(eventid)
	return self.EventData[eventid] ~= nil
end

function BTEventManager:GetEventById(eventid)
	return self.EventData[eventid]
end

function BTEventManager:RemoveEventById(eventid)
	self.EventData[eventid] = nil
end

function BTEventManager:GetEventCustomParam(eventid)
	local eventData = self.EventData[eventid]

	if eventData and eventData.param then
		local customData = eventData.param.customdata

		if customData and customData.CustomEventParams then
			return customData.CustomEventParams
		end
	end

	return nil
end

function BTEventManager:GetEventTime(eventid)
	if self.EventData[eventid] then
		return self.EventData[eventid].time
	end

	return -1
end

function BTEventManager:AddEventParam(eventid, paramId, value, treeid)
	if not self.EventParam[eventid] then
		self.EventParam[eventid] = {}
	end

	self.EventParam[eventid][paramId] = value

	if not self.TreeEventParam[treeid] then
		self.TreeEventParam[treeid] = {}
	end

	if not self.TreeEventParam[treeid][eventid] then
		self.TreeEventParam[treeid][eventid] = {}
	end

	if not self.TreeEventParam[treeid][eventid][paramId] then
		self.TreeEventParam[treeid][eventid][paramId] = {}
	end

	table.insert(self.TreeEventParam[treeid][eventid][paramId], value)
end

function BTEventManager:GetEventParam(eventid, paramId, treeid)
	if treeid ~= nil then
		return self:GetTreeEventParam(treeid, eventid, paramId)
	end

	if self.EventParam[eventid] then
		return self.EventParam[eventid][paramId]
	end

	return nil
end

function BTEventManager:GetTreeEventParam(treeid, eventid, paramId)
	if self.TreeEventParam[treeid] and self.TreeEventParam[treeid][eventid] and self.TreeEventParam[treeid][eventid][paramId] then
		local queue = self.TreeEventParam[treeid][eventid][paramId]

		if type(queue) == "table" and #queue > 1 then
			local value = table.remove(queue, 1)

			return value
		elseif type(queue) == "table" and #queue == 1 then
			local value = self.TreeEventParam[treeid][eventid][paramId][1]

			return value
		end
	end

	return nil
end

function BTEventManager:GetEventParamNum(eventid)
	if self.EventParam[eventid] then
		return #self.EventParam[eventid]
	end

	return 0
end

function BTEventManager:CheckVals(eventid, vals)
	local eventParams = self.EventParam[eventid]

	if not eventParams or not vals then
		return false
	end

	if #vals ~= #eventParams then
		return false
	end

	for index, value in ipairs(vals) do
		if value ~= eventParams[index] then
			return false
		end
	end

	return true
end
