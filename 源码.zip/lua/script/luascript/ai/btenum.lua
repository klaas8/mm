if not BTClass then
	assert(false)

	return
end

local BTEnumClass = BTClass:Class("BTEnum")
BTEnumClass.BTNODERESULT = {
	NO_RUN = 4,
	LOGIC_WAIT = 3,
	WAIT = 2,
	FAIL = 1,
	SUCCESS = 0
}
