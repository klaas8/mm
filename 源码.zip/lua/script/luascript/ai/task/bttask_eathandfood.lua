return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local canEat, eatTime = AIFunctionMgr:eatHandFood(obj, 0)

		if canEat then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
