return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local pos = obj:getPosition()
		local x, y, z = CoordDivBlock(pos.x, pos.y, pos.z)
		local monsterid = controller.bb.get(controller.subparam.monsterid)
		local dist = controller.bb.get(controller.subparam.dist)
		local topHeight = CurWorld:getTopHeight(x + dist, z + dist)
		local canUsed = AIFunctionMgr:CheckPosCanUsed(obj, x + dist, topHeight + 1, z + dist)

		if type(monsterid) == "number" and canUsed then
			AIFunctionMgr:spawnActorEx(obj, monsterid, pos.x + dist * BLOCK_SIZE, (topHeight + 1) * BLOCK_SIZE, pos.z + dist * BLOCK_SIZE)

			return controller.success()
		end

		return controller.fail()
	end
}
