return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local count = AIFunctionMgr:GetEmptyGridCount(obj)
		local bagcapacity = AIFunctionMgr:GetBagCapacity(obj)

		if count == bagcapacity then
			return controller.fail()
		else
			controller.success()
		end
	end
}
