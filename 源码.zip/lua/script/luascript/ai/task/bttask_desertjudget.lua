return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local judgetType = controller.subparam.judgettype

		if judgetType == 1 then
			local pos = controller.bb.get(controller.subparam.bb_stollpos)
			local blockid = CurWorld:getBlockID(pos.x, pos.y, pos.z)

			if blockid == 0 then
				return controller.success()
			else
				return controller.fail()
			end
		elseif judgetType == 2 then
			local pos = controller.bb.get(controller.subparam.bbkey_targetpos)
			local id = CurWorld:getBlockID(pos.x, pos.y, pos.z)

			if id == 484 then
				return controller.fail()
			else
				return controller.success()
			end
		end
	end
}
