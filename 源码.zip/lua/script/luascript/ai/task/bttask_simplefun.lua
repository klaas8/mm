local bit = require("bit")
local funcs = {
	setExplorePos = function (mob, extravalue, controller)
		local mobType = controller.subparam.mobType or "ActorDesertBusInessMan"
		local funcName = controller.subparam.getFun or "getExplorePos"
		mob = tolua.cast(mob, mobType)

		if not mob or not extravalue then
			return false
		end

		local fun = mob[funcName]

		if not fun then
			return false
		end

		local mobPos = mob:getPosition()
		local x, y, z = nil
		x, y, z = CoordDivBlock(mobPos.x, mobPos.y, mobPos.z)
		local pos = fun(mob)

		if pos.x == 0 and pos.y == 0 and pos.z == 0 then
			return false
		end

		controller.bb.set(controller.subparam.extraValue, {
			x = pos.x,
			y = pos.y,
			z = pos.z
		})

		return true
	end,
	nextExplore = function (mob, extraValue, controller)
		mob = tolua.cast(mob, "ActorDesertBusInessMan")

		if not mob then
			return false
		end

		if not mob:isLeader() then
			return false
		end

		if mob:isToOasis() then
			mob:exploreVillage()
		elseif mob:isToVillage() then
			mob:setExploreType(0)
		end

		return true
	end,
	setFollowObj = function (mob, extraValue, controller)
		mob = tolua.cast(mob, "ActorDesertBusInessMan")

		if not mob or not extraValue then
			return false
		end

		local id = mob:getFollowObjId()

		if id <= 0 then
			mob:checkFollowObjId()

			id = mob:getFollowObjId()

			if id <= 0 then
				return false
			end
		end

		controller.bb.set(extraValue, {
			actor = id
		})

		return true
	end,
	checkMoveToEnd = function (mob, extraValue, controller)
		mob = tolua.cast(mob, "ActorDesertBusInessMan")

		if not mob or not extraValue then
			return false
		end

		if not mob:isLeader() then
			return true
		end

		if mob:isToOasis() then
			return true
		end

		if mob:isToVillage() then
			return true
		end
	end,
	findPitchPos = function (mob, extraValue, controller)
		mob = tolua.cast(mob, "ActorDesertBusInessMan")

		if not mob then
			return false
		end

		local bedpos = controller.bb.get(controller.subparam.bb_bed)
		local id = CurWorld:getBlockID(bedpos.x, bedpos.y, bedpos.z)

		if id ~= 484 then
			return false
		end

		local footBlockToHeadBlockMap = {
			{
				-1,
				0,
				-1,
				-1,
				90
			},
			{
				1,
				0,
				1,
				1,
				-90
			},
			{
				0,
				-1,
				1,
				-1,
				0
			},
			{
				0,
				1,
				-1,
				1,
				180
			}
		}
		local posA = WCoord:new_local()
		posA.x = bedpos.x
		posA.y = bedpos.y
		posA.z = bedpos.z
		local blockdata = CurWorld:getBlockData(posA)
		local blockdir = bit.band(blockdata, 3) + 1
		local dir = footBlockToHeadBlockMap[blockdir]
		local pitchPos = {
			z = 0,
			x = 0,
			y = bedpos.y
		}
		local pitchDir = {
			z = 0,
			x = 0,
			y = 0
		}
		local dis = 1
		pitchPos.x = bedpos.x + dir[1]
		pitchPos.z = bedpos.z + dir[2]
		pitchDir.x = dir[5]
		pitchDir.y = 1

		controller.bb.set(controller.subparam.bb_pitch, pitchPos)
		controller.bb.set(controller.subparam.bb_pitchDir, pitchDir.x)

		posA.x = pitchPos.x
		posA.y = pitchPos.y
		posA.z = pitchPos.z

		mob:setWorkPos(posA)
		mob:setWorkYaw(pitchDir.x)

		return true
	end,
	setMobWorkPos = function (mob, extraValue, controller)
		mob = tolua.cast(mob, "ActorDesertBusInessMan")

		if not mob then
			return false
		end

		local workPos = WCoord:new_local()
		local pos = controller.bb.get(controller.subparam.workPos)
		workPos.x = pos.x
		workPos.y = pos.y
		workPos.z = pos.z

		mob:setWorkPos(workPos)

		local yaw = controller.bb.get(controller.subparam.workDir)

		mob:setWorkYaw(yaw)

		return true
	end,
	getGuardWorkPos = function (mob, extraValue, controller)
		mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

		if not mob then
			return false
		end

		local pos = nil

		if mob:isNightGuard() then
			pos = mob:getNightWorkPos()
		else
			pos = mob:getWorkPos()
		end

		local yaw = mob:getWorkYaw()

		controller.bb.set(controller.subparam.workPos, {
			x = pos.x,
			y = pos.y,
			z = pos.z
		})
		controller.bb.set(controller.subparam.standDir, yaw)

		return true
	end,
	setExchangeItem = function (mob, extraValue, controller)
		local list = LuaConstants.desertTradeSpecialExchage.specialDeal

		if not list then
			return false
		end

		local totalWeight = 0

		for index, value in ipairs(list) do
			totalWeight = totalWeight + (value.weight or 10)
		end

		local select = math.random(1, totalWeight)
		local selectData = nil

		for index, value in ipairs(list) do
			select = select - (value.weight or 10)

			if select <= 0 then
				selectData = value

				break
			end
		end

		local needNum = selectData.needNum

		if selectData.need == 14001 then
			needNum = needNum * 100 / EXP_STAR_RATIO
		end

		controller.bb.set(controller.subparam.bb_exchange, selectData.need)
		controller.bb.set(controller.subparam.bb_sale, selectData.sale)
		controller.bb.set(controller.subparam.bb_exchangeNum, needNum)
		controller.bb.set(controller.subparam.bb_saleNum, selectData.saleNum)

		return true
	end,
	setCamelExchangeItem = function (mob, extraValue, controller)
		local list = LuaConstants.desertTradeSpecialExchage.camelDeal

		if not list then
			return false
		end

		local totalWeight = 0

		for index, value in ipairs(list) do
			totalWeight = totalWeight + (value.weight or 10)
		end

		local select = math.random(1, totalWeight)
		local selectData = nil

		for index, value in ipairs(list) do
			select = select - (value.weight or 10)

			if select <= 0 then
				selectData = value

				break
			end
		end

		controller.bb.set(controller.subparam.bb_exchange, selectData.need)
		controller.bb.set(controller.subparam.bb_sale, 3822)
		controller.bb.set(controller.subparam.bb_exchangeNum, selectData.needNum)
		controller.bb.set(controller.subparam.bb_saleNum, 1)

		return true
	end
}

function funcs.exchangeItemFormPlayer(mob, extraValue, controller)
	local exchangeItem = controller.bb.get(controller.subparam.bb_exchange)
	local exchangeNum = controller.bb.get(controller.subparam.bb_exchangeNum)
	local saleItem = controller.bb.get(controller.subparam.bb_sale)
	local saleItemNum = controller.bb.get(controller.subparam.bb_saleNum)

	if not saleItem or not exchangeItem then
		return false
	end

	if not exchangeNum or not saleItemNum or exchangeNum <= 0 or saleItemNum <= 0 then
		return false
	end

	local uin = controller.bb.get(controller.subparam.bb_player).actor
	local player = WorldMgr:GetPlayerByUin(uin)

	if not player then
		return false
	end

	if not CurWorld then
		return
	end

	local function itemCallback(sucess)
		if sucess then
			player:updateTaskSysProcess(TASKSYS_NPC_TRADER, 3212)
		end

		if ROOM_SERVER_RENT ~= GetGameInfo():GetRoomHostType() and not CurWorld:isRemoteMode() and AccountManager:getUin() == uin then
			if sucess then
				userTaskReportedGlobal(-1, UserTaskReportType_DEAL, 3212, -1, -1)
			end

			local worldDesc = AccountManager:findWorldDesc(WorldMgr:getWorldId())

			if worldDesc then
				if worldDesc.fromowid and worldDesc.fromowid ~= 0 then
					fromowid = worldDesc.fromowid
				else
					fromowid = worldDesc.worldid
				end

				local playType = 0
				local since_create = AccountManager:get_time_since_create() or 0

				if since_create < 86400 then
					playType = 1
				end

				local multiPlayer = AccountManager:getMultiPlayer() > 0 and "multi" or "single"

				if ROOM_SERVER_RENT == GetGameInfo():GetRoomHostType() then
					multiPlayer = "multi"
				end

				local isOwner = worldDesc.realowneruin == AccountManager:getUin() and 1 or 0
				local stringType = nil

				if worldDesc.worldtype == 0 then
					stringType = "_adventure"
				elseif worldDesc.worldtype == 2 then
					stringType = "_extreme-adventure"
				elseif worldDesc.worldtype == 6 then
					stringType = "_advanced-adventure"
				end

				if stringType then
					local standby1 = sucess and 1 or 0
					local standby2 = string.format("%s_%s_%d_%d", multiPlayer, stringType, isOwner, playType)

					standReportEvent(405, "ADVENTURE_NPC_3212", "-", "click", {
						cid = fromowid,
						standby1 = standby1,
						standby2 = standby2
					})
				end
			end
		else
			local content = {
				sucess = sucess,
				defid = 3212,
				uin = uin,
				special = true
			}

			SandboxLuaMsg.sendToClient(uin, SANDBOX_LUAMSG_NAME.Survive.DESERT_BUSSINESSMAN_DEAL, content)
		end
	end

	if exchangeItem == 14001 then
		local attrib = player:getAttrib()
		attrib = tolua.cast(attrib, "PlayerAttrib")

		if not attrib then
			return false
		end

		local num = math.floor(attrib:getExp() / EXP_STAR_RATIO)

		if exchangeNum <= num then
			attrib:addExp(-exchangeNum * EXP_STAR_RATIO)
			player:gainItems(saleItem, saleItemNum, 1)
			itemCallback(true)

			return true
		end

		controller.bb.set(controller.subparam.refuseSound, "ent.3212.anger")
		itemCallback(false)

		return false
	else
		local attrib = player:getAttrib()
		attrib = tolua.cast(attrib, "PlayerAttrib")

		if not attrib then
			return false
		end

		local brid = attrib:getEquipGrid(5)

		if not brid then
			return false
		end

		local id = brid:getItemID()

		if id ~= exchangeItem then
			controller.bb.set(controller.subparam.refuseSound, "ent.3212.refuse")
			itemCallback(false)

			return false
		end

		local num = brid:getNum()

		if num < exchangeNum then
			controller.bb.set(controller.subparam.refuseSound, "ent.3212.anger")
			itemCallback(false)

			return false
		end

		num = num - exchangeNum

		if num <= 0 then
			brid:clear()
		else
			brid:setNum(num)
		end

		local backPack = player:getBackPack()

		player:gainItems(saleItem, saleItemNum, 1)
		backPack:afterChangeGrid(brid:getIndex())
		itemCallback(true)

		return true
	end

	return false
end

function funcs.camelExchange(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	local exchangeItem = controller.bb.get(controller.subparam.bb_exchange)
	local exchangeNum = controller.bb.get(controller.subparam.bb_exchangeNum)
	local uin = controller.bb.get(controller.subparam.bb_player).actor
	local player = WorldMgr:GetPlayerByUin(uin)

	if not player then
		return false
	end

	if not exchangeItem then
		return false
	end

	if not exchangeNum or exchangeNum <= 0 then
		return false
	end

	if not CurWorld then
		return
	end

	local function itemCallback(sucess)
		if ROOM_SERVER_RENT ~= GetGameInfo():GetRoomHostType() and not CurWorld:isRemoteMode() and AccountManager:getUin() == uin then
			if sucess then
				userTaskReportedGlobal(-1, UserTaskReportType_DEAL, 3212, -1, -1)
			end

			local worldDesc = AccountManager:findWorldDesc(WorldMgr:getWorldId())

			if worldDesc then
				if worldDesc.fromowid and worldDesc.fromowid ~= 0 then
					fromowid = worldDesc.fromowid
				else
					fromowid = worldDesc.worldid
				end

				local playType = 0
				local since_create = AccountManager:get_time_since_create() or 0

				if since_create < 86400 then
					playType = 1
				end

				local multiPlayer = AccountManager:getMultiPlayer() > 0 and "multi" or "single"
				local isOwner = worldDesc.realowneruin == AccountManager:getUin() and 1 or 0
				local stringType = nil

				if worldDesc.worldtype == 0 then
					stringType = "_adventure"
				elseif worldDesc.worldtype == 2 then
					stringType = "_extreme-adventure"
				elseif worldDesc.worldtype == 6 then
					stringType = "_advanced-adventure"
				end

				if stringType then
					local standby1 = sucess and 1 or 0
					local standby2 = string.format("%s_%s_%d_%d", multiPlayer, stringType, isOwner, playType)

					standReportEvent(405, "ADVENTURE_NPC_3212", "-", "click", {
						cid = fromowid,
						standby1 = standby1,
						standby2 = standby2
					})
				end
			end
		else
			local content = {
				sucess = sucess,
				defid = 3212,
				uin = uin,
				special = true
			}

			SandboxLuaMsg.sendToClient(uin, SANDBOX_LUAMSG_NAME.Survive.DESERT_BUSSINESSMAN_DEAL, content)
		end
	end

	local camelId = mob:getDealCamel()
	local camelMob = mob:getActorMgr():findActorByWID(camelId)

	if not camelMob then
		mob:setDealCamel(-1)

		return false
	end

	local attrib = player:getAttrib()
	attrib = tolua.cast(attrib, "PlayerAttrib")

	if not attrib then
		return false
	end

	local brid = attrib:getEquipGrid(5)

	if not brid then
		return false
	end

	local id = brid:getItemID()

	if id ~= exchangeItem then
		controller.bb.set(controller.subparam.refuseSound, "ent.3212.refuse")
		itemCallback(false)

		return false
	end

	local num = brid:getNum()

	if num < exchangeNum then
		controller.bb.set(controller.subparam.refuseSound, "ent.3212.anger")
		itemCallback(false)

		return false
	end

	num = num - exchangeNum

	if num <= 0 then
		brid:clear()
	else
		brid:setNum(num)
	end

	mob:setDealCamel(-1)
	camelMob:mobTamed(uin, 3823)

	local backPack = player:getBackPack()

	backPack:afterChangeGrid(brid:getIndex())
	itemCallback(true)

	return true
end

function funcs.setGuardObj(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob or not extraValue then
		return false
	end

	local id = mob:getFollowObjId()

	if id <= 0 then
		mob:findFollow()

		id = mob:getFollowObjId()

		if id <= 0 then
			return false
		end
	end

	controller.bb.set(extraValue, {
		actor = id
	})

	return true
end

function funcs.informGuard(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob or not extraValue then
		return false
	end

	mob:informGuardsStand(extraValue)

	return true
end

function funcs.setStandGuardPos(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	local pos = nil

	if mob:isNightGuard() then
		pos = mob:getNightWorkPos()
	else
		pos = mob:getWorkPos()
	end

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	local dir = mob:getWorkYaw()

	controller.bb.set(controller.subparam.standDir, dir)
	controller.bb.set(controller.subparam.workPos, {
		x = pos.x,
		y = pos.y,
		z = pos.z
	})

	return true
end

function funcs.clearPos(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	mob:clearPos()

	return true
end

function funcs.findStandGuardPos(mob, extraValue, controller, funcs)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	if not mob:needStandGuard() then
		return false
	end

	if mob:isNightGuard() then
		return funcs._findNightStandGuardPos(mob, extraValue, controller)
	else
		return funcs._findPitchGuardPos(mob, extraValue, controller)
	end

	return false
end

function funcs._findPitchGuardPos(mob, extraValue, controller)
	local followId = mob:getFollowObjId()

	if followId <= 0 then
		return false
	end

	local follow = mob:findFollowObj()

	if not follow then
		mob:setFollowObjId(-1)

		return false
	end

	local pos = follow:getWorkPos()

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	local dir = follow:getWorkYaw()
	local left = pos.x - 3
	local bottom = pos.z - 3
	local standPos = WCoord:new_local()
	standPos.y = pos.y
	local objId = mob:getObjId()
	local ranking = follow:guardRanking(objId)

	if ranking == 1 then
		if dir == 0 or dir == -180 or dir == 180 then
			standPos.x = pos.x - 2
			standPos.z = pos.z
		else
			standPos.z = pos.z - 2
			standPos.x = pos.x
		end
	elseif ranking == 2 then
		if dir == 0 or dir == -180 or dir == 180 then
			standPos.x = pos.x + 2
			standPos.z = pos.z
		else
			standPos.z = pos.z + 2
			standPos.x = pos.x
		end
	end

	if ranking > 2 or not AIFunctionMgr:CheckPosCanUsed(mob, standPos.x, standPos.y, standPos.z) then
		standPos.x = left + math.random(0, 6)
		standPos.z = bottom + math.random(0, 6)
		standPos.y = mob:getWorld():getTopHeight(standPos.x, standPos.z) + 1
	end

	mob:setWorkPos(standPos)
	mob:setWorkYaw(dir)

	return true
end

function funcs._findNightStandGuardPos(mob, extraValue, controller)
	local followId = mob:getFollowObjId()

	if followId <= 0 then
		return false
	end

	local follow = mob:findFollowObj()

	if not follow then
		mob:setFollowObjId(-1)

		return false
	end

	local pos = follow:getWorkPos()

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	local dir = follow:getWorkYaw()
	local left = pos.x - 3
	local bottom = pos.z - 3
	local standPos = WCoord:new_local()
	standPos.x = left + math.random(0, 6)
	standPos.z = bottom + math.random(0, 6)
	standPos.y = mob:getWorld():getTopHeight(standPos.x, standPos.z) + 1

	mob:setNightWorkPos(standPos)
	mob:setWorkYaw(dir)

	return true
end

function funcs.placeBed(mob, extraValue, controller)
	if not mob then
		return false
	end

	local pos = controller.bb.get(controller.subparam.bedPos)

	if not CurWorld:canPlaceBlockAt(pos.x, pos.y, pos.z, 484, mob) then
		return false
	end

	mob:placeBlock(484, pos.x, pos.y, pos.z, 2)

	return true
end

function funcs.removeBed(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	local pos = controller.bb.get(controller.subparam.bedPos)

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return true
	end

	local workPos = WCoord:new_local()
	workPos.x = 0
	workPos.y = 0
	workPos.z = 0

	mob:setBedBindPos(workPos)

	local blockid = CurWorld:getBlockID(pos.x, pos.y, pos.z)

	if blockid ~= 484 then
		return true
	end

	workPos.x = pos.x
	workPos.y = pos.y
	workPos.z = pos.z

	mob:destroyBlock(workPos, false, BLOCK_MINE_NONE)

	return true
end

function funcs.setAvoidStand(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	mob:setAvoidStand(controller.subparam.value or false)

	return true
end

function funcs.setBedBind(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	local bedpos = controller.bb.get(extraValue)

	if not bedpos then
		return false
	end

	AIFunctionMgr:setBedBindPos(mob, bedpos.x, bedpos.y, bedpos.z)

	return true
end

function funcs.checkHateUinAndAttack(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	local uin = mob:getWarningUin()

	if uin > 0 then
		mob:triggerAttackWarningUin()

		return true
	else
		return false
	end

	return false
end

function funcs.clearHateUin(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	mob:clearWarn()

	return true
end

function funcs.findSitAvoidStand(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	mob:findSitAvoidStandPos()

	local pos = mob:getBedBindPos()

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	controller.bb.set(controller.subparam.avoidStandPos, {
		x = pos.x,
		y = pos.y,
		z = pos.z
	})

	return true
end

function funcs.getPickingCamelPos(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	local objId = mob:getPickingCamel()
	local camel = mob:getActorMgr():findActorByWID(objId)

	if not camel then
		mob:clearWarn()

		return false
	end

	local pos = camel:getPosition()
	local posx, posy, posz = nil
	posx, posy, posz = CoordDivBlock(pos.x, pos.y, pos.z)

	controller.bb.set(controller.subparam.camelPos, {
		x = posx,
		y = posy,
		z = posz
	})

	return true
end

function funcs.informPlayerCloseUI(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	local uin = mob:getWarningUin()

	if uin > 0 then
		if ROOM_SERVER_RENT ~= GetGameInfo():GetRoomHostType() and ClientCurGame:isHost(uin) then
			if GetInst("MiniUIManager"):IsShown("storageBoxFrame") then
				GetInst("MiniUIManager"):CloseUI("storageBoxFrameAutoGen")
			end
		else
			local content = {
				uiName = "MobInteractBackpack"
			}

			SandboxLuaMsg.sendToClient(uin, SANDBOX_LUAMSG_NAME.Survive.PLAYER_CLOSE_UI, content)
		end

		return true
	end

	return false
end

function funcs.resetMobHeadDir(mob)
	if not mob then
		return false
	end

	mob.m_Body:clearMove()

	return true
end

function funcs.normalTradeGetExchangeItem(mob, extraValue, controller)
	if not mob then
		return false
	end

	local id = mob:shouldPlayDealAnim()

	if id > 0 then
		controller.bb.set(controller.subparam.bb_exchange, id)
		mob:setShouldPlayDealAnim(-1)

		return true
	else
		return false
	end

	return false
end

function funcs.findHavePlayerSurround(mob, extraValue, controller)
	if not mob then
		return false
	end

	local range = controller.subparam.range
	range = range or 6

	return AIFunctionMgr:haveActorSurround(mob, range, range)
end

function funcs.findPlayerByMobViewRay(mob, extraValue, controller)
	if not mob then
		return false
	end

	local find, type = nil
	local uin = 0
	find, uin = AIFunctionMgr:findPlayerByMobViewRay(mob, uin)

	if find then
		controller.bb.set(controller.subparam.player, {
			actor = uin
		})

		return true
	end

	return false
end

function funcs.playerDropEquip(mob, extraValue, controller)
	if not mob then
		return false
	end

	local uin = controller.bb.get(controller.subparam.player).actor
	local player = WorldMgr:GetPlayerByUin(uin)

	if not player then
		return false
	end

	local attrib = player:getAttrib()
	attrib = tolua.cast(attrib, "PlayerAttrib")

	if not attrib then
		return false
	end

	local targetId = 0

	for i = 1, MAX_EQUIP_SLOTS do
		local grid = attrib:getEquipGrid(i - 1)
		local selectItemId = grid:getItemID()

		if selectItemId > 0 then
			player:discardEquip(i - 1, 1)

			targetId = selectItemId

			controller.bb.set(controller.subparam.target, targetId)
			controller.bb.set(controller.subparam.targetType, i)

			return true
		end
	end

	return false
end

function funcs.findDropItemNear(mob, extraValue, controller)
	if not mob then
		return false
	end

	local id = controller.bb.get(controller.subparam.target)
	local isGet, targetObjID, posX, posY, posZ = AIFunctionMgr:GetNearestActorPos(mob, id, 0, 2, 5, 0, 0, 0)

	if isGet then
		controller.bb.set(controller.subparam.targetId, {
			actor = targetObjID
		})
		controller.bb.set(controller.subparam.targetPos, {
			x = posX,
			y = posY,
			z = posZ
		})

		return true
	end

	return false
end

function funcs.mobEquipFromBackPack(mob, extraValue, controller)
	local equipType = controller.bb.get(controller.subparam.targetType)

	if equipType < 0 then
		return false
	end

	local obj = controller.target.get()
	local targetId = controller.bb.get(controller.subparam.dropItemId).actor or 0
	local targetObj = AIFunctionMgr:getActorByObjId(obj, targetId)
	local itemId = targetObj and targetObj.GetItemId and targetObj:GetItemId() or 0
	local itemNum = 0

	if ActorComponentCallModule then
		itemNum = ActorComponentCallModule(targetObj, "DropItemComponent", "getDropItemNum") or 0
	else
		itemNum = targetObj and targetObj.getDropItemNum and targetObj:getDropItemNum() or 0
	end

	local curEquipId = obj:getEquipItem(equipType - 1)

	if curEquipId <= 0 then
		AIFunctionMgr:playSound(obj, "npc.pick", 1, 1, 2)
		AIFunctionMgr:pickItem(obj, targetObj, 0)
	elseif AIFunctionMgr:checkPutItem(obj, itemId, itemNum) then
		AIFunctionMgr:playSound(obj, "npc.pick", 1, 1, 2)
		AIFunctionMgr:pickItem(obj, targetObj)

		return true
	end

	return false
end

function funcs.calculatePlayerEquip(mob, extraValue, controller)
	local uin = controller.bb.get(controller.subparam.player).actor
	local player = WorldMgr:GetPlayerByUin(uin)

	if not player then
		return false
	end

	local attrib = player:getAttrib()
	attrib = tolua.cast(attrib, "PlayerAttrib")

	if not attrib then
		return false
	end

	local t_score = {
		[12284.0] = 6,
		[12291.0] = 4,
		[12005.0] = 6,
		[12010.0] = 5,
		[12302.0] = 4,
		[12301.0] = 4,
		[12283.0] = 4,
		[12303.0] = 4,
		[12304.0] = 4,
		[12056.0] = 6,
		[12311.0] = 5,
		[12009.0] = 5
	}
	local targetId = 0
	local score = 0

	for i = 1, MAX_EQUIP_SLOTS do
		local grid = attrib:getEquipGrid(i - 1)
		local selectItemId = grid:getItemID()

		if selectItemId >= 12201 and selectItemId <= 12205 then
			score = score + 1
		elseif selectItemId >= 12211 and selectItemId <= 12214 then
			score = score + 3
		elseif selectItemId >= 12216 and selectItemId <= 12219 then
			score = score + 2
		elseif selectItemId >= 12221 and selectItemId <= 12225 then
			score = score + 4
		elseif selectItemId >= 12231 and selectItemId <= 12234 then
			score = score + 5
		elseif selectItemId >= 12241 and selectItemId <= 12244 then
			score = score + 6
		elseif t_score[selectItemId] then
			score = score + t_score[selectItemId]
		else
			local toolDef = DefMgr:getToolDef(selectItemId)

			if toolDef then
				local type = toolDef.Type

				if type == 1 or type == 2 or type == 6 or type == 7 or type == 24 then
					score = score + 3
				end
			end
		end
	end

	if score < 12 then
		return true
	end

	return false
end

function funcs.mobOpenContainer(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorIslandBusInessMan")

	if not mob then
		return false
	end

	local uin = controller.bb.get(controller.subparam.player).actor
	local player = WorldMgr:GetPlayerByUin(uin)

	if not player then
		return false
	end

	mob:islandBusInessManInteract(player)

	return true
end

function funcs.mobResetAI(mob, extraValue, controller)
	if not mob then
		return false
	end

	AIFunctionMgr:playAnimBySeqId(mob, 100100)
	mob:ResetBTree()

	return true
end

function funcs.numberMinus(mob, extraValue, controller)
	local num = controller.bb.get(controller.subparam.minuend)
	local minue = controller.bb.get(controller.subparam.minus)
	num = num - minue

	controller.bb.set(controller.subparam.minuend, num)

	return true
end

function funcs.findRangePosInWater(mob, xtraValue, controller)
	if not mob or not CurWorld then
		return false
	end

	if mob.setWaterMove then
		mob:setWaterMove(true)
	else
		local lWrap = mob:getFuncWrapper()

		lWrap:setWaterMove(true)
	end

	local x, y, z = mob:getPosition(0, 0, 0)
	x, y, z = CoordDivBlock(x, y, z)
	local range = controller.subparam.range
	local randX = math.random(0, range * 2)
	local randZ = math.random(0, range * 2)

	if range < randX then
		randX = range - randX
	end

	if range < randZ then
		randZ = range - randZ
	end

	x = x + randX
	z = z + randZ
	local curTopHeight = CurWorld:getTopHeight(x, z) + 1

	controller.bb.set(controller.subparam.bb_stollpos, {
		x = x,
		y = curTopHeight,
		z = z
	})

	return true
end

function funcs.patrolMobSleep(mob)
	mob = tolua.cast(mob, "ActorPatrolMob")

	if not mob then
		return false
	end

	mob:patrolSleep()

	return true
end

function funcs.testAI(mob)
	mob.m_Body.m_RotationYawHead = mob.m_Body.m_RenderYawOffset + 50

	return true
end

return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local fun = funcs[controller.subparam.fun]

		if not fun then
			return controller.fail()
		end

		if fun(obj, controller.subparam.extraValue, controller, funcs) then
			return controller.success()
		end

		return controller.fail()
	end
}
