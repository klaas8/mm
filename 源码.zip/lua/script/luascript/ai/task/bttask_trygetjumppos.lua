return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()

		if not obj then
			return controller.fail()
		end

		local workpos = controller.bb.get(controller.subparam.bb_workpos)
		local pos = controller.bb.get(controller.subparam.block_pos_key)

		AIFunctionMgr:tryGetJumpPos(obj, WCoord(workpos.x, workpos.y, workpos.z), WCoord(pos.x, pos.y, pos.z))

		return controller.success()
	end
}
