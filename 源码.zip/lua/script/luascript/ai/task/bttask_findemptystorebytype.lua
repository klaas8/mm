return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local isFind = false
		local posX = 0
		local posY = 0
		local posZ = 0
		slot4 = 0
		slot5 = 0
		local obj = controller.target.get()
		local centerX = 0
		local centerY = 0
		local centerZ = 0
		local type = controller.subparam.type or 1
		local range = controller.subparam.range or 8

		if type == 1 then
			local center = controller.bb.get(controller.subparam.bbCenterpos)
			centerX = center.x
			centerY = center.y
			centerZ = center.z
		end

		isFind, posX, posY, posZ = AIFunctionMgr:GetSurvivableStorePosInRange(obj, type, range, centerX, centerY, centerZ, posX, posY, posZ)

		if isFind then
			controller.bb.set(controller.subparam.bbTargetpos, {
				x = posX,
				y = posY,
				z = posZ
			})

			return controller.success()
		else
			return controller.fail()
		end
	end
}
