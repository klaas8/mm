return {
	subparam = {
		type = 1,
		bbflag = 0,
		targetUin = 0,
		contentType = 0,
		content = "default commonTips"
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local tipsContent = controller.subparam.content

		if controller.subparam.bbflag == 1 then
			tipsContent = controller.bb.get(tipsContent)
		end

		local tipsContentType = controller.subparam.contentType
		local tipsType = controller.subparam.type
		local tipsUin = controller.subparam.targetUin
		local flag = false

		if tipsContent and tipsType and ClientCurGame and ClientCurGame.sendChat then
			if tipsContentType == 1 then
				tipsContent = controller.bb.get(tipsContent)

				if type(tipsContent) == "table" then
					local tempContent = ""

					for k, v in pairs(tipsContent) do
						tempContent = tempContent .. " " .. v
					end

					tipsContent = tempContent
				elseif type(tipsContent) == "boolean" then
					if tipsContent then
						tipsContent = "true"
					else
						tipsContent = "false"
					end
				end
			end

			ClientCurGame:sendChat(tipsContent, tipsType, tipsUin)

			flag = true
		end

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
