return {
	run = function ()
		local obj = controller.target.get()

		if not obj then
			return controller.fail()
		end

		if AIFunctionMgr:isSleeping(obj) then
			AIFunctionMgr:wakeUp(obj, "")
		end

		return controller.success()
	end
}
