return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()

		local function getCurValueByJudgeType(judgeType)
			local extraValue = controller.bb.get(controller.subparam.extraValue)
			local curValue = 0
			local judgeTypeEnum = AIFunctionDefsGetDefByKey("judgeType")

			if judgeType == judgeTypeEnum.sleepTime then
				curValue = AIFunctionMgr:GetTime()
			elseif judgeType == judgeTypeEnum.isSleeping then
				if AIFunctionMgr:isSleeping(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.stayUpLateTime then
				curValue = AIFunctionMgr:GetTime()
			elseif judgeType == judgeTypeEnum.isStayUpLate then
				if AIFunctionMgr:isStayingUp(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.getUpTime then
				curValue = AIFunctionMgr:GetTime()
			elseif judgeType == judgeTypeEnum.fullUp then
				curValue = AIFunctionMgr:GetFullUp(obj)
			elseif judgeType == judgeTypeEnum.temperature then
				curValue = AIFunctionMgr:getTemperature(obj)
			elseif judgeType == judgeTypeEnum.equipItemId then
				curValue = AIFunctionMgr:getCurShowEquipItemId(obj, 1)
			elseif judgeType == judgeTypeEnum.huggerStatus then
				curValue = AIFunctionMgr:getHuggerStatus(obj)
			elseif judgeType == judgeTypeEnum.fatigueStatus then
				curValue = AIFunctionMgr:GetFatigue(obj)
			elseif judgeType == judgeTypeEnum.isDefection then
				if AIFunctionMgr:IsDefection(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.professionType then
				curValue = AIFunctionMgr:getProfession(obj)
			elseif judgeType == judgeTypeEnum.professionCount then
				local professionType = extraValue
				local player = AIFunctionMgr:GetOwner(obj)

				if player then
					curValue = AIFunctionMgr:GetPlayerSavageCount(player, professionType)
				end
			elseif judgeType == judgeTypeEnum.bagItemCount then
				local itemId = 0
				local isTypeItemId = false

				if type(extraValue) ~= "number" then
					itemId = extraValue[1]
					isTypeItemId = extraValue[2]
				else
					itemId = extraValue
					isTypeItemId = false
				end

				curValue = AIFunctionMgr:GetItemOwnedCount(obj, itemId, isTypeItemId)
			elseif judgeType == judgeTypeEnum.isCooling then
				local cdType = extraValue
				curValue = AIFunctionMgr:IsCooling(obj, cdType, getServerTime()) and 1 or 0
			elseif judgeType == judgeTypeEnum.isHaveBindPoint then
				local player = AIFunctionMgr:GetOwner(obj)

				if player then
					if AIFunctionMgr:IsPlayerHaveBindPoint(player) then
						curValue = 1
					else
						curValue = 0
					end
				end
			elseif judgeType == judgeTypeEnum.isBindWithWorkPoint then
				local posX = extraValue.x
				local posY = extraValue.y
				local posZ = extraValue.z
				curValue = AIFunctionMgr:IsBindWithPoint(obj, 1, posX, posY, posZ) and 1 or 0
			elseif judgeType == judgeTypeEnum.isBindWithBedPoint then
				local posX = extraValue.x
				local posY = extraValue.y
				local posZ = extraValue.z

				if obj:getObjType() == OBJ_TYPE_DESERTVILLAGER then
					if AIFunctionMgr:IsBindWithDesertBedPoint(obj, posX, posY, posZ) then
						curValue = 1
					else
						curValue = 0
					end
				elseif obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
					if AIFunctionMgr:IsBindWithFishingVillageBedPoint(obj, posX, posY, posZ) then
						curValue = 1
					else
						curValue = 0
					end
				elseif AIFunctionMgr:IsBindWithPoint(obj, 2, posX, posY, posZ) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isBindWithVillagePoint then
				local posX = extraValue.x
				local posY = extraValue.y
				local posZ = extraValue.z
				curValue = AIFunctionMgr:IsBindWithPoint(obj, 3, posX, posY, posZ) and 1 or 0
			elseif judgeType == judgeTypeEnum.targetDis then
				local posX = extraValue.x
				local posY = extraValue.y
				local posZ = extraValue.z
				curValue = AIFunctionMgr:GetTargetDis(obj, posX, posY, posZ)
			elseif judgeType == judgeTypeEnum.isBlockOccupyed then
				local posX = extraValue.x
				local posY = extraValue.y
				local posZ = extraValue.z
				curValue = AIFunctionMgr:GetBlockOccupieState(posX, posY, posZ) and 1 or 0
			elseif judgeType == judgeTypeEnum.disposition then
				curValue = AIFunctionMgr:getDisposition(obj)
			elseif judgeType == judgeTypeEnum.favor then
				curValue = AIFunctionMgr:getFavor(obj)
			elseif judgeType == judgeTypeEnum.extremisVal then
				curValue = AIFunctionMgr:getExtremisVal(obj)
			elseif judgeType == judgeTypeEnum.isTamed then
				if AIFunctionMgr:getTamedId(obj) ~= 0 then
					curValue = 1
				end
			elseif judgeType == judgeTypeEnum.emptygrid then
				curValue = AIFunctionMgr:GetEmptyGridCount(obj)
			elseif judgeType == judgeTypeEnum.demand then
				curValue = AIFunctionMgr:getDemand(obj)
			elseif judgeType == judgeTypeEnum.foodByTamed then
				curValue = AIFunctionMgr:getFoodByTamed(obj)
			elseif judgeType == judgeTypeEnum.hairId then
				curValue = AIFunctionMgr:getHairId(obj)
			elseif judgeType == judgeTypeEnum.hairColor then
				curValue = AIFunctionMgr:getHairColor(obj)
			elseif judgeType == judgeTypeEnum.faceId then
				curValue = AIFunctionMgr:getFaceId(obj)
			elseif judgeType == judgeTypeEnum.bedBindPos then
				if obj:getObjType() == OBJ_TYPE_DESERTVILLAGER then
					local posX, posY, posZ = AIFunctionMgr:getDesertBedBindPos(obj, 0, 0, 0)
				elseif obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
					local posX, posY, posZ = AIFunctionMgr:getFishingVillageBedBindPos(obj, 0, 0, 0)
				else
					local posX, posY, posZ = AIFunctionMgr:getBedBindPos(obj, 0, 0, 0)
				end

				curValue = {
					x = posX,
					y = posY,
					z = posZ
				}
			elseif judgeType == judgeTypeEnum.workBindPos then
				local posX, posY, posZ = AIFunctionMgr:getWorkBindPos(obj, 0, 0, 0)
				curValue = {
					x = posX,
					y = posY,
					z = posZ
				}
			elseif judgeType == judgeTypeEnum.hugger then
				curValue = AIFunctionMgr:getHugger(obj)
			elseif judgeType == judgeTypeEnum.speedOfBreakingBlock then
				curValue = AIFunctionMgr:getSpeedOfBreakingBlock(obj)
			elseif judgeType == judgeTypeEnum.moveSpeed then
				local moveType = extraValue or 0
				curValue = AIFunctionMgr:GetMoveSpeed(obj, moveType)
			elseif judgeType == judgeTypeEnum.maxHp then
				curValue = AIFunctionMgr:getMaxHp(obj)
			elseif judgeType == judgeTypeEnum.curHp then
				curValue = AIFunctionMgr:getHp(obj)
			elseif judgeType == judgeTypeEnum.shortRangeAttack then
				curValue = AIFunctionMgr:GetAttackBase(obj, 0)
			elseif judgeType == judgeTypeEnum.longRangeAttack then
				curValue = AIFunctionMgr:GetAttackBase(obj, 1)
			elseif judgeType == judgeTypeEnum.shortRangeDefense then
				curValue = AIFunctionMgr:GetDefenseBase(obj, 0)
			elseif judgeType == judgeTypeEnum.longRangeDefense then
				curValue = AIFunctionMgr:GetDefenseBase(obj, 1)
			elseif judgeType == judgeTypeEnum.modelScale then
				curValue = AIFunctionMgr:getScale(obj)
			elseif judgeType == judgeTypeEnum.handItem then
				curValue = AIFunctionMgr:GetHoldItemId(obj)
			elseif judgeType == judgeTypeEnum.sitstate then
				if AIFunctionMgr:getSitState(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isGuardForPlayer then
				if AIFunctionMgr:IsGuardForPlayer(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isIceVillage then
				if AIFunctionMgr:isIceVillage(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.cdDuration then
				curValue = AIFunctionMgr:getTickDuration(obj, 0)
			elseif judgeType == judgeTypeEnum.bufferDuration then
				curValue = AIFunctionMgr:getTickDuration(obj, 1)
			elseif judgeType == judgeTypeEnum.isHaveWorshipBlock then
				if AIFunctionMgr:isHaveWorshipBlock(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isFreezing then
				if AIFunctionMgr:isFreezing(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isOtherFreezing then
				if AIFunctionMgr:isOtherFreezing(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isReachTime then
				local timeType = extraValue or 0
				local timeTypeEnum = AIFunctionDefsGetDefByKey("timeType")
				local curTime = 0

				if timeType == timeTypeEnum.wakeUp then
					curTime = AIFunctionMgr:getWakeupTime(obj)
				elseif timeType == timeTypeEnum.offWork then
					curTime = AIFunctionMgr:getSleepTime(obj) - 2
				elseif timeType == timeTypeEnum.sleep then
					curTime = AIFunctionMgr:getSleepTime(obj)
				elseif timeType == timeTypeEnum.stayUpLate then
					curTime = AIFunctionMgr:getStayupTime(obj)
				end

				if curTime <= AIFunctionMgr:GetTime() then
					curValue = 1
				end
			elseif judgeType == judgeTypeEnum.isBedBindWithOthers then
				local posX = extraValue.x
				local posY = extraValue.y
				local posZ = extraValue.z
				curValue = AIFunctionMgr:IsBedCanBeBind(obj, posX, posY, posZ) and 0 or 1
			elseif judgeType == judgeTypeEnum.randomValue then
				local randomMax = extraValue
				curValue = AIFunctionMgr:GenRandomIntAi(randomMax)
			elseif judgeType == judgeTypeEnum.isInRange then
				local rangeType = 0

				if type(extraValue) == "number" then
					rangeType = extraValue or AIFunctionDefsGetDefByKey("rangeType").work
				else
					rangeType = extraValue and extraValue[1] or AIFunctionDefsGetDefByKey("rangeType").work
				end

				local range = 0
				local centerPos = {
					x = 0,
					z = 0,
					y = 0
				}
				local selfPos = {
					x = 0,
					z = 0,
					y = 0
				}

				local function isInRange(selfPos, centerPos, range)
					if selfPos.x == 0 and selfPos.y == 0 and selfPos.z == 0 then
						return false
					end

					if centerPos.x == 0 and centerPos.y == 0 and centerPos.z == 0 then
						return false
					end

					if range == 0 then
						return false
					end

					local minX = centerPos.x - range
					local maxX = centerPos.x + range
					local minY = centerPos.y - range
					local maxY = centerPos.y + range
					local minZ = centerPos.z - range
					local maxZ = centerPos.z + range

					if minX <= selfPos.x and selfPos.x <= maxX and minY <= selfPos.y and selfPos.y <= maxY and minZ <= selfPos.z and selfPos.z <= maxZ then
						return true
					else
						return false
					end
				end

				selfPos.x, selfPos.y, selfPos.z = AIFunctionMgr:GetActorPos(obj, 0, 0, 0)

				if rangeType == AIFunctionDefsGetDefByKey("rangeType").work then
					range = AIFunctionDefsGetDefByKey("workRange")
					centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:getWorkBindPos(obj, 0, 0, 0)
				elseif rangeType == AIFunctionDefsGetDefByKey("rangeType").village then
					if obj:getObjType() == OBJ_TYPE_DESERTVILLAGER then
						range = 64
						centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:getDesertVillagePoint(obj, 0, 0, 0)
					elseif obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
						range = 64
						centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:getFishingVillagePoint(obj, 0, 0, 0)
					else
						range = AIFunctionDefsGetDefByKey("villageRange")
						centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:GetVillagePoint(obj, 0, 0, 0)
					end
				elseif rangeType == AIFunctionDefsGetDefByKey("rangeType").villageStore then
					range = AIFunctionDefsGetDefByKey("villageStoreRange")
					centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:GetVillagePoint(obj, 0, 0, 0)
				elseif rangeType == AIFunctionDefsGetDefByKey("rangeType").view then
					range = AIFunctionMgr:GetViewDis(obj)
					local actor = AIFunctionMgr:getActorByObjId(obj, controller.bb.get(extraValue[2]).actor)
					local actorPos = {}
					actorPos.x, actorPos.y, actorPos.z = AIFunctionMgr:GetActorPos(actor, 0, 0, 0)
					selfPos = actorPos
					centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:GetActorPos(obj, 0, 0, 0)
				elseif rangeType == AIFunctionDefsGetDefByKey("rangeType").bpWork then
					range = AIFunctionDefsGetDefByKey("bpWorkRange")
					centerPos.x, centerPos.y, centerPos.z = AIFunctionMgr:getWorkBindPos(obj, 0, 0, 0)
				end

				if isInRange(selfPos, centerPos, range) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isHelperWorking then
				if AIFunctionMgr:IsVillagerHasHelper(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.isActorExist then
				local actorObjId = extraValue.actor

				if actorObjId then
					if AIFunctionMgr:getActorByObjId(obj, actorObjId) then
						curValue = 1
					else
						curValue = 0
					end
				end
			elseif judgeType == judgeTypeEnum.handItemType then
				local handItemId = AIFunctionMgr:GetHoldItemId(obj)
				local profession = AIFunctionMgr:getProfession(obj)
				curValue = GetInst("AIFunctionDefs"):GetItemType(handItemId, profession)
			elseif judgeType == judgeTypeEnum.isInWater then
				if AIFunctionMgr:GetIsInWater(obj) then
					curValue = 1
				else
					curValue = 0
				end
			elseif judgeType == judgeTypeEnum.value then
				curValue = controller.bb.get(controller.subparam.curValue)
			elseif judgeType == judgeTypeEnum.handItemIsSapling then
				local handItemid = AIFunctionMgr:GetHoldItemId(obj)
				curValue = AIFunctionMgr:IsSapling(handItemid) and 1 or 0
			elseif judgeType == judgeTypeEnum.handItemIsCropSeed then
				local handItemid = AIFunctionMgr:GetHoldItemId(obj)
				curValue = AIFunctionMgr:IsCropSeed(handItemid) and 1 or 0
			elseif judgeType == judgeTypeEnum.stayBiome then
				local x, y, z = obj:getPosition(0, 0, 0)
				curValue = CurWorld:getBiomeType(math.floor(x / 100), math.floor(z / 100))
			end

			return curValue
		end

		local judgeType = controller.subparam.judgeType
		local compareType = controller.subparam.compareType
		local compareValue = controller.bb.get(controller.subparam.compareValue)
		local curValue = getCurValueByJudgeType(judgeType)
		local flag = false
		local compareTypeEnum = AIFunctionDefsGetDefByKey("compareType")

		if type(curValue) == "number" then
			if compareType == compareTypeEnum.less then
				if curValue < compareValue then
					flag = true
				end
			elseif compareType == compareTypeEnum.equal then
				if curValue == compareValue then
					flag = true
				end
			elseif compareType == compareTypeEnum.more then
				if compareValue < curValue then
					flag = true
				end
			elseif compareType == compareTypeEnum.lessEqual then
				if curValue <= compareValue then
					flag = true
				end
			elseif compareType == compareTypeEnum.moreEqual then
				if compareValue <= curValue then
					flag = true
				end
			elseif compareType == compareTypeEnum.notequal and curValue ~= compareValue then
				flag = true
			end
		elseif compareType == compareTypeEnum.equal then
			if IsTableEqual(curValue, compareValue) then
				flag = true
			end
		elseif compareType == compareTypeEnum.notequal and not IsTableEqual(curValue, compareValue) then
			flag = true
		end

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
