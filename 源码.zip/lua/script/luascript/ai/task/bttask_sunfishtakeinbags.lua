return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local blockpos = controller.bb.get(controller.subparam.blockpos)
		local isSuccess = false

		for index = 1, 3 do
			local itemtab = {
				12520,
				12703,
				12704
			}

			for index, value in ipairs(itemtab) do
				local tempCount = AIFunctionMgr:getItemCountByBags(obj, value)

				if tempCount > 0 then
					local ret = AIFunctionMgr:addFreshFish(obj, blockpos.x, blockpos.y, blockpos.z, value)

					if ret then
						isSuccess = true

						break
					end
				end
			end
		end

		if isSuccess then
			return controller.success()
		end

		return controller.fail()
	end
}
