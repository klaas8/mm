return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local range = controller.bb.get(controller.subparam.range)
		local enemy_id = controller.bb.get(controller.subparam.escapeId)
		local findObj = AIFunctionMgr:getActorByObjId(obj, enemy_id.actor)

		if findObj then
			local isFind, posX, posY, posZ = AIFunctionMgr:getEscapePos(obj, findObj, range, 0, 0, 0)

			if isFind then
				controller.bb.set(controller.subparam.targetPos, {
					x = posX,
					y = posY,
					z = posZ
				})

				return controller.success()
			else
				return controller.fail()
			end
		end
	end
}
