return {
	{
		script = "BTTask_commonJudge",
		desc = "通用判断叶子，所有的判断都可用此叶子实现",
		subparam = {
			compareValue = "比较值(必要参数,如果是bool类型，真为1，假为0)",
			compareType = "比较类型(必要参数,类型定义在AIFunctionDefs)",
			extraValue = "增量值(非必要参数,用于一些特殊判断)",
			judgeType = "判断类型(必要参数,类型定义在AIFunctionDefs)"
		}
	},
	{
		script = "BTTask_commonPlayAction",
		desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
		subparam = {
			tipsBgName = "头顶提示背景图名",
			animID = "动作ID",
			tipsItemId = "头顶提示内容(这里可以使用黑板数据)",
			tipsType = "头顶提示类型",
			faceId = "面部表情(这里可以使用黑板数据)",
			effectID = "特效ID",
			duration = "持续时间",
			soundName = "音效名"
		}
	},
	{
		script = "BTTask_commonFindTargetPos",
		desc = "通用寻找目标位置叶子，所有的寻找目标位置都可用此叶子实现",
		subparam = {
			bbKeyTargetPos = "保存寻找对象的位置",
			targetID = "寻找对象的ID(必要参数)",
			bbKeyTargetObjId = "保存寻找对象的OBJID",
			actorObjType = "生物的类型",
			targetType = "寻找对象的类型(必要参数,类型定义在AIFunctionDefs)",
			range = "寻找范围(必要参数)"
		}
	},
	{
		script = "BTTask_commonSetValue",
		desc = "通用设置值叶子，所有的设置值操作都可用此叶子实现",
		subparam = {
			value = "需要设置的值（必要参数）",
			valueType = "值类型(必要参数,类型定义在AIFunctionDefs)",
			operationType = "运算类型（加，减，乘，除），直接设置值的话，不需要填该字段",
			extraValue = "增量值(非必要参数,用于一些特殊设置)",
			key = "需要设置的值的key(非必要参数，当valueType = 100时为纯数值才有意义)"
		}
	},
	{
		script = "BTTask_commonTips",
		desc = "通用提示叶子",
		subparam = {
			type = "0表示普通聊天，1表示系统消息",
			contentType = "0表示手写文本，1表示从黑板取信息",
			targetUin = "0表示发给所有玩家 >0表示发给uin为targetuin的玩家",
			content = "提示内容"
		}
	},
	{
		script = "BTTask_LookAt",
		desc = "看向某个玩家或者或左右看看 ",
		subparam = {
			waittimemin = 1,
			actorwaittime = 0.2,
			searchRange = 8,
			waittimemax = 4
		}
	},
	{
		script = "BTTask_FindPosByNeedType",
		desc = "尝试移动到需求位置 ",
		subparam = {
			searchType = 1,
			findboxid = 0,
			bbkey_targetpos = "BTTask_FindStoragePos",
			bbkey_itemid = "finditem",
			bempty = false,
			equipslot = 0
		}
	},
	{
		script = "BTTask_getBedPos",
		desc = "前往已绑定床位",
		subparam = {
			bb_bedpos = "bedpos"
		}
	},
	{
		script = "BTTask_getWorkPos",
		desc = "前往已绑定床位",
		subparam = {
			bb_workpos = "workpos"
		}
	},
	{
		script = "BTTask_getVillagePos",
		desc = "前往已绑定床位",
		subparam = {
			bb_villagepos = "villagepos"
		}
	},
	{
		script = "BTTask_sleepOnAndBindBed",
		desc = "驯服后的野人睡觉，同时绑定自己的私人床位",
		subparam = {
			bb_bedpos = "bedpos"
		}
	},
	{
		script = "BTTask_wakeup",
		desc = "起床"
	},
	{
		script = "BTTask_sitDown",
		desc = "坐下",
		subparam = {
			bbkey_chairPos = ""
		}
	},
	{
		script = "BTTask_standUp",
		desc = "站起"
	},
	{
		script = "BTTask_doonce",
		desc = "执行一次"
	},
	{
		script = "BTTask_getRandStollPos",
		desc = "获取随机闲逛位置",
		subparam = {
			bb_stollpos = "stollpos",
			centerPos = "centerPos",
			rangeWidth = "rangeWidth",
			rangeHeight = "rangeHeight"
		}
	},
	{
		script = "BTTask_findPosOfObjects",
		desc = "获取指定的一组id，在指定范围内最近的位置",
		subparam = {
			bb_targetpos = "targetpos",
			bb_centerpos = "centerpos",
			rangexyz = {
				x = 1,
				y = 1,
				z = 1
			},
			objects = {
				200,
				201
			}
		}
	},
	{
		script = "BTTask_giveItem",
		desc = "给与物品",
		subparam = {
			bbKeyGiveItemId = "bbKeyGiveItemId",
			bbKeyTargetObjId = "bbKeyTargetObjId",
			bbKeyGiveItemFromHand = "bbKeyGiveItemFromHand",
			bbKeyGiveItemCount = "bbKeyGiveItemCount"
		}
	},
	{
		script = "BTTask_storeItem",
		desc = "存储物品",
		subparam = {
			bbKeyStoreItemId = "bbKeyStoreItemId",
			bbKeyStoreItemCount = "bbKeyStoreItemCount",
			bbKeyTargetPos = "bbKeyTargetPos"
		}
	},
	{
		script = "BTTask_storeAllItem",
		desc = "存储所有物品",
		subparam = {
			bbkey_targetpos = "bbKeyTargetPos"
		}
	},
	{
		script = "BTTask_PEventPlayAction",
		desc = "概率事件播放动作",
		subparam = {
			type = 2,
			flag = false,
			duration = 0
		}
	},
	{
		script = "BTTask_FindBiologyPos",
		desc = "寻找生物的位置",
		subparam = {
			biologyId = 3202,
			bbBiologyPosKey = "find_helper_pos"
		}
	},
	{
		script = "BTTask_AskHelperForNeed",
		desc = "向帮手申请需求",
		subparam = {
			needType = 1,
			needNum = 1
		}
	},
	{
		script = "BTTask_cancelHelperService",
		desc = "取消帮手需求",
		subparam = {}
	},
	{
		script = "BTTask_putFoodInHand",
		desc = "把食物放在手上",
		subparam = {
			bbFoodId = ""
		}
	},
	{
		script = "BTTask_Pick",
		desc = "捡起掉落物到背包",
		subparam = {
			dropItemId = "bbKeyTargetObjId"
		}
	},
	{
		script = "BTTask_craftingItem",
		desc = "合成道具",
		subparam = {
			subparam = {
				craftdiffernum = 0,
				bbkey_craftID = "craft_ID",
				craftdifferID = 0,
				bbkey_takenum = "basenum",
				bbkey_takeItemID = "baseitemid",
				bbkey_needtype = "need_type"
			}
		}
	},
	{
		script = "BTTask_craftCondition",
		desc = "查询可以合成的道具",
		subparam = {
			bbkey_craftID = "craft_ID",
			bbkey_targetActor = "mob_Target",
			bbkey_needtype = "need_type"
		}
	},
	{
		script = "BTTask_FindPosByStorageID",
		desc = "寻找有某个道具ID的储物箱位置",
		subparam = {
			bbkey_targetpos = "",
			bbkey_itemid = ""
		}
	},
	{
		script = "BTTask_TakeItemToPack",
		desc = "从箱子中取出一定数量的道具",
		subparam = {
			bbkey_multi_iteminfos = "finditem_itemids",
			bbkey_in_boxpos = "finditem_out_boxpos",
			takeitemmode = 2
		}
	},
	{
		script = "BTTask_FindDropFoodPos",
		desc = "搜寻范围内掉落食物的位置",
		subparam = {
			bbTargetIdKey = "find_food_targetid",
			bbPosKey = "find_food_pos"
		}
	},
	{
		node = "BTNTaskDigBlock",
		param = {
			speed = 1,
			block_pos_key = "bbkey_targetpos",
			dig_dist = 230,
			dist = 1600
		}
	},
	{
		node = "BTNTaskPlant",
		param = {
			speed = 1,
			block_pos_key = "bbkey_targetpos",
			isauto_change_land = 0,
			plant_type = 1,
			dist = 1600
		}
	},
	{
		node = "BTNTaskFollow",
		param = {
			refreshtick = 100,
			bbkey_followobj = "bb_actor",
			bbkey_targetpos = "bbkey_targetpos"
		}
	},
	{
		node = "BTNTaskAttack",
		param = {
			keeptick = 1,
			bbkey_attackobj = "bbkey_attackobj"
		}
	},
	{
		node = "BTNTaskMoveTo",
		param = {
			speed = 1,
			CollideHorizontallyStop = 1,
			bbkey_limitrange = 1,
			bbkey_targetpos = "bbkey_targetpos",
			minDistance = 2,
			avoidWater = 1
		}
	},
	{
		node = "BTNTaskFollowDirection",
		desc = "跟随导向牌，沿着导向牌移动，找不到导向牌返回失败，否则导向完成后返回成功",
		param = {
			speed = 1
		}
	},
	{
		script = "BTTask_checkEscape",
		desc = "是否需要逃离",
		subparam = {
			bbKeyTargetPos = "bbKeyEscapeTargetPos",
			bbKeyTargetObjId = "bbKeyEscapeTargetObjId",
			range = 32
		}
	},
	{
		script = "BTTask_checkAttack",
		desc = "是否需要攻击",
		subparam = {
			bbKeyTargetPos = "bbKeyAttackTargetPos",
			bbKeyTargetObjId = "bbKeyAttackTargetObjId",
			range = 32
		}
	},
	{
		script = "BTTask_EatHandFood",
		desc = "吃手上的食物"
	},
	{
		script = "BTTask_TurnToTarget",
		desc = "转向目标",
		subparam = {
			bbTargetKey = "target_actor"
		}
	},
	{
		node = "BTNTaskRangeAttack",
		desc = "远程攻击",
		param = {
			bbkey_attackobj = "bbkey_attackobj",
			count = 1,
			power = 0.5,
			bufferId = 1,
			max_attack_time = 5,
			min_attack_time = 1
		}
	},
	{
		script = "BTTask_GetBagData",
		desc = "获得背包数据",
		subparam = {
			bbFirstItemId = "first_id",
			typeId = 1
		}
	},
	{
		script = "BTTask_getOwnerInfo",
		desc = "主人信息获取",
		subparam = {
			bbKey_ownerID = "",
			bbKey_ownerPos = "",
			bbKey_ownerRevive = ""
		}
	},
	{
		script = "BTTask_EquipWeapon",
		desc = "把背包道具拿到手上",
		subparam = {
			bbEquipItemId = 200,
			bbEquipItemNum = 1
		}
	},
	{
		script = "BTTask_EquipWeaponEx",
		desc = "道具拿到手上, 不需要背包拥有该道具",
		subparam = {
			bbEquipItemId = 200,
			bbEquipItemNum = 1
		}
	},
	{
		script = "BTTask_PutHandItemInBags",
		desc = "把手持道具放回背包"
	},
	{
		script = "BTTask_FindDropByList",
		desc = "搜寻范围内列表里的掉落物的位置",
		subparam = {
			bbTargetIdKey = "find_drop_targetid",
			listsKey = "foodsList",
			bbPosKey = "find_drop_pos"
		}
	},
	{
		script = "BTTask_storeItemByList",
		desc = "把列表里的物品往箱子里存放",
		subparam = {
			storeMode = 1,
			customList = {}
		}
	},
	{
		script = "BTTask_FindWorkTarget",
		desc = "寻找获取有合成需求的村民",
		subparam = {
			bbkey_targetId = "Attr_Target",
			bbkey_needNum = "need_num",
			bbkey_needType = "need_type"
		}
	},
	{
		script = "BTTask_UnbindWorkTarget",
		desc = "解除需求绑定,重置需求数据",
		subparam = {
			bbkey_targetId = "Attr_Target",
			bbkey_needType = "need_type"
		}
	},
	{
		script = "BTTask_FindItemFromBox",
		subparam = {
			findPositionType = 100,
			range = 32,
			findItemType = AI_FIND_CUSTOM,
			findCustomItems = {}
		}
	},
	{
		script = "BTTask_FindBlock",
		subparam = {
			findPositionType = 100,
			rangeY = 20,
			range = 32,
			findBlockType = AI_FIND_CUSTOM,
			findCustomBlocks = {}
		}
	},
	{
		script = "BTTask_GetItemFromBody",
		subparam = {
			getMode = AI_FINDPOSITION_HAND_BAG,
			itemType = AI_FIND_CUSTOM,
			itemCustomDatas = {}
		}
	},
	{
		script = "BTTask_CraftingItemCompound",
		subparam = {
			compoundMode = 1
		}
	},
	{
		script = "BTTask_CraftingItemSplit",
		subparam = {}
	},
	{
		script = "BTTask_CraftingItemNext",
		subparam = {}
	},
	{
		script = "BTTask_FindEmptyStoreByType",
		desc = "寻找某个寻范围内空箱子的位置",
		subparam = {
			type = 1,
			bbCenterpos = "centerpos",
			bbTargetpos = "targetpos",
			range = 8
		}
	},
	{
		script = "BTTask_isReachTime",
		desc = "是否在某个时间段内",
		subparam = {
			timeType = 0
		}
	},
	{
		script = "BTTask_transformItem",
		desc = "转换手上道具，背包中检测道具，若满足转换列表，自动转换成目标道具",
		subparam = {
			srcItemId = 12500,
			srcItemNum = 1
		}
	},
	{
		script = "BTTask_getRoundPlaying",
		desc = "寻找周边的玩家是否演奏",
		subparam = {
			bb_roundPlayer = 0
		}
	},
	{
		script = "BTTask_HaveBagContainer",
		desc = "根据背包是否有物品来判断是否进行储存"
	},
	{
		script = "BTTask_DesertVillgerEscape",
		subparam = {
			escapePos = "位置",
			targetPos = "逃跑",
			escapeId = "攻击者的id",
			range = ""
		}
	},
	{
		script = "BTTask_DesertVillgerGossip",
		subparam = {
			gossiptype = ""
		}
	},
	{
		script = "BTTask_DesertVillgerSing",
		subparam = {}
	},
	{
		script = "BTTask_LoockAtPlayer",
		subparam = {
			searchRange = "绑定对象搜寻玩家范围",
			actorwaittime = "看向某个玩家每次刷新时间"
		}
	},
	{
		script = "BTTask_getDesertVillagePos",
		desc = "获取沙漠村庄位置",
		subparam = {
			bb_desertvillagepos = "desertvillagepos"
		}
	},
	{
		script = "BTTask_getSleepState",
		desc = "获取睡觉状态"
	},
	{
		script = "BTTask_isDayTime",
		desc = "9-19工作时间"
	},
	{
		script = "BTTask_notDayTime",
		desc = "19-9睡觉时间",
		subparam = {}
	},
	{
		script = "BTTask_desertJudget",
		subparam = {
			bb_stollpos = "判断该位置是不是空气方块",
			judgettype = "1-判断位置是不是空气方块，2-判断位置是不是帐篷方块"
		}
	},
	{
		script = "BTTask_commonCompare",
		desc = "比较函数",
		subparam = {
			type = "",
			extraValue = "1223",
			range = ""
		}
	},
	{
		script = "BTTask_sleepOnBed",
		desc = "睡觉",
		subparam = {
			bb_bedpos = "bedpos"
		}
	},
	{
		script = "BTTask_wakeAndbedUnOccupied",
		desc = "起床并强制解除床的占用",
		subparam = {
			bb_bedpos = "bedpos"
		}
	},
	{
		script = "BTTask_FindPlaneArea",
		desc = "在与mob一定范围内寻找一块w x h大小的平面区域, 该区域与mob所在block一样高度.所含block相同.range 为半径block数",
		subparam = {
			bb_pitch = "pitchPos",
			extraValue = {
				range = 10,
				blockid = 100,
				w = 10
			}
		}
	},
	{
		script = "BTTask_commonSitDown",
		desc = "更通用的sitDown,之前那个sitdown野人专用的,这个增加了mob类型",
		subparam = {
			bbkey_chairPos = "",
			type = "ActorDesertBusInessMan"
		}
	},
	{
		script = "BTTask_taskExplore",
		desc = "探寻任务, 去比较远的一个点，这里会把路段拆分为多个路段",
		subparam = {
			stagePos = "bb_curToPos",
			explorePos = "bb_explorePos"
		}
	},
	{
		script = "BTTask_simpleFun",
		desc = "在这里可以添加一些简单的函数, 之前的BTTask_commonSetValue专门用于野人的，不好扩展",
		subparam = {
			type = "函数名",
			extraValue = "1"
		}
	},
	{
		script = "BTTask_turnBodyByDir",
		desc = "将身体转到某个方向",
		subparam = {
			standDir = "standDir"
		}
	},
	{
		script = "BTTask_NurseryRhyme",
		desc = "唱童谣",
		subparam = {
			times = "播放到第几张图片"
		}
	},
	{
		script = "BTTask_FishingVillagePos",
		desc = "获取渔村村庄位置",
		subparam = {
			bb_fishingvillagepos = "fishingvillagepos"
		}
	},
	{
		script = "BTTask_FishingVillageGossip",
		subparam = {
			gossiptype = ""
		}
	},
	{
		script = "BTTask_FishingVillageWorkTime",
		desc = "8-16男渔民工作时间",
		subparam = {}
	},
	{
		script = "BTTask_FishingVillageWomenWorkTime",
		desc = "10-16女渔民工作时间",
		subparam = {}
	},
	{
		script = "BTTask_FishingVillageSleepTime",
		desc = "19-3渔民睡觉时间",
		subparam = {}
	},
	{
		script = "BTTask_FishingVillageOtherTime",
		desc = "3-8,16-19渔民其他时间",
		subparam = {}
	},
	{
		script = "BTTask_findRainbow",
		desc = "遇见彩虹"
	},
	{
		script = "BTTask_findTempestWeatherOfPos",
		desc = "该位置是否暴风雨",
		subparam = {
			centerPos = "centerPos"
		}
	},
	{
		script = "BTTask_isInTempestWeather",
		desc = "是否处于暴风雨"
	},
	{
		script = "BTTask_FishingSuccess",
		desc = "钓鱼是否成功",
		subparam = {
			bb_fishId = "fishId",
			probability = "probability"
		}
	},
	{
		script = "BTTask_HaveBagContainerEx",
		desc = "根据背包有物品数量超过来判断是否进行储存",
		subparam = {
			objId = 0,
			itemCount = "itemCount",
			itemId = "itemId",
			workType = 0
		}
	},
	{
		script = "BTTask_FindEatFishOfSeagulls",
		desc = "查找周边在吃鱼的海鸥",
		subparam = {
			mobId = "itemId",
			searchRange = "searchRange",
			bbkey_evictedobj = "bbkey_evictedobj"
		}
	},
	{
		script = "BTTask_getFishStateByBlockFishFrame",
		desc = "晒鱼架方块有什么类型，空位-鲜鱼-咸鱼",
		subparam = {
			targettype = 0
		}
	},
	{
		script = "BTTask_getAllSaltFishPutInBags",
		desc = "收取鱼架方块所有咸鱼 放进背包",
		subparam = {
			bb_fishId = "fishId"
		}
	},
	{
		script = "BTTask_sunFishTakeInBags",
		desc = "从背包取出鲜鱼晒在鱼架",
		subparam = {}
	},
	{
		script = "BTTask_getFollowTick",
		desc = "tick倒计时"
	},
	{
		script = "BTTask_SpwanActor",
		desc = "创建生物",
		subparam = {
			monsterid = "monsterid",
			dist = 1
		}
	},
	{
		script = "BTTask_sleepOnAndBindBedEx",
		desc = "渔村村民睡觉绑定床",
		subparam = {
			bb_bedpos = "bedpos"
		}
	},
	{
		script = "BTTask_RemoveActor",
		desc = "移除生物",
		subparam = {
			bbkey_attackobj = "bbkey_attackobj"
		}
	},
	{
		script = "BTTask_DigBlockCoconut",
		desc = "敲方块",
		subparam = {
			blockid = 0
		}
	},
	{
		script = "BTTask_removeItem",
		desc = "移除手上道具",
		subparam = {
			bbEquipItemId = 200,
			bbEquipItemNum = 1
		}
	},
	{
		script = "BTTask_EvictedActor",
		desc = "驱赶生物",
		subparam = {
			bbkey_evictedobj = "bbkey_evictedobj"
		}
	},
	{
		script = "BTTask_FishingVillageStopWorking"
	},
	{
		script = "BTTask_isAttachedToUI",
		desc = "是否处于交易状态"
	},
	{
		script = "BTTask_faceWorldPos",
		desc = "",
		subparam = {}
	},
	{
		script = "BTTask_speedRatio",
		desc = "移动速度的比例"
	},
	{
		script = "BTTask_architectBluePrint",
		desc = "蓝图"
	},
	{
		script = "BTTask_setArchitectState"
	},
	{
		script = "BTTask_checkBluePrint"
	},
	{
		script = "BTTask_getArchitectInfo"
	},
	{
		script = "BTTask_tryGetJumpPos"
	},
	{
		script = "BTTask_checkBeHurt",
		desc = "是否被伤害",
		subparam = {
			bbkey_targetpos = "bbKeyEscapeTargetPos",
			range = 10
		}
	},
	{
		script = "BTTask_travelingTraderLeave",
		desc = "游商离开",
		subparam = {
			maxWait = 5,
			leaveDistance = 40,
			bbkey_inhome = "bbkey_inHome"
		}
	},
	{
		script = "BTTask_travelingTraderHunger",
		desc = "游商饥饿"
	},
	{
		script = "BTTask_travelingTraderCheckBed",
		desc = "游商检查绑定床信息",
		subparam = {
			bb_bedpos = "bedpos"
		}
	},
	{
		script = "BTTask_moveTo",
		desc = "寻路到位置",
		subparam = {
			speed = 1,
			limit = 50,
			enforceWait = 10,
			bbkey_targetpos = "xxx",
			distance = 0
		}
	}
}
