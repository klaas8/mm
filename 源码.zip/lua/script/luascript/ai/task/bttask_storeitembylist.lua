local StoreMode = {
	Def_CutterDrops = 4,
	Def_FamerDrops = 3,
	Def_Drops = 2,
	AllItems = 1,
	CustomItems = 100
}

return {
	subparam = {
		storeMode = StoreMode.AllItems,
		customList = {}
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local boxpos = controller.bb.get(controller.subparam.in_TargetPos)

		if not boxpos then
			return controller.fail()
		end

		local posX = boxpos.x
		local posY = boxpos.y
		local posZ = boxpos.z

		if not posX or not posY or not posY then
			return controller.fail()
		end

		local storeMode = controller.bb.get(controller.subparam.storeMode)

		if not storeMode then
			return controller.fail()
		end

		if storeMode == StoreMode.AllItems then
			local ok = AIFunctionMgr:StoreAllItem(obj, posX, posY, posZ)

			if ok then
				return controller.success()
			else
				return controller.fail()
			end
		end

		local storeList = nil

		if storeMode == StoreMode.Def_Drops then
			storeList = AIFunctionDefsGetDefByKey("toolsList")
		elseif storeMode == StoreMode.Def_FamerDrops then
			storeList = AIFunctionDefsGetDefByKey("famerToolsList")
		elseif storeMode == StoreMode.Def_CutterDrops then
			storeList = AIFunctionDefsGetDefByKey("cutterToolsList")
		elseif storeMode == StoreMode.CustomItems then
			storeList = controller.bb.get(controller.subparam.customList)
		end

		if not storeList or not next(storeList) then
			return controller.fail()
		end

		local ok = false

		for _, itemid in ipairs(storeList) do
			local num = AIFunctionMgr:getItemCountByBags(obj, itemid)

			if num > 0 then
				local ok = AIFunctionMgr:StoreItem(obj, posX, posY, posZ, itemid, num, "")

				if not ok then
					return controller.fail()
				end

				controller.wait()
			end
		end

		return controller.success()
	end
}
