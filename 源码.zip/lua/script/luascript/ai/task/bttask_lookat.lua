return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targtid = 0
		local needSearchPlayer = controller.subparam.needSearchPlayer

		if needSearchPlayer == nil then
			needSearchPlayer = true
		end

		if needSearchPlayer then
			targtid = AIFunctionMgr:findNearPlayer(obj, controller.subparam.searchRange * 100)
		end

		if targtid > 0 then
			AIFunctionMgr:keepLookAt(obj, targtid)
			controller.wait(controller.subparam.actorwaittime)
			AIFunctionMgr:stopLookAt(obj)
			controller.wait(1)
		else
			local X = math.cos(math.random(180)) * 100
			local Z = math.sin(math.random(180)) * 100

			AIFunctionMgr:keepLookAt(obj, X, Z)
			controller.wait(math.random(controller.subparam.waittimemin, controller.subparam.waittimemax))
			AIFunctionMgr:stopLookAt(obj)
			controller.wait(1)
		end

		return controller.success()
	end
}
