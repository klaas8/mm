return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local blockpos = controller.bb.get(controller.subparam.blockpos)
		local ret, fish1, fish2, fish3 = AIFunctionMgr:getAllSaltFish(obj, blockpos.x, blockpos.y, blockpos.z, 0, 0, 0)
		local itemtab = {
			fish1,
			fish2,
			fish3
		}

		if ret > 0 then
			for index, value in ipairs(itemtab) do
				if value > 0 then
					AIFunctionMgr:addItemToBags(obj, value, 1)
					controller.bb.set(controller.subparam.bb_fishId, value)
				end
			end

			return controller.success()
		else
			return controller.fail()
		end
	end
}
