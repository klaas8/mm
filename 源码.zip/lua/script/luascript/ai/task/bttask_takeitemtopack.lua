local TakeItemMode = {
	Total = 2,
	New = 1
}

return {
	subparam = {
		bbkey_one_takenum = 1,
		takeitemmode = TakeItemMode.New
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local takeitemmode = controller.bb.get(controller.subparam.takeitemmode) or TakeItemMode.New
		local boxpos = controller.bb.get(controller.subparam.bbkey_in_boxpos)

		if not boxpos then
			return controller.fail()
		end

		local takeid = controller.bb.get(controller.subparam.bbkey_one_takeid)
		local takecount = controller.bb.get(controller.subparam.bbkey_one_takenum) or 1
		local iteminfos = controller.bb.get(controller.subparam.bbkey_multi_iteminfos)

		if not iteminfos then
			if not takeid then
				return controller.fail()
			end

			iteminfos = {
				itemid = takeid,
				num = takecount
			}
		end

		if not iteminfos[1] then
			iteminfos = {
				iteminfos
			}
		end

		local datas = {}

		for _, v in ipairs(iteminfos) do
			local itemid = v.itemid
			local num = v.num
			local isgroup = v.isgroup
			local data = datas[itemid] or {}

			if isgroup then
				data[1] = data[1] and data[1] + num or num
			else
				data[2] = data[2] and data[2] + num or num
			end

			datas[itemid] = data
		end

		local getnum = 0

		if takeitemmode == TakeItemMode.New then
			for itemid, data in pairs(datas) do
				local groupnum = data[1]
				local selfnum = data[2]

				if selfnum then
					getnum = getnum + AIFunctionMgr:TakeItem(obj, boxpos.x, boxpos.y, boxpos.z, itemid, selfnum, "", false)
				end

				if groupnum then
					getnum = getnum + AIFunctionMgr:TakeItem(obj, boxpos.x, boxpos.y, boxpos.z, itemid, groupnum, "", true)
				end
			end
		elseif takeitemmode == TakeItemMode.Total then
			for itemid, data in pairs(datas) do
				local groupnum = data[1]
				local selfnum = data[2]
				local curnum = AIFunctionMgr:getItemCountByBags(obj, itemid, false)
				local curgroup = AIFunctionMgr:getItemCountByBags(obj, itemid, true)

				if selfnum then
					curgroup = selfnum < curgroup and curgroup - selfnum or 0
				end

				if selfnum and curnum < selfnum then
					getnum = getnum + AIFunctionMgr:TakeItem(obj, boxpos.x, boxpos.y, boxpos.z, itemid, selfnum - curnum, "", false)
				end

				if groupnum and curgroup < groupnum then
					getnum = getnum + AIFunctionMgr:TakeItem(obj, boxpos.x, boxpos.y, boxpos.z, itemid, groupnum - curgroup, "", true)
				end
			end
		end

		if getnum == 0 then
			return controller.fail()
		end

		return controller.success()
	end
}
