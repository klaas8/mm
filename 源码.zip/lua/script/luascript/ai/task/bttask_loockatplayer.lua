return {
	onbeg = function ()
	end,
	onend = function ()
		local obj = controller.target.get()

		AIFunctionMgr:stopLookAt(obj)
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targtid = AIFunctionMgr:findNearPlayer(obj, controller.subparam.searchRange * 100)
		local randomNumber = math.random(1, 10)
		local times = controller.bb.get("times")
		local id = obj:getDefID()

		if targtid > 0 and randomNumber <= 3 and times == 0 then
			AIFunctionMgr:keepLookAt(obj, targtid)
			AIFunctionMgr:playAnimBySeqId(obj, 100140)
			AIFunctionMgr:playSound(obj, "ent." .. id .. ".idle1", 1, 1, 2)
		else
			local X = math.cos(math.random(180)) * 100
			local Z = math.sin(math.random(180)) * 100

			AIFunctionMgr:playSound(obj, "", 0, 0, 0)
			AIFunctionMgr:keepLookAt(obj, X, Z)
		end

		controller.wait(1)

		return controller.success()
	end
}
