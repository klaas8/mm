return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local pos = {
			x = 0,
			y = 0,
			z = 0
		}
		pos.x, pos.y, pos.z = AIFunctionMgr:getDesertVillagePoint(obj, pos.x, pos.y, pos.z)

		controller.bb.set(controller.subparam.bb_desertvillagepos, pos)

		return controller.success()
	end
}
