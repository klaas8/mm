return {
	{
		node = "BTNodeSequence",
		desc = "顺序节点(常用)，子节点依次执行，直到某一个子节点返回失败时，返回失败，或者全部子节点返回成功时，返回成功",
		children = {}
	},
	{
		node = "BTNodeSelector",
		desc = "选择节点(常用)，子节点依次执行，直到某一个子节点返回成功时，返回成功，或者全部子节点返回失败时，返回失败",
		children = {}
	},
	{
		node = "BTNodeCondition",
		desc = "条件节点(慎用)，有且仅有两个子节点，第一个节点运行，若成功，则运行第二个节点，完成后返回成功；若失败，立即返回失败",
		children = {}
	},
	{
		node = "BTNodeBranch",
		desc = "分支节点(少用)，有且仅有三个子节点，第一个节点运行，若成功，则运行第二个节点；若失败，则运行第三个节点",
		children = {}
	},
	{
		node = "BTNodeSimpleParallel",
		desc = "简单平行节点，有且仅有两个子节点，并列同时执行。第一个节点为主节点，第二个节点为副节点，主节点决定返回值",
		param = {
			loop = false
		},
		children = {}
	},
	{
		node = "BTNodeRandom",
		desc = "随机节点，可配置每个叶子节点的权重，默认的默认权重为100(可修改)",
		param = {
			defWeight = 120,
			weight = {
				1,
				20,
				100
			}
		},
		children = {
			{},
			{},
			{},
			{},
			{},
			{}
		}
	},
	{
		node = "BTNodeSuccess",
		desc = "成功节点，有且仅有一个子节点，子节点执行完成(返回成功或者失败)后，返回成功",
		children = {}
	},
	{
		node = "BTNodeFail",
		desc = "失败节点，有且仅有一个子节点，子节点执行完成(返回成功或者失败)后，返回失败",
		children = {}
	},
	{
		node = "BTNodeInversion",
		desc = "反转节点，有且仅有一个子节点，子节点执行完成(返回成功或者失败)后，对返回值取反后返回(成功返回失败，失败返回成功)",
		children = {}
	},
	{
		node = "BTNodeLoop",
		desc = "循环节点，有且仅有一个子节点，子节点执行n次(由参数决定，默认无限次)，子节点执行失败时，返回失败，或者子节点执行完n次后，返回成功",
		param = {
			loop = 12
		},
		children = {}
	},
	{
		node = "BTNodeWait",
		desc = "等待节点，叶子节点，等待n秒(由参数决定，默认一个tick)后，返回成功",
		param = {
			wait = 1.2
		}
	},
	{
		node = "BTNodeReset",
		desc = "重置节点，叶子节点，会重置行为树执行状态，从根节点开始执行"
	},
	{
		node = "BTNodeTaskLua",
		desc = "lua叶子节点，",
		param = {
			script = "BTTask_xxxxxx",
			subparam = {}
		}
	}
}
