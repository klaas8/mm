return {
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local selfTrader = tolua.cast(selfActor, "ActorTravelingTrader")

		if not selfTrader then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local bedPos = controller.bb.get(controller.subparam.bb_bedpos)
		local selfTrader = tolua.cast(selfActor, "ActorTravelingTrader")

		if bedPos and selfTrader:IsBindedBed(bedPos.x, bedPos.y, bedPos.z) then
			return controller.success()
		else
			selfTrader:ResetHousingLv()

			return controller.fail()
		end
	end,
	onend = function ()
	end
}
