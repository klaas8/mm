return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemId = controller.bb.get(controller.subparam.bbEquipItemId)
		local itemNum = controller.bb.get(controller.subparam.bbEquipItemNum)

		AIFunctionMgr:addItemToBags(obj, itemId, itemNum)
		AIFunctionMgr:equipWeapon(obj, itemId, itemNum)

		return controller.success()
	end
}
