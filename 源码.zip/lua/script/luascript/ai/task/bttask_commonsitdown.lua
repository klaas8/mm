return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local type = controller.subparam.type

		if not type then
			return controller.fail()
		end

		local obj = controller.target.get()
		local pos = controller.bb.get(controller.subparam.bbkey_chairPos)
		local result = 0

		if controller.subparam.extraValue == nil then
			controller.subparam.extraValue = true
		end

		if pos then
			result = AIFunctionMgr:commonSitDown(obj, pos.x, pos.y, pos.z)
		else
			result = AIFunctionMgr:commonSitDown(obj, type, controller.subparam.extraValue)
		end

		if result == 0 then
			return controller.fail()
		end

		return controller.success()
	end
}
