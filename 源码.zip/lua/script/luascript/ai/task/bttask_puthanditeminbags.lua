return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemId = AIFunctionMgr:GetHoldItemId(obj)

		if itemId and itemId > 0 then
			local num = AIFunctionMgr:GetEmptyGridCount(obj)

			if num and num > 0 then
				AIFunctionMgr:putHandItemInBags(obj)

				return controller.success()
			end
		end

		return controller.success()
	end
}
