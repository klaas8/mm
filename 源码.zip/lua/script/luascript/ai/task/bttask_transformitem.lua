return {
	run = function ()
		local obj = controller.target.get()
		local itemid = controller.bb.get(controller.subparam.srcItemId) or 0
		local itemnum = controller.bb.get(controller.subparam.srcItemNum) or 0
		local transList = AIFunctionDefsGetDefByKey("itemTransformList") or {}
		local dstItemid = transList[itemid]

		if not dstItemid then
			return controller.fail()
		end

		local mobAttr = obj:getMobAttrib()
		local grid = mobAttr and mobAttr:findItem(itemid)

		if not grid then
			return controller.fail()
		end

		grid:setItem(dstItemid, itemnum)

		return controller.success()
	end
}
