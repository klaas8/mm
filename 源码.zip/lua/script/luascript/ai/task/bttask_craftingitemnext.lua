return {
	subparam = {},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local targetItems = controller.bb.get(controller.subparam.bbkey_targetItems)

		if not targetItems or not next(targetItems) then
			return controller.fail()
		end

		local firstitem = targetItems[1]

		table.remove(targetItems, 1)

		local itemid = firstitem.itemid
		local num = firstitem.num or 1

		if not itemid then
			return controller.fail()
		end

		local ok1 = controller.bb.set(controller.subparam.bbkey_out_first, itemid)
		local ok2 = controller.bb.set(controller.subparam.bbkey_targetItems, targetItems)

		if ok1 and ok2 then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
