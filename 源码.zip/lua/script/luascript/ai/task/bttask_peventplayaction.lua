local needCleanUpData = {}

return {
	onbeg = function ()
	end,
	onend = function ()
		if needCleanUpData.obj then
			if needCleanUpData.effectName then
				AIFunctionMgr:stopEffect(needCleanUpData.obj, needCleanUpData.effectName)
			end

			if needCleanUpData.faceId then
				AIFunctionMgr:setFaceId(needCleanUpData.obj, 1)
			end

			if needCleanUpData.playtype and needCleanUpData.playtype > 1000 then
				AIFunctionMgr:clearFlagBit(needCleanUpData.obj)
			end
		end

		needCleanUpData.obj = nil
		needCleanUpData.effectName = nil
		needCleanUpData.faceId = nil
		needCleanUpData.playtype = nil
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local isPlay = true
		local flag = controller.subparam.flag
		local playtype = controller.bb.get(controller.subparam.type)
		local flag2 = controller.subparam.flag2
		local probability = 30
		local obj = controller.target.get()

		if flag then
			local judgeTypeEnum = AIFunctionDefsGetDefByKey("judgeType")
			local judgeType = {
				judgeTypeEnum.huggerStatus,
				judgeTypeEnum.fatigueStatus,
				judgeTypeEnum.fatigueStatus
			}
			local Value = 1

			if judgeType[playtype] == judgeTypeEnum.huggerStatus then
				Value = AIFunctionMgr:getHuggerStatus(obj)
			elseif judgeType[playtype] == judgeTypeEnum.fatigueStatus then
				Value = AIFunctionMgr:GetFatigue(obj)
			end

			if Value > 1 then
				probability = 30 + 10 * (Value - 1)
			end

			local isStay = AIFunctionMgr:isStayingUp(obj)

			if playtype > 1 and isStay and probability < 80 then
				probability = 80
			end

			if probability > 100 then
				probability = 100
			end

			if probability < 100 then
				math.randomseed(os.time())

				local rnd = math.random(100)

				if probability < rnd then
					isPlay = false
				end
			end
		end

		if flag2 then
			local rnd = math.random(1, 100)

			if rnd > 50 then
				isPlay = false
			end
		end

		if isPlay then
			local bGetConfOk = true
			local config = AIFunctionDefsGetDefByKey("interactActionDef")

			if not config or not config[playtype] then
				bGetConfOk = false
			end

			if bGetConfOk then
				local animID = config[playtype].animID
				local effectName = config[playtype].effectName
				local soundName = config[playtype].soundName
				local faceId = config[playtype].faceId
				local bComposeSound = config[playtype].bComposeSound
				local duration = controller.subparam.duration
				needCleanUpData.playtype = playtype
				needCleanUpData.effectName = effectName
				needCleanUpData.obj = obj
				needCleanUpData.faceId = nil

				if animID then
					AIFunctionMgr:playAnimBySeqId(obj, animID)
				end

				if effectName then
					AIFunctionMgr:playEffect(obj, effectName)

					needCleanUpData.effectName = effectName
				end

				if bComposeSound then
					if obj:getDefID() == 3239 then
						soundName = string.format("ent.%d.%s", 3234, soundName)
					elseif obj:getDefID() >= 3235 and obj:getDefID() <= 3238 then
						soundName = string.format("ent.%d.%s", 3233, soundName)
					else
						soundName = string.format("ent.%d.%s", obj:getDefID(), soundName)
					end
				end

				if soundName then
					AIFunctionMgr:playSound(obj, soundName, 1, 1, 2)
				end

				if type(faceId) == "number" and faceId > 0 then
					AIFunctionMgr:setFaceId(obj, faceId)

					needCleanUpData.faceId = faceId
				end

				if duration and duration > 0 then
					controller.wait(duration)
				end

				return controller.success()
			else
				return controller.fail()
			end
		else
			return controller.fail()
		end
	end
}
