return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local blockpos = controller.bb.get(controller.subparam.blockpos)
		local targettype = controller.subparam.targettype
		local ret = AIFunctionMgr:getFishStateByBlockFishFrame(obj, targettype, blockpos.x, blockpos.y, blockpos.z)

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
