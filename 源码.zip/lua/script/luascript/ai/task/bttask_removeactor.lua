return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local objid = controller.bb.get(controller.subparam.bbkey_attackobj).actor

		AIFunctionMgr:removeActor(obj, objid)

		return controller.success()
	end
}
