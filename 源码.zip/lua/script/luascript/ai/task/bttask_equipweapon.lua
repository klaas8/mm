return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemId = controller.bb.get(controller.subparam.bbEquipItemId)
		local itemNum = controller.bb.get(controller.subparam.bbEquipItemNum)
		local num = AIFunctionMgr:getItemCountByBags(obj, itemId)

		if num and num > 0 then
			if not itemNum or itemNum == 0 then
				itemNum = num
			end

			AIFunctionMgr:equipWeapon(obj, itemId, itemNum)

			return controller.success()
		end

		return controller.fail()
	end
}
