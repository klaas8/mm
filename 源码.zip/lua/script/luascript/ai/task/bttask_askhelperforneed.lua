return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local needNum = controller.bb.get(controller.subparam.needNum) or 1
		local needType = controller.bb.get(controller.subparam.needType)
		local obj = controller.target.get()
		local hasHelp = AIFunctionMgr:IsVillagerHasHelper(obj)

		if hasHelp then
			return controller.success()
		end

		if AIFunctionMgr:AskForVillageHelper(obj, needType, needNum) then
			return controller.success()
		end

		return controller.fail()
	end
}
