local config = {}

function config.actorInView(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	local actorId = controller.bb.get(controller.subparam.extraValue).actor
	local range = controller.subparam.range
	range = range or mob:getViewDist() / 100

	local function isInRange(selfPos, centerPos, range)
		if selfPos.x == 0 and selfPos.y == 0 and selfPos.z == 0 then
			return false
		end

		if centerPos.x == 0 and centerPos.y == 0 and centerPos.z == 0 then
			return false
		end

		if range == 0 then
			return false
		end

		local minX = centerPos.x - range
		local maxX = centerPos.x + range
		local minY = centerPos.y - range
		local maxY = centerPos.y + range
		local minZ = centerPos.z - range
		local maxZ = centerPos.z + range

		if minX <= selfPos.x and selfPos.x <= maxX and minY <= selfPos.y and selfPos.y <= maxY and minZ <= selfPos.z and selfPos.z <= maxZ then
			return true
		else
			return false
		end
	end

	local actor = mob:getActorMgr():findActorByWID(actorId)

	if not actor then
		return false
	end

	if actor:isDead() then
		return false
	end

	local selfPos = actor:getPosition()
	local centerPos = mob:getPosition()
	local mobPos = {}
	local actorPos = {}
	mobPos.x, mobPos.y, mobPos.z = CoordDivBlock(selfPos.x, selfPos.y, selfPos.z)
	actorPos.x, actorPos.y, actorPos.z = CoordDivBlock(centerPos.x, centerPos.y, centerPos.z)

	return isInRange(mobPos, actorPos, range)
end

function config.actorIsExist(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	local objId = controller.bb.get(controller.subparam.extraValue).actor

	if objId <= 0 then
		return false
	end

	return mob:getActorMgr():findActorByWID(objId)
end

function config.actorIsInvalid(mob, extraValue, controller)
	if not mob or not extraValue then
		return false
	end

	local objId = controller.bb.get(controller.subparam.extraValue).actor

	if objId <= 0 then
		return false
	end

	return true
end

function config.isSleeping(mob)
	if not mob then
		return false
	end

	return mob:isSleeping()
end

function config.hourCompare(mob, extraValue)
	if ClientCurGame and ClientCurGame:isInGame() and CurWorld then
		local hours = CurWorld:getHours()

		return hours < extraValue.max and extraValue.min <= hours
	end

	return false
end

function config.isUsablePos(mob, extraValue, controller)
	if not mob then
		return false
	end

	local pos = controller.bb.get(controller.subparam.bb_pos)

	if not pos then
		return false
	end

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	local range = controller.subparam.range
	range = range or 8
	local x, y, z = nil
	local mobPos = mob:getPosition()
	x, y, z = CoordDivBlock(mobPos.x, mobPos.y, mobPos.z)
	x = pos.x - x
	y = pos.y - y
	z = pos.z - z

	if x * x + y * y + z * z > range * range then
		return false
	end

	return AIFunctionMgr:CheckPosCanUsed(mob, pos.x, pos.y, pos.z)
end

function config.isUsablePosCheckBlock(mob, extraValue, controller)
	if not mob then
		return false
	end

	local pos = controller.bb.get(controller.subparam.bb_pos)

	if not pos then
		return false
	end

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	local topHeight = CurWorld:getTopHeight(pos.x, pos.z)
	local blockid = CurWorld:getBlockID(pos.x, pos.y, pos.z)
	local heightBlock = CurWorld:getBlockID(pos.x, topHeight, pos.z)

	if blockid == 0 and heightBlock ~= 3 and heightBlock ~= 4 then
		return true
	end
end

function config.isUsableCenterPos(mob, extraValue, controller)
	if not mob then
		return false
	end

	local pos = controller.bb.get(controller.subparam.centerPos)

	if not pos then
		return false
	end

	if pos.x == 0 and pos.y == 0 and pos.z == 0 then
		return false
	end

	return true
end

function config.isSitting(mob)
	if not mob then
		return false
	end

	return mob:getSitting()
end

function config.isOnGround(mob)
	if not mob then
		return false
	end

	return mob:getLocoMotion():onGround()
end

function config.isToOasis(mob)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob or not mob.isToOasis then
		return false
	end

	return mob:isToOasis()
end

function config.isToVillage(mob)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob or not mob.isToVillage then
		return false
	end

	return mob:isToVillage()
end

function config.isToEnd(mob)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	return mob:isToEnd()
end

function config.isFollow(mob)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	return mob:isFollow()
end

function config.isUableBedPos(mob, extraValue, controller)
	if not extraValue then
		return false
	end

	local bedPos = controller.bb.get(extraValue)

	if bedPos.x == 0 and bedPos.y == 0 and bedPos.z == 0 then
		return false
	end

	local id = CurWorld:getBlockID(bedPos.x, bedPos.y, bedPos.z)

	if id ~= 484 then
		return false
	end

	return true
end

function config.isUsableActor(mob, extravalue, controller)
	local id = controller.bb.get(controller.subparam.extraValue)

	if id and id > 0 then
		return true
	end

	return false
end

function config.isPosOutRange(mob, extraValue, controller)
	if not mob then
		return false
	end

	local mobPos = mob:getPosition()
	local x, y, z = nil
	x, y, z = CoordDivBlock(mobPos.x, mobPos.y, mobPos.z)

	if x == 0 and y == 0 and z == 0 then
		return false
	end

	local comparePos = controller.bb.get(extraValue.comparePos)
	local range = extraValue.range
	local diffx = x - comparePos.x
	local diffz = z - comparePos.z

	if diffx * diffx + diffz * diffz > range * range then
		return true
	end

	return false
end

function config.isStandGuard(mob, extraValue, controller)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	return mob:needStandGuard()
end

function config.isNeedFollowTrade(mob)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	return mob:needFollow()
end

function config.isAvoidingStand(mob, extraValue)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	return mob:isAvoidIngStand()
end

function config.isInStandStorm(mob, extraValue)
	if not mob or not extraValue then
		return false
	end

	mob = tolua.cast(mob, extraValue)

	if not mob then
		return false
	end

	if mob.isLeader and mob:isLeader() then
		local pos = mob:getPosition()

		if CurWorld:getWeatherMgr():getSandDuststormPower(pos) ~= 0 then
			mob:informFollowManAvoidStand(true)

			return true
		else
			mob:informFollowManAvoidStand(false)

			return false
		end
	else
		return mob:needAvoidStand()
	end
end

function config.haveSaleCamel(mob, extraValue)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	return mob:getDealCamel() > 0
end

function config.isWarning(mob, extraValue)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	return mob:getWarningType() == 1
end

function config.isAttacking(mob, extraValue)
	mob = tolua.cast(mob, "ActorDesertBusInessMan")

	if not mob then
		return false
	end

	return mob:getWarningType() == 2
end

function config.guardIsExplore(mob, extraValue)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	return mob:isExplore()
end

function config.isNightGuard(mob)
	mob = tolua.cast(mob, "ActorDesertBusInessManGuard")

	if not mob then
		return false
	end

	return mob:isNightGuard()
end

function config.playerIsDead(mob, extraValue, controller)
	if not mob then
		return false
	end

	local uin = controller.bb.get(extraValue).actor
	local player = WorldMgr:GetPlayerByUin(uin)

	if not player then
		return false
	end

	return player:isDead()
end

function config.BBCompareValue(mob, extraValue, controller)
	if not mob then
		return false
	end

	return controller.bb.get(extraValue[1]) == extraValue[2]
end

return {
	subparam = {
		type = ""
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get("mob")
		local type = controller.subparam.type
		local flag = controller.subparam.reversal
		local result = false

		if config[type] then
			result = config[type](obj, controller.subparam.extraValue, controller)
		end

		if not flag and result then
			return controller.success()
		elseif flag and not result then
			return controller.success()
		end

		return controller.fail()
	end
}
