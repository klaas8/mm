return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()

		AIFunctionMgr:wakeUp(obj, "")

		local pos = controller.bb.get(controller.subparam.bb_bedpos)

		AIFunctionMgr:ClearBedOccupied(obj, pos.x, pos.y, pos.z)

		return controller.success()
	end
}
