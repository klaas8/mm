return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		print("!!! BTTask_sleepOnAndBindBed hotfix [for test] !!!")

		local obj = controller.target.get()
		local bedpos = controller.bb.get(controller.subparam.bb_bedpos)

		if not bedpos then
			return controller.fail()
		end

		local ret = AIFunctionMgr:sleepInBed(obj, bedpos.x, bedpos.y, bedpos.z, "")

		if ret == 0 then
			AIFunctionMgr:setBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
			controller.wait(1)

			return controller.success()
		end

		return controller.fail()
	end
}
