return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		return controller.fail()
	end
}
