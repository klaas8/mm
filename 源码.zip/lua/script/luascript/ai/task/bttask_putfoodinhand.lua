return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local curNum = AIFunctionMgr:GetOwnedFoodCount(obj)

		if curNum == 0 then
			return controller.fail()
		end

		local itemId = AIFunctionMgr:findFoodByBags(obj)

		if itemId == 0 then
			return controller.fail()
		end

		AIFunctionMgr:equipWeapon(obj, itemId, 1)

		return controller.success()
	end
}
