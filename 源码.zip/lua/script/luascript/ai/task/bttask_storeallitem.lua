return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targetPos = controller.bb.get(controller.subparam.bbkey_targetpos)
		local flag = AIFunctionMgr:StoreAllItem(obj, targetPos.x, targetPos.y, targetPos.z)

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
