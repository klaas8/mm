return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()

		AIFunctionMgr:RemoveHelperRelationship(obj)

		if controller.subparam.bbkey_targetId then
			controller.bb.set(controller.subparam.bbkey_targetId, {
				actor = 0
			})
		end

		if controller.subparam.bbkey_needType then
			controller.bb.set(controller.subparam.bbkey_needType, 0)
		end

		return controller.success()
	end
}
