return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local pos = {
			z = 0,
			x = 0,
			y = 0
		}
		pos.x, pos.y, pos.z = AIFunctionMgr:getFishingVillagePoint(obj, pos.x, pos.y, pos.z)

		controller.bb.set(controller.subparam.bb_fishingvillagepos, pos)

		return controller.success()
	end
}
