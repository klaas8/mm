return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()

		if not obj then
			return controller.fail()
		end

		local digDist = controller.subparam.bp_dig_dist
		local pos = controller.bb.get(controller.subparam.block_pos_key)
		local blockid = controller.bb.get(controller.subparam.blockid)
		local blockdata = controller.bb.get(controller.subparam.blockdata)

		if blockid == 0 then
			return controller.fail()
		end

		local targetPos = WCoord()
		targetPos.x = pos.x * BLOCK_SIZE
		targetPos.y = pos.y * BLOCK_SIZE
		targetPos.z = pos.z * BLOCK_SIZE
		local vec = obj:getPosition() - targetPos
		local dist = vec:length()

		if digDist < dist then
			return controller.fail()
		end

		if CurWorld:getBlockID(pos.x, pos.y, pos.z) ~= BLOCK_AIR then
			-- Nothing
		end

		CurWorld:setBlockAll(pos.x, pos.y, pos.z, blockid, blockdata)
		obj:playBlockPlaceSound(blockid, pos.x, pos.y, pos.z)

		return controller.success()
	end
}
