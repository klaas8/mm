return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local owner = AIFunctionMgr:GetOwner(obj)

		if owner then
			local x = 0
			local y = 0
			local z = 0

			if controller.subparam.bbKey_ownerPos then
				x, y, z = AIFunctionMgr:GetPlayerPos(owner, 0, 0, 0)

				controller.bb.set(controller.subparam.bbKey_ownerPos, {
					x = x,
					y = y,
					z = z
				})
			end

			if controller.subparam.bbKey_ownerID then
				controller.bb.set(controller.subparam.bbKey_ownerID, {
					actor = owner:getObjId()
				})
			end

			if controller.subparam.bbKey_ownerRevive then
				x, y, z = AIFunctionMgr:GetOwnerRevivePos(owner, 0, 0, 0)

				controller.bb.set(controller.subparam.bbKey_ownerRevive, {
					x = x,
					y = y,
					z = z
				})
			end

			return controller.success()
		end

		return controller.fail()
	end
}
