return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local bedpos = controller.bb.get(controller.subparam.bb_bedpos)

		if not bedpos then
			return controller.fail()
		end

		local ret = AIFunctionMgr:sleepInBed(obj, bedpos.x, bedpos.y, bedpos.z, "")

		if ret == 0 then
			if obj:getObjType() == OBJ_TYPE_DESERTVILLAGER then
				AIFunctionMgr:setDesertBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
			elseif obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
				AIFunctionMgr:setFishingVillageBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
			else
				AIFunctionMgr:setBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
			end

			controller.wait(1)

			return controller.success()
		end

		return controller.fail()
	end
}
