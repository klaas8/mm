return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local pos = controller.bb.get(controller.subparam.bbkey_chairPos)
		local result = 0

		if pos then
			result = AIFunctionMgr:sitDown(obj, pos.x, pos.y, pos.z)
		else
			result = AIFunctionMgr:sitDown(obj)
		end

		if result == 0 then
			return controller.fail()
		end

		return controller.success()
	end
}
