return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local followticks = controller.bb.get(controller.subparam.followtick)

		MiniLog("followticksfollowticksfollowticks=", followticks)

		if followticks <= 0 then
			local time = math.random(600, 1200)

			controller.bb.set(controller.subparam.followtick, time)

			return controller.success()
		else
			followticks = followticks - 1

			controller.bb.set(controller.subparam.followtick, followticks)

			return controller.fail()
		end
	end
}
