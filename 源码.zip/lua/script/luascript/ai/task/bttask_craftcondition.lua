return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local id = controller.bb.get(controller.subparam.bbkey_craftID)

		if id > 0 then
			return controller.success()
		end

		local objid = controller.bb.get(controller.subparam.bbkey_targetActor).actor
		local type = controller.bb.get(controller.subparam.bbkey_needtype)

		if type <= 0 then
			return controller.fail()
		end

		id = AIFunctionMgr:CraftingCondation(obj, objid, type)

		if id > 0 then
			controller.bb.set(controller.subparam.bbkey_craftID, id)
		else
			return controller.fail()
		end

		return controller.success()
	end
}
