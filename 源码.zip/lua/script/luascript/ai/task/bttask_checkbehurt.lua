return {
	will = function ()
		local obj = controller.target.get("mob")

		if not obj or not obj:alive() then
			return false
		end

		local ret = false

		if obj:getBeHurtTarget() and (obj:getBeHurtTimer() <= 0 or obj:getLiveTicks() - obj:getBeHurtTimer() <= 100) then
			controller.luabb.findObj = obj:getBeHurtTarget()
			ret = true
		elseif obj:isBurning() then
			local pos = {
				y = 0,
				z = 0,
				x = 0
			}
			pos.x, pos.y, pos.z = AIFunctionMgr:GetRandStrollPosBySelf(obj, pos.x, pos.y, pos.z, 8, 8)
			controller.luabb.findPos = pos
			ret = true
		end

		if ret and AIFunctionMgr:isSleeping(obj) then
			AIFunctionMgr:wakeUp(obj, "")
		end

		return ret
	end,
	run = function ()
		local obj = controller.target.get("mob")
		local range = controller.subparam.range
		local bbkey_targetpos = controller.subparam.bbkey_targetpos

		if controller.luabb.findObj then
			local isFind, posX, posY, posZ = AIFunctionMgr:getEscapePos(obj, controller.luabb.findObj, range, 0, 0, 0)

			if isFind then
				controller.bb.set(bbkey_targetpos, {
					x = posX,
					y = posY,
					z = posZ
				})

				return controller.success()
			else
				return controller.fail()
			end
		elseif controller.luabb.findPos then
			controller.bb.set(bbkey_targetpos, controller.luabb.findPos)

			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
		controller.luabb.findObj = nil
		controller.luabb.findPos = nil
	end
}
