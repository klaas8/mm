return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local dir = controller.bb.get(controller.subparam.standDir) or 0

		obj:getLocoMotion():setRotateYaw(dir)
		controller.wait(1)

		return controller.success()
	end
}
