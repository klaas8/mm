return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		if not controller.subparam or not controller.subparam.extraValue then
			return controller.fail()
		end

		local obj = controller.target.get()
		local x, y, z = obj:getPosition(0, 0, 0)
		local extraValue = controller.subparam.extraValue
		local w = extraValue.w
		local range = extraValue.range
		local searchId = extraValue.blockid
		local retType = controller.subparam.retType or 1
		local random = controller.subparam.random

		if random == nil then
			random = true
		end

		if not w or not range or not searchId then
			return controller.fail()
		end

		local function compareFun(id)
			for index, value in ipairs(searchId) do
				if id == value then
					return false
				end
			end

			return true
		end

		x, y, z = CoordDivBlock(x, y, z)
		local blockid, curX, curY = nil
		local left = x - range
		local top = z - range
		local have = true
		local findx = 0
		local findz = 0
		local find = false
		local topHeight = 0
		local curTopHeight = 0
		local findy = 0

		if random then
			left = left + math.random(0, range * 2)
			top = top + math.random(0, range * 2)
			have = true
			topHeight = CurWorld:getTopHeight(left, top)

			if math.abs(topHeight - y) < 3 then
				for k = left, left + w - 1 do
					for g = top, top + w - 1 do
						curTopHeight = CurWorld:getTopHeight(k, g)

						if topHeight ~= curTopHeight then
							have = false

							break
						end

						blockid = CurWorld:getBlockID(k, curTopHeight - 1, g)

						if not compareFun(blockid) then
							have = false

							break
						end

						blockid = CurWorld:getBlockID(k, curTopHeight, g)

						if blockid ~= 0 and blockid ~= 224 and blockid ~= 225 and blockid ~= 110 then
							have = false

							break
						end

						blockid = CurWorld:getBlockID(k, curTopHeight + 1, g)

						if blockid ~= 0 then
							have = false

							break
						end
					end

					if not have then
						break
					end
				end

				if have then
					findx = left
					findz = top
					findy = topHeight
					find = true
				end
			end
		else
			for i = top, z + range * 2 - 1 - w / 2 do
				for j = left, x + range * 2 - 1 - w / 2 do
					have = true
					topHeight = CurWorld:getTopHeight(j, i)

					if math.abs(topHeight - y) < 5 then
						for k = j, j + w - 1 do
							for g = i, i + w - 1 do
								curTopHeight = CurWorld:getTopHeight(k, g)

								if topHeight ~= curTopHeight then
									have = false

									break
								end

								blockid = CurWorld:getBlockID(k, curTopHeight - 1, g)

								if not compareFun(blockid) then
									have = false

									break
								end

								blockid = CurWorld:getBlockID(k, curTopHeight, g)

								if blockid ~= 0 and blockid ~= 224 and blockid ~= 225 and blockid ~= 110 then
									have = false

									break
								end

								blockid = CurWorld:getBlockID(k, curTopHeight + 1, g)

								if blockid ~= 0 then
									have = false

									break
								end
							end

							if not have then
								j = k

								break
							end
						end

						if have and AIFunctionMgr:CheckPosCanUsed(obj, j, topHeight, i) then
							findx = j
							findz = i
							findy = topHeight
							find = true

							break
						end
					end
				end

				if find then
					break
				end
			end
		end

		if find then
			if retType == 1 then
				findx = left + w / 2
				findz = top + w / 2
			elseif retType == 2 then
				-- Nothing
			end

			controller.bb.set(controller.subparam.bb_pitch, {
				x = findx,
				y = findy,
				z = findz
			})

			return controller.success()
		else
			return controller.fail()
		end

		return controller.fail()
	end
}
