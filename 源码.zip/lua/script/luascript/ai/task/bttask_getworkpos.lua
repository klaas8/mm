return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local pos = {
			y = 0,
			z = 0,
			x = 0
		}
		pos.x, pos.y, pos.z = AIFunctionMgr:getWorkBindPos(obj, pos.x, pos.y, pos.z)

		controller.bb.set(controller.subparam.bb_workpos, pos)

		return controller.success()
	end
}
