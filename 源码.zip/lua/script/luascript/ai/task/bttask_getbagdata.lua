return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local typeid = controller.subparam.typeId

		if not typeid then
			return controller.fail()
		end

		local count, idlist, countlist = AIFunctionMgr:GetItemsDataWithTypeInBag(obj, typeid, 0, "", "")

		if count and count > 0 then
			local l = utils.split(idlist, "|")
			local t = utils.split(countlist, "|")

			controller.bb.set(controller.subparam.bbFirstItemId, tonumber(l[1]))

			return controller.success()
		else
			return controller.fail()
		end
	end
}
