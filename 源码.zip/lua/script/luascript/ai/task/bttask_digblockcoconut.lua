return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local blockid = controller.bb.get(controller.subparam.blockid)
		local blockpos = controller.bb.get(controller.subparam.blockpos)

		obj:getBody():stopAllAnim()

		local ret = AIFunctionMgr:DigBlockCoconut(obj, blockid, blockpos.x, blockpos.y, blockpos.z)

		return controller.success()
	end
}
