return {
	subparam = {
		getMode = AI_FINDPOSITION_HAND_BAG,
		itemType = AI_FIND_CUSTOM,
		itemCustomDatas = {}
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local getmode = controller.bb.get(controller.subparam.getMode)
		local itemType = controller.bb.get(controller.subparam.itemType)
		local customItems = controller.bb.get(controller.subparam.itemCustomDatas)
		local param = AIFunctionMgr:Get_inFindParam()

		param:Clear()
		param:SetGetMode(getmode)
		param:SetFindType(itemType)

		if itemType == AI_FIND_CUSTOM then
			for _, iteminfo in ipairs(customItems) do
				local typeinfo = type(iteminfo)

				if typeinfo == "table" then
					local itemid = iteminfo.itemid
					local isgroup = iteminfo.isgroup

					if itemid and itemid > 0 then
						param:AddCustomItem(itemid, isgroup)
					end
				elseif typeinfo == "number" then
					param:AddCustomItem(iteminfo)
				else
					print("BT ERROR : BTTask_GetItemFromBody itemCustomDatas is failed! customItems=", customItems)

					return controller.fail()
				end
			end
		end

		local ok = AIFunctionMgr:GetItemUseBuffer(obj)

		if not ok then
			return controller.fail()
		end

		local result = AIFunctionMgr:Get_RtFindTarget()

		print("-BTTask_GetItemFromBody-")
		print("itemid=" .. tostring(result.m_itemid))
		print("num=" .. tostring(result.m_num))
		print("grididx=" .. tostring(result.m_gridIndex))

		local out_items = controller.subparam.result_out_items

		if out_items then
			local ok = controller.bb.set(out_items, {
				itemid = result.m_itemid,
				num = result.m_num
			})

			if not ok then
				return controller.fail()
			end
		end

		local out_itemid = controller.subparam.result_out_itemid

		if out_itemid then
			local ok = controller.bb.set(out_itemid, result.m_itemid)

			if not ok then
				return controller.fail()
			end
		end

		return controller.success()
	end
}
