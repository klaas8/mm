return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targetpos = controller.bb.get(controller.subparam.bb_targetpos)

		AIFunctionMgr:faceWorldPos(obj, targetpos.x * BLOCK_SIZE, targetpos.y * BLOCK_SIZE, targetpos.z * BLOCK_SIZE, 180, 180)

		return controller.success()
	end
}
