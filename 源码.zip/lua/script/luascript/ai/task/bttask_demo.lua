return {
	subparam = {
		toolid = 1234,
		collectCount = 0,
		bbkey_followobj = "Attr_Target",
		collectTotal = 100
	},
	onbeg = function ()
		controller.subparam.collectCount = 0
	end,
	onend = function ()
		controller.subparam.collectCount = 0
	end,
	decorator = function ()
		local toolid = controller.subparam.toolid
		local obj = controller.target.get("mob")

		if not obj then
			return controller.fail()
		end

		if not obj.hasTool or not obj:hasTool(toolid) then
			return controller.fail()
		end

		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get("mob")
		local bb_hp = controller.bb.get("hp_1")

		if bb_hp then
			print("bb_hp=" .. tostring(bb_hp))
			print("obj hp=" .. tostring(obj:getLivingAttrib():getHP()))

			if bb_hp <= obj:getLivingAttrib():getHP() then
				print("BT 2")
			end
		end

		repeat
			if obj.collectMaterials and obj:collectMaterials() then
				controller.subparam.collectCount = controller.subparam.collectCount + 1

				return controller.wait()
			else
				return controller.fail()
			end
		until controller.subparam.collectTotal <= controller.subparam.collectCount

		controller.bb.get(controller.subparam.bbkey_followobj)

		return controller.success()
	end
}
