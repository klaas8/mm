return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local id = 0
		local posX = 0
		local posY = 0
		local posZ = 0
		local bempty = controller.subparam.bempty or false
		local searchType = controller.subparam.searchType
		local equipslot = controller.subparam.equipslot or 0
		local findboxid = controller.subparam.findboxid or 0

		if not searchType then
			return controller.fail()
		end

		if searchType >= 100 then
			id, posX, posY, posZ = AIFunctionMgr:hasitemByType(obj, searchType, posX, posY, posZ, equipslot, findboxid)
		elseif searchType > 2 then
			id, posX, posY, posZ = AIFunctionMgr:GetNearBlockPosByType(obj, searchType, posX, posY, posZ, bempty)
		else
			id, posX, posY, posZ = AIFunctionMgr:hasitemByType(obj, searchType, posX, posY, posZ, equipslot, findboxid)
		end

		if id > 0 then
			controller.bb.set(controller.subparam.bbkey_itemid, id)
			controller.bb.set(controller.subparam.bbkey_targetpos, {
				x = posX,
				y = posY,
				z = posZ
			})

			return controller.success()
		end

		return controller.fail()
	end
}
