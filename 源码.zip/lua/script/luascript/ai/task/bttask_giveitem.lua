return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targetObjId = controller.bb.get(controller.subparam.bbKeyTargetObjId).actor
		local target = AIFunctionMgr:getActorByObjId(obj, targetObjId)
		local itemId = controller.bb.get(controller.subparam.bbKeyGiveItemId)
		local itemCount = controller.bb.get(controller.subparam.bbKeyGiveItemCount)
		local itemGiveFromHand = controller.bb.get(controller.subparam.bbKeyGiveItemFromHand) or false
		local flag = false
		local giveCount = AIFunctionMgr:giveItem(itemId, itemCount, obj, target, itemGiveFromHand)

		if giveCount > 0 then
			flag = true
		end

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
