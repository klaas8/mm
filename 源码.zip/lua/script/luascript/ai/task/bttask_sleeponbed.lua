return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local bedpos = controller.bb.get(controller.subparam.bb_bedpos)

		if not bedpos then
			return controller.fail()
		end

		local objPos = obj:getPosition()

		if AIFunctionMgr:isSleeping(obj) and objPos.x == bedpos.x and objPos.y == bedpos.y and objPos.z == bedpos.z then
			return controller.success()
		end

		local ret = AIFunctionMgr:sleepInBed(obj, bedpos.x, bedpos.y, bedpos.z, "")

		if ret == 0 then
			return controller.success()
		end

		return controller.fail()
	end
}
