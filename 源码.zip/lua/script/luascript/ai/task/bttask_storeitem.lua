return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targetPos = controller.bb.get(controller.subparam.bbKeyTargetPos)
		local itemId = controller.bb.get(controller.subparam.bbKeyStoreItemId)
		local itemCount = controller.bb.get(controller.subparam.bbKeyStoreItemCount)
		local flag = AIFunctionMgr:StoreItem(obj, targetPos.x, targetPos.y, targetPos.z, itemId, itemCount, "")

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
