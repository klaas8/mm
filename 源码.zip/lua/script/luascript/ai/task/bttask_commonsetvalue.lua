return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()

		local function getValueByType(valueType)
			local valueTypeEnum = AIFunctionDefsGetDefByKey("valueType")
			local value = 0

			if valueType == valueTypeEnum.demand then
				value = AIFunctionMgr:getDemand(obj)
			elseif valueType == valueTypeEnum.foodByTamed then
				value = AIFunctionMgr:getFoodByTamed(obj)
			elseif valueType == valueTypeEnum.disposition then
				value = AIFunctionMgr:getDisposition(obj)
			elseif valueType == valueTypeEnum.favor then
				value = AIFunctionMgr:getFavor(obj)
			elseif valueType == valueTypeEnum.hairId then
				value = AIFunctionMgr:getHairId(obj)
			elseif valueType == valueTypeEnum.hairColor then
				value = AIFunctionMgr:getHairColor(obj)
			elseif valueType == valueTypeEnum.faceId then
				value = AIFunctionMgr:getFaceId(obj)
			elseif valueType == valueTypeEnum.profession then
				value = AIFunctionMgr:getProfession(obj)
			elseif valueType == valueTypeEnum.bedBindPos then
				if obj:getObjType() == OBJ_TYPE_DESERTVILLAGER then
					AIFunctionMgr:setDesertBedBindPos(obj, value.x, value.y, value.z)
				elseif obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
					AIFunctionMgr:setFishingVillageBedBindPos(obj, value.x, value.y, value.z)
				else
					AIFunctionMgr:setBedBindPos(obj, value.x, value.y, value.z)
				end
			elseif valueType == valueTypeEnum.workBindPos then
				-- Nothing
			elseif valueType == valueTypeEnum.hugger then
				value = AIFunctionMgr:getHugger(obj)
			elseif valueType == valueTypeEnum.fullUp then
				value = AIFunctionMgr:GetFullUp(obj)
			elseif valueType == valueTypeEnum.huggerStatus then
				value = AIFunctionMgr:getHuggerStatus(obj)
			elseif valueType == valueTypeEnum.getUpTime then
				value = AIFunctionMgr:GetTime()
			elseif valueType == valueTypeEnum.sleepTime then
				value = AIFunctionMgr:GetTime()
			elseif valueType == valueTypeEnum.stayUpLateTime then
				value = AIFunctionMgr:GetTime()
			elseif valueType == valueTypeEnum.isStayUpLate then
				-- Nothing
			elseif valueType == valueTypeEnum.fatigueStatus then
				value = AIFunctionMgr:GetFatigue(obj)
			elseif valueType == valueTypeEnum.speedOfBreakingBlock then
				value = AIFunctionMgr:getSpeedOfBreakingBlock(obj)
			elseif valueType == valueTypeEnum.extremisVal then
				value = AIFunctionMgr:getExtremisVal(obj)
			elseif valueType == valueTypeEnum.isTraitor then
				-- Nothing
			elseif valueType == valueTypeEnum.coolingTime then
				-- Nothing
			elseif valueType == valueTypeEnum.moveSpeed then
				local moveSpeedType = controller.subparam.extraValue or 0
				value = AIFunctionMgr:GetMoveSpeed(obj, moveSpeedType)
			elseif valueType == valueTypeEnum.maxHp then
				value = AIFunctionMgr:getMaxHp(obj)
			elseif valueType == valueTypeEnum.curHp then
				value = AIFunctionMgr:getHp(obj)
			elseif valueType == valueTypeEnum.shortRangeAttack then
				value = AIFunctionMgr:GetAttackBase(obj, 0)
			elseif valueType == valueTypeEnum.longRangeAttack then
				value = AIFunctionMgr:GetAttackBase(obj, 1)
			elseif valueType == valueTypeEnum.shortRangeDefense then
				value = AIFunctionMgr:GetDefenseBase(obj, 0)
			elseif valueType == valueTypeEnum.longRangeDefense then
				value = AIFunctionMgr:GetDefenseBase(obj, 1)
			elseif valueType == valueTypeEnum.modelScale then
				value = AIFunctionMgr:getScale(obj)
			elseif valueType == valueTypeEnum.value then
				local key = controller.subparam.key

				if key then
					value = controller.bb.get(key)
				end
			end

			return value
		end

		local function setValueByType(valueType, value, operationType)
			local valueTypeEnum = AIFunctionDefsGetDefByKey("valueType")
			local operationTypeEnum = AIFunctionDefsGetDefByKey("operationType")

			if operationType and operationType > 0 then
				if operationType == operationTypeEnum.add then
					value = getValueByType(valueType) + value
				elseif operationType == operationTypeEnum.reduce then
					value = getValueByType(valueType) - value
				end
			end

			if valueType == valueTypeEnum.demand then
				AIFunctionMgr:setDemand(obj, value)
			elseif valueType == valueTypeEnum.foodByTamed then
				AIFunctionMgr:setFoodByTamed(obj, value)
			elseif valueType == valueTypeEnum.disposition then
				AIFunctionMgr:setDisposition(obj, value)
			elseif valueType == valueTypeEnum.favor then
				AIFunctionMgr:setFavor(obj, value)
			elseif valueType == valueTypeEnum.hairId then
				AIFunctionMgr:setHairId(obj, value)
			elseif valueType == valueTypeEnum.hairColor then
				AIFunctionMgr:setHairColor(obj, value)
			elseif valueType == valueTypeEnum.faceId then
				AIFunctionMgr:setFaceId(obj, value)
			elseif valueType == valueTypeEnum.profession then
				AIFunctionMgr:setProfession(obj, value)
			elseif valueType == valueTypeEnum.bedBindPos then
				AIFunctionMgr:setBedBindPos(obj, value.x, value.y, value.z)
			elseif valueType == valueTypeEnum.workBindPos then
				AIFunctionMgr:setWorkBindPos(obj, value.x, value.y, value.z)
			elseif valueType == valueTypeEnum.hugger then
				AIFunctionMgr:setHugger(obj, value)
			elseif valueType == valueTypeEnum.fullUp then
				AIFunctionMgr:setFullUp(obj, value)
			elseif valueType == valueTypeEnum.huggerStatus then
				AIFunctionMgr:setHuggerStatus(obj, value)
			elseif valueType == valueTypeEnum.getUpTime then
				AIFunctionMgr:setWakeupTime(obj, value)
			elseif valueType == valueTypeEnum.sleepTime then
				AIFunctionMgr:setSleepTime(obj, value)
			elseif valueType == valueTypeEnum.stayUpLateTime then
				AIFunctionMgr:setStayupTime(obj, value)
			elseif valueType == valueTypeEnum.isStayUpLate then
				AIFunctionMgr:setStayingUp(obj, value)
			elseif valueType == valueTypeEnum.fatigueStatus then
				AIFunctionMgr:setFatigue(obj, value)
			elseif valueType == valueTypeEnum.speedOfBreakingBlock then
				AIFunctionMgr:setSpeedOfBreakingBlock(obj, value)
			elseif valueType == valueTypeEnum.extremisVal then
				AIFunctionMgr:setExtremisVal(obj, value)
			elseif valueType == valueTypeEnum.isTraitor then
				AIFunctionMgr:SetIsDefection(obj, value)
			elseif valueType == valueTypeEnum.coolingTime then
				local coolingTimeType = controller.subparam.extraValue

				if coolingTimeType then
					AIFunctionMgr:setCoolingTime(obj, coolingTimeType, value + getServerTime())
				end
			elseif valueType == valueTypeEnum.moveSpeed then
				local moveSpeedType = controller.subparam.extraValue or 0

				AIFunctionMgr:SetMoveSpeed(obj, value, moveSpeedType)
			elseif valueType == valueTypeEnum.maxHp then
				AIFunctionMgr:setMaxHp(obj, value)
			elseif valueType == valueTypeEnum.curHp then
				AIFunctionMgr:setHp(obj, value)
			elseif valueType == valueTypeEnum.shortRangeAttack then
				AIFunctionMgr:SetAttackBase(obj, 0, value)
			elseif valueType == valueTypeEnum.longRangeAttack then
				AIFunctionMgr:SetAttackBase(obj, 1, value)
			elseif valueType == valueTypeEnum.shortRangeDefense then
				AIFunctionMgr:SetDefenseBase(obj, 0, value)
			elseif valueType == valueTypeEnum.longRangeDefense then
				AIFunctionMgr:SetDefenseBase(obj, 1, value)
			elseif valueType == valueTypeEnum.modelScale then
				AIFunctionMgr:setScale(obj, value)
			elseif valueType == valueTypeEnum.loopAction then
				local flagBitType = controller.subparam.extraValue[1] or 0
				local isForce = controller.subparam.extraValue[2] or false

				AIFunctionMgr:setFlagBit(obj, flagBitType, value, isForce)
			elseif valueType == valueTypeEnum.saveCdTick then
				AIFunctionMgr:saveTickTime(obj, 0)
			elseif valueType == valueTypeEnum.saveBufferTick then
				AIFunctionMgr:saveTickTime(obj, 1)
			elseif valueType == valueTypeEnum.value then
				local key = controller.subparam.key

				if key then
					controller.bb.set(key, value)
				end
			end
		end

		local valueType = controller.subparam.valueType
		local value = controller.bb.get(controller.subparam.value)
		local operationType = controller.subparam.operationType
		local flag = false

		if valueType ~= nil and value ~= nil then
			setValueByType(valueType, value, operationType)

			flag = true
		end

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
