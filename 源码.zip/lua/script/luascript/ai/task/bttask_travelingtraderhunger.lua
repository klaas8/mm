return {
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local selfTrader = tolua.cast(selfActor, "ActorTravelingTrader")

		if not selfTrader then
			return false
		end

		if not selfTrader:IsInHomeReal() then
			return false
		end

		local hungerState = selfTrader:GetHungerState()

		if hungerState == 0 then
			if controller.subparam.cd <= selfTrader:GetHoursFromeLastDo() and math.random(100) <= controller.subparam.prob then
				selfTrader:SetHungerState(1)
			end

			return false
		elseif hungerState == 1 then
			selfActor:setHeadIconByPath("", "items/icon12502", 60, 60)

			return false
		elseif hungerState == 2 then
			selfActor:setHeadIconByPath("", "", 0, 0)

			return true
		else
			return false
		end
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local selfTrader = tolua.cast(selfActor, "ActorTravelingTrader")

		AIFunctionMgr:playAnimBySeqId(selfActor, 100114)
		AIFunctionMgr:playSound(selfActor, "ent.3928.happy", 1, 1, 2)
		controller.wait(1)
		selfTrader:SetHungerState(3, true)

		return controller.success()
	end,
	onend = function ()
	end
}
