local FindPositionType = {
	WorkPos = 4,
	Village = 3,
	SelfPosition = 2,
	StoreRange = 1,
	Custom = 100,
	WharfPos = 5
}
local rangeOnceMaxDefault = 5
local rangeOnceMinDefault = 2
local rangeOnceDecrease = 0.5

return {
	subparam = {
		rangeY = 20,
		range = 32,
		findPositionType = 100,
		findBlockType = AI_FIND_CUSTOM,
		findCustomBlocks = {}
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local blocktype = controller.bb.get(controller.subparam.findBlockType)
		local customBlocks = controller.bb.get(controller.subparam.findCustomBlocks)
		local rangeY = controller.bb.get(controller.subparam.rangeY)
		local range = controller.bb.get(controller.subparam.range)
		local centerPosX = 0
		local centerPosY = -1
		local centerPosZ = 0
		local postype = controller.bb.get(controller.subparam.findPositionType)

		if postype == FindPositionType.StoreRange then
			range = AIFunctionDefsGetDefByKey("villageStoreRange")
			local villageX, villageY, villageZ = AIFunctionMgr:GetVillagePoint(obj, 0, 0, 0)
			centerPosZ = villageZ
			centerPosY = villageY
			centerPosX = villageX
		elseif postype == FindPositionType.SelfPosition then
			local x, y, z = obj:getPosition(0, 0, 0)
			x = math.floor(x * 0.01)
			y = math.floor(y * 0.01)
			z = math.floor(z * 0.01)
			centerPosZ = z
			centerPosY = y
			centerPosX = x
		elseif postype == FindPositionType.Village then
			local villageX, villageY, villageZ = AIFunctionMgr:GetVillagePoint(obj, 0, 0, 0)
			centerPosZ = villageZ
			centerPosY = villageY
			centerPosX = villageX
		elseif postype == FindPositionType.WorkPos then
			local x, y, z = AIFunctionMgr:getWorkBindPos(obj, 0, 0, 0)
			centerPosZ = z
			centerPosY = y
			centerPosX = x
		elseif postype == FindPositionType.WharfPos then
			local x, y, z = AIFunctionMgr:getWharfBindPos(obj, 0, 0, 0)
			centerPosZ = z
			centerPosY = y
			centerPosX = x
		elseif postype == FindPositionType.Custom then
			local centerpos = controller.bb.get(controller.subparam.custom_centerPos)

			if not centerpos then
				return controller.fail()
			end

			centerPosZ = centerpos.z
			centerPosY = centerpos.y
			centerPosX = centerpos.x
		else
			return controller.fail()
		end

		local curRangeOnceAdd = rangeOnceMaxDefault
		local rangeMin = 0
		local rangeMax = rangeOnceMaxDefault

		if rangeMax <= 0 then
			return controller.fail()
		end

		local find = false

		while rangeMin < range do
			rangeMax = math.min(rangeMax, range)
			local param = AIFunctionMgr:Get_inFindParam()

			param:Clear()
			param:SetRange(rangeMin, rangeMax)
			param:SetRangeY(rangeY)
			param:SetFindType(blocktype)

			if blocktype == AI_FIND_CUSTOM then
				for _, blockid in ipairs(customBlocks) do
					param:AddCustomBlock(blockid)
				end
			end

			param:SetCenter(centerPosX, centerPosY, centerPosZ)

			local ok = AIFunctionMgr:FindBlockUseBuffer(obj)

			if ok then
				find = true

				break
			end

			curRangeOnceAdd = curRangeOnceAdd - rangeOnceDecrease
			rangeMin = rangeMax
			rangeMax = rangeMax + math.ceil(math.max(curRangeOnceAdd, rangeOnceMinDefault))

			controller.wait()
		end

		if not find then
			return controller.fail()
		end

		local result = AIFunctionMgr:Get_RtFindTarget()
		local rt_blockpos = controller.subparam.result_blockpos

		if rt_blockpos then
			local ok = controller.bb.set(rt_blockpos, {
				x = result.m_x,
				y = result.m_y,
				z = result.m_z
			})

			if not ok then
				return controller.fail()
			end
		end

		return controller.success()
	end
}
