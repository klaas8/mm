return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local timeType = controller.subparam.timeType or 0
		local timeTypeEnum = AIFunctionDefsGetDefByKey("timeType")
		local curTime = AIFunctionMgr:GetTime()
		local startTime = 0
		local endTime = 0
		local wakeUpTime = AIFunctionMgr:getWakeupTime(obj)
		local workTime = wakeUpTime
		local offWorkTime = AIFunctionMgr:getSleepTime(obj) - 2

		if offWorkTime < 0 then
			offWorkTime = 24 + offWorkTime
		end

		local sleepTime = AIFunctionMgr:getSleepTime(obj)
		local stayUpTime = AIFunctionMgr:getStayupTime(obj)

		if timeType == timeTypeEnum.wakeUp then
			endTime = sleepTime
			startTime = wakeUpTime
		elseif timeType == timeTypeEnum.offWork then
			endTime = sleepTime
			startTime = offWorkTime
		elseif timeType == timeTypeEnum.sleep then
			endTime = wakeUpTime
			startTime = sleepTime
		elseif timeType == timeTypeEnum.stayUpLate then
			endTime = wakeUpTime
			startTime = stayUpTime
		elseif timeType == timeTypeEnum.work then
			endTime = offWorkTime
			startTime = workTime
		end

		if startTime < endTime then
			if startTime <= curTime and curTime < endTime then
				return controller.success()
			end
		elseif endTime < startTime and (startTime <= curTime or curTime < endTime) then
			return controller.success()
		end

		return controller.fail()
	end
}
