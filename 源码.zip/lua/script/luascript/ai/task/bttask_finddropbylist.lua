return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local isGet = false
		local targetObjID = 0
		local posX = 0
		local posY = 0
		local posZ = 0
		slot5 = 0
		local obj = controller.target.get()
		local profession = AIFunctionMgr:getProfession(obj)
		local list = {}

		if profession == PROFESSION_WOODCUTTER then
			list = AIFunctionDefsGetDefByKey("cutterToolsList")
		elseif profession == PROFESSION_FARMER then
			list = AIFunctionDefsGetDefByKey("famerToolsList")
		elseif profession == PROFESSION_HUNTER then
			list = AIFunctionDefsGetDefByKey("hunterToolsList")
		else
			list = AIFunctionDefsGetDefByKey(controller.subparam.listsKey)
		end

		local dis = AIFunctionDefsGetDefByKey("dropRange")

		for _, v in ipairs(list) do
			isGet, targetObjID, posX, posY, posZ = AIFunctionMgr:GetNearestActorPos(obj, v, 0, 2, dis, 0, 0, 0)

			if isGet then
				break
			end
		end

		if isGet then
			controller.bb.set(controller.subparam.bbTargetIdKey, {
				actor = targetObjID
			})
			controller.bb.set(controller.subparam.bbPosKey, {
				x = posX,
				y = posY,
				z = posZ
			})

			return controller.success()
		else
			return controller.fail()
		end
	end
}
