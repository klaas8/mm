return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local succ = false
		local targetActor = controller.bb.get(controller.subparam.bbTargetKey)

		if targetActor.actor > 0 then
			local obj = controller.target.get()
			local target = AIFunctionMgr:getActorByObjId(obj, targetActor.actor)

			if target then
				succ = AIFunctionMgr:rotateBodyToActor(obj, target)
			end
		end

		if succ then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
