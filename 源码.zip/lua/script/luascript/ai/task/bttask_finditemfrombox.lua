local FindPositionType = {
	Custom = 100,
	WorkPos = 4,
	Village = 3,
	SelfPosition = 2,
	StoreRange = 1
}
local rangeOnceMaxDefault = 7
local rangeOnceMinDefault = 3
local rangeOnceDecrease = 1

return {
	subparam = {
		range = 8,
		findPositionType = 100,
		rangeY = 5,
		findItemType = AI_FIND_CUSTOM,
		findCustomItems = {}
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemtype = controller.bb.get(controller.subparam.findItemType)
		local customItems = controller.bb.get(controller.subparam.findCustomItems)
		local rangeY = controller.bb.get(controller.subparam.rangeY)
		local range = controller.bb.get(controller.subparam.range)
		local centerPosX = 0
		local centerPosY = -1
		local centerPosZ = 0
		local postype = controller.bb.get(controller.subparam.findPositionType)

		if postype == FindPositionType.StoreRange then
			range = AIFunctionDefsGetDefByKey("villageStoreRange")
			local villageX, villageY, villageZ = AIFunctionMgr:GetVillagePoint(obj, 0, 0, 0)
			centerPosZ = villageZ
			centerPosY = villageY
			centerPosX = villageX
		elseif postype == FindPositionType.SelfPosition then
			local x, y, z = obj:getPosition(0, 0, 0)
			x = math.floor(x * 0.01)
			y = math.floor(y * 0.01)
			z = math.floor(z * 0.01)
			centerPosZ = z
			centerPosY = y
			centerPosX = x
		elseif postype == FindPositionType.Village then
			local villageX, villageY, villageZ = AIFunctionMgr:GetVillagePoint(obj, 0, 0, 0)
			centerPosZ = villageZ
			centerPosY = villageY
			centerPosX = villageX
		elseif postype == FindPositionType.WorkPos then
			local x, y, z = AIFunctionMgr:getWorkBindPos(obj, 0, 0, 0)
			centerPosZ = z
			centerPosY = y
			centerPosX = x
		elseif postype == FindPositionType.Custom then
			local centerpos = controller.bb.get(controller.subparam.custom_centerPos)

			if not centerpos then
				return controller.fail()
			end

			centerPosZ = centerpos.z
			centerPosY = centerpos.y
			centerPosX = centerpos.x
		end

		local curRangeOnceAdd = rangeOnceMaxDefault
		local rangeMin = 0
		local rangeMax = rangeOnceMaxDefault

		if rangeMax <= 0 then
			return controller.fail()
		end

		local find = false

		while rangeMin < range do
			rangeMax = math.min(rangeMax, range)
			local param = AIFunctionMgr:Get_inFindParam()

			param:Clear()
			param:SetRange(rangeMin, rangeMax)
			param:SetRangeY(rangeY)
			param:SetFindType(itemtype)

			if itemtype == AI_FIND_CUSTOM then
				for _, iteminfo in ipairs(customItems) do
					local typeinfo = type(iteminfo)

					if typeinfo == "table" then
						local itemid = iteminfo.itemid
						local isgroup = iteminfo.isgroup

						if itemid and itemid > 0 then
							param:AddCustomItem(itemid, isgroup)
						end
					elseif typeinfo == "number" then
						param:AddCustomItem(iteminfo)
					else
						print("BT ERROR : BTTask_FindItemFromBox itemCustomDatas is failed! customItems=", customItems)

						return controller.fail()
					end
				end
			end

			param:SetCenter(centerPosX, centerPosY, centerPosZ)

			local ok = AIFunctionMgr:FindItemsFromBoxUseBuffer(obj)

			if ok then
				find = true

				break
			end

			curRangeOnceAdd = curRangeOnceAdd - rangeOnceDecrease
			rangeMin = rangeMax
			rangeMax = rangeMax + math.ceil(math.max(curRangeOnceAdd, rangeOnceMinDefault))

			controller.wait()
		end

		if not find then
			return controller.fail()
		end

		local result = AIFunctionMgr:Get_RtFindTarget()

		print("-BTTask_FindItemFromBox- i=" .. tostring(i))
		print("itemid=" .. tostring(result.m_itemid))
		print("num=" .. tostring(result.m_num))
		print("x=" .. tostring(result.m_x))
		print("y=" .. tostring(result.m_y))
		print("z=" .. tostring(result.m_z))
		print("grididx=" .. tostring(result.m_gridIndex))

		local bbkey_out_boxpos = controller.subparam.bbkey_out_boxpos

		if bbkey_out_boxpos then
			local ok = controller.bb.set(bbkey_out_boxpos, {
				x = result.m_x,
				y = result.m_y,
				z = result.m_z
			})

			if not ok then
				return controller.fail()
			end
		end

		local bbkey_out_boxgrididx = controller.subparam.bbkey_out_boxgrididx

		if bbkey_out_boxgrididx then
			local ok = controller.bb.set(bbkey_out_boxgrididx, result.m_gridIndex)

			if not ok then
				return controller.fail()
			end
		end

		local bbkey_out_iteminfo = controller.subparam.bbkey_out_iteminfo

		if bbkey_out_iteminfo then
			local ok = controller.bb.set(bbkey_out_iteminfo, {
				itemid = result.m_itemid,
				num = result.m_num
			})

			if not ok then
				return controller.fail()
			end
		end

		return controller.success()
	end
}
