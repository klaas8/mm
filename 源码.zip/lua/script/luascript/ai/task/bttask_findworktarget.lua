return {
	subparam = {},
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local bbkey_out_targetId = controller.subparam.bbkey_out_targetId
		local bbkey_out_needType = controller.subparam.bbkey_out_needType
		local bbkey_out_needItems = controller.subparam.bbkey_out_needItems

		if not bbkey_out_targetId or not bbkey_out_needType or not bbkey_out_needItems then
			return controller.fail()
		end

		local ret, targetId, itemType, itemNum = AIFunctionMgr:IsHelperHasWorkTarget(obj, 0, 0, 0)

		if not ret then
			controller.bb.set(bbkey_out_targetId, {
				actor = 0
			})
			controller.bb.set(bbkey_out_needType, 0)
			controller.bb.set(bbkey_out_needItems, {})

			return controller.fail()
		end

		if not AIFunctionMgr:getActorByObjId(obj, targetId) then
			AIFunctionMgr:RemoveHelperRelationship(obj)

			return controller.fail()
		end

		local itemids = AIFunctionDefsGetDefByKey("itemType")[itemType]

		if not itemids then
			return controller.fail()
		end

		local iteminfos = {}

		for _, itemid in ipairs(itemids) do
			table.insert(iteminfos, {
				num = 1,
				itemid = itemid
			})
		end

		controller.bb.set(bbkey_out_targetId, {
			actor = targetId
		})
		controller.bb.set(bbkey_out_needType, itemType)
		controller.bb.set(bbkey_out_needItems, iteminfos)

		return controller.success()
	end
}
