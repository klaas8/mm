return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targetID = controller.bb.get(controller.subparam.bbkey_craftID)
		local need_type = controller.bb.get(controller.subparam.bbkey_needtype)

		if not targetID or targetID <= 0 or need_type <= 0 then
			return controller.fail()
		end

		local baseCraftId = controller.bb.get(controller.subparam.bbkey_baseCraftId)
		local baseCraftNum = controller.bb.get(controller.subparam.bbkey_baseCraftNum)
		local currCraftId = targetID
		local result = 0
		local lackItemId = 0
		local lackItemNum = 0

		if not baseCraftId or baseCraftId == 0 then
			result, lackItemId, lackItemNum = AIFunctionMgr:NewCraftingItem(obj, targetID, 1, 0, 0)
		else
			currCraftId = baseCraftId
			result, lackItemId, lackItemNum = AIFunctionMgr:NewCraftingItem(obj, baseCraftId, baseCraftNum, 0, 0)
		end

		controller.bb.set(controller.subparam.bbkey_cancraft, 0)
		controller.bb.set(controller.subparam.bbkey_baseCraftId, 0)
		controller.bb.set(controller.subparam.bbkey_baseCraftNum, 0)

		if result > 0 then
			if result == 1 then
				controller.bb.set(controller.subparam.bbkey_cancraft, 1)
			elseif result == 2 then
				controller.bb.set(controller.subparam.bbkey_baseCraftId, lackItemId)
				controller.bb.set(controller.subparam.bbkey_baseCraftNum, lackItemNum)
			end

			controller.bb.set(controller.subparam.bbkey_takeItemID, lackItemId)
			controller.bb.set(controller.subparam.bbkey_takenum, lackItemNum)

			return controller.success()
		elseif result == 0 then
			if currCraftId == targetID then
				controller.bb.set(controller.subparam.bbkey_needtype, 0)
			end

			return controller.success()
		else
			controller.bb.set(controller.subparam.bbkey_craftID, 0)
			controller.bb.set(controller.subparam.bbkey_needtype, 0)

			return controller.fail()
		end
	end
}
