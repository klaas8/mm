return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local intervaltime = AIFunctionMgr:getDesertSingIntervalTime(obj)
		local judgettype = controller.subparam.judgettype

		if judgettype == 1 then
			if intervaltime <= 0 then
				local singInterval = 2000

				controller.bb.set(controller.subparam.times, 1)
				AIFunctionMgr:setDesertSingIntervalTime(obj, singInterval)

				return controller.success()
			else
				return controller.fail()
			end
		elseif judgettype == 2 then
			local times = controller.bb.get(controller.subparam.times)

			if times >= 1 then
				return controller.success()
			else
				if times == 0 then
					AIFunctionMgr:playSound(obj, "", 0, 0, 0)
					obj:setHeadIconByPath("", "", 0, 0)
				end

				return controller.fail()
			end
		elseif judgettype == 3 then
			local sleepstate = AIFunctionMgr:isSleeping(obj)
			local gossipstate = AIFunctionMgr:getDesertGossipState(obj)

			if sleepstate or gossipstate then
				return controller.fail()
			else
				return controller.success()
			end
		elseif judgettype == 4 then
			AIFunctionMgr:playSound(obj, "", 0, 0, 0)
			obj:setHeadIconByPath("", "", 0, 0)

			return controller.success()
		end
	end
}
