return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local objid = controller.bb.get(controller.subparam.bbkey_evictedobj)
		local target = AIFunctionMgr:getActorByObjId(obj, objid)

		if target then
			target:setBeEvicted(true)
		end

		return controller.success()
	end
}
