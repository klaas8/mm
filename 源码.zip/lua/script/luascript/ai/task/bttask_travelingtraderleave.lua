return {
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() or not CurMainPlayer or not CurMainPlayer:alive() then
			return false
		end

		local inHome = controller.bb.get(controller.subparam.bbkey_inhome)

		if inHome then
			return false
		end

		local leaveDistance = controller.subparam.leaveDistance

		if math.pow(BLOCK_SIZE * leaveDistance, 2) <= PosSquareDistanceToPos(selfActor:getPosition(), CurMainPlayer:getPosition()) then
			return true
		end

		local p_pos = CurMainPlayer:getPosition()
		local centerPos = {
			x = p_pos.x,
			y = p_pos.y,
			z = p_pos.z
		}
		centerPos.x, centerPos.y, centerPos.z = CoordDivBlock(centerPos.x, centerPos.y, centerPos.z)
		local f_pos = {
			z = 0,
			y = 0,
			x = 0
		}
		f_pos.x, f_pos.y, f_pos.z = AIFunctionMgr:GetRandStrollPos(selfActor, f_pos.x, f_pos.y, f_pos.z, centerPos.x, centerPos.y, centerPos.z, leaveDistance, 2)
		f_pos.x, f_pos.y, f_pos.z = BlockBottomCoord(f_pos.x, f_pos.y, f_pos.z)
		local targetDir = Rainbow.Vector3f(f_pos.x - p_pos.x, 0, f_pos.z - p_pos.z)
		targetDir = targetDir:GetNormalizedSafe()
		controller.taskparam.cache_wcTargetDir = WCoord(targetDir.x * leaveDistance * BLOCK_SIZE * 0.5, targetDir.y * leaveDistance * BLOCK_SIZE * 0.5, targetDir.z * leaveDistance * BLOCK_SIZE * 0.5)

		if AIFunctionMgr:isSleeping(selfActor) then
			AIFunctionMgr:wakeUp(selfActor, "")
		end

		return true
	end,
	onbeg = function ()
		controller.taskparam.cache_beginMoveTime = CommonUtil:getSystemTick()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local taskparam = controller.taskparam

		if taskparam.cache_wcTargetDir then
			local leaveDistance = controller.subparam.leaveDistance

			while PosSquareDistanceToPos(selfActor:getPosition(), CurMainPlayer:getPosition()) < math.pow(BLOCK_SIZE * leaveDistance, 2) do
				local t_pos = selfActor:getPosition() + taskparam.cache_wcTargetDir

				if selfActor:getNavigator():canMoveTo(t_pos.x, t_pos.y, t_pos.z, leaveDistance * BLOCK_SIZE) then
					selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1.2, leaveDistance * BLOCK_SIZE)
					controller.wait_until(function ()
						return Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) < math.pow(BLOCK_SIZE, 2) or selfActor:getNavigator():noPath()
					end)

					if taskparam.cache_break then
						break
					end
				else
					controller.wait(5)

					break
				end
			end
		end

		local actorTravelingTrader = tolua.cast(selfActor, "ActorTravelingTrader")

		if actorTravelingTrader then
			actorTravelingTrader:ResetTimePoint()
		end

		selfActor:setNeedClear()

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()
		local taskparam = controller.taskparam

		if taskparam.cache_beginMoveTime then
			local timeLen = CommonUtil:getSystemTick() - taskparam.cache_beginMoveTime
			local maxLen = controller.subparam.maxWait * 1000

			if timeLen >= maxLen then
				taskparam.cache_break = true

				return false
			end
		end

		if math.pow(BLOCK_SIZE * controller.subparam.leaveDistance, 2) <= PosSquareDistanceToPos(selfActor:getPosition(), CurMainPlayer:getPosition()) then
			return false
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		if selfActor then
			selfActor:getNavigator():clearPathEntity()
		end

		controller.taskparam.cache_wcTargetDir = nil
		controller.taskparam.cache_beginMoveTime = nil
		controller.taskparam.cache_break = nil
	end
}
