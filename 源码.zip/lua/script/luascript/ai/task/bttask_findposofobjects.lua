return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local center = controller.bb.get(controller.subparam.bb_centerpos)
		local range = controller.subparam.rangexyz or {
			x = 1,
			z = 1,
			y = 1
		}
		local objs = controller.subparam.objects or {}
		local strObjs = JSON:encode(objs)
		local ret = false
		local x = 0
		local y = 0
		local z = 0
		ret, x, y, z = AIFunctionMgr:GetOneOfBlockPosInRange(obj, center.x, center.y, center.z, range.x, range.y, range.z, strObjs, x, y, z)

		if ret == true then
			controller.bb.set(controller.subparam.bb_targetpos, {
				x = x,
				y = y,
				z = z
			})

			return controller.success()
		end

		return controller.fail()
	end
}
