local function GetCanMovedPos(actor, x, y, z)
	if actor and actor:getWorld() then
		local world = actor:getWorld()
		x, y, z = CoordDivBlock(x, y, z)

		while not world:isAirBlock(x, y, z) do
			y = y + 1

			if y > 255 then
				break
			end
		end

		return BlockCenterCoord(x, y, z)
	end

	return x, y, z
end

return {
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local dis_min = selfActor:getLocoMotion().m_BoundSize
		local dis_max = selfActor:getViewDist()
		local distance = controller.subparam.distance * BLOCK_SIZE
		local reach_dis = math.clamp(distance, dis_min, dis_max)
		controller.luabb.cache_reachDist = reach_dis
		controller.luabb.cache_limitRange = (controller.subparam.limit or 50) * BLOCK_SIZE
		local bb_pos = controller.bb.get(controller.subparam.bbkey_targetpos)
		local t_pos = {
			x = bb_pos.x,
			y = bb_pos.y,
			z = bb_pos.z
		}
		t_pos.x, t_pos.y, t_pos.z = BlockCenterCoord(t_pos.x, t_pos.y, t_pos.z)

		if math.pow(reach_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.luabb.cache_targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}

			if controller.subparam.enforceWait then
				return true
			else
				controller.luabb.cache_targetPos_can = selfActor:getNavigator():canMoveTo(t_pos.x, t_pos.y, t_pos.z, controller.luabb.cache_limitRange)

				return controller.luabb.cache_targetPos_can
			end
		else
			controller.luabb.cache_targetPos = nil

			return true
		end
	end,
	onbeg = function ()
		if controller.luabb.cache_targetPos then
			local selfActor = controller.target.get()
			local t_pos = controller.luabb.cache_targetPos
			controller.luabb.cache_targetPos_can = selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, controller.subparam.speed, controller.luabb.cache_limitRange)
		end
	end,
	run = function ()
		if controller.luabb.cache_targetPos then
			local selfActor = controller.target.get()
			local t_pos = controller.luabb.cache_targetPos

			if controller.luabb.cache_targetPos_can then
				local reach_dis = controller.luabb.cache_reachDist
				local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(reach_dis, 2) or selfActor:getNavigator():noPath()

				if not checkTag then
					controller.luabb.cache_beginMoveTime = CommonUtil:getSystemTick()

					controller.wait_until(function ()
						return Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(reach_dis, 2) or selfActor:getNavigator():noPath()
					end)
					selfActor:getNavigator():clearPathEntity()

					if controller.subparam.enforceWait then
						checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(reach_dis, 2)

						if not checkTag then
							t_pos.x, t_pos.y, t_pos.z = GetCanMovedPos(selfActor, t_pos.x, t_pos.y, t_pos.z)

							selfActor:setPosition(t_pos.x, t_pos.y, t_pos.z)
						end
					end
				end
			elseif controller.subparam.enforceWait then
				controller.wait(controller.subparam.enforceWait)

				t_pos.x, t_pos.y, t_pos.z = GetCanMovedPos(selfActor, t_pos.x, t_pos.y, t_pos.z)

				selfActor:setPosition(t_pos.x, t_pos.y, t_pos.z)
			end
		end

		return controller.success()
	end,
	onwait = function ()
		if controller.luabb.cache_beginMoveTime and controller.subparam.enforceWait then
			local timeLen = CommonUtil:getSystemTick() - controller.luabb.cache_beginMoveTime
			local maxLen = controller.subparam.enforceWait * 1000

			if timeLen >= maxLen then
				return false
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()

		controller.luabb.cache_reachDist = nil
		controller.luabb.cache_limitRange = nil
		controller.luabb.cache_targetPos = nil
		controller.luabb.cache_targetPos_can = nil
		controller.luabb.cache_beginMoveTime = nil
	end
}
