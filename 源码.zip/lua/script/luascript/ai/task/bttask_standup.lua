return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local result = AIFunctionMgr:standUp(obj)

		if result == 0 then
			return controller.fail()
		end

		return controller.success()
	end
}
