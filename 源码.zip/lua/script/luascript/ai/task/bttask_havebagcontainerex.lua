return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemId = controller.subparam.itemId
		local itemCount = controller.subparam.itemCount
		local objId = controller.subparam.objId
		local workType = controller.subparam.workType
		local itemtab = {}
		local count = 0

		if objId == 3214 or objId == 3229 then
			itemtab = {
				12520,
				12703,
				12704
			}
		elseif objId == 3216 then
			if workType == 0 then
				itemtab = {
					11659,
					12707,
					12708
				}
			else
				itemtab = {
					12520,
					12703,
					12704
				}
			end
		elseif objId == 3218 then
			itemtab = {
				13621
			}
		end

		for index, value in ipairs(itemtab) do
			local tempCount = AIFunctionMgr:getItemCountByBags(obj, value)
			count = count + tempCount
		end

		if itemCount <= count then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
