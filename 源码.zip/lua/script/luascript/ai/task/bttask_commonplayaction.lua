return {
	onbeg = function ()
	end,
	onend = function ()
		local obj = controller.target.get()
		local animID = controller.bb.get(controller.subparam.animID)
		local tipsItemId = controller.subparam.tipsItemId and controller.bb.get(controller.subparam.tipsItemId) or nil
		local effectID = controller.subparam.effectID
		local faceId = controller.subparam.faceId and controller.bb.get(controller.subparam.faceId) or nil
		local exchangeItemId = controller.subparam.exchangeItemId and controller.bb.get(controller.subparam.exchangeItemId) or nil
		local exchangeNum = controller.subparam.exchangeItemNum and controller.bb.get(controller.subparam.exchangeItemNum) or nil
		local saleItemId = controller.subparam.saleItemId and controller.bb.get(controller.subparam.saleItemId) or nil
		local saleItemNum = controller.subparam.saleItemNum and controller.bb.get(controller.subparam.saleItemNum) or nil
		local fishId = controller.subparam.bb_fishId and controller.bb.get(controller.subparam.bb_fishId) or 12520

		if animID and animID == 100829 and exchangeItemId > 0 then
			obj:addInitEquip(5, 0, -1)
		end

		if animID == 100894 or animID == 100882 or animID == 100103 then
			AIFunctionMgr:playAnimBySeqId(obj, 100100)
		end

		if type(tipsItemId) == "number" and tipsItemId > 0 then
			AIFunctionMgr:SetHeadDisplayIcon(obj, tipsItemId, 1)
		end

		if exchangeItemId and saleItemId and exchangeItemId > 0 and saleItemId > 0 then
			obj:getBody():setHeadExchangeDisplayIcon(0, 0, false, 1, 1)
		end

		if effectID then
			if type(effectID) == "number" then
				AIFunctionMgr:stopEffectByEffectId(obj, effectID)
			elseif type(effectID) == "string" then
				AIFunctionMgr:stopEffect(obj, effectID)
			end
		end

		if type(faceId) == "number" and faceId > 0 then
			AIFunctionMgr:setFaceId(obj, 1)
		end
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local animID = controller.bb.get(controller.subparam.animID)
		local soundName = controller.bb.get(controller.subparam.soundName) or controller.subparam.soundName
		local effectID = controller.subparam.effectID
		local tipsType = controller.subparam.tipsType or 0
		local tipsBgName = controller.subparam.tipsBgName or ""
		local tipsItemId = controller.subparam.tipsItemId and controller.bb.get(controller.subparam.tipsItemId) or nil
		local tipsItemId2 = controller.subparam.tipsItemId2 and controller.bb.get(controller.subparam.tipsItemId2) or nil
		local exchangeItemId = controller.subparam.exchangeItemId and controller.bb.get(controller.subparam.exchangeItemId) or nil
		local exchangeNum = controller.subparam.bb_exchangeNum and controller.bb.get(controller.subparam.bb_exchangeNum) or nil
		local saleItemId = controller.subparam.saleItemId and controller.bb.get(controller.subparam.saleItemId) or nil
		local saleItemNum = controller.subparam.bb_saleNum and controller.bb.get(controller.subparam.bb_saleNum) or nil
		local fishId = controller.subparam.bb_fishId and controller.bb.get(controller.subparam.bb_fishId) or 12520
		local isActor = controller.subparam.isActor

		if isActor == nil then
			isActor = false
		end

		local faceId = controller.subparam.faceId and controller.bb.get(controller.subparam.faceId) or nil
		local duration = controller.subparam.duration
		local flag = false

		if obj and (animID or soundName or effectID or tipsType or tipsBgName or tipsItemId or tipsItemId2 or faceId or duration) then
			flag = true

			if animID then
				if animID == 100829 and exchangeItemId and exchangeItemId > 0 then
					if obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
						exchangeItemId = fishId
					end

					obj:addInitEquip(5, exchangeItemId, -1)
				end

				AIFunctionMgr:playAnimBySeqId(obj, animID)
			end

			if soundName then
				AIFunctionMgr:playSound(obj, soundName, 1, 1, 2)
			end

			if effectID then
				if type(effectID) == "number" then
					AIFunctionMgr:playEffectByEffectId(obj, effectID)
				elseif type(effectID) == "string" then
					AIFunctionMgr:playEffect(obj, effectID)
				end
			end

			if type(tipsItemId) == "number" and tipsItemId > 0 then
				AIFunctionMgr:SetHeadDisplayIcon(obj, tipsItemId)
			end

			if type(tipsItemId2) == "number" and tipsItemId2 > 0 then
				AIFunctionMgr:SetHeadDisplayIcon(obj, tipsItemId2)
			end

			if exchangeItemId and saleItemId and exchangeItemId > 0 and saleItemId > 0 then
				obj:getBody():setHeadExchangeDisplayIcon(exchangeItemId, saleItemId, isActor, exchangeNum, saleItemNum)
			end

			if type(faceId) == "number" and faceId > 0 then
				AIFunctionMgr:setFaceId(obj, faceId)
			end

			if duration then
				controller.wait(duration)

				if animID and controller.subparam.isLoopAnim then
					AIFunctionMgr:stopAnimBySeqId(obj, animID)
				end
			end
		end

		if flag then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
