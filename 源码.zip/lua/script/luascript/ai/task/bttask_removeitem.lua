return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemId = controller.bb.get(controller.subparam.bbEquipItemId)
		local itemCount = controller.bb.get(controller.subparam.bbEquipItemNum)
		local isequipweapon = controller.subparam.isequipweapon or false

		AIFunctionMgr:removeItem(obj, itemId, itemCount, isequipweapon)

		return controller.success()
	end
}
