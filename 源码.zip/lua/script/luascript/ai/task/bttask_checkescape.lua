return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local range = controller.subparam.range
		local bossRange = controller.subparam.bossRange
		local escapeList = AIFunctionDefsGetDefByKey("escapeEnemyIds")
		local escapeBossList = AIFunctionDefsGetDefByKey("escapeEnemyBossIds")
		local isGuard = false
		local profession = AIFunctionMgr:getProfession(obj)

		if profession == PROFESSION_MELEE_GUARD or profession == PROFESSION_REMOTE_GUARD or profession == PROFESSION_HUNTER then
			isGuard = true
		end

		local flag = false
		local isFind = false
		local findObjId = 0
		local posX = 0
		local posY = 0
		local posZ = 0

		if not isGuard then
			for i = 1, #escapeList do
				local aEscapeId = escapeList[i]
				local aEscapeObjId = 0
				isFind, findObjId, posX, posY, posZ = AIFunctionMgr:GetNearestActorPos(obj, aEscapeId, 0, 0, bossRange, 0, 0, 0)

				if isFind and AIFunctionMgr:canSeeInAICache(obj, findObjId) then
					flag = true

					break
				end
			end

			if not flag then
				for i = 1, #escapeBossList do
					local aEscapeId = escapeBossList[i]
					local aEscapeObjId = 0
					isFind, findObjId, posX, posY, posZ = AIFunctionMgr:GetNearestBossActorPos(obj, aEscapeId, 0, 0, bossRange, 0, 0, 0)

					if isFind and AIFunctionMgr:canSeeInAICache(obj, findObjId) then
						flag = true

						break
					end
				end
			end
		end

		if not flag then
			local hurtType = AIFunctionMgr:getHurtType(obj)

			if hurtType == 1 then
				flag = true
			end
		end

		if flag then
			local findObj = AIFunctionMgr:getActorByObjId(obj, findObjId)
			local isFind, posX, posY, posZ = AIFunctionMgr:getEscapePos(obj, findObj, range, 0, 0, 0)

			if isFind then
				controller.bb.set(controller.subparam.bbKeyTargetPos, {
					x = posX,
					y = posY,
					z = posZ
				})

				return controller.success()
			else
				return controller.fail()
			end
		else
			return controller.fail()
		end
	end
}
