return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local flag = true

		if controller.subparam.value then
			controller.bb.set(controller.subparam.bbkeySpeedRatio, controller.subparam.value)

			return controller.success()
		else
			return controller.fail()
		end
	end
}
