return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()

		AIFunctionMgr:CancelVillageHelperTask(obj)

		return controller.success()
	end
}
