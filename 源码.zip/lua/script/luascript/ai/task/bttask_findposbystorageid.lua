return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local id = 0
		local posX = 0
		local posY = 0
		local posZ = 0
		local itemid = controller.bb.get(controller.subparam.bbkey_itemid) or 0
		id, posX, posY, posZ = AIFunctionMgr:hasProp(obj, itemid, posX, posY, posZ, controller.subparam.bbkey_group)

		if id > 0 then
			controller.bb.set(controller.subparam.bbkey_targetpos, {
				x = posX,
				y = posY,
				z = posZ
			})

			if itemid > 0 then
				controller.bb.set(controller.subparam.bbkey_targetid, id)
			end

			return controller.success()
		end

		return controller.fail()
	end
}
