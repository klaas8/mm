return {
	subparam = {},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemid = controller.bb.get(controller.subparam.bbkey_targetItem)

		if not itemid or itemid == 0 then
			print("BT ERROR : BTTask_CraftingItemSplit subparam failed! bbkey_targetItem=", controller.subparam.bbkey_targetItem)

			return controller.fail()
		end

		local ok = AIFunctionMgr:CraftingItemMaterials(obj, itemid)

		if not ok then
			return controller.fail()
		end

		local result = AIFunctionMgr:Get_RtFindList()
		local size = result:size()
		local out = {}

		for i = 1, size do
			local finditem = result:getData(i - 1)
			local itemid = finditem.m_itemid
			local num = finditem.m_num
			local isgroup = finditem.m_isgroup

			print("-BTTask_CraftingItemSplit- i=" .. tostring(i))
			print("itemid=" .. tostring(itemid))
			print("num=" .. tostring(num))
			print("isgroup=" .. tostring(isgroup))
			table.insert(out, {
				itemid = itemid,
				num = num,
				isgroup = isgroup
			})
		end

		local out_materails = controller.subparam.bbkey_out_materails

		if out_materails then
			local ok = controller.bb.set(out_materails, out)

			if not ok then
				return controller.fail()
			end
		end

		return controller.success()
	end
}
