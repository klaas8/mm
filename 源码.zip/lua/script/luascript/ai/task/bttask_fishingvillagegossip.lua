return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local gossiptype = controller.subparam.gossiptype

		if gossiptype == 0 then
			if controller.subparam.state == 0 then
				local intervalTime = 2400

				AIFunctionMgr:setFishingVillageGossipIntervalTime(obj, intervalTime)

				return controller.success()
			elseif controller.subparam.state == 1 then
				local intervalTime = AIFunctionMgr:getFishingVillageGossipIntervalTime(obj)

				if intervalTime <= 1 then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 1 then
			if controller.subparam.state == 0 then
				AIFunctionMgr:setFishingVillageGossipTime(obj)

				return controller.success()
			elseif controller.subparam.state == 1 then
				local gossipTime = AIFunctionMgr:getFishingVillageGossipTime(obj)

				if gossipTime <= 0 then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 2 then
			if controller.subparam.state == 0 then
				local gossipstate = false

				AIFunctionMgr:setFishingVillageGossipState(obj, gossipstate)

				return controller.success()
			elseif controller.subparam.state == 1 then
				local gossipstate = true

				AIFunctionMgr:setFishingVillageGossipState(obj, gossipstate)

				return controller.success()
			elseif controller.subparam.state == 2 then
				local gossipstate = AIFunctionMgr:getFishingVillageGossipState(obj)

				if gossipstate then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 3 then
			if controller.subparam.state == 0 then
				-- Nothing
			elseif controller.subparam.state == 1 then
				local lookTime = AIFunctionMgr:getFishingVillageLookTime(obj)

				if lookTime <= 0 then
					AIFunctionMgr:FishingVillageGossipAction(obj)
				end

				return controller.success()
			end
		elseif gossiptype == 4 then
			if controller.subparam.state == 0 then
				-- Nothing
			elseif controller.subparam.state == 1 then
				local targetid = AIFunctionMgr:findNearFishingVillager(obj)

				if targetid ~= 0 then
					local target = AIFunctionMgr:getActorByObjId(obj, targetid)
					local gossipPos = target:getPosition()

					if controller.subparam.gossipId and controller.subparam.gossipPos then
						controller.bb.set(controller.subparam.gossipPos, {
							x = gossipPos.x / 100,
							y = gossipPos.y / 100,
							z = gossipPos.z / 100
						})
						controller.bb.set(controller.subparam.gossipId, {
							actor = targetid
						})
					end

					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 5 then
			if controller.subparam.gossipId then
				local targetid = controller.bb.get(controller.subparam.gossipId)
				local target = AIFunctionMgr:getActorByObjId(obj, targetid.actor)

				if target then
					AIFunctionMgr:rotateBodyToActor(obj, target)
					AIFunctionMgr:setFishingVillageGossipState(target, true)
				end
			end
		elseif gossiptype == 6 then
			local num = AIFunctionMgr:getFishingVillagerNum(obj)

			if num >= 2 then
				return controller.success()
			else
				AIFunctionMgr:setFishingVillageGossipState(obj, false)

				return controller.fail()
			end
		elseif gossiptype == 7 then
			AIFunctionMgr:setFishingVillageSound(obj)

			return controller.success()
		elseif gossiptype == 8 then
			local id = 0

			AIFunctionMgr:setFishingVillageGoosipTeamId(obj, id)

			return controller.success()
		elseif gossiptype == 9 then
			local list = LuaConstants.fishingVillagerGossip
			local groupid = AIFunctionMgr:getFishingVillageGoosipGroupId(obj)
			local iconid = AIFunctionMgr:getFishingVillageGoosipIconId(obj)

			if groupid ~= 0 then
				local groupname = "group" .. groupid
				local list2 = list[groupname]
				local length = #list2

				if length < iconid + 1 then
					local id = 0

					AIFunctionMgr:setFishingVillageGoosipGroupId(obj, id)
				end
			end

			return controller.success()
		end
	end
}
