return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local x, y, z = obj:getPosition(0, 0, 0)
		x, y, z = CoordDivBlock(x, y, z)
		local explorePos = controller.bb.get(controller.subparam.explorePos)
		local diffValueY = 0
		local diffValueX = explorePos.x - x
		local diffValueZ = explorePos.z - z
		local squareX = diffValueX * diffValueX
		local squareZ = diffValueZ * diffValueZ

		if squareX + squareZ > 256 then
			local squareY = diffValueY * diffValueY
			local sqrtLen = math.sqrt(squareX + squareZ)
			local stagePosX, stagePosY, stagePosZ = nil
			local unitX = diffValueX / sqrtLen
			local unitZ = diffValueZ / sqrtLen
			stagePosX = math.floor(unitX * 16) + x
			stagePosZ = math.floor(unitZ * 16) + z
			stagePosY = CurWorld:getTopHeight(stagePosX, stagePosZ)

			if stagePosY == 0 then
				stagePosY = y
			end

			controller.bb.set(controller.subparam.stagePos, {
				x = stagePosX,
				y = stagePosY,
				z = stagePosZ
			})
		else
			if explorePos.y == 0 then
				explorePos.y = CurWorld:getTopHeight(explorePos.x, explorePos.z)
			end

			controller.bb.set(controller.subparam.stagePos, {
				x = explorePos.x,
				y = explorePos.y,
				z = explorePos.z
			})
		end

		return controller.success()
	end
}
