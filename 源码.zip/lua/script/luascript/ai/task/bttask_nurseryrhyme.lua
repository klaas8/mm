return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local body = obj:getBody()
		local singtime = controller.bb.get("singtick")
		local times = controller.bb.get(controller.subparam.times)
		local animaltime = controller.bb.get("animaltick")
		local icontime = controller.bb.get("icontick")

		if singtime <= 0 then
			controller.bb.set("singtick", 200)
			AIFunctionMgr:playSound(obj, "", 0, 0, 0)

			if times ~= 6 and times ~= 0 or times == 3 then
				AIFunctionMgr:playSound(obj, "ent.3208.sing", 1, 1, 2)
			end

			if times == 0 then
				AIFunctionMgr:playSound(obj, "", 0, 0, 0)
				obj:setHeadIconByPath("", "", 0, 0)
			end
		else
			singtime = singtime - 1

			controller.bb.set("singtick", singtime)
		end

		if icontime <= 0 then
			controller.bb.set("icontick", 100)
			obj:setHeadIconByPath("", "", 0, 0)

			if times ~= 6 and times ~= 0 or times == 3 then
				local pathName = "particles/texture/" .. "folk_rhyme" .. times

				obj:setHeadIconByPath("", pathName, 60, 60)
			end

			local times2 = 0

			if times + 1 == 4 then
				times2 = times + 2
			else
				times2 = times + 1
			end

			if times2 > 6 then
				times2 = 0
			end

			controller.bb.set(controller.subparam.times, times2)
		else
			icontime = icontime - 1

			controller.bb.set("icontick", icontime)
		end

		if animaltime <= 0 then
			controller.bb.set("animaltick", 50)

			if times ~= 6 and times ~= 0 or times == 3 then
				AIFunctionMgr:playAnimBySeqId(obj, 100825)
			end
		else
			animaltime = animaltime - 1

			controller.bb.set("animaltick", animaltime)
		end

		return controller.success()
	end
}
