return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local pos = {
			z = 0,
			y = 0,
			x = 0
		}
		local centerPos = controller.bb.get(controller.subparam.centerPos)
		local rangeWidth = controller.bb.get(controller.subparam.rangeWidth) or 0
		local rangeHeight = controller.bb.get(controller.subparam.rangeHeight) or 0

		if not centerPos then
			pos.x, pos.y, pos.z = AIFunctionMgr:GetRandStrollPosBySelf(obj, pos.x, pos.y, pos.z, rangeWidth, rangeHeight)
		else
			pos.x, pos.y, pos.z = AIFunctionMgr:GetRandStrollPos(obj, pos.x, pos.y, pos.z, centerPos.x, centerPos.y, centerPos.z, rangeWidth, rangeHeight)
		end

		if controller.subparam.bigCenterPos and controller.subparam.bigRange then
			local bigCenterPos = controller.bb.get(controller.subparam.bigCenterPos)
			local bigRange = controller.bb.get(controller.subparam.bigRange)
			pos.x = math.min(math.max(pos.x, bigCenterPos.x - bigRange.x), bigCenterPos.x + bigRange.x)
			pos.y = math.min(math.max(pos.y, bigCenterPos.y - bigRange.y), bigCenterPos.y + bigRange.y)
			pos.z = math.min(math.max(pos.z, bigCenterPos.z - bigRange.z), bigCenterPos.z + bigRange.z)
		end

		controller.bb.set(controller.subparam.bb_stollpos, pos)

		return controller.success()
	end
}
