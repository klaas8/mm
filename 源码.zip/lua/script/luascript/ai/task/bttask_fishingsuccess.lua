return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local probability = controller.bb.get(controller.subparam.probability)
		local random = math.random(1, 10)
		local itemid = 12520

		if random <= 3 then
			itemid = 12703
		elseif random > 3 and random <= 6 then
			itemid = 12704
		end

		AIFunctionMgr:addItemToBags(obj, itemid, 1)

		local count = AIFunctionMgr:getItemCountByBags(obj, itemid)

		AIFunctionMgr:equipWeapon(obj, itemid, 1)
		AIFunctionMgr:addItemToBags(obj, itemid, count)
		controller.bb.set(controller.subparam.bb_fishId, itemid)

		return controller.success()
	end
}
