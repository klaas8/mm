return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local curTime = AIFunctionMgr:GetTime()
		local bbKeyBeHurtTargetObjId = controller.bb.get(controller.subparam.bbKeyBeHurtTargetObjId)
		local enemy_id = controller.bb.get(controller.subparam.enemy_id)
		local bbKeyAttackTargetObjId = controller.bb.get(controller.subparam.bbKeyAttackTargetObjId)

		if curTime >= 16 and curTime < 19 then
			if bbKeyBeHurtTargetObjId.actor ~= 0 or enemy_id.actor ~= 0 or bbKeyAttackTargetObjId.actor ~= 0 then
				return controller.fail()
			else
				return controller.success()
			end
		else
			return controller.fail()
		end
	end
}
