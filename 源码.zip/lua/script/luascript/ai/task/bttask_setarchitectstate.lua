return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local state = controller.subparam.state
		local pos = controller.bb.get(controller.subparam.block_pos_key)
		local workpos = controller.bb.get(controller.subparam.bb_workpos)

		AIFunctionMgr:setArchitectState(obj, WCoord(workpos.x, workpos.y, workpos.z), WCoord(pos.x, pos.y, pos.z), state)

		return controller.success()
	end
}
