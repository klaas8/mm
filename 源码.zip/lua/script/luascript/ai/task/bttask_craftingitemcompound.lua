local CompoundMode = {
	First = 2,
	All = 1
}

return {
	subparam = {
		compoundMode = CompoundMode.All
	},
	onbeg = function ()
	end,
	onend = function ()
	end,
	run = function ()
		local obj = controller.target.get()
		local compoundMode = controller.bb.get(controller.subparam.compoundMode)
		local targetItems = controller.bb.get(controller.subparam.bbkey_targetItems)

		if not targetItems then
			print("BT ERROR : BTTask_CraftingItemCompound subparam failed! bbkey_targetItems=", controller.subparam.bbkey_targetItems)

			return controller.fail()
		end

		if type(targetItems) ~= "table" then
			targetItems = {
				targetItems
			}
		end

		local finish = false
		local crafTimes = 0
		local result = {}

		if compoundMode == CompoundMode.All then
			finish = true

			for _, itemid in ipairs(targetItems) do
				local ok, times = AIFunctionMgr:CraftingItemRecursion(obj, itemid, 1, 0)
				crafTimes = times

				if not ok then
					finish = false

					break
				end

				table.insert(result, itemid)
			end
		elseif compoundMode == CompoundMode.First then
			for _, itemid in ipairs(targetItems) do
				local ok, times = AIFunctionMgr:CraftingItemRecursion(obj, itemid, 1, 0)
				crafTimes = times

				if ok then
					finish = true

					table.insert(result, itemid)

					break
				end
			end
		else
			print("BT ERROR : BTTask_CraftingItemCompound compoundMode failed! compoundMode=", compoundMode)
		end

		local out_craftTimes = controller.subparam.bbkey_out_craftTimes

		if out_craftTimes then
			controller.bb.set(out_craftTimes, crafTimes)
		end

		if finish then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
