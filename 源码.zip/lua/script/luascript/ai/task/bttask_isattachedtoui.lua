return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local ret = AIFunctionMgr:getAttachedToUI(obj)

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
