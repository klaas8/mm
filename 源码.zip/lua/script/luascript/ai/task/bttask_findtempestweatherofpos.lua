return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local centerPos = controller.bb.get(controller.subparam.centerPos)
		local ret = false

		if centerPos then
			ret = AIFunctionMgr:isTempestWeather(obj, centerPos.x * BLOCK_SIZE, centerPos.y * BLOCK_SIZE, centerPos.z * BLOCK_SIZE)
		end

		if ret then
			return controller.fail()
		else
			return controller.success()
		end
	end
}
