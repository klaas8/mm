return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local range = controller.subparam.range
		local attackList = AIFunctionDefsGetDefByKey("attackEnemyIds")
		local isGuard = false
		local profession = AIFunctionMgr:getProfession(obj)

		if profession == PROFESSION_MELEE_GUARD or profession == PROFESSION_REMOTE_GUARD or profession == PROFESSION_HUNTER then
			isGuard = true
		end

		if profession == PROFESSION_HUNTER then
			attackList = AIFunctionDefsGetDefByKey("hunterAttackEnemyIds")
		end

		local flag = false
		local isFind = false
		local findObjId = 0
		local posX = 0
		local posY = 0
		local posZ = 0
		local minDis = 0
		local minDisObjId = 0

		if isGuard then
			for i = 1, #attackList do
				local aAttackId = attackList[i]
				isFind, findObjId, posX, posY, posZ = AIFunctionMgr:GetNearestActorPos(obj, aAttackId, 0, 0, range, 0, 0, 0)

				if isFind then
					local curDis = AIFunctionMgr:GetTargetDis(obj, posX, posY, posZ)

					if minDis == 0 then
						minDis = curDis
						minDisObjId = findObjId
					elseif curDis < minDis then
						minDis = curDis
						minDisObjId = findObjId
					end

					flag = true
				end
			end
		end

		if flag then
			controller.bb.set(controller.subparam.bbKeyTargetPos, {
				x = posX,
				y = posY,
				z = posZ
			})
			controller.bb.set(controller.subparam.bbKeyTargetObjId, {
				actor = minDisObjId
			})

			return controller.success()
		else
			return controller.fail()
		end
	end
}
