return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local findRange = controller.subparam.range
		local targetType = controller.subparam.targetType
		local targetID = controller.bb.get(controller.subparam.targetID)
		local targetObjID = 0
		local targetObjtype = controller.subparam.actorObjType or obj:getObjType()
		local flag = false
		local posX = 0
		local posY = 0
		local posZ = 0
		local findTargetTypeEnum = AIFunctionDefsGetDefByKey("findTargetType")

		if targetType == findTargetTypeEnum.block then
			if obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
				flag, posX, posY, posZ = AIFunctionMgr:GetNearestBlockPos(obj, targetID, findRange, 0, 0, 0, true)
			else
				flag, posX, posY, posZ = AIFunctionMgr:GetNearestBlockPos(obj, targetID, findRange, 0, 0, 0)
			end
		elseif targetType == findTargetTypeEnum.actor then
			flag, targetObjID, posX, posY, posZ = AIFunctionMgr:GetNearestActorPos(obj, targetID, targetObjID, targetObjtype, findRange, 0, 0, 0)
		elseif targetType == findTargetTypeEnum.player then
			flag, targetObjID, posX, posY, posZ = AIFunctionMgr:GetNearestPlayerPos(obj, targetObjID, findRange, 0, 0, 0)
		end

		if flag then
			controller.bb.set(controller.subparam.bbKeyTargetPos, {
				x = posX,
				y = posY,
				z = posZ
			})
			controller.bb.set(controller.subparam.bbKeyTargetObjId, {
				actor = targetObjID
			})

			return controller.success()
		else
			return controller.fail()
		end
	end
}
