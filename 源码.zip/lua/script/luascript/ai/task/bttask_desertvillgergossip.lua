return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local gossiptype = controller.subparam.gossiptype

		if gossiptype == 0 then
			if controller.subparam.state == 0 then
				local intervalTime = 2400

				AIFunctionMgr:setDesertGossipIntervalTime(obj, intervalTime)

				return controller.success()
			elseif controller.subparam.state == 1 then
				local intervalTime = AIFunctionMgr:getDesertGossipIntervalTime(obj)

				if intervalTime <= 1 then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 1 then
			if controller.subparam.state == 0 then
				AIFunctionMgr:setDesertGossipTime(obj)

				return controller.success()
			elseif controller.subparam.state == 1 then
				local gossipTime = AIFunctionMgr:getDesertGossipTime(obj)

				if gossipTime <= 0 then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 2 then
			if controller.subparam.state == 0 then
				local gossipstate = false

				AIFunctionMgr:setDesertGossipState(obj, gossipstate)

				return controller.success()
			elseif controller.subparam.state == 1 then
				local gossipstate = true

				AIFunctionMgr:setDesertGossipState(obj, gossipstate)

				return controller.success()
			elseif controller.subparam.state == 2 then
				local gossipstate = AIFunctionMgr:getDesertGossipState(obj)

				if gossipstate then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 3 then
			if controller.subparam.state == 0 then
				-- Nothing
			elseif controller.subparam.state == 1 then
				local lookTime = AIFunctionMgr:getDesertLookTime(obj)

				if lookTime <= 0 then
					AIFunctionMgr:DesertVillgerGossipAction(obj)
				end

				return controller.success()
			end
		elseif gossiptype == 4 then
			if controller.subparam.state == 0 then
				-- Nothing
			elseif controller.subparam.state == 1 then
				local targetid = AIFunctionMgr:findNearDesertVillger(obj)

				if targetid ~= 0 then
					local target = AIFunctionMgr:getActorByObjId(obj, targetid)
					local gossipPos = target:getPosition()

					if controller.subparam.gossipId and controller.subparam.gossipPos then
						controller.bb.set(controller.subparam.gossipPos, {
							x = gossipPos.x / 100,
							y = gossipPos.y / 100,
							z = gossipPos.z / 100
						})
						controller.bb.set(controller.subparam.gossipId, {
							actor = targetid
						})
					end

					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 5 then
			if controller.subparam.gossipId then
				local targetid = controller.bb.get(controller.subparam.gossipId)
				local target = AIFunctionMgr:getActorByObjId(obj, targetid.actor)

				if target then
					AIFunctionMgr:rotateBodyToActor(obj, target)
					AIFunctionMgr:setDesertGossipState(target, true)
				end
			end
		elseif gossiptype == 6 then
			local num = AIFunctionMgr:getDesertVillgerNum(obj)

			if num >= 2 then
				return controller.success()
			else
				AIFunctionMgr:setDesertGossipState(obj, false)

				return controller.fail()
			end
		elseif gossiptype == 7 then
			AIFunctionMgr:setDesertVillgerSound(obj)

			return controller.success()
		elseif gossiptype == 8 then
			local id = 0

			AIFunctionMgr:setDesertGoosipTeamId(obj, id)

			return controller.success()
		elseif gossiptype == 9 then
			local list = LuaConstants.desertVillagerGossip
			local groupid = AIFunctionMgr:getDesertGoosipGroupId(obj)
			local iconid = AIFunctionMgr:getDesertGoosipIconId(obj)

			if groupid ~= 0 then
				local groupname = "group" .. groupid
				local list2 = list[groupname]
				local length = #list2

				if length < iconid + 1 then
					local id = 0

					AIFunctionMgr:setDesertGoosipGroupId(obj, id)
				end
			end

			return controller.success()
		elseif gossiptype == 10 then
			local followstate = AIFunctionMgr:getDesertHelloFollowState(obj)
			local sleepstate = AIFunctionMgr:isSleeping(obj)
			local playerid = controller.bb.get(controller.subparam.followobjid)
			local bbKeyBeHurtTargetObjId = controller.bb.get(controller.subparam.bbKeyBeHurtTargetObjId)
			local enemy_id = controller.bb.get(controller.subparam.enemy_id)
			local bbKeyAttackTargetObjId = controller.bb.get(controller.subparam.bbKeyAttackTargetObjId)

			if followstate and playerid.actor ~= 0 and sleepstate == false then
				if bbKeyBeHurtTargetObjId.actor ~= 0 or enemy_id.actor ~= 0 or bbKeyAttackTargetObjId.actor ~= 0 then
					return controller.fail()
				else
					return controller.success()
				end
			else
				return controller.fail()
			end
		elseif gossiptype == 11 then
			local random2 = controller.bb.get("randomgroup")

			if random2 == 0 then
				random2 = math.random(1, 5)
			end

			local list = LuaConstants.desertVillagerGossip
			local groupname = "group" .. random2
			local list2 = list[groupname]
			local length = #list2
			local helloiconid = controller.bb.get("helloiconid")
			local path = ""

			if helloiconid <= length then
				path, name = desertGoosipIcon(random2, helloiconid)

				if path ~= "" then
					local random = math.random(1, 10)
					local id = obj:getDefID()

					if random <= 5 then
						AIFunctionMgr:playAnimBySeqId(obj, 100110)
						AIFunctionMgr:playSound(obj, "ent." .. id .. ".idle1", 1, 1, 2)
					else
						AIFunctionMgr:playAnimBySeqId(obj, 100826)
						AIFunctionMgr:playSound(obj, "ent." .. id .. ".idle1", 1, 1, 2)
					end

					local i, j = string.find(path, "emoticon")
					local ii, jj = string.find(path, "roleicons")

					if i and j then
						obj:setHeadIconByPath("ui/mobile/texture0/emoticon", name, 90, 90)
					elseif ii and jj then
						obj:setHeadIconByPath("", path, 128, 128)
					else
						obj:setHeadIconByPath("", path, 60, 60)
					end
				end

				helloiconid = helloiconid + 1

				controller.bb.set("helloiconid", helloiconid)
				controller.bb.set("randomgroup", random2)
			else
				local random3 = math.random(1, 5)

				controller.bb.set("randomgroup", random3)
				controller.bb.set("helloiconid", 1)
				obj:setHeadIconByPath("", path, 0, 0)
				AIFunctionMgr:playSound(obj, 0, 0, 0, 0)
				controller.bb.set(controller.subparam.followobjid, {
					actor = 0
				})
				AIFunctionMgr:setDesertHelloFollowState(obj, false)

				local uin = controller.bb.get(controller.subparam.followobjid)

				if CurWorld then
					local player = GetCurWorldActorMgr():findPlayerByUin(uin.actor)

					if player then
						player:setFollowByVillager(false)
					end
				end

				return controller.fail()
			end

			return controller.success()
		elseif gossiptype == 12 then
			local followticks = controller.bb.get(controller.subparam.followtick)

			if followticks <= 0 then
				controller.bb.set(controller.subparam.followtick, 10)

				return controller.success()
			else
				followticks = followticks - 1

				controller.bb.set(controller.subparam.followtick, followticks)

				return controller.fail()
			end
		elseif gossiptype == 13 then
			local pos = obj:getPosition()

			if CurWorld.getBiomeType then
				local biometype = CurWorld:getBiomeType(math.floor(pos.x / 100), math.floor(pos.z / 100))

				if biometype == BIOME_DESERT_OASIS then
					return controller.success()
				else
					return controller.fail()
				end
			end
		elseif gossiptype == 888 then
			local duration = controller.subparam.duration
			local ico = controller.subparam.ico
			local w = controller.subparam.w
			local h = controller.subparam.h

			obj:setHeadIconByPath("", ico, w, h)

			if duration then
				controller.wait(duration)
			end

			obj:setHeadIconByPath("", "", 0, 0)

			return controller.success()
		end
	end
}
