return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local curTime = AIFunctionMgr:GetTime()

		if curTime > 9 and curTime < 19 then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
