return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local dis = AIFunctionDefsGetDefByKey("searchRange")
		local posX, posY, posZ = AIFunctionMgr:GetActorInFrontPos(obj, dis, 0, 0, 0)

		AIFunctionMgr:TryMoveToPos(obj, posX, posY, posZ, 1.1)
		controller.wait(3)

		return controller.success()
	end
}
