return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local targetId = controller.bb.get(controller.subparam.dropItemId).actor or 0
		local targetObj = AIFunctionMgr:getActorByObjId(obj, targetId)
		local itemId = targetObj and targetObj.GetItemId and targetObj:GetItemId() or 0
		local itemNum = 0

		if ActorComponentCallModule then
			itemNum = ActorComponentCallModule(targetObj, "DropItemComponent", "getDropItemNum") or 0
		else
			itemNum = targetObj and targetObj.getDropItemNum and targetObj:getDropItemNum() or 0
		end

		controller.bb.set(controller.subparam.out_Itemid, itemId)
		controller.bb.set(controller.subparam.out_Itemnum, itemNum)

		if AIFunctionMgr:checkPutItem(obj, itemId, itemNum) then
			AIFunctionMgr:playSound(obj, "npc.pick", 1, 1, 2)
			AIFunctionMgr:pickItem(obj, targetObj)

			return controller.success()
		end

		return controller.fail()
	end
}
