return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local sleepstate = AIFunctionMgr:isSleeping(obj)

		if sleepstate then
			return controller.fail()
		else
			return controller.success()
		end
	end
}
