return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local bedpos = {
			y = 0,
			z = 0,
			x = 0
		}

		if obj:getObjType() == OBJ_TYPE_DESERTVILLAGER then
			bedpos.x, bedpos.y, bedpos.z = AIFunctionMgr:getDesertBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
		elseif obj:getObjType() == OBJ_TYPE_FISHINGVILLAGER or obj:getObjType() == OBJ_TYPE_FISHERMAN then
			bedpos.x, bedpos.y, bedpos.z = AIFunctionMgr:getFishingVillageBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
		else
			bedpos.x, bedpos.y, bedpos.z = AIFunctionMgr:getBedBindPos(obj, bedpos.x, bedpos.y, bedpos.z)
		end

		controller.bb.set(controller.subparam.bb_bedpos, bedpos)

		return controller.success()
	end
}
