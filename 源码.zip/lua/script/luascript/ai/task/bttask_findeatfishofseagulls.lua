return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local mobId = controller.subparam.mobId
		local searchRange = controller.subparam.searchRange
		local flag = false
		local posX = 0
		local posY = 0
		local posZ = 0
		local targetObjID = 0
		flag, targetObjID, posX, posY, posZ = AIFunctionMgr:GetNearestActorPos(obj, mobId, targetObjID, 2, searchRange, 0, 0, 0)

		if flag then
			local mob = AIFunctionMgr:getActorByObjId(obj, targetObjID)

			if mob then
				local flag = false
				local posX = 0
				local posY = 0
				local posZ = 0
				flag, posX, posY, posZ = AIFunctionMgr:GetNearestBlockPos(mob, 1192, 16, 0, 0, 0)

				if flag then
					local targetPos = WCoord()
					targetPos.x = posX
					targetPos.y = posY
					targetPos.z = posZ
					local disPos = mob:getLocoMotion():getPosition() - BlockBottomCenter(targetPos)
					local dist = disPos:length()

					if dist <= BLOCK_SIZE * 1.5 then
						local rt_blockpos = controller.subparam.result_blockpos

						if rt_blockpos then
							local okgg = controller.bb.set(controller.subparam.bbkey_evictedobj, targetObjID)
							local ok = controller.bb.set(rt_blockpos, {
								x = posX,
								y = posY,
								z = posZ
							})

							if not ok then
								return controller.fail()
							end
						end

						return controller.success()
					end
				end
			end
		end

		return controller.fail()
	end
}
