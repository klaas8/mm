return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local bolRoundPlayer = controller.bb.get(controller.subparam.bb_roundPlayer)

		controller.bb.set("bb_roundPlayer", bolRoundPlayer)

		return controller.success()
	end
}
