if not BTClass then
	assert(false)

	return
end

local BTBlackboardClass = BTClass:Class("BTBlackboard")

function BTBlackboardClass:constructor(btreeid, defid, cfg, bbname, blackboard)
	self.btreeid = btreeid
	self.bbname = bbname
	self.this = blackboard
	self.timerkeys = {}
	self.keyname = {}
	self.defid = defid

	if cfg.iscfgs then
		self:LoadDatas(defid, cfg.data)
	else
		self:LoadData(defid, cfg)
	end

	self.cach = {}
	self.setData = {}
	self.needSave = false
end

function BTBlackboardClass:ClearCache()
	self.cach = {}
	self.setData = {}
end

function BTBlackboardClass:destructor()
	local this = self.this

	for _, key in ipairs(self.timerkeys) do
		self:DeletTimer(key)
	end

	self.keyname = self.keyname or {}

	for k, v in pairs(self.keyname) do
		local ok, luadata = this:GetDataLua(k, nil)

		if luadata then
			local valtype = luadata:GetType()

			if valtype == BTLuaDataType_Area then
				local ok, oldvalue = BTDataDecodeLuaData(luadata)

				if oldvalue and oldvalue.areaid > 0 then
					self:Decrement(SSClassVar.VARTYPE.AREAINS, oldvalue.areaid)
				end
			elseif valtype == BTLuaDataType_ArrayArea then
				local arr = self:GetData(k)

				if arr then
					for i = 1, #arr do
						if arr[i].areaid and arr[i].areaid > 0 then
							self:Decrement(SSClassVar.VARTYPE.AREAINS, arr[i].areaid)
						end
					end
				end
			end
		end
	end

	self.btreeid = nil
	self.bbname = nil
	self.this = nil
	self.timerkeys = {}
	self.keyname = {}
end

function BTBlackboardClass:LoadData(defid, cfg)
	if type(cfg) ~= "table" then
		return false
	end

	local treeid = cfg.treeid
	local bbinfo = BehaviorTree_GetTempBB(treeid)

	if bbinfo then
		self.this:Insert(bbinfo.bb)

		for k, value in pairs(bbinfo.keyname) do
			self.keyname[k] = value
		end

		for index, value in ipairs(bbinfo.timerkeys) do
			table.insert(self.timerkeys, value)
		end

		for _, key in ipairs(bbinfo.timerkeys) do
			local ok, luadata = self.this:GetDataLua(key, nil)

			if ok and luadata then
				local name = bbinfo.keyname[key]
				local timerid = BTService:CreateTimer(name) or 0

				luadata:SetValue_Timer(timerid)
			end
		end
	else
		if treeid then
			local bbinf = {}
			local tempbb = BTCreator:CreateTempBlackboard()
			local timerkeys = {}
			local keyname = {}

			for _, cell in ipairs(cfg) do
				local key = cell.key
				local bbtype = AIDefine.BTDataTypeToBTLuaDataType[cell.type] or cell.type
				local value = cell.value
				local name = cell.name

				if type(key) == "string" and type(bbtype) == "number" then
					local ret = self:CreateBBData(tempbb, key, bbtype, value, name)

					if not ret then
						print("BT ERROR : blackboard load failed! key=" .. tostring(key) .. ", type=" .. tostring(bbtype))
					elseif value then
						self:SetBBData(tempbb, key, value, true)
					end

					if bbtype == BTLuaDataType_Timer then
						table.insert(timerkeys, key)
						table.insert(self.timerkeys, key)
					end

					keyname[key] = name
					self.keyname[key] = name
				end
			end

			self.this:Insert(tempbb)

			bbinf.bb = tempbb
			bbinf.keyname = keyname
			bbinf.timerkeys = timerkeys

			BehaviorTree_AddTempBB(treeid, bbinf)
		else
			for _, cell in ipairs(cfg) do
				local key = cell.key
				local bbtype = AIDefine.BTDataTypeToBTLuaDataType[cell.type] or cell.type
				local value = cell.value
				local name = cell.name

				if type(key) == "string" and type(bbtype) == "number" then
					local ret = self:CreateData(key, bbtype, value, name)

					if not ret then
						print("BT ERROR : blackboard load failed! key=" .. tostring(key) .. ", type=" .. tostring(bbtype))
					elseif value then
						self:SetData(key, value)
					end

					if bbtype == BTLuaDataType_Timer then
						table.insert(self.timerkeys, key)
					end

					self.keyname[key] = name
				end
			end
		end

		if defid then
			local bbinf = {}
			local tempbb = BTCreator:CreateTempBlackboard()

			tempbb:AIEditInitByBTBlackboard(self.this)

			bbinf.bb = tempbb
			bbinf.keyname = self.keyname[key]
			bbinf.timerkeys = self.timerkeys

			BehaviorTree_AddTempBB(defid, bbinf)
		end
	end

	if defid then
		local files = BehaviorTree_GetChildBBFiles(defid)

		if files then
			for index, value in ipairs(files) do
				local ccfg = _G.BBManager:LoadAIEditConfig(value.filename)

				if ccfg then
					ccfg.treeid = value.treeid

					self:LoadData(nil, ccfg)
				end
			end
		end
	end
end

function BTBlackboardClass:LoadDatas(defid, cfgs)
	if type(cfgs) ~= "table" then
		return false
	end

	for _, cfg in ipairs(cfgs) do
		local loadtype = self:LoadData(nil, cfg)
	end

	if defid then
		local files = BehaviorTree_GetChildBBFiles(defid)

		if files then
			for index, value in ipairs(files) do
				local ccfg = _G.BBManager:LoadAIEditConfig(value.filename)

				if ccfg then
					ccfg.treeid = value.treeid

					self:LoadData(nil, ccfg)
				end
			end
		end
	end

	return true
end

function BTBlackboardClass:Increment(type, varid)
	if not type or not varid then
		return
	end

	if type == SSClassVar.VARTYPE.AREAINS then
		local SSVarPool = SSMgrResource and SSMgrResource:GetVarPoolIns()
		local ssvar = SSVarPool and SSVarPool:GetUnique(type, varid)

		if ssvar then
			ssvar:Increment()
		end
	end
end

function BTBlackboardClass:Decrement(type, varid)
	if not type or not varid then
		return
	end

	if type == SSClassVar.VARTYPE.AREAINS then
		local SSVarPool = SSMgrResource and SSMgrResource:GetVarPoolIns()
		local ssvar = SSVarPool and SSVarPool:GetUnique(type, varid)

		if ssvar then
			ssvar:Decrement()
		end
	end
end

function BTBlackboardClass:CreateBBData(bb, key, valtype, value, name)
	local this = bb

	if not this or not this.CreateData then
		return false
	end

	local luadata = this:GetTempLuaData()

	if not luadata then
		return false
	end

	local ok = BTDataEncodeLuaData(luadata, valtype, value, true, name)
	ok = ok and this:CreateData(key, luadata)

	if not ok then
		print("BT ERROR! blackboard create bb data failed! key=" .. tostring(key) .. ", valtype=" .. tostring(valtype) .. ", value=", value)
	end

	return ok
end

function BTBlackboardClass:CreateData(key, valtype, value, name)
	return self:CreateBBData(self.this, key, valtype, value, name)
end

function BTBlackboardClass:DestroyData(key)
	local this = self.this

	if this and this.DestroyData then
		self:DeletTimer(key)

		return this:DestroyData(key)
	end

	return false
end

function BTBlackboardClass:DeletTimer(key)
	local this = self.this

	if this then
		local ok, luadata = this:GetDataLua(key, nil)

		if ok and luadata then
			local valtype = luadata:GetType()

			if valtype == BTLuaDataType_Timer then
				local timer = luadata:GetValue_Timer()
				local timerid = timer._timerid

				BTService:DeleteTimer(timerid)
			end
		end
	end
end

function BTBlackboardClass:GetName(key)
	return self.keyname[key]
end

function BTBlackboardClass:GetGroupRandomValue(key)
	local this = self.this

	if not this then
		return nil
	end

	local ok, luadata = this:GetDataLua(key, nil)

	if not ok then
		return nil
	end

	if not luadata then
		print("BT ERROR! blackboard get GetGroupRandomValue failed! -1- key=" .. tostring(key))

		return nil
	end

	local lenth = self:GetGroupDataSize(luadata)

	if lenth <= 0 then
		return nil
	end

	local rand = tostring(os.time()):reverse():sub(1, 7)

	math.randomseed(rand)

	local index = math.random(1, lenth)

	return self:GetGroupDataByIndex(key, index)
end

function BTBlackboardClass:GetGroupDataByIndex(key, index)
	local this = self.this

	if not this then
		return nil
	end

	local ok, luadata = this:GetDataLua(key, nil)

	if not ok then
		return nil
	end

	if not luadata then
		print("BT ERROR! blackboard get GetGroupRandomValue failed! -1- key=" .. tostring(key))

		return nil
	end

	return self:GetGroupData(luadata, index)
end

local cjson = require("cjson")
local time = os.time

function BTBlackboardClass:TaskSaveBBData()
	local nowTime = time()

	if self.lastTime == nil then
		self.lastTime = nowTime
	end

	if nowTime < self.lastTime + 30 then
		return
	end

	self.lastTime = nowTime

	self:SaveBBData()
end

function BTBlackboardClass:SaveBBData()
	if self.needSave and self.defid ~= nil then
		local str = cjson.encode(self.setData)

		self.this:SetByString(str)

		self.setData = {}
		self.needSave = false
	end
end

function BTBlackboardClass:SetBBData(bb, key, value, isInit)
	local this = bb

	if not this then
		return false
	end

	local ok, luadata = this:GetDataLua(key, nil)

	if not ok then
		return false
	end

	if luadata then
		local valtype = luadata:GetType()

		if valtype == BTLuaDataType_Bool then
			if type(value) ~= "boolean" then
				return false
			end
		elseif valtype == BTLuaDataType_Number then
			if type(value) ~= "number" then
				return false
			end
		elseif valtype == BTLuaDataType_String and type(value) ~= "string" then
			return false
		end
	end

	if self.defid ~= nil and not isInit then
		if self.cach == nil then
			self.cach = {}
		end

		if self.setData == nil then
			self.setData = {}
		end

		self.cach[key] = value
		self.setData[key] = value
		self.needSave = true
		local tree = self.this:GetBtree()

		if tree then
			tree:bbChange(key)
		end

		return true
	end

	if not luadata then
		print("BT ERROR! blackboard set bb data failed! -1- key=" .. tostring(key) .. ", value=", value)

		return false
	end

	local valtype = luadata:GetType()
	local oldvalue = nil

	if valtype == BTLuaDataType_Area then
		ok, oldvalue = BTDataDecodeLuaData(luadata)
	end

	ok = BTDataEncodeLuaData(luadata, valtype, value)

	if not ok then
		print("BT ERROR! blackboard set bb data failed! -2- key=" .. tostring(key) .. ", valtype=" .. tostring(valtype) .. ", value=", value)

		return false
	end

	ok = this:SetDataLua(key, luadata)

	if not ok then
		print("BT ERROR! blackboard set bb data failed! -3- key=" .. tostring(key) .. ", valtype=" .. tostring(valtype) .. ", value=", value)

		return false
	end

	if valtype == BTLuaDataType_Area then
		local areaid = 0

		if type(value) == "table" then
			if value.areaid then
				areaid = value.areaid or 0
			end
		elseif type(value) == "number" then
			areaid = value
		end

		if oldvalue and oldvalue.areaid > 0 then
			if oldvalue.areaid == areaid then
				return ok
			end

			self:Decrement(SSClassVar.VARTYPE.AREAINS, oldvalue.areaid)
		end

		if areaid > 0 then
			self:Increment(SSClassVar.VARTYPE.AREAINS, areaid)
		end
	end

	return ok
end

function BTBlackboardClass:SetData(key, value)
	return self:SetBBData(self.this, key, value)
end

function BTBlackboardClass:SetGroupDataByIndex(key, index, value)
	local this = self.this

	if not this then
		return false
	end

	local ok, luadata = this:GetDataLua(key, nil)

	if not ok then
		return false
	end

	if not luadata then
		print("BT ERROR! blackboard set bb SetGroupDataByIndex failed! -1- key=" .. tostring(key) .. ",index = ", index, ", value=", value)

		return false
	end

	local valtype = luadata:GetType()
	local oldvalue = nil

	if valtype == BTLuaDataType_ArrayArea then
		oldvalue = self:GetGroupData(luadata, index)
	end

	ok = self:SetGroupData(luadata, index, value)

	if not ok then
		print("BT ERROR! blackboard set bb SetGroupDataByIndex failed! -1- key=" .. tostring(key) .. ",index = ", index, ", value=", value)

		return false
	end

	ok = this:SetDataLua(key, luadata)

	if not ok then
		print("BT ERROR! blackboard set bb SetGroupDataByIndex failed! -1- key=" .. tostring(key) .. ",index = ", index, ", value=", value)

		return false
	end

	if self.cach[key] ~= nil then
		self.cach[key] = nil
	end

	if valtype == BTLuaDataType_ArrayArea then
		local areaid = 0

		if type(value) == "table" then
			if value.areaid then
				areaid = value.areaid or 0
			end
		elseif type(value) == "number" then
			areaid = value
		end

		if oldvalue and oldvalue.areaid > 0 then
			if oldvalue.areaid == areaid then
				return ok
			end

			self:Decrement(SSClassVar.VARTYPE.AREAINS, oldvalue.areaid)
		end

		if areaid > 0 then
			self:Increment(SSClassVar.VARTYPE.AREAINS, areaid)
		end
	end

	return ok
end

local function GetGroupDataArrayNumber(luadata, index)
	local value = luadata:GetValue_ArrayNumber_ByIndex(index - 1)

	return value
end

local function GetGroupDataArrayItem(luadata, index)
	local value = luadata:GetValue_ArrayItem_ByIndex(index - 1)

	if value then
		local itemid = value and value._itemid or 0
		local num = value and value._num or 1
		local isgroup = value and value._isgroup and true or false
		local result = {
			itemid = itemid,
			num = num,
			isgroup = isgroup
		}

		return result
	end
end

local function GetGroupDataArrayObject(luadata, index)
	local value = luadata:GetValue_ArrayObject_ByIndex(index - 1)

	if value then
		local objid = value and value._objid or 0
		local result = {
			objid = objid
		}

		return result
	end
end

local function GetGroupDataArrayString(luadata, index)
	if luadata.Get_ArrStringSize then
		local size = luadata:Get_ArrStringSize()

		if size > index - 1 then
			local result = luadata:Get_ArrStringByIndex(index - 1)
			result = result or ""

			return result
		end
	else
		local arr = luadata:GetValue_ArrString()

		if arr then
			local size = arr._size

			if size > index - 1 then
				local result = nil

				if arr._arr[index - 1] then
					if arr._arr[index - 1]._str then
						result = arr._arr[index - 1]._str
					else
						result = arr._arr[index - 1]
					end
				else
					result = ""
				end

				return result
			end
		end
	end
end

local function GetGroupDataArrayBool(luadata, index)
	local value = luadata:GetValue_ArrayBool_ByIndex(index - 1)

	return value
end

local function GetGroupDataArrayPlayer(luadata, index)
	local value = luadata:GetValue_ArrayPlayer_ByIndex(index - 1)

	if value then
		local result = {
			uin = value._uin or 0
		}

		return result
	end
end

local function GetGroupDataArrayVector3(luadata, index)
	local value = luadata:GetValue_ArrayVector3_ByIndex(index - 1)

	if value then
		local result = {
			x = value._x or 0,
			y = value._y or 0,
			z = value._z or 0
		}

		return result
	end
end

local function GetGroupDataArrayArea(luadata, index)
	local value = luadata:GetValue_ArrayArea_ByIndex(index - 1)

	if value then
		local result = {
			areaid = value._areaid or 0
		}

		return result
	end
end

local function GetGroupDataArrayActorType(luadata, index)
	local value = luadata:GetValue_ArrayType_ByIndex(index - 1)

	if value then
		local result = {
			actorid = value._type or 0
		}

		return result
	end
end

local function GetGroupDataArrayBlockType(luadata, index)
	local value = luadata:GetValue_ArrayType_ByIndex(index - 1)

	if value then
		local result = {
			blockid = value._type or 0
		}

		return result
	end
end

local function GetGroupDataArrayItemType(luadata, index)
	local value = luadata:GetValue_ArrayType_ByIndex(index - 1)

	if value then
		local result = {
			itemid = value._type or 0
		}

		return result
	end
end

local function GetGroupDataArrayEffectType(luadata, index)
	local value = luadata:GetValue_ArrayType_ByIndex(index - 1)

	if value then
		local result = {
			itemid = value._type or 0
		}

		return result
	end
end

local function GetGroupDataArrayArrayTimer(luadata, index)
	local value = luadata:GetValue_ArrayTimer_ByIndex(index - 1)

	if value then
		local result = {
			timerid = value._timerid or 0
		}

		return result
	end
end

local GetGroupDataFuns = {
	[BTLuaDataType_ArrayNumber] = GetGroupDataArrayNumber,
	[BTLuaDataType_ArrayItem] = GetGroupDataArrayItem,
	[BTLuaDataType_ArrayObject] = GetGroupDataArrayObject,
	[BTLuaDataType_ArrayString] = GetGroupDataArrayString,
	[BTLuaDataType_ArrayBool] = GetGroupDataArrayBool,
	[BTLuaDataType_ArrayPlayer] = GetGroupDataArrayPlayer,
	[BTLuaDataType_ArrayVector3] = GetGroupDataArrayVector3,
	[BTLuaDataType_ArrayArea] = GetGroupDataArrayArea,
	[BTLuaDataType_ArrayActorType] = GetGroupDataArrayActorType,
	[BTLuaDataType_ArrayBlockType] = GetGroupDataArrayBlockType,
	[BTLuaDataType_ArrayItemType] = GetGroupDataArrayItemType,
	[BTLuaDataType_ArrayEffectType] = GetGroupDataArrayEffectType,
	[BTLuaDataType_ArrayTimer] = GetGroupDataArrayArrayTimer
}

local function BTBlackboardSetGroupDataArrayNumber(luadata, index, value)
	local arr = luadata:GetValue_ArrNumber()
	local size = arr._size

	if size < index then
		local nums = {}

		for i = 1, size do
			local num = GetGroupDataArrayNumber(luadata, i - 1)

			table.insert(nums, num)
		end

		luadata:SetValue_ArrayNumber(index)

		for i = 1, #nums do
			luadata:SetValue_ArrayNumber_ByIndex(i - 1, nums[i])
		end
	end

	if type(value) == "number" then
		return luadata:SetValue_ArrayNumber_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayItem(luadata, index, value)
	local size = arr._size

	if size < index then
		local items = {}

		for i = 1, size do
			local num = GetGroupDataArrayItem(luadata, i - 1)

			table.insert(items, num)
		end

		luadata:SetValue_ArrayItem(index)

		for i = 1, #items do
			luadata:SetValue_ArrayItem_ByIndex(index - 1, items[i].itemid, items[i].num, items[i].isgroup)
		end
	end

	if type(value) == "table" and value.itemid and value.num then
		local isgroup = false

		if value.isgroup ~= nil then
			isgroup = value.isgroup
		end

		return luadata:SetValue_ArrayItem_ByIndex(index - 1, value.itemid, value.num, isgroup)
	end
end

local function BTBlackboardSetGroupDataArrObject(luadata, index, value)
	local arr = luadata:GetValue_ArrObject()
	local size = arr._size

	if size < index then
		local objs = {}

		for i = 1, size do
			local obj = GetGroupDataArrayObject(luadata, i)

			table.insert(objs, obj)
		end

		luadata:SetValue_ArrayObject(index)

		for i = 1, #objs do
			luadata:SetValue_ArrayObject_ByIndex(index - 1, objs[i].objid)
		end
	end

	if type(value) == "table" and value.objid then
		return luadata:SetValue_ArrayObject_ByIndex(index - 1, value.objid)
	elseif type(value) == "table" and value.actor then
		return luadata:SetValue_ArrayObject_ByIndex(index - 1, value.actor)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayObject_ByIndex(index - 1, value)
	end
end

local function BTBlackboardGetGroupDataStrings(luadata, size)
	local strings = {}

	for i = 1, size do
		local str = GetGroupDataArrayString(luadata, i)

		table.insert(strings, str)
	end

	return strings
end

local function BTBlackboardSetGroupDataStrings(luadata, strs)
	for i = 1, #strs do
		luadata:SetValue_ArrayString_ByIndex(i - 1, strs[i])
	end
end

local function BTBlackboardSetGroupDataArrayString(luadata, index, value)
	if luadata.Get_ArrStringSize then
		local size = luadata:Get_ArrStringSize()

		if size < index then
			local strs = BTBlackboardGetGroupDataStrings(luadata, size)

			luadata:SetValue_ArrayString(index)
			BTBlackboardSetGroupDataStrings(luadata, strs)
		end
	else
		local arr = luadata:GetValue_ArrString()
		local size = arr._size

		if size < index then
			local strs = BTBlackboardGetGroupDataStrings(luadata, size)

			luadata:SetValue_ArrayString(index)
			BTBlackboardSetGroupDataStrings(luadata, strs)
		end
	end

	if type(value) == "string" and string.len(value) < 256 then
		return luadata:SetValue_ArrayString_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayBool(luadata, index, value)
	local arr = luadata:GetValue_ArrayBool()
	local size = arr._size

	if size < index then
		local bs = {}

		for i = 1, size do
			local b = GetGroupDataArrayBool(luadata, i)

			table.insert(bs, b)
		end

		luadata:SetValue_ArrayBool(index)

		for i = 1, #bs do
			luadata:SetValue_ArrayBool_ByIndex(i - 1, bs[i])
		end
	end

	if type(value) == "boolean" then
		return luadata:SetValue_ArrayBool_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayPlayer(luadata, index, value)
	local arr = luadata:GetValue_ArrPlayer()
	local size = arr._size

	if size < index then
		local players = {}

		for i = 1, size do
			local player = GetGroupDataArrayPlayer(luadata, i)

			table.insert(players, player)
		end

		luadata:SetValue_ArrayPlayer(index)

		for i = 1, #players do
			luadata:SetValue_ArrayPlayer_ByIndex(i - 1, players[i].uin)
		end
	end

	if type(value) == "table" and value.uin then
		return luadata:SetValue_ArrayPlayer_ByIndex(index - 1, value.uin)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayPlayer_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayVector3(luadata, index, value)
	local arr = luadata:GetValue_ArrVecror3()
	local size = arr._size

	if size < index then
		local poss = {}

		for i = 1, size do
			local pos = GetGroupDataArrayVector3(luadata, i)

			table.insert(poss, pos)
		end

		luadata:SetValue_ArrayVector3(index)

		for i = 1, #poss do
			luadata:SetValue_ArrayVector3_ByIndex(i - 1, poss[i].x, poss[i].y, poss[i].z)
		end
	end

	if type(value) == "table" and value.x and value.y and value.z then
		local x = tonumber(value.x) or 0
		local y = tonumber(value.y) or 0
		local z = tonumber(value.z) or 0

		return luadata:SetValue_ArrayVector3_ByIndex(index - 1, x, y, z)
	end
end

local function BTBlackboardSetGroupDataArrayArea(luadata, index, value)
	local arr = luadata:GetValue_ArrayArea()
	local size = arr._size

	if size < index then
		local areas = {}

		for i = 1, size do
			local area = GetGroupDataArrayArea(luadata, i)

			table.insert(areas, area)
		end

		luadata:SetValue_ArrayArea(index)

		for i = 1, #areas do
			luadata:SetValue_ArrayArea_ByIndex(i - 1, areas[i].areaid)
		end
	end

	if type(value) == "table" and value.areaid then
		return luadata:SetValue_ArrayArea_ByIndex(index - 1, value.areaid)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayArea_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayActorType(luadata, index, value)
	local arr = luadata:GetValue_ArrayType()
	local size = arr._size

	if size < index then
		local actortypes = {}

		for i = 1, size do
			local actortype = GetGroupDataArrayActorType(luadata, i)

			table.insert(actortypes, actortype)
		end

		luadata:SetValue_ArrayActorType(index)

		for i = 1, #actortypes do
			luadata:SetValue_ArrayType_ByIndex(i - 1, actortypes[i].actorid)
		end
	end

	if type(value) == "table" and value.actorid then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value.actorid)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value)
	elseif type(value) == "string" then
		value = BTService:ResidToId(value)

		if value then
			return luadata:SetValue_ArrayType_ByIndex(index - 1, value)
		else
			return false
		end
	end
end

local function BTBlackboardSetGroupDataArrayBlockType(luadata, index, value)
	local arr = luadata:GetValue_ArrayType()
	local size = arr._size

	if size < index then
		local blocktypes = {}

		for i = 1, size do
			local blocktype = GetGroupDataArrayBlockType(luadata, i)

			table.insert(blocktypes, blocktype)
		end

		luadata:SetValue_ArrayBlockType(index)

		for i = 1, #blocktypes do
			luadata:SetValue_ArrayType_ByIndex(i - 1, blocktypes[i].blockid)
		end
	end

	if type(value) == "table" and value.blockid then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value.blockid)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayItemType(luadata, index, value)
	local arr = luadata:GetValue_ArrayType()
	local size = arr._size

	if size < index then
		local itemtypes = {}

		for i = 1, size do
			local itemtype = GetGroupDataArrayItemType(luadata, i)

			table.insert(itemtypes, itemtype)
		end

		luadata:SetValue_ArrayItemType(index)

		for i = 1, #itemtypes do
			luadata:SetValue_ArrayType_ByIndex(i - 1, itemtypes[i].itemid)
		end
	end

	if type(value) == "table" and value.itemid then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value.itemid)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayEffectType(luadata, index, value)
	local arr = luadata:GetValue_ArrayType()
	local size = arr._size

	if size < index then
		local effectTypes = {}

		for i = 1, size do
			local effectType = GetGroupDataArrayEffectType(luadata, index)

			table.insert(effectTypes, effectType)
		end

		luadata:SetValue_ArrayEffectType(index)

		for i = 1, #effectTypes do
			luadata:SetValue_ArrayType_ByIndex(i - 1, effectTypes[i].itemid)
		end
	end

	if type(value) == "table" and value.effectid then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value.itemid)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayType_ByIndex(index - 1, value)
	end
end

local function BTBlackboardSetGroupDataArrayTimer(luadata, index, value)
	local arr = luadata:GetValue_ArrayTimer()
	local size = arr._size

	if size < index then
		local timers = {}

		for i = 1, size do
			local timer = GetGroupDataArrayArrayTimer(luadata, index)

			table.insert(timers, timer)
		end

		luadata:SetValue_ArrayTimer(index)

		for i = 1, #timers do
			luadata:SetValue_ArrayTimer_ByIndex(i - 1, timers[i].timerid)
		end
	end

	if type(value) == "table" and value.timerid then
		return luadata:SetValue_ArrayTimer_ByIndex(index - 1, value.timerid)
	elseif type(value) == "number" then
		return luadata:SetValue_ArrayTimer_ByIndex(index - 1, value)
	end
end

local SetGroupDataFuns = {
	[BTLuaDataType_ArrayNumber] = BTBlackboardSetGroupDataArrayNumber,
	[BTLuaDataType_ArrayItem] = BTBlackboardSetGroupDataArrayItem,
	[BTLuaDataType_ArrayObject] = BTBlackboardSetGroupDataArrObject,
	[BTLuaDataType_ArrayString] = BTBlackboardSetGroupDataArrayString,
	[BTLuaDataType_ArrayBool] = BTBlackboardSetGroupDataArrayBool,
	[BTLuaDataType_ArrayPlayer] = BTBlackboardSetGroupDataArrayPlayer,
	[BTLuaDataType_ArrayVector3] = BTBlackboardSetGroupDataArrayVector3,
	[BTLuaDataType_ArrayArea] = BTBlackboardSetGroupDataArrayArea,
	[BTLuaDataType_ArrayActorType] = BTBlackboardSetGroupDataArrayActorType,
	[BTLuaDataType_ArrayBlockType] = BTBlackboardSetGroupDataArrayBlockType,
	[BTLuaDataType_ArrayItemType] = BTBlackboardSetGroupDataArrayItemType,
	[BTLuaDataType_ArrayEffectType] = BTBlackboardSetGroupDataArrayEffectType,
	[BTLuaDataType_ArrayTimer] = BTBlackboardSetGroupDataArrayTimer
}

function BTBlackboardClass:SetGroupData(luadata, index, value)
	local valtype = luadata:GetType()
	local fun = SetGroupDataFuns[valtype]

	if fun then
		return fun(luadata, index, value)
	end

	return false
end

local function GetGroupSizeArrayNumber(luadata)
	local arr = luadata:GetValue_ArrNumber()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayItem(luadata)
	local arr = luadata:GetValue_ArrItem()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayObject(luadata)
	local arr = luadata:GetValue_ArrObject()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayString(luadata)
	if luadata.Get_ArrStringSize then
		return luadata:Get_ArrStringSize()
	else
		local arr = luadata:GetValue_ArrString()

		if arr then
			return arr._size
		end
	end

	return 0
end

local function GetGroupSizeArrayBool(luadata)
	local arr = luadata:GetValue_ArrayBool()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayPlayer(luadata)
	local arr = luadata:GetValue_ArrPlayer()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayVector3(luadata)
	local arr = luadata:GetValue_ArrVecror3()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayArea(luadata)
	local arr = luadata:GetValue_ArrayArea()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayActorType(luadata)
	local arr = luadata:GetValue_ArrayType()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayBlockType(luadata)
	local arr = luadata:GetValue_ArrayType()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayItemType(luadata)
	local arr = luadata:GetValue_ArrayType()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayEffectType(luadata)
	local arr = luadata:GetValue_ArrayType()

	if arr then
		return arr._size
	end

	return 0
end

local function GetGroupSizeArrayTimer(luadata)
	local arr = luadata:GetValue_ArrayTimer()

	if arr then
		return arr._size
	end

	return 0
end

local GetGroupDataSizeFuns = {
	[BTLuaDataType_ArrayNumber] = GetGroupSizeArrayNumber,
	[BTLuaDataType_ArrayItem] = GetGroupSizeArrayItem,
	[BTLuaDataType_ArrayObject] = GetGroupSizeArrayObject,
	[BTLuaDataType_ArrayString] = GetGroupSizeArrayString,
	[BTLuaDataType_ArrayBool] = GetGroupSizeArrayBool,
	[BTLuaDataType_ArrayPlayer] = GetGroupSizeArrayPlayer,
	[BTLuaDataType_ArrayVector3] = GetGroupSizeArrayVector3,
	[BTLuaDataType_ArrayArea] = GetGroupSizeArrayArea,
	[BTLuaDataType_ArrayActorType] = GetGroupSizeArrayActorType,
	[BTLuaDataType_ArrayBlockType] = GetGroupSizeArrayBlockType,
	[BTLuaDataType_ArrayItemType] = GetGroupSizeArrayItemType,
	[BTLuaDataType_ArrayEffectType] = GetGroupSizeArrayEffectType,
	[BTLuaDataType_ArrayTimer] = GetGroupSizeArrayTimer
}

function BTBlackboardClass:GetGroupDataSize(luadata)
	local valtype = luadata:GetType()
	local size = 0
	local fun = GetGroupDataSizeFuns[valtype]

	if fun then
		return fun(luadata)
	end

	return size
end

function BTBlackboardClass:GetGroupData(luadata, index)
	local valtype = luadata:GetType()
	local fun = GetGroupDataFuns[valtype]

	if fun then
		return fun(luadata, index)
	end

	return nil
end

function BTBlackboardClass:InitCach(key, value)
	if self.defid ~= nil then
		self.cach[key] = value
	end
end

function BTBlackboardClass:GetData(key)
	local this = self.this

	if not this then
		return nil
	end

	if self.defid ~= nil and self.cach[key] ~= nil then
		return self.cach[key]
	end

	local ok, luadata = this:GetDataLua(key, nil)

	if not ok then
		return nil
	end

	if not luadata then
		print("BT ERROR! blackboard get bb data failed! -1- key=" .. tostring(key))

		return nil
	end

	local ok, data = BTDataDecodeLuaData(luadata)

	if not ok then
		print("BT ERROR! blackboard get bb data failed! -2- key=" .. tostring(key) .. ", valtype=" .. tostring(luadata:GetType()))

		return nil
	end

	self:InitCach(key, data)

	return data
end

function BTBlackboardClass:GetSize()
	local this = self.this

	if not this then
		return 0
	end

	return this:DataSize()
end

function BTBlackboardClass:GetDataByIndex(index)
	local this = self.this

	if not this then
		return nil
	end

	local ok, luadata = this:GetDataLuaByIndex(index, nil)

	if not ok then
		return nil
	end

	if not luadata then
		print("BT ERROR! blackboard get bb data failed! -1- key=" .. tostring(index))

		return nil
	end

	local ok, data = BTDataDecodeLuaData(luadata)

	if not ok then
		print("BT ERROR! blackboard get bb data failed! -2- key=" .. tostring(index) .. ", valtype=" .. tostring(luadata:GetType()))

		return nil
	end

	return data
end
