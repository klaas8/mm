local BTService = ClassEx("BTService")
local table = _G.table
local type = _G.type
local ss_list = {
	ObjectLib = "ObjectLib",
	Actor = "SSActor",
	Player = "Player",
	World = "World",
	Mob = "Mob",
	Game = "Game",
	Item = "Item",
	Block = "Block",
	Backpack = "Backpack",
	Graphics = "graphics",
	MiniTimer = "SSMiniTimer2",
	VarLib2 = "SSSVariableLib2",
	Customui = "SSCustomUI",
	ValueGroup = "SSValueGroup",
	Buff = "SSBuff",
	Area = "Area"
}

function BTService:Init()
	self.ssobjs = {}

	for key, service in pairs(ss_list) do
		self.ssobjs[key] = class[service].new()
	end

	self.enumValues = {}
	self.enumStr = {}
	self.componentEnsurePending = {}
	self.m_bSubparamReuseEnabled = GetUGCBTSubparamReuseEnabled() == true
end

function BTService:Release()
	for key, __ in pairs(self.ssobjs) do
		self.ssobjs[key] = nil
	end

	self.tagTemp = nil
	self.componentEnsurePending = nil
end

function BTService:GetSSObj(ssname)
	if not ssname then
		return nil
	end

	local sev = self.ssobjs[ssname]

	if not sev and ssname == "Data" and ServiceEnv then
		self.ssobjs[ssname] = ServiceEnv.Data
		sev = ServiceEnv.Data
	end

	return sev
end

function BTService:ResolveAndEnsureComponent(objectId, cmpName)
	if type(objectId) == "table" then
		objectId = objectId.actor or objectId.uin
	end

	if objectId == nil or type(cmpName) ~= "string" or cmpName == "" then
		return nil, false
	end

	local object = Service and Service.GameObject and Service.GameObject:FindObject(objectId)

	if not object or type(object.GetComponent) ~= "function" then
		return nil, false
	end

	if object:GetComponent(cmpName) then
		return object, true
	end

	local pendingComponents = self.componentEnsurePending

	if not pendingComponents then
		pendingComponents = {}
		self.componentEnsurePending = pendingComponents
	end

	local pendingKey = tostring(objectId) .. "" .. cmpName

	if pendingComponents[pendingKey] then
		return object, false
	end

	pendingComponents[pendingKey] = true
	local ok = pcall(function ()
		if type(object.AddComponent) == "function" then
			return object:AddComponent(cmpName)
		end
	end)
	pendingComponents[pendingKey] = nil

	if ok and object:GetComponent(cmpName) then
		return object, true
	end

	return object, false
end

local BTEnumToParam = {
	[4550009.0] = "5",
	[350003.0] = "2",
	[4550008.0] = "10",
	[350006.0] = "5",
	[350002.0] = "1",
	[4550004.0] = "7",
	[4550003.0] = "6",
	[4550006.0] = "2",
	[4550001.0] = "1",
	[4550005.0] = "8",
	[4550011.0] = "9",
	[4470002.0] = "2",
	[350005.0] = "4",
	[350001.0] = "0",
	[4560002.0] = "1",
	[4560003.0] = "2",
	[4560001.0] = "0",
	[350004.0] = "3",
	[4550007.0] = "3",
	[4550002.0] = "4",
	[4550010.0] = "0",
	[4470001.0] = "1"
}

function BTService:GetEnumValue(enumId)
	if not enumId then
		return
	end

	local enumStr = ""

	if type(enumId) == "string" then
		enumStr = enumId
	else
		enumStr = self.enumStr[enumId]

		if enumStr == nil then
			enumStr = VisualCodeApiProxy:GetEnumInfo(enumId)
			enumStr = enumStr or BTEnumToParam[enumId]
			self.enumStr[enumId] = enumStr
		end

		if not enumStr then
			return
		end
	end

	local enumValue = self.enumValues[enumStr]

	if enumValue == nil then
		local l = utils.split(enumStr, ".")

		if l and #l > 1 then
			enumValue = _G[l[1]][l[2]]
		end

		if type(enumStr) == "string" and enumStr == "true" then
			enumValue = true
		elseif type(enumStr) == "string" and enumStr == "false" then
			enumValue = false
		elseif type(enumStr) == "string" then
			local num = tonumber(enumStr)

			if type(num) == "number" then
				enumValue = num
			end
		end

		self.enumValues[enumStr] = enumValue
	end

	return enumValue
end

function BTService:GetBoolVal(boolVal)
	if type(boolVal) == "boolean" then
		return boolVal
	elseif type(boolVal) == "string" then
		if boolVal == "==" or boolVal == "true" then
			return true
		elseif boolVal == "~=" or boolVal == "false" then
			return false
		end
	end

	return nil
end

function BTService:GetBoolValById(id)
	local newrType = self:GetFactorType(id)
	local result = self:GetBoolVal(newrType)

	if result == nil then
		result = false
	end

	return result
end

function BTService:GetRangeTypeVal(id)
	local newrType = self:GetFactorType(id)
	newrType = newrType or 1

	return newrType
end

function BTService:GetAttrType(attTypeId)
	local result = self:GetEnumValue(attTypeId)

	if result == nil then
		return -1
	end

	return result
end

function BTService:ChangeObjAttr(targetObj, attrType, attrValue, changetType)
	local ret = ErrorCode.FAILED

	if not targetObj then
		return ret
	end

	if not attrType or not changetType then
		return ret
	end

	local ss_obj = self:GetSSObj(targetObj.objType)

	if not ss_obj then
		return ret
	end

	local function getAttrType(attrType_)
		if type(attrType_) ~= "string" then
			return
		end

		local attr = utils.split(attrType_, ".")

		if attr then
			return _G[attr[1]][attr[2]]
		end
	end

	local newAttrType = getAttrType(attrType)

	if not newAttrType then
		return ret
	end

	if changetType == "3" then
		ret = ss_obj:setAtt(targetObj.actor, attrValue, newAttrType)
	else
		local ret_, cur_attr = ss_obj:getAtt(targetObj.actor, newAttrType)

		if ret_ == ErrorCode.OK then
			if changetType == "1" then
				attrValue = cur_attr + attrValue
			elseif changetType == "2" then
				attrValue = cur_attr - attrValue
			end

			ret = ss_obj:setAtt(targetObj.actor, attrValue, newAttrType)
		end
	end

	return ret
end

function BTService:GetFactorType(enumType)
	local str = enumType

	if type(enumType) == "number" then
		if enumType < 50000 then
			return enumType
		end

		str = VisualCodeApiProxy.VCFactorToEnum[enumType]
	end

	if not str then
		str = BTEnumToParam[enumType]

		if not str then
			return
		end
	end

	local l = utils.split(str, ".")

	if l then
		if type(l) == "table" and #l > 1 then
			return _G[l[1]][l[2]]
		else
			return str
		end
	end
end

function BTService:getBuffData(buff)
	local typebuff = type(buff)

	if typebuff == "number" then
		local ssBuff = self:GetSSObj("Buff")
		local ret = ssBuff:isCustomBuff(buff)

		if ret ~= ErrorCode.OK then
			local buffid = math.floor(buff / 1000)
			local bufflv = buff % 10

			return buffid, bufflv
		else
			return buff, 1
		end
	elseif typebuff == "table" then
		local buffid = tonumber(buff.id)
		local bufflv = tonumber(buff.lvl) or 1

		if buffid then
			return buffid, bufflv
		end
	elseif typebuff == "string" and Service and Service.Mod then
		local buffid = Service.Mod:GetCfgIdByAssetId(buff)

		if buffid then
			return buffid, 1
		end
	end
end

function BTService:getAttackDef(fileName)
	if not self.ComboAttackDefs then
		self.ComboAttackDefs = {}
	end

	if self.ComboAttackDefs[fileName] then
		return self.ComboAttackDefs[fileName]
	end

	if type(fileName) == "string" and fileName ~= "" then
		local jsonStr = AIFunctionMgr:loadFileToStr(string.format("json/AttackCfg/%s.json", fileName))

		if type(jsonStr) == "string" and jsonStr ~= "" then
			local luaTable = json2table(jsonStr)

			if type(luaTable) == "table" and next(luaTable) then
				self.ComboAttackDefs[fileName] = luaTable

				return luaTable
			end
		end
	end
end

function BTService:mathAdd(v1, v2)
	if v1 == nil or v2 == nil then
		return nil
	end

	return v1 + v2
end

function BTService:mathSub(v1, v2)
	if v1 == nil or v2 == nil then
		return nil
	end

	return v1 - v2
end

function BTService:mathMultiply(v1, v2)
	if v1 == nil or v2 == nil then
		return nil
	end

	return v1 * v2
end

function BTService:mathDivide(v1, v2)
	if v1 == nil or v2 == nil or v2 == 0 then
		return nil
	end

	return v1 / v2
end

function BTService:dotShort(num, dot)
	if type(num) == "number" then
		dot = dot or 1
		local fmt = "%." .. dot .. "f"
		local str_num = string.format(fmt, num)

		return tonumber(str_num)
	end
end

function BTService:ResidToId(id)
	if type(id) == "string" and Service and Service.Mod then
		id = Service.Mod:GetCfgIdByAssetId(id)
	end

	return id
end

function BTService:GetCustomAssetId(objType, cfgId)
	return Service.Mod:GetCustomAssetId(objType, cfgId)
end

function BTService:GetRandomPos(id)
	if id == nil then
		return nil
	end

	local result, movpos = self:GetSSObj("Area"):getRandomPos(id)

	if result ~= ErrorCode.FAILED then
		return movpos
	end

	local movpos = Service.Area:GetRandomPos(id)

	return movpos
end

function BTService:PosInArea(areaid, pos)
	if areaid == nil or pos == nil then
		return false
	end

	local result = self:GetSSObj("Area"):getAreaCenter(areaid)

	if result ~= ErrorCode.FAILED then
		result = self:GetSSObj("Area"):posInArea(pos, areaid)

		if result == ErrorCode.FAILED then
			return false
		else
			return true
		end
	end

	return Service.Area:PosInArea(areaid, pos)
end

function BTService:GetAreaDebugData(areaid)
	if areaid == nil then
		return ""
	end

	local result, posbeg, posend = self:GetSSObj("Area"):getAreaRectRange(areaid)

	if result ~= ErrorCode.FAILED then
		return "posbeg x:" .. posbeg.x .. ",y:" .. posbeg.y .. ",z:" .. posbeg.z .. ",posend x:" .. posend.x .. ",y:" .. posend.y .. "," .. posend.z
	end

	posbeg, posend = Service.Area:GetAreaRectRange(areaid)

	if posbeg ~= nil and posend ~= nil then
		return "posbeg x:" .. posbeg.x .. ",y:" .. posbeg.y .. ",z:" .. posbeg.z .. ",posend x:" .. posend.x .. ",y:" .. posend.y .. "," .. posend.z
	end

	return ""
end

function BTService:AreaIsExit(areaid)
	if areaid == nil then
		return false
	end

	local result, posbeg, posend = self:GetSSObj("Area"):getAreaRectRange(areaid)

	if result ~= ErrorCode.FAILED then
		return true
	end

	posbeg, posend = Service.Area:GetAreaRectRange(areaid)

	if posbeg ~= nil and posend ~= nil then
		return true
	end

	return false
end

function BTService:GetAreaRectRange(areaid)
	if areaid == nil then
		return nil, nil
	end

	local result, posbeg, posend = self:GetSSObj("Area"):getAreaRectRange(areaid)

	if result ~= ErrorCode.FAILED then
		return posbeg, posend
	end

	posbeg, posend = Service.Area:GetAreaRectRange(areaid)

	return posbeg, posend
end

function BTService:GetObjWithKey(uuid)
	if uuid == nil then
		return nil
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ObjectLib = self:GetSSObj("ObjectLib")
		local ret, val = ObjectLib:getAreaData(uuid)

		if ret == ErrorCode.OK then
			return val
		end

		local ret, val = ObjectLib:getPositionData(uuid)

		if ret == ErrorCode.OK then
			return val
		end

		local ret, val = ObjectLib:getLivingData(uuid)

		if ret == ErrorCode.OK then
			return val
		end

		if math.floor(uuid / 10000000) == 5 then
			local ret, val = ObjectLib:getItemData(uuid)

			if ret == ErrorCode.OK then
				return val
			end
		end

		if math.floor(uuid / 10000000) == 4 then
			return uuid
		end
	end

	local result = Service.GameObject:GetObjInstanceID(uuid)

	if type(result) == "number" and result == uuid then
		return uuid
	elseif type(result) == "table" and result.x ~= nil and result.y ~= nil and result.z ~= nil then
		result.z = math.floor(result.z)
		result.y = math.floor(result.y)
		result.x = math.floor(result.x)
	end

	return result
end

function BTService:GetPositionData(uuid)
	if uuid == nil then
		return nil
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret, val = ObjectLib:getPositionData(uuid)

		if ret == ErrorCode.OK then
			return val
		end
	end

	local result = Service.GameObject:GetObjInstanceID(uuid)

	if type(result) == "number" and result == uuid then
		return
	elseif result.x ~= nil and result.y ~= nil and result.z ~= nil then
		result.z = math.floor(result.z)
		result.y = math.floor(result.y)
		result.x = math.floor(result.x)
	end

	return result
end

function BTService:GetGroupData(uuid, grouptype, controller)
	if uuid == nil then
		return nil
	end

	local result = {}

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() and type(uuid) == "number" then
		local ret, newid = self:GetSSObj("VarLib2"):getLibVar(0, uuid)

		if newid then
			local valueGroup = self:GetSSObj("ValueGroup")
			local code, num = valueGroup:getGrouplength(grouptype, newid)

			if code == ErrorCode.FAILED then
				return nil
			end

			for i = 1, num do
				local retCode, value = valueGroup:getGroupValueByNo(grouptype, newid, i)

				if retCode == ErrorCode.OK then
					table.insert(result, value)
				end
			end

			return result
		end
	end

	if type(uuid) == "string" then
		local num = Service.Data.Array:GetSize(uuid)

		if num > 0 then
			for i = 1, num do
				local value = Service.Data.Array:GetValue(uuid, nil, i)

				if value then
					table.insert(result, value)
				end
			end

			return result
		end

		return deep_copy_table(controller.bb.get(uuid))
	end
end

function BTService:CreateTimer(name)
	if name == nil then
		return nil
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret, timerid = self:GetSSObj("MiniTimer"):createTimer(name)

		if ret == ErrorCode.OK then
			return timerid
		end
	end

	local timerid = Service.Timer:CreateTimer(name)

	return timerid
end

function BTService:DeleteTimer(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret, timerid = self:GetSSObj("MiniTimer"):deleteTimer(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:DeleteTimer(id)
end

function BTService:PauseTimer(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):pauseTimer(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:PauseTimer(id)
end

function BTService:StopTimer(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):stopTimer(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:StopTimer(id)
end

function BTService:StartForwardTimer(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):startForwardTimer(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:StartForwardTimer(id)
end

function BTService:ResumeTimer(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):resumeTimer(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:ResumeTimer(id)
end

function BTService:GetTimerTime(id)
	if id == nil then
		return nil
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret, runtime = self:GetSSObj("MiniTimer"):getTimerTime(id)

		if ret == ErrorCode.OK then
			return runtime
		end

		return
	end

	return Service.Timer:GetTimerTime(id)
end

function BTService:TimerisExist(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):isExist(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:IsExist(id)
end

function BTService:TimerIsPlaying(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):isPlaying(id)

		if ret == ErrorCode.OK then
			return true
		else
			return false
		end
	end

	return Service.Timer:IsPlaying(id)
end

function BTService:TimerIsPause(id)
	if id == nil then
		return false
	end

	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):isPause(id)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Timer:IsPause(id)
end

function BTService:IsUGC3()
	if UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		return true
	end

	if WorldMgr then
		local gameMode = WorldMgr:getGameMode()

		if gameMode == g_WorldType.OWTYPE_SINGLE or gameMode == g_WorldType.OWTYPE_EXTREMITY then
			return true
		end
	end

	return false
end

function BTService:ChangeCustomModel(objid, modelName)
	if not self:IsUGC3() then
		local ss_actor = self:GetSSObj("Actor")
		local ret = ss_actor:changeCustomModel(objid, modelName)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	return Service.Actor:ChangeCustomModel(objid, modelName)
end

function BTService:ShowTimerTips(playersid, timerid, title, isShow)
	if not UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		local ret = self:GetSSObj("MiniTimer"):startForwardTimer(playersid, timerid, title, isShow)

		if ret == ErrorCode.OK then
			return true
		end

		return false
	end

	if isShow then
		return Service.Timer:ShowTimerWnd(playersid, timerid, title)
	else
		return Service.Timer:HideTimerWnd(playersid)
	end
end

function BTService:DealTagToArrayData(tag, needSendDebug, val)
	if tag == nil then
		return nil, ""
	end

	if val == nil then
		val = std.vector_std__string_()
	else
		val:clear()
	end

	local data = Service.Data.Array:DealTagToArrayData(tag, true, nil, val)

	if needSendDebug then
		local size = data:size()
		local debugData = {}

		for i = 0, size - 1 do
			table.insert(debugData, data[i])
		end

		return data, table.concat(debugData, ",")
	end

	return data, ""
end

function BTService:IsXYZ(pos)
	if type(pos) ~= "table" then
		return false
	end

	if type(pos.x) ~= "number" or type(pos.y) ~= "number" or type(pos.z) ~= "number" then
		return false
	end

	return true
end

function BTService:RestoreSavedYaw(actor, taskparam)
	if not taskparam then
		return
	end

	local lastYaw = taskparam.lastYaw
	taskparam.lastYaw = nil

	if not actor or lastYaw == nil then
		return
	end

	local navigator = actor:getNavigator()

	if navigator then
		navigator:clearPathEntity()
	end

	local locoMotion = actor:getLocoMotion()

	if locoMotion and actor:IsMob() then
		local moblocoMotion = tolua.cast(actor:getLocoMotion(), "MobLocomotion")

		if moblocoMotion then
			moblocoMotion:ClearNavigationMoveTarget()
			moblocoMotion:clearTarget()
			moblocoMotion:ClearMotion()
		end
	end
end

local resulttypetokey = {
	[AIDefine.ValueType.Item] = "itemid",
	[AIDefine.ValueType.Player] = "uin",
	[AIDefine.ValueType.Area] = "areaid",
	[AIDefine.ValueType.ActorType] = "actorid",
	[AIDefine.ValueType.BlockType] = "blockid",
	[AIDefine.ValueType.ItemType] = "itemid",
	[AIDefine.ValueType.EffectType] = "effectid",
	[AIDefine.ValueType.Timer] = "timerid"
}

function btget_result(valtype, result)
	if type(result) ~= "table" then
		return result
	end

	if valtype == AIDefine.ValueType.Object or valtype == AIDefine.ValueType.Player then
		local data = result.actor or result.objid or result.uin or result

		return data
	end

	local valkey = resulttypetokey[valtype]

	if valkey and result[valkey] then
		return result[valkey]
	end

	return result
end

local function paramValfun(controller, cparam)
	return cparam.val
end

local function paramEumfun(controller, cparam)
	local enumValue = VisualCodeApiProxy:GetEnumInfo(cparam.val)
	enumValue = enumValue or BTEnumToParam[cparam.val]

	return enumValue
end

local function parameGetValueFun(controller, cparam)
	local result = cparam.func({
		controller = BTSelectControllerForExternal(controller)
	})
	result = btget_result(cparam.valtype, result)

	return result
end

local function parameSetValueFun(controller, cparam)
	if not BTIsSafeControllerEnabled() then
		return cparam
	end

	if type(cparam) ~= "table" or type(cparam.func) ~= "function" then
		return cparam
	end

	if cparam.__safeWrapped then
		return cparam
	end

	local func = cparam.func

	function cparam.func(param)
		param = param or {}

		if param.controller then
			param.controller = BTSelectControllerForExternal(param.controller or controller)
		end

		return func(param)
	end

	cparam.__safeWrapped = true

	return cparam
end

local paramsTypesFun = {
	[AIDefine.BtreeParamType.Val] = paramValfun,
	[AIDefine.BtreeParamType.Enum] = paramEumfun,
	[AIDefine.BtreeParamType.GetValueFun] = parameGetValueFun,
	[AIDefine.BtreeParamType.SetValueFun] = parameSetValueFun
}

local function get_param_value(controller, cparam)
	if type(cparam) == "string" then
		return controller.bb.get(cparam)
	end

	if type(cparam) ~= "table" then
		return cparam
	end

	local fun = paramsTypesFun[cparam.paramtype]

	if fun then
		return fun(controller, cparam)
	end
end

local function create_ugc_subparam_plan_item(cparam)
	return {
		param = cparam,
		paramtype = type(cparam) == "table" and cparam.paramtype or nil
	}
end

local function get_ugc_subparam_resolve_plan(controller, reuseEnabled)
	if controller._isUGCTask ~= true or not reuseEnabled then
		return nil
	end

	local plan = controller._ugcSubparamResolvePlan

	if not plan then
		plan = {}
		controller._ugcSubparamResolvePlan = plan

		for index, cparam in pairs(controller.subparam or {}) do
			plan[index] = create_ugc_subparam_plan_item(cparam)
		end
	end

	return plan
end

local function get_subparam_value(controller, index, plan)
	local subparam = controller.subparam
	local cparam = subparam and subparam[index]

	if not plan then
		return get_param_value(controller, cparam)
	end

	local planItem = plan[index]

	if not planItem or planItem.param ~= cparam then
		planItem = create_ugc_subparam_plan_item(cparam)
		plan[index] = planItem
	end

	if planItem.paramtype == AIDefine.BtreeParamType.Val then
		return cparam.val
	end

	if planItem.paramtype == AIDefine.BtreeParamType.Enum then
		if planItem.enumResolved then
			return planItem.enumValue
		end

		local enumValue = paramEumfun(controller, cparam)

		if enumValue ~= nil then
			planItem.enumValue = enumValue
			planItem.enumResolved = true
		end

		return enumValue
	end

	return get_param_value(controller, cparam)
end

function btget_param_value(controller, cparam)
	return get_param_value(controller, cparam)
end

function BTService:SetSubparamReuseEnabled(enabled)
	self.m_bSubparamReuseEnabled = enabled == true
end

function BTService:IsSubparamReuseEnabled()
	return self.m_bSubparamReuseEnabled == true
end

function BTService:GetSubparamOutputBuffer(controller)
	local out = controller._btSubparamOutput

	if not out then
		out = {}
		controller._btSubparamOutput = out
	end

	return out
end

local function valGetVale(controller, subparam, ckeys)
	local param = subparam[ckeys]

	return get_param_value(controller, param)
end

local function TableGetVale(controller, subparam, ckeys)
	ckeys = ckeys or {}
	local result = {}

	if not next(ckeys) then
		for ii = 1, #subparam do
			table.insert(ckeys, ii)
		end
	end

	local num = #ckeys

	for i = 1, num do
		local param = subparam[ckeys[i]]
		local value = get_param_value(controller, param)
		result[i] = value
	end

	return result
end

local getfuntable = {
	number = valGetVale,
	string = valGetVale,
	table = TableGetVale,
	["nil"] = TableGetVale
}

function BTService:GetSubparamInto(controller, keyCount, out)
	local plan = get_ugc_subparam_resolve_plan(controller, self:IsSubparamReuseEnabled())

	for i = 1, keyCount do
		out[i] = get_subparam_value(controller, i, plan)
	end
end

function btget_subparam(controller, ckeys)
	local ktype = type(ckeys)
	local subparam = controller.subparam
	local fun = getfuntable[ktype]

	if fun then
		return fun(controller, subparam, ckeys)
	end
end

function get_AI_OBJTYPE(objtype)
	local ai_objtype = GameActorTypeToObjType[objtype]

	if ai_objtype == nil then
		ai_objtype = 0
	end

	return ai_objtype
end

function btget_path_range()
	return BLOCK_SIZE * 70
end

function btget_MovPos_Threshold()
	return 1
end

function btget_Pos_Dist(x1, y1, z1, x2, y2, z2)
	local vx = x2 - x1
	local vz = z2 - z1
	local vy = y2 - y1
	local dist = math.sqrt(vx * vx + vz * vz + vy * vy)

	return dist
end

function BTGetRandValue(min, max)
	return math.random(min, max)
end

local function CalPos(val, centerval, rightval, leftval, pos)
	local result = 0

	if leftval < pos and pos < rightval then
		result = pos
	elseif val == 0 then
		result = centerval
	elseif val > 0 then
		result = rightval
	else
		result = leftval
	end

	return result
end

function BTCalCampMiniPos(devInfo, pos)
	if devInfo.size == nil then
		return nil
	end

	local certer = devInfo.minPos
	local size = devInfo.size
	local dz = pos.z - certer.z
	local dx = pos.x - certer.x
	local dy = pos.y - certer.y
	local minix = CalPos(dx, certer.x, certer.x + size.x + 1, certer.x - size.x - 1, pos.x)
	local miniz = CalPos(dz, certer.z, certer.z + size.z + 1, certer.z - size.z - 1, pos.z)
	local miniy = CalPos(dy, certer.y, certer.y + size.y, certer.y - 1, pos.y)

	return {
		x = minix,
		y = miniy,
		z = miniz
	}
end

function BTCalDeviceMiniPos(devInfo, pos)
	if devInfo.size == nil then
		return nil
	end

	local certer = devInfo.minPos
	local size = devInfo.size
	local dir = devInfo.dir
	local dz = pos.z - certer.z
	local dx = pos.x - certer.x
	local dy = pos.y - certer.y
	local minix = 0
	local miniz = 0

	if dir == 0 then
		minix = CalPos(dx, certer.x, certer.x + size.x, certer.x - 1, pos.x)
		miniz = CalPos(dz, certer.z, certer.z + 1, certer.z - size.z, pos.z)
	elseif dir == 1 then
		minix = CalPos(dx, certer.x, certer.x + 1, certer.x - size.x, pos.x)
		miniz = CalPos(dz, certer.z, certer.z + size.z, certer.z - 1, pos.z)
	elseif dir == 2 then
		minix = CalPos(dx, certer.x, certer.x + size.x, certer.x - 1, pos.x)
		miniz = CalPos(dz, certer.z, certer.z + size.z, certer.z - 1, pos.z)
	else
		minix = CalPos(dx, certer.x, certer.x + 1, certer.x - size.x, pos.x)
		miniz = CalPos(dz, certer.z, certer.z + 1, certer.z - size.z, pos.z)
	end

	local miniy = CalPos(dy, certer.y, certer.y + size.y, certer.y, pos.y)

	return {
		x = minix,
		y = miniy,
		z = miniz
	}
end

_G.BTServiceEnum = {
	["RELATIVECAMPTYPE.FRIENDLY"] = RELATIVECAMPTYPE.FRIENDLY,
	["RELATIVECAMPTYPE.ANY"] = RELATIVECAMPTYPE.ANY,
	["RELATIVECAMPTYPE.ENEMY"] = RELATIVECAMPTYPE.ENEMY,
	["RELATIVECAMPTYPE.NEUTRAL"] = RELATIVECAMPTYPE.NEUTRAL,
	["ABSOLUTECAMPTYPE.ANY"] = ABSOLUTECAMPTYPE.ANY,
	["ABSOLUTECAMPTYPE.ENEMY"] = ABSOLUTECAMPTYPE.ENEMY,
	["ABSOLUTECAMPTYPE.PASSIVE"] = ABSOLUTECAMPTYPE.PASSIVE,
	["ABSOLUTECAMPTYPE.NOTEAM"] = ABSOLUTECAMPTYPE.NOTEAM,
	["ABSOLUTECAMPTYPE.TEAM_1"] = ABSOLUTECAMPTYPE.TEAM_1,
	["ABSOLUTECAMPTYPE.TEAM_2"] = ABSOLUTECAMPTYPE.TEAM_2,
	["ABSOLUTECAMPTYPE.TEAM_3"] = ABSOLUTECAMPTYPE.TEAM_3,
	["ABSOLUTECAMPTYPE.TEAM_4"] = ABSOLUTECAMPTYPE.TEAM_4,
	["ABSOLUTECAMPTYPE.TEAM_5"] = ABSOLUTECAMPTYPE.TEAM_5,
	["ABSOLUTECAMPTYPE.TEAM_6"] = ABSOLUTECAMPTYPE.TEAM_6,
	["ABSOLUTECAMPTYPE.TEAM_NPC1"] = ABSOLUTECAMPTYPE.TEAM_NPC1,
	["ABSOLUTECAMPTYPE.TEAM_NPC2"] = ABSOLUTECAMPTYPE.TEAM_NPC2,
	["ABSOLUTECAMPTYPE.TEAM_NPC3"] = ABSOLUTECAMPTYPE.TEAM_NPC3
}
