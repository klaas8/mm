local bt_action_idle_stroll = {
	node = "BTNodeSequence",
	param = {
		tip = "bt_action_idle_stroll"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getSleepState"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getRandStollPos",
				subparam = {
					rangeWidth = 10,
					bb_stollpos = "stollPos",
					centerPos = "fishingvillagepos",
					rangeHeight = 2
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				CollideHorizontallyStop = false,
				speed = 0.8,
				minDistance = 0,
				bbkey_targetpos = "stollPos"
			}
		}
	}
}
local bt_fire_battle_attack_behurt = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNTaskFollow",
			param = {
				speed = 1.3,
				bbkey_followobj = "bbKeyBeHurtTargetObjId",
				minDistance = 1,
				canTeleport = false
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "bbKeyBeHurtTargetObjId"
				}
			}
		},
		{
			node = "BTNTaskAttack",
			param = {
				keeptick = 10,
				bbkey_attackobj = "bbKeyBeHurtTargetObjId"
			}
		}
	}
}
local bt_fire_battle_attack_enemy = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNTaskFollow",
			param = {
				speed = 1.3,
				bbkey_followobj = "enemy_id",
				minDistance = 1,
				canTeleport = false
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "enemy_id"
				}
			}
		},
		{
			node = "BTNTaskAttack",
			param = {
				keeptick = 10,
				bbkey_attackobj = "enemy_id"
			}
		}
	}
}
local bt_fire = {
	node = "BTNodeSelector",
	param = {
		tip = "bt_fire1"
	},
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "bbKeyBeHurtTargetObjId",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									range = 16,
									extraValue = "bbKeyBeHurtTargetObjId",
									type = "actorInView"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						bt_fire_battle_attack_behurt
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "bbKeyBeHurtTargetObjId",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeBranch",
			param = {
				tip = "bt_fire2"
			},
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "enemy_id",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									range = 16,
									extraValue = "enemy_id",
									type = "actorInView"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						bt_fire_battle_attack_enemy
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "enemy_id",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_sleep2 = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isSleeping,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				speed = 1,
				minDistance = 0,
				bbkey_targetpos = "fishingvillagepos"
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindPosByNeedType",
								subparam = {
									equipslot = 0,
									searchType = 3,
									bbkey_targetpos = "bedpos",
									bempty = true
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				speed = 1,
				minDistance = 0,
				bbkey_targetpos = "bedpos"
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 0,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBlockOccupyed,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							extraValue = "bedpos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBedBindWithOthers,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_sleepOnAndBindBedEx",
				subparam = {
					bb_bedpos = "bedpos"
				}
			}
		}
	}
}
local bt_action_sleep = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_sleep"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageSleepTime",
				subparam = {
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					enemy_id = "enemy_id",
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_action_sleep2,
				{
					node = "BTNodeWait",
					param = {
						wait = 1
					}
				}
			}
		}
	}
}
local bt_action_wakeup = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_wakeup"
	},
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FishingVillageWorkTime",
						subparam = {
							bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
							enemy_id = "enemy_id",
							bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 0,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_wakeup"
			}
		}
	}
}
local bt_save = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				speed = 1,
				minDistance = 0,
				bbkey_targetpos = "fishingvillagepos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindBlock",
				subparam = {
					range = 16,
					result_blockpos = "finditem_out_boxpos",
					rangeY = 5,
					findPositionType = 2,
					findBlockType = AI_FIND_BOX_NOT_FULL
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				speed = 1,
				minDistance = 1,
				bbkey_targetpos = "finditem_out_boxpos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_storeItemByList",
				subparam = {
					in_TargetPos = "finditem_out_boxpos",
					storeMode = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 1,
					animID = 100829
				}
			}
		}
	}
}
local bt_need_save = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_HaveBagContainerEx",
				subparam = {
					objId = 3229,
					itemCount = 10,
					itemId = 12520
				}
			}
		},
		bt_save
	}
}
local bt_inspect = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_FishingVillagePos",
					subparam = {
						bb_fishingvillagepos = "fishingvillagepos"
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								avoidWater = true,
								speed = 1,
								minDistance = 3,
								bbkey_targetpos = "fishingvillagepos"
							}
						}
					}
				}
			}
		}
	}
}
local bt_inwater = {
	node = "BTNodeCondition",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isInWater,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSequence",
			param = {
				tip = "stroll_in_water"
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getRandStollPos",
						subparam = {
							bb_stollpos = "stollPos"
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						speed = 1,
						bbkey_targetpos = "stollPos"
					}
				}
			}
		}
	}
}
local bt_meet_rainbow = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_findRainbow"
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							curValue = "isRainbow",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillageWorkTime",
										subparam = {
											bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
											enemy_id = "enemy_id",
											bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillageOtherTime",
										subparam = {
											bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
											enemy_id = "enemy_id",
											bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
										}
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 5,
									extraValue = 10,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
									compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									soundName = "ent.3229.surprise",
									duration = 1,
									animID = 100865
								}
							}
						},
						{
							node = "BTNodeWait",
							param = {
								wait = 3
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "isRainbow",
									value = 1,
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						key = "isRainbow",
						value = 0,
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_avoid_tempest = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_isInTempestWeather"
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FishingVillageWorkTime",
								subparam = {
									bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
									enemy_id = "enemy_id",
									bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FishingVillageOtherTime",
								subparam = {
									bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
									enemy_id = "enemy_id",
									bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
								}
							}
						}
					}
				},
				{
					node = "BTNodeBranch",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									curValue = "is_avoid_tempest",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 5,
											extraValue = 10,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
											compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											rangeWidth = 2,
											bb_stollpos = "stollPos",
											rangeHeight = 1
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										CollideHorizontallyStop = false,
										speed = 0.5,
										minDistance = 0,
										bbkey_targetpos = "stollPos"
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillagePos",
										subparam = {
											bb_fishingvillagepos = "fishingvillagepos"
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 0,
										bbkey_targetpos = "fishingvillagepos"
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillagePos",
										subparam = {
											bb_fishingvillagepos = "fishingvillagepos"
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1.2,
										minDistance = 0,
										bbkey_targetpos = "fishingvillagepos"
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonSetValue",
										subparam = {
											key = "is_avoid_tempest",
											value = 1,
											valueType = AIFunctionDefsGetDefByKey("valueType").value
										}
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						key = "is_avoid_tempest",
						value = 0,
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_hunger_status = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 30,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
					compareType = AIFunctionDefsGetDefByKey("compareType").less
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getRandStollPos",
				subparam = {
					rangeWidth = 6,
					bb_stollpos = "stollPos",
					centerPos = "villagepos",
					rangeHeight = 2
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeSimpleParallel",
					children = {
						{
							node = "BTNTaskMoveTo",
							param = {
								CollideHorizontallyStop = false,
								speed = 0.3,
								minDistance = 1,
								bbkey_targetpos = "stollPos"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									effectID = "mob_3200_hungery",
									duration = 1,
									animID = 100103
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getFollowTick",
								subparam = {
									followtick = "followtick"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									soundName = "npc.hungry"
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_need_Tamed_Eat_BagHaveFood = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				desc = "判断：背包内有食物",
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 3,
					extraValue = {
						1,
						true
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				desc = "把食物放在手上",
				script = "BTTask_putFoodInHand",
				subparam = {
					bbFoodId = ""
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_EAT,
						true
					}
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				desc = "吃手上的食物",
				script = "BTTask_EatHandFood"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = false,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_EAT,
						true
					}
				}
			}
		}
	}
}
local bt_need_Tamed_Eat_BagHaveNotFood = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				desc = "判断：背包中没有食物",
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						1,
						true
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				speed = 1.2,
				minDistance = 0,
				bbkey_targetpos = "fishingvillagepos"
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						desc = "获取需求箱子位置 ",
						script = "BTTask_FindPosByNeedType",
						subparam = {
							bbkey_itemid = "finditem",
							bbkey_targetpos = "BTTask_FindStoragePos",
							equipslot = 0,
							searchType = 2,
							findboxid = 801
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						desc = "获取需求箱子位置 ",
						script = "BTTask_FindPosByNeedType",
						subparam = {
							bbkey_itemid = "finditem",
							bbkey_targetpos = "BTTask_FindStoragePos",
							equipslot = 0,
							searchType = 2,
							findboxid = 1180
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						desc = "获取需求箱子位置 ",
						script = "BTTask_FindPosByNeedType",
						subparam = {
							bbkey_itemid = "finditem",
							bbkey_targetpos = "BTTask_FindStoragePos",
							equipslot = 0,
							searchType = 2,
							findboxid = 1181
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				CollideHorizontallyStop = false,
				speed = 1,
				minDistance = 0,
				bbkey_targetpos = "BTTask_FindStoragePos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				desc = "从箱子中取出一定数量的道具",
				script = "BTTask_TakeItemToPack",
				subparam = {
					bbkey_in_boxpos = "BTTask_FindStoragePos",
					bbkey_one_takenum = 5,
					bbkey_one_takeid = "finditem"
				}
			}
		}
	}
}
local bt_need_eat = {
	node = "BTNodeSelector",
	param = {
		tip = "need eat"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							curValue = "isEating",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 80,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
											compareType = AIFunctionDefsGetDefByKey("compareType").moreEqual
										}
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_commonSetValue",
											subparam = {
												key = "isEating",
												value = 0,
												valueType = AIFunctionDefsGetDefByKey("valueType").value
											}
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_PutHandItemInBags",
										subparam = {}
									}
								}
							}
						},
						bt_need_Tamed_Eat_BagHaveFood,
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeSelector",
									children = {
										bt_need_Tamed_Eat_BagHaveNotFood,
										bt_work
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 30,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
							compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							key = "isEating",
							value = 1,
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						key = "isEating",
						value = 0,
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_fishing = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									result_blockpos = "find_fishing_pos",
									rangeY = 5,
									findPositionType = 5,
									range = 6,
									findBlockType = AI_FIND_CUSTOM,
									findCustomBlocks = {
										3,
										4
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									result_blockpos = "find_fishing_pos",
									rangeY = 5,
									findPositionType = 2,
									range = 20,
									findBlockType = AI_FIND_CUSTOM,
									findCustomBlocks = {
										3,
										4
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNTaskMoveTo",
							param = {
								avoidWater = true,
								speed = 1,
								minDistance = 1,
								bbkey_targetpos = "find_fishing_pos"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_faceWorldPos",
								subparam = {
									bb_targetpos = "find_fishing_pos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									animID = 100921
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 0.5,
									animID = 100877
								}
							}
						},
						{
							node = "BTNodeSimpleParallel",
							param = {
								loop = true
							},
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonPlayAction",
										subparam = {
											duration = 25,
											animID = 100878
										}
									}
								},
								{
									node = "BTNodeCondition",
									children = {
										{
											node = "BTNodeSelector",
											children = {
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_FishingVillageSleepTime",
														subparam = {
															bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
															enemy_id = "enemy_id",
															bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
														}
													}
												},
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_isInTempestWeather"
													}
												},
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_isAttachedToUI"
													}
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_FishingVillageStopWorking"
											}
										}
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 0.5,
									animID = 100879
								}
							}
						},
						{
							node = "BTNodeBranch",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 8,
											extraValue = 10,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
											compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_FishingSuccess",
												subparam = {
													bb_fishId = "fishId",
													probability = 10
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonPlayAction",
												subparam = {
													exchangeItemId = 12520,
													duration = 2,
													bb_fishId = "fishId",
													animID = 100829
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_PutHandItemInBags",
												subparam = {}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonPlayAction",
												subparam = {
													soundName = "ent.3229.happy",
													duration = 2,
													animID = 100880
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_PutHandItemInBags",
												subparam = {}
											}
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonPlayAction",
										subparam = {
											soundName = "ent.3229.lose",
											duration = 2,
											animID = 100881
										}
									}
								}
							}
						}
					}
				},
				bt_action_idle_stroll
			}
		}
	}
}
local bt_work = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageWorkTime",
				subparam = {
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					enemy_id = "enemy_id",
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					curValue = "is_avoid_tempest",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_need_save,
				bt_fishing
			}
		}
	}
}
local bt = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isOnGround"
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_inspect
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_action_wakeup
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_inwater
			}
		},
		bt_fire,
		bt_action_sleep,
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getSleepState"
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						bt_avoid_tempest,
						bt_need_eat,
						bt_meet_rainbow,
						bt_hunger_status,
						bt_work
					}
				},
				bt_action_wakeup
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FishingVillageOtherTime",
						subparam = {
							bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
							enemy_id = "enemy_id",
							bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId"
						}
					}
				},
				bt_action_wakeup,
				{
					node = "BTNodeSelector",
					children = {
						bt_action_idle_stroll
					}
				}
			}
		}
	}
}

return bt
