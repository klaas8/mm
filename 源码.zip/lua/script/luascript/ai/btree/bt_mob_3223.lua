local bt_action_escape = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "bbKeyBeHurtTargetObjId",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									range = 16,
									extraValue = "bbKeyBeHurtTargetObjId",
									type = "actorInView"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerEscape",
								subparam = {
									targetPos = "bb_curToPos",
									range = 16,
									escapeId = "bbKeyBeHurtTargetObjId"
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								speed = 1.5,
								minDistance = 2,
								bbkey_targetpos = "bb_curToPos",
								CollideHorizontallyStop = false
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "bbKeyBeHurtTargetObjId",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_main = {
	node = "BTNodeSelector",
	children = {
		bt_action_escape
	}
}

return bt_main
