local bt_action_idle_stroll = {
	node = "BTNodeSequence",
	param = {
		tip = "bt_action_idle_stroll"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getSleepState"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getRandStollPos",
				subparam = {
					bb_stollpos = "stollPos",
					centerPos = "fishingvillagepos",
					rangeHeight = 2,
					rangeWidth = 10
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 0,
				bbkey_targetpos = "stollPos",
				CollideHorizontallyStop = false,
				speed = 0.8
			}
		}
	}
}
local bt_action_escape = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "enemy_id",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									extraValue = "enemy_id",
									type = "actorInView",
									range = 16
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerEscape",
								subparam = {
									escapeId = "enemy_id",
									targetPos = "escapetoPos",
									range = 16
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								minDistance = 2,
								bbkey_targetpos = "escapetoPos",
								CollideHorizontallyStop = false,
								speed = 1.2
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "enemy_id",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bbKeyBeHurtTargetObjId",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									extraValue = "bbKeyBeHurtTargetObjId",
									type = "actorInView",
									range = 16
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerEscape",
								subparam = {
									escapeId = "bbKeyBeHurtTargetObjId",
									targetPos = "bbKeyBeHurtTargetPos",
									range = 16
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								minDistance = 2,
								bbkey_targetpos = "bbKeyBeHurtTargetPos",
								CollideHorizontallyStop = false,
								speed = 1.2
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "bbKeyBeHurtTargetObjId",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_sleep2 = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isSleeping,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 0,
				bbkey_targetpos = "fishingvillagepos",
				avoidWater = true,
				speed = 1
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindPosByNeedType",
								subparam = {
									bempty = true,
									equipslot = 0,
									searchType = 3,
									bbkey_targetpos = "bedpos"
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 0,
				bbkey_targetpos = "bedpos",
				avoidWater = true,
				speed = 1
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 0,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBlockOccupyed,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							extraValue = "bedpos",
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBedBindWithOthers,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_sleepOnAndBindBedEx",
				subparam = {
					bb_bedpos = "bedpos"
				}
			}
		}
	}
}
local bt_action_sleep = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_sleep"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageSleepTime",
				subparam = {
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
					enemy_id = "enemy_id"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_action_sleep2,
				{
					node = "BTNodeWait",
					param = {
						wait = 1
					}
				}
			}
		}
	}
}
local bt_gossip = {
	node = "BTNodeSelector",
	tip = "gossip",
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								tip = "get_gossipstate",
								script = "BTTask_FishingVillageGossip",
								subparam = {
									gossiptype = 2,
									state = 2
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								tip = "get_gossipstate",
								script = "BTTask_FishingVillageGossip",
								subparam = {
									gossiptype = 6
								}
							}
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "isgoosiTime",
										script = "BTTask_FishingVillageGossip",
										subparam = {
											gossiptype = 1,
											state = 1
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												tip = "clearGossipState",
												script = "BTTask_FishingVillageGossip",
												subparam = {
													gossiptype = 2,
													state = 0
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												tip = "setintervalTime",
												script = "BTTask_FishingVillageGossip",
												subparam = {
													gossiptype = 0,
													state = 0
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_FishingVillageGossip",
												subparam = {
													gossiptype = 7
												}
											}
										}
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillageGossip",
										subparam = {
											gossiptype = 9
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "lookat_villger",
										script = "BTTask_FishingVillageGossip",
										subparam = {
											gossiptype = 3,
											state = 1
										}
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								tip = "get_interval_time",
								script = "BTTask_FishingVillageGossip",
								subparam = {
									gossiptype = 0,
									state = 1
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FishingVillageGossip",
								subparam = {
									gossiptype = 7
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FishingVillageGossip",
								subparam = {
									gossiptype = 8
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "around_gossipState",
										script = "BTTask_FishingVillageGossip",
										subparam = {
											gossipId = "gossipId",
											state = 1,
											gossiptype = 4,
											gossipPos = "gossipPos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "set_gossipTime",
										script = "BTTask_FishingVillageGossip",
										subparam = {
											gossiptype = 1,
											state = 0
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "setGossipState",
										script = "BTTask_FishingVillageGossip",
										subparam = {
											gossiptype = 2,
											state = 1
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNTaskMoveTo",
											desc = "moveto",
											param = {
												minDistance = 2,
												bbkey_targetpos = "gossipPos",
												avoidWater = true,
												speed = 1
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												tip = "lookat_villger",
												script = "BTTask_FishingVillageGossip",
												subparam = {
													gossiptype = 5,
													gossipId = "gossipId"
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_setgossipaction = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageSleepTime",
				subparam = {
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
					enemy_id = "enemy_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageGossip",
				subparam = {
					gossiptype = 2,
					state = 0
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageGossip",
				subparam = {
					gossiptype = 7
				}
			}
		}
	}
}
local bt_action_wakeup = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_wakeup"
	},
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FishingVillageWorkTime",
						subparam = {
							bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
							bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
							enemy_id = "enemy_id"
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 0,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_wakeup"
			}
		}
	}
}
local bt_save = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageWorkTime",
				subparam = {
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
					enemy_id = "enemy_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 0,
				bbkey_targetpos = "fishingvillagepos",
				avoidWater = true,
				speed = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindBlock",
				subparam = {
					rangeY = 5,
					findPositionType = 2,
					range = 16,
					result_blockpos = "finditem_out_boxpos",
					findBlockType = AI_FIND_BOX_NOT_FULL
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 1,
				bbkey_targetpos = "finditem_out_boxpos",
				avoidWater = true,
				speed = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_storeItemByList",
				subparam = {
					in_TargetPos = "finditem_out_boxpos",
					storeMode = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 1,
					animID = 100105
				}
			}
		}
	}
}
local bt_need_save = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_HaveBagContainerEx",
				subparam = {
					itemCount = 6,
					itemId = 13621,
					objId = 3218
				}
			}
		},
		bt_save
	}
}
local bt_inspect = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_FishingVillagePos",
					subparam = {
						bb_fishingvillagepos = "fishingvillagepos"
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								minDistance = 3,
								bbkey_targetpos = "fishingvillagepos",
								avoidWater = true,
								speed = 1
							}
						}
					}
				}
			}
		}
	}
}
local bt_inwater = {
	node = "BTNodeCondition",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isInWater,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSequence",
			param = {
				tip = "stroll_in_water"
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						tip = "get_gossipstate",
						script = "BTTask_FishingVillageGossip",
						subparam = {
							gossiptype = 2,
							state = 0
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getRandStollPos",
						subparam = {
							bb_stollpos = "stollPos"
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						speed = 1,
						bbkey_targetpos = "stollPos"
					}
				}
			}
		}
	}
}
local bt_meet_rainbow = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_findRainbow"
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							curValue = "isRainbow",
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillageWorkTime",
										subparam = {
											bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
											bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
											enemy_id = "enemy_id"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillageOtherTime",
										subparam = {
											bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
											bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
											enemy_id = "enemy_id"
										}
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = 10,
									compareValue = 5,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
									compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									animID = 100865,
									soundName = "ent.3218.surprise"
								}
							}
						},
						{
							node = "BTNodeWait",
							param = {
								wait = 3
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "isRainbow",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = 0,
						key = "isRainbow",
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_avoid_tempest = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_isInTempestWeather"
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FishingVillageWorkTime",
								subparam = {
									bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
									bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
									enemy_id = "enemy_id"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FishingVillageOtherTime",
								subparam = {
									bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
									bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
									enemy_id = "enemy_id"
								}
							}
						}
					}
				},
				{
					node = "BTNodeBranch",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									curValue = "is_avoid_tempest",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											extraValue = 10,
											compareValue = 5,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
											compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											bb_stollpos = "stollPos",
											rangeHeight = 1,
											rangeWidth = 2
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										minDistance = 0,
										bbkey_targetpos = "stollPos",
										CollideHorizontallyStop = false,
										speed = 0.5
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillagePos",
										subparam = {
											bb_fishingvillagepos = "fishingvillagepos"
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										minDistance = 0,
										bbkey_targetpos = "fishingvillagepos",
										avoidWater = true,
										speed = 1
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FishingVillagePos",
										subparam = {
											bb_fishingvillagepos = "fishingvillagepos"
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										minDistance = 0,
										bbkey_targetpos = "fishingvillagepos",
										avoidWater = true,
										speed = 1.2
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonSetValue",
										subparam = {
											value = 1,
											key = "is_avoid_tempest",
											valueType = AIFunctionDefsGetDefByKey("valueType").value
										}
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = 0,
						key = "is_avoid_tempest",
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_hunger_status = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 30,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
					compareType = AIFunctionDefsGetDefByKey("compareType").less
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getRandStollPos",
				subparam = {
					bb_stollpos = "stollPos",
					centerPos = "villagepos",
					rangeHeight = 2,
					rangeWidth = 6
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeSimpleParallel",
					children = {
						{
							node = "BTNTaskMoveTo",
							param = {
								minDistance = 1,
								bbkey_targetpos = "stollPos",
								CollideHorizontallyStop = false,
								speed = 0.3
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									animID = 100103,
									effectID = "mob_3200_hungery"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getFollowTick",
								subparam = {
									followtick = "followtick"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									soundName = "npc.hungry"
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_need_Tamed_Eat_BagHaveFood = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包内有食物",
				subparam = {
					judgeType = 12,
					compareValue = 0,
					compareType = 3,
					extraValue = {
						1,
						true
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_putFoodInHand",
				desc = "把食物放在手上",
				subparam = {
					bbFoodId = ""
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_EAT,
						true
					}
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_EatHandFood",
				desc = "吃手上的食物"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = false,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_EAT,
						true
					}
				}
			}
		}
	}
}
local bt_need_Tamed_Eat_BagHaveNotFood = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有食物",
				subparam = {
					judgeType = 12,
					compareValue = 0,
					compareType = 2,
					extraValue = {
						1,
						true
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillagePos",
				subparam = {
					bb_fishingvillagepos = "fishingvillagepos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 0,
				bbkey_targetpos = "fishingvillagepos",
				avoidWater = true,
				speed = 1.2
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindPosByNeedType",
						desc = "获取需求箱子位置 ",
						subparam = {
							bbkey_itemid = "finditem",
							equipslot = 0,
							findboxid = 801,
							bbkey_targetpos = "BTTask_FindStoragePos",
							searchType = 2
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindPosByNeedType",
						desc = "获取需求箱子位置 ",
						subparam = {
							bbkey_itemid = "finditem",
							equipslot = 0,
							findboxid = 1180,
							bbkey_targetpos = "BTTask_FindStoragePos",
							searchType = 2
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindPosByNeedType",
						desc = "获取需求箱子位置 ",
						subparam = {
							bbkey_itemid = "finditem",
							equipslot = 0,
							findboxid = 1181,
							bbkey_targetpos = "BTTask_FindStoragePos",
							searchType = 2
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 0,
				bbkey_targetpos = "BTTask_FindStoragePos",
				CollideHorizontallyStop = false,
				speed = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				desc = "从箱子中取出一定数量的道具",
				subparam = {
					bbkey_in_boxpos = "BTTask_FindStoragePos",
					bbkey_one_takenum = 5,
					bbkey_one_takeid = "finditem"
				}
			}
		}
	}
}
local bt_need_eat = {
	node = "BTNodeSelector",
	param = {
		tip = "need eat"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							curValue = "isEating",
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 80,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
											compareType = AIFunctionDefsGetDefByKey("compareType").moreEqual
										}
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_commonSetValue",
											subparam = {
												value = 0,
												key = "isEating",
												valueType = AIFunctionDefsGetDefByKey("valueType").value
											}
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_PutHandItemInBags",
										subparam = {}
									}
								}
							}
						},
						bt_need_Tamed_Eat_BagHaveFood,
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeSelector",
									children = {
										bt_need_Tamed_Eat_BagHaveNotFood,
										bt_action_idle_stroll
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 30,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
							compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							value = 1,
							key = "isEating",
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = 0,
						key = "isEating",
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_drive_away = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindEatFishOfSeagulls",
				subparam = {
					bbkey_evictedobj = "bbkey_evictedobj",
					result_blockpos = "find_seagull_fish_frame_pos",
					searchRange = 20,
					mobId = 3622
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 1,
				bbkey_targetpos = "find_seagull_fish_frame_pos",
				CollideHorizontallyStop = false,
				speed = 1.3
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 0.5,
					animID = 100866,
					soundName = "ent.3218.anger"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_EvictedActor",
				subparam = {
					bbkey_evictedobj = "bbkey_evictedobj"
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 1
			}
		}
	}
}
local bt_pick_crabs = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindDropByList",
				desc = "搜寻范围内列表里的掉落物的位置",
				subparam = {
					bbTargetIdKey = "find_drop_targetid",
					bbPosKey = "find_drop_pos",
					listsKey = "fishermanToolsList"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				minDistance = 1,
				bbkey_targetpos = "find_drop_pos",
				CollideHorizontallyStop = false,
				speed = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_Pick",
				desc = "捡起掉落物到背包",
				subparam = {
					out_Itemid = "bb_gotItemid",
					dropItemId = "find_drop_targetid",
					out_Itemnum = "bb_gotItemNum"
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 0.5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_EquipWeapon",
				subparam = {
					bbEquipItemId = 13621,
					bbEquipItemNum = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					animID = 100865
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_PutHandItemInBags",
				subparam = {}
			}
		}
	}
}
local bt_catch_crabs = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					extraValue = 10,
					compareValue = 2,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
					compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				subparam = {
					bbKeyTargetPos = "attackActorPos",
					targetID = 3621,
					range = 16,
					bbKeyTargetObjId = "bbKeyTargetObjId",
					targetType = AIFunctionDefsGetDefByKey("findTargetType").actor
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_wakeup"
			}
		},
		{
			node = "BTNTaskFollow",
			param = {
				minDistance = 1,
				bbkey_followobj = "bbKeyTargetObjId",
				canTeleport = false,
				speed = 1.3
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNTaskAttack",
			param = {
				bbkey_attackobj = "bbKeyTargetObjId",
				keeptick = 10
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					extraValue = 10,
					compareValue = 2,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
					compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_RemoveActor",
				subparam = {
					bbkey_attackobj = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_EquipWeaponEx",
				subparam = {
					bbEquipItemId = 13621,
					bbEquipItemNum = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 1,
					animID = 100868,
					soundName = "ent.3218.ache"
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 2
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_PutHandItemInBags",
				subparam = {}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_removeItem",
				subparam = {
					bbEquipItemId = 13621,
					bbEquipItemNum = 1
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 0.5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_SpwanActor",
				subparam = {
					dist = 1,
					monsterid = 3621
				}
			}
		}
	}
}
local bt_caught_by_crab = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					curValue = "isCatchingCrabs",
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					extraValue = 10,
					compareValue = 3,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
					compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 1,
					animID = 100868
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_SpwanActor",
				subparam = {
					dist = 1,
					monsterid = 3400
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "isCatchingCrabs",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		}
	}
}
local bt_knock_coconut_tree = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					extraValue = 10,
					compareValue = 2,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
					compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				subparam = {
					bbKeyTargetPos = "bbHackTreeTargetPos",
					targetID = 1266,
					range = 20,
					targetType = AIFunctionDefsGetDefByKey("findTargetType").block
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							type = "isPosOutRange",
							extraValue = {
								range = 2,
								comparePos = "bbHackTreeTargetPos"
							}
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						minDistance = 1,
						bbkey_targetpos = "bbHackTreeTargetPos",
						avoidWater = true,
						speed = 1
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_faceWorldPos",
								subparam = {
									bb_targetpos = "bbHackTreeTargetPos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 2,
									animID = 100867
								}
							}
						},
						{
							node = "BTNodeWait",
							param = {
								wait = 3
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DigBlockCoconut",
								subparam = {
									blockpos = "bbHackTreeTargetPos",
									blockid = 1266
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FishingVillageWorkTime",
				subparam = {
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
					enemy_id = "enemy_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					curValue = "is_avoid_tempest",
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_need_save,
				bt_drive_away,
				bt_pick_crabs,
				bt_catch_crabs,
				bt_knock_coconut_tree
			}
		}
	}
}
local bt = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isOnGround"
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_inspect
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_action_wakeup
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_setgossipaction
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_inwater
			}
		},
		bt_action_escape,
		bt_action_sleep,
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getSleepState"
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						bt_avoid_tempest,
						bt_need_eat,
						bt_meet_rainbow,
						bt_hunger_status,
						bt_work,
						bt_gossip
					}
				},
				bt_action_wakeup
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FishingVillageOtherTime",
						subparam = {
							bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
							bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
							enemy_id = "enemy_id"
						}
					}
				},
				bt_action_wakeup,
				{
					node = "BTNodeSelector",
					children = {
						bt_action_idle_stroll
					}
				}
			}
		}
	}
}

return bt
