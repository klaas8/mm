local bt_action_hello = {
	node = "BTNodeTaskLua",
	param = {
		script = "BTTask_LoockAtPlayer",
		subparam = {
			waittimemax = 4,
			waittimemin = 1,
			actorwaittime = 4,
			searchRange = 4
		}
	}
}
local bt_action_idle_stroll = {
	node = "BTNodeSequence",
	param = {
		tip = "bt_action_idle_stroll"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getSleepState"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getDesertVillagePos",
				subparam = {
					bb_desertvillagepos = "desertvillagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getRandStollPos",
				subparam = {
					centerPos = "desertvillagepos",
					rangeHeight = 2,
					rangeWidth = 10,
					bb_stollpos = "stollPos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				bbkey_targetpos = "stollPos",
				CollideHorizontallyStop = false,
				speed = 0.8,
				minDistance = 0
			}
		},
		bt_action_hello
	}
}
local bt_action_sleep2 = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindPosByNeedType",
								subparam = {
									bempty = true,
									equipslot = 0,
									searchType = 3,
									bbkey_targetpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_desertJudget",
								subparam = {
									judgettype = 2,
									bbkey_targetpos = "bedpos"
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				bbkey_targetpos = "bedpos",
				avoidWater = true,
				speed = 1,
				minDistance = 0
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 0,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBlockOccupyed,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							extraValue = "bedpos",
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBedBindWithOthers,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_sleepOnAndBindBed",
				subparam = {
					bb_bedpos = "bedpos"
				}
			}
		}
	}
}
local bt_action_sleep = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_sleep"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_notDayTime",
				subparam = {
					bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
					bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
					enemy_id = "enemy_id"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_action_sleep2,
				bt_action_idle_stroll,
				{
					node = "BTNodeWait",
					param = {
						wait = 1
					}
				}
			}
		}
	}
}
local bt_action_wakeup = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_wakeup"
	},
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bedpos",
									compareValue = 0,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_isDayTime"
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_wakeup"
			}
		}
	}
}
local bt_gossip = {
	node = "BTNodeSelector",
	tip = "gossip",
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								tip = "get_gossipstate",
								script = "BTTask_DesertVillgerGossip",
								subparam = {
									state = 2,
									gossiptype = 2
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								tip = "get_gossipstate",
								script = "BTTask_DesertVillgerGossip",
								subparam = {
									gossiptype = 6
								}
							}
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "isgoosiTime",
										script = "BTTask_DesertVillgerGossip",
										subparam = {
											state = 1,
											gossiptype = 1
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												tip = "clearGossipState",
												script = "BTTask_DesertVillgerGossip",
												subparam = {
													state = 0,
													gossiptype = 2
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												tip = "setintervalTime",
												script = "BTTask_DesertVillgerGossip",
												subparam = {
													state = 0,
													gossiptype = 0
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_DesertVillgerGossip",
												subparam = {
													gossiptype = 7
												}
											}
										}
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_DesertVillgerGossip",
										subparam = {
											gossiptype = 9
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "lookat_villger",
										script = "BTTask_DesertVillgerGossip",
										subparam = {
											state = 1,
											gossiptype = 3
										}
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						bt_action_idle_stroll,
						{
							node = "BTNodeTaskLua",
							param = {
								tip = "get_interval_time",
								script = "BTTask_DesertVillgerGossip",
								subparam = {
									state = 1,
									gossiptype = 0
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerGossip",
								subparam = {
									gossiptype = 7
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerGossip",
								subparam = {
									gossiptype = 8
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "around_gossipState",
										script = "BTTask_DesertVillgerGossip",
										subparam = {
											state = 1,
											gossiptype = 4,
											gossipId = "gossipId",
											gossipPos = "gossipPos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "set_gossipTime",
										script = "BTTask_DesertVillgerGossip",
										subparam = {
											state = 0,
											gossiptype = 1
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										tip = "setGossipState",
										script = "BTTask_DesertVillgerGossip",
										subparam = {
											state = 1,
											gossiptype = 2
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											desc = "moveto",
											node = "BTNTaskMoveTo",
											param = {
												bbkey_targetpos = "gossipPos",
												avoidWater = true,
												speed = 1.5,
												minDistance = 2
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												tip = "lookat_villger",
												script = "BTTask_DesertVillgerGossip",
												subparam = {
													gossipId = "gossipId",
													gossiptype = 5
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_inspect = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getDesertVillagePos",
					subparam = {
						bb_desertvillagepos = "desertvillagepos"
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						bbkey_targetpos = "desertvillagepos",
						avoidWater = true,
						speed = 1,
						minDistance = 3
					}
				}
			}
		}
	}
}
local bt_action_escape = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "enemy_id",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									extraValue = "enemy_id",
									range = 16,
									type = "actorInView"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerEscape",
								subparam = {
									escapeId = "enemy_id",
									range = 16,
									targetPos = "escapetoPos"
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								bbkey_targetpos = "escapetoPos",
								CollideHorizontallyStop = false,
								speed = 1.5,
								minDistance = 2
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "enemy_id",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									extraValue = "bbKeyBeHurtTargetObjId",
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									extraValue = "bbKeyBeHurtTargetObjId",
									range = 16,
									type = "actorInView"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_wakeup"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerEscape",
								subparam = {
									escapeId = "bbKeyBeHurtTargetObjId",
									range = 16,
									targetPos = "bbKeyBeHurtTargetPos"
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								bbkey_targetpos = "bbKeyBeHurtTargetPos",
								CollideHorizontallyStop = false,
								speed = 1.5,
								minDistance = 2
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "bbKeyBeHurtTargetObjId",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_setgossipaction = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeInversion",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_isDayTime"
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_DesertVillgerGossip",
				subparam = {
					state = 0,
					gossiptype = 2
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_DesertVillgerGossip",
				subparam = {
					gossiptype = 7
				}
			}
		}
	}
}
local bt_inwater = {
	node = "BTNodeCondition",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isInWater,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSequence",
			param = {
				tip = "stroll_in_water"
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						tip = "get_gossipstate",
						script = "BTTask_DesertVillgerGossip",
						subparam = {
							state = 0,
							gossiptype = 2
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getRandStollPos",
						subparam = {
							bb_stollpos = "stollPos"
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						bbkey_targetpos = "stollPos",
						speed = 1
					}
				}
			}
		}
	}
}
local bt_action_sing = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_DesertVillgerSing",
						subparam = {
							judgettype = 1,
							times = "times"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_DesertVillgerSing",
						subparam = {
							judgettype = 2,
							times = "times"
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_DesertVillgerSing",
				subparam = {
					judgettype = 3
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_NurseryRhyme",
				subparam = {
					times = "times"
				}
			}
		}
	}
}
local bt_interact_look_node = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					curValue = "greeted_act_id",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").more
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "greeted_obj_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					animID = "greeted_act_id"
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 1.2
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "greeted_act_id",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		}
	}
}
local hello_follow_player = {
	node = "BTNodeSimpleParallel",
	param = {
		loop = false
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNTaskFollow",
					param = {
						bbkey_followobj = "followobjid",
						speed = 1.3,
						minDistance = 3
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_TurnToTarget",
						subparam = {
							bbTargetKey = "followobjid"
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_DesertVillgerGossip",
						subparam = {
							followtick = "followtick",
							gossiptype = 12,
							ticks = 40
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_DesertVillgerGossip",
						subparam = {
							followobjid = "followobjid",
							gossiptype = 11,
							followstate = "followstate"
						}
					}
				}
			}
		}
	}
}
local bt_followplayer = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_DesertVillgerGossip",
						subparam = {
							followstate = "followstate",
							gossiptype = 10,
							followobjid = "followobjid",
							bbKeyAttackTargetObjId = "bbKeyAttackTargetObjId",
							bbKeyBeHurtTargetObjId = "bbKeyBeHurtTargetObjId",
							enemy_id = "enemy_id"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							extraValue = "followobjid",
							range = 16,
							type = "actorInView"
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_wakeup"
					}
				},
				hello_follow_player
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							key = "followobjid",
							valueType = AIFunctionDefsGetDefByKey("valueType").value,
							value = {
								actor = 0
							}
						}
					}
				},
				{
					node = "BTNodeFail",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_DesertVillgerGossip",
								subparam = {
									gossiptype = 7
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isOnGround"
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_inspect
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_action_wakeup
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_setgossipaction
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_inwater
			}
		},
		{
			node = "BTNodeFail",
			children = {
				bt_interact_look_node
			}
		},
		bt_followplayer,
		bt_action_escape,
		bt_action_sleep,
		bt_gossip,
		{
			node = "BTNodeSequence",
			children = {
				bt_action_wakeup,
				{
					node = "BTNodeSimpleParallel",
					param = {
						loop = true
					},
					children = {
						bt_action_idle_stroll,
						bt_action_sing
					}
				}
			}
		}
	}
}

return bt
