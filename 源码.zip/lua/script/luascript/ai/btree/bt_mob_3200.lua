local bt_action_idle_Leisure = {
	node = "BTNodeTaskLua",
	param = {
		script = "BTTask_commonPlayAction",
		desc = "休闲动作",
		subparam = {
			duration = 10,
			soundName = "bb_relaxSoundName",
			animID = 100108
		}
	}
}
local bt_action_idle_lookAround = {
	node = "BTNodeTaskLua",
	param = {
		script = "BTTask_LookAt",
		subparam = {
			actorwaittime = 0.2,
			searchRange = 4,
			waittimemax = 4,
			waittimemin = 1
		}
	}
}
local ll_BTTask_getDisPos = {
	run = function ()
		local obj = controller.target.get()
		local pos = controller.bb.get(controller.subparam.block_pos_key)
		local dist = controller.subparam.blockdist
		local targetPos = WCoord()
		targetPos.x = pos.x * BLOCK_SIZE
		targetPos.y = pos.y * BLOCK_SIZE
		targetPos.z = pos.z * BLOCK_SIZE
		local vec = obj:getPosition() - targetPos
		local len = vec:length()

		if dist < len then
			return controller.fail()
		end

		return controller.success()
	end
}

local function TaskMoveToFunc(name)
	local t = {
		node = "BTNTaskMoveTo",
		param = {
			CollideHorizontallyStop = false,
			speed = 1,
			minDistance = 1,
			bbkey_speed_ratio = "bbkeySpeedRatio",
			bbkey_targetpos = name
		}
	}

	return t
end

local bt_moveto_finditem_out_boxpos = {
	node = "BTNTaskMoveTo",
	param = {
		avoidWater = true,
		speed = 1,
		minDistance = 1,
		bbkey_targetpos = "finditem_out_boxpos",
		bbkey_speed_ratio = "bbkeySpeedRatio"
	}
}
local bt_moveto_stoll_pos = TaskMoveToFunc("stollPos")
local bt_moveto_find_chair_pos = TaskMoveToFunc("findChairPos")
local bt_moveto_bonfirepos = TaskMoveToFunc("bonfirepos")
local bt_moveto_bbKeyEscapeTargetPos = TaskMoveToFunc("bbKeyEscapeTargetPos")
local bt_moveto_bbkey_targetpos = TaskMoveToFunc("bbkey_targetpos")
local bt_action_idle_stroll = {
	node = "BTNodeSequence",
	param = {
		tip = "bt_action_idle_stroll"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getVillagePos",
				subparam = {
					bb_villagepos = "villagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getRandStollPos",
				subparam = {
					bb_stollpos = "stollPos",
					bigCenterPos = "villagepos",
					bigRange = {
						x = AIFunctionDefsGetDefByKey("villageRange"),
						y = AIFunctionDefsGetDefByKey("villageRange"),
						z = AIFunctionDefsGetDefByKey("villageRange")
					}
				}
			}
		},
		bt_moveto_stoll_pos
	}
}
local bt_action_idle_sitWander = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindPosByNeedType",
								subparam = {
									bbkey_targetpos = "findChairPos",
									bbkey_itemid = "",
									bempty = true,
									equipslot = 0,
									searchType = 4
								}
							}
						},
						bt_moveto_find_chair_pos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_sitDown",
								subparam = {
									bbkey_chairPos = "findChairPos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 10,
									soundName = "fantasy.ogg",
									animID = 100103
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_sitDown"
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 10,
									animID = 100103
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 2
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_standUp"
			}
		}
	}
}
local bt_action_idle_dance = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				subparam = {
					targetID = 1200,
					range = 16,
					bbKeyTargetPos = "bonfirepos",
					targetType = AIFunctionDefsGetDefByKey("findTargetType").block
				}
			}
		},
		bt_moveto_bonfirepos,
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_PEventPlayAction",
						subparam = {
							type = 4,
							duration = 5,
							flag = false
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = true,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_DANCE,
										true
									}
								}
							}
						},
						{
							node = "BTNodeWait",
							param = {
								wait = 5
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = false,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_DANCE,
										true
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_idle_sing = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				subparam = {
					targetID = 1200,
					range = 16,
					bbKeyTargetPos = "bonfirepos",
					targetType = AIFunctionDefsGetDefByKey("findTargetType").block
				}
			}
		},
		bt_moveto_bonfirepos,
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_PEventPlayAction",
						subparam = {
							type = 5,
							duration = 5,
							flag = false
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = true,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_SING,
										true
									}
								}
							}
						},
						{
							node = "BTNodeWait",
							param = {
								wait = 5
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = false,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_SING,
										true
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_idle_talk = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 2,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").disposition,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonFindTargetPos",
						subparam = {
							actorObjType = 62,
							range = 16,
							bbKeyTargetPos = "chatActorPos",
							targetID = 3200,
							targetType = AIFunctionDefsGetDefByKey("findTargetType").actor
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonFindTargetPos",
						subparam = {
							actorObjType = 62,
							range = 16,
							bbKeyTargetPos = "chatActorPos",
							targetID = 3201,
							targetType = AIFunctionDefsGetDefByKey("findTargetType").actor
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonFindTargetPos",
						subparam = {
							actorObjType = 62,
							range = 16,
							bbKeyTargetPos = "chatActorPos",
							targetID = 3202,
							targetType = AIFunctionDefsGetDefByKey("findTargetType").actor
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 400,
					extraValue = "chatActorPos",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").targetDis,
					compareType = AIFunctionDefsGetDefByKey("compareType").less
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 10,
					animID = 200206
				}
			}
		}
	}
}
local bt_neardeath = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "通用判断叶子，所有的判断都可用此叶子实现",
				subparam = {
					compareValue = 100,
					judgeType = 20,
					compareType = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "通用判断叶子，所有的判断都可用此叶子实现",
				subparam = {
					compareValue = 70,
					judgeType = 20,
					compareType = 5
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_checkEscape",
				desc = "是否需要逃离",
				subparam = {
					range = 16,
					bbKeyTargetPos = "bbKeyEscapeTargetPos",
					bossRange = 32,
					bbKeyTargetObjId = "bbKeyEscapeTargetObjId"
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNTaskMoveTo",
					param = {
						CollideHorizontallyStop = false,
						speed = 0.5,
						minDistance = 1,
						bbkey_targetpos = "bbKeyEscapeTargetPos"
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
						subparam = {
							soundName = "bb_dying1SoundName",
							duration = 5
						}
					}
				}
			}
		}
	}
}
local bt_action_work_needTrain = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				desc = "通用设置值叶子，所有的设置值操作都可用此叶子实现",
				subparam = {
					valueType = 1,
					extraValue = "",
					value = 4,
					key = ""
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				desc = "通用设置值叶子，所有的设置值操作都可用此叶子实现",
				subparam = {
					valueType = 2,
					extraValue = "",
					value = "bb_tamedFoodId",
					key = ""
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				desc = "通用提示叶子",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "老哥快驯服我"
				}
			}
		},
		{
			desc = "等待节点，叶子节点，等待n秒(由参数决定，默认一个tick)后，返回成功",
			node = "BTNodeWait",
			param = {
				wait = 3
			}
		}
	}
}
local bt_Untamed_Escape = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_checkEscape",
				desc = "是否需要逃离",
				subparam = {
					range = 16,
					bbKeyTargetPos = "bbKeyEscapeTargetPos",
					bossRange = 32,
					bbKeyTargetObjId = "bbKeyEscapeTargetObjId"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				desc = "通用提示叶子",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "发现野人！"
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = true,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_FLEE,
										true
									}
								}
							}
						},
						bt_moveto_bbKeyEscapeTargetPos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = false,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_FLEE,
										true
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
						subparam = {
							duration = 5,
							effectID = "",
							soundName = "bb_escapeSoundName",
							animID = 200104
						}
					}
				}
			}
		}
	}
}
local bt_Untamed_NeedTame = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeInversion",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_checkEscape",
						desc = "是否需要逃离",
						subparam = {
							range = 16,
							bbKeyTargetPos = "bbKeyEscapeTargetPos",
							bossRange = 32,
							bbKeyTargetObjId = "bbKeyEscapeTargetObjId"
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						desc = "通用设置值叶子，所有的设置值操作都可用此叶子实现",
						subparam = {
							valueType = 1,
							extraValue = "",
							value = 4,
							key = ""
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						desc = "通用设置值叶子，所有的设置值操作都可用此叶子实现",
						subparam = {
							valueType = 2,
							extraValue = "",
							value = "bb_tamedFoodId",
							key = ""
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonTips",
						desc = "通用提示叶子",
						subparam = {
							type = 1,
							contentType = 0,
							targetUin = 0,
							content = "老哥快驯服我"
						}
					}
				},
				{
					node = "BTNodeRandom",
					children = {
						{
							node = "BTNodeSimpleParallel",
							children = {
								bt_action_idle_sitWander,
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonPlayAction",
										desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
										subparam = {
											duration = 5,
											tipsItemId = "bb_tamedFoodId",
											soundName = "npc.hungry",
											animID = 100103,
											tipsBgName = "",
											tipsType = "",
											effectID = "mob_3200_hungery"
										}
									}
								}
							}
						},
						{
							node = "BTNodeRandom",
							children = {
								bt_action_idle_Leisure,
								bt_action_idle_lookAround
							}
						}
					}
				},
				{
					desc = "等待节点，叶子节点，等待n秒(由参数决定，默认一个tick)后，返回成功",
					node = "BTNodeWait",
					param = {
						wait = 3
					}
				}
			}
		}
	}
}
local bt_node_find_material = {
	node = "BTNodeSelector",
	param = {
		tip = "find_material"
	},
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getVillagePos",
					subparam = {
						bb_villagepos = "villagepos"
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						avoidWater = true,
						speed = 1,
						bbkey_targetpos = "villagepos",
						minDistance = AIFunctionDefsGetDefByKey("villageStoreRange")
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "villagepos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithVillagePoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "store range find items"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindItemFromBox",
								subparam = {
									bbkey_out_iteminfo = "finditem_out_iteminfo",
									bbkey_out_boxpos = "finditem_out_boxpos",
									findPositionType = 1,
									findCustomItems = "finditem_itemids",
									findItemType = AI_FIND_CUSTOM
								}
							}
						},
						bt_moveto_finditem_out_boxpos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_TakeItemToPack",
								subparam = {
									bbkey_multi_iteminfos = "finditem_itemids",
									bbkey_in_boxpos = "finditem_out_boxpos",
									takeitemmode = 2
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindItemFromBox",
						subparam = {
							range = 11,
							bbkey_out_boxpos = "finditem_out_boxpos",
							findPositionType = 2,
							findCustomItems = "finditem_itemids",
							findItemType = AI_FIND_CUSTOM
						}
					}
				},
				bt_moveto_finditem_out_boxpos,
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_TakeItemToPack",
						subparam = {
							bbkey_multi_iteminfos = "finditem_itemids",
							bbkey_in_boxpos = "finditem_out_boxpos",
							takeitemmode = 2
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							curValue = "finditem_idle_times",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").more
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							value = 1,
							key = "finditem_idle_times",
							valueType = AIFunctionDefsGetDefByKey("valueType").value,
							operationType = AIFunctionDefsGetDefByKey("operationType").reduce
						}
					}
				},
				bt_action_idle_stroll
			}
		}
	}
}
local bt_node_find_item = {
	node = "BTNodeSelector",
	param = {
		tip = "find_item"
	},
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getVillagePos",
					subparam = {
						bb_villagepos = "villagepos"
					}
				}
			}
		},
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getWorkPos",
					subparam = {
						bb_workpos = "find_bind_workPoint"
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 1,
											extraValue = "find_bind_workPoint",
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										bbkey_targetpos = "find_bind_workPoint",
										minDistance = AIFunctionDefsGetDefByKey("workRange")
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FindItemFromBox",
										subparam = {
											bbkey_out_iteminfo = "finditem_out_iteminfo",
											bbkey_out_boxpos = "finditem_out_boxpos",
											findPositionType = 4,
											findCustomItems = "finditem_itemids",
											findItemType = AI_FIND_CUSTOM
										}
									}
								},
								bt_moveto_finditem_out_boxpos,
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_TakeItemToPack",
										subparam = {
											bbkey_multi_iteminfos = "finditem_itemids",
											bbkey_in_boxpos = "finditem_out_boxpos",
											takeitemmode = 2
										}
									}
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								avoidWater = true,
								speed = 1,
								bbkey_targetpos = "villagepos",
								minDistance = AIFunctionDefsGetDefByKey("villageStoreRange")
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "villagepos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithVillagePoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "store range find items"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindItemFromBox",
								subparam = {
									bbkey_out_iteminfo = "finditem_out_iteminfo",
									bbkey_out_boxpos = "finditem_out_boxpos",
									findPositionType = 1,
									findCustomItems = "finditem_itemids",
									findItemType = AI_FIND_CUSTOM
								}
							}
						},
						bt_moveto_finditem_out_boxpos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_TakeItemToPack",
								subparam = {
									bbkey_multi_iteminfos = "finditem_itemids",
									bbkey_in_boxpos = "finditem_out_boxpos",
									takeitemmode = 2
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindItemFromBox",
						subparam = {
							range = 11,
							bbkey_out_boxpos = "finditem_out_boxpos",
							findPositionType = 2,
							findCustomItems = "finditem_itemids",
							findItemType = AI_FIND_CUSTOM
						}
					}
				},
				bt_moveto_finditem_out_boxpos,
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_TakeItemToPack",
						subparam = {
							bbkey_multi_iteminfos = "finditem_itemids",
							bbkey_in_boxpos = "finditem_out_boxpos",
							takeitemmode = 2
						}
					}
				}
			}
		},
		bt_action_idle_stroll
	}
}
local bt_node_store_material = {
	node = "BTNodeSelector",
	param = {
		tip = "find_material"
	},
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getVillagePos",
					subparam = {
						bb_villagepos = "villagepos"
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						avoidWater = true,
						speed = 1,
						bbkey_targetpos = "villagepos",
						minDistance = AIFunctionDefsGetDefByKey("villageStoreRange")
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "villagepos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithVillagePoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "store range find items"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 1,
									result_blockpos = "finditem_out_boxpos",
									rangeY = 10,
									findBlockType = AI_FIND_BOX_NOT_FULL,
									range = AIFunctionDefsGetDefByKey("villageStoreRange")
								}
							}
						},
						bt_moveto_finditem_out_boxpos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_storeItemByList",
								subparam = {
									in_TargetPos = "finditem_out_boxpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									animID = 100105
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindBlock",
						subparam = {
							findPositionType = 2,
							range = 11,
							result_blockpos = "finditem_out_boxpos",
							rangeY = 10,
							findBlockType = AI_FIND_BOX_NOT_FULL
						}
					}
				},
				bt_moveto_finditem_out_boxpos,
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_storeItemByList",
						subparam = {
							in_TargetPos = "finditem_out_boxpos"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						subparam = {
							duration = 1,
							animID = 100105
						}
					}
				}
			}
		},
		bt_action_idle_stroll
	}
}
local bt_is_can_store_item = {
	tip = "work props judge",
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").emptygrid,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 13,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").bagItemCount,
					compareType = AIFunctionDefsGetDefByKey("compareType").moreEqual,
					extraValue = {
						2,
						true
					}
				}
			}
		}
	}
}
local bt_node_store_item = {
	node = "BTNodeSelector",
	param = {
		tip = "find_item"
	},
	children = {
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getVillagePos",
					subparam = {
						bb_villagepos = "villagepos"
					}
				}
			}
		},
		{
			node = "BTNodeInversion",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_getWorkPos",
					subparam = {
						bb_workpos = "find_bind_workPoint"
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							extraValue = AIFunctionDefsGetDefByKey("rangeType").village
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 1,
											extraValue = "find_bind_workPoint",
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										bbkey_targetpos = "find_bind_workPoint",
										minDistance = AIFunctionDefsGetDefByKey("workRange")
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FindBlock",
										subparam = {
											findPositionType = 4,
											result_blockpos = "finditem_out_boxpos",
											rangeY = 10,
											findBlockType = AI_FIND_BOX_NOT_FULL,
											range = AIFunctionDefsGetDefByKey("workRange")
										}
									}
								},
								bt_moveto_finditem_out_boxpos,
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_storeItemByList",
										subparam = {
											storeMode = 2,
											in_TargetPos = "finditem_out_boxpos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonPlayAction",
										subparam = {
											duration = 1,
											animID = 100105
										}
									}
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								avoidWater = true,
								speed = 1,
								bbkey_targetpos = "villagepos",
								minDistance = AIFunctionDefsGetDefByKey("villageStoreRange")
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "villagepos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithVillagePoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "store range find items"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 1,
									result_blockpos = "finditem_out_boxpos",
									rangeY = 10,
									findBlockType = AI_FIND_BOX_NOT_FULL,
									range = AIFunctionDefsGetDefByKey("villageStoreRange")
								}
							}
						},
						bt_moveto_finditem_out_boxpos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_storeItemByList",
								subparam = {
									storeMode = 2,
									in_TargetPos = "finditem_out_boxpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 1,
									animID = 100105
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindBlock",
						subparam = {
							findPositionType = 2,
							range = 11,
							result_blockpos = "finditem_out_boxpos",
							rangeY = 10,
							findBlockType = AI_FIND_BOX_NOT_FULL
						}
					}
				},
				bt_moveto_finditem_out_boxpos,
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_storeItemByList",
						subparam = {
							storeMode = 2,
							in_TargetPos = "finditem_out_boxpos"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						subparam = {
							duration = 1,
							animID = 100105
						}
					}
				}
			}
		},
		bt_action_idle_stroll
	}
}
local bt_node_set_craftItem = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 1,
					key = "craftItem_flag",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = "craft_need_items",
					key = "craftItem_target_items",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 3,
					key = "finditem_idle_times",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		}
	}
}
local bt_node_clear_craftItem = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "craftItem_flag",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					key = "craftItem_target_items",
					valueType = AIFunctionDefsGetDefByKey("valueType").value,
					value = {}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "craftItem_cur_item",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					key = "craftItem_need_materials",
					valueType = AIFunctionDefsGetDefByKey("valueType").value,
					value = {}
				}
			}
		}
	}
}
local bt_node_craftItem_delivery = {
	node = "BTNodeCondition",
	param = {
		tip = "delivery"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					curValue = "craftItem_success_item",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").notequal
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeSuccess",
					children = {
						node = "BTNodeSequence",
						children = {
							{
								node = "BTNodeSuccess",
								children = {
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_EquipWeapon",
										subparam = {
											bbEquipItemId = "craftItem_success_item",
											bbEquipItemNum = 1
										}
									}
								}
							},
							{
								node = "BTNTaskFollow",
								param = {
									speed = 1.3,
									bbkey_followobj = "craft_guest_target",
									minDistance = 2.5
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_giveItem",
									subparam = {
										bbKeyGiveItemFromHand = true,
										bbKeyTargetObjId = "craft_guest_target",
										bbKeyGiveItemId = "craftItem_success_item",
										bbKeyGiveItemCount = 1
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						node = "BTNodeTaskLua",
						param = {
							script = "BTTask_UnbindWorkTarget"
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						bt_node_store_material
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							value = 0,
							key = "craftItem_success_item",
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				}
			}
		}
	}
}
local bt_node_craftItem_success = {
	node = "BTNodeSequence",
	param = {
		tip = "craftItem_success"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					content = "合成成功"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = "craftItem_cur_item",
					key = "craftItem_success_item",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					content = "craftItem_success_item",
					bbflag = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "craft_working",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					soundName = "crafted.ogg",
					tipsBgName = "mob_3200_craft"
				}
			}
		},
		bt_node_clear_craftItem
	}
}
local bt_node_craftItem_fail = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "craft_working",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				bt_node_store_material
			}
		},
		bt_node_clear_craftItem
	}
}
local bt_node_craftItem = {
	node = "BTNodeCondition",
	param = {
		tip = "craftItem"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					curValue = "craftItem_flag",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeCondition",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_GetItemFromBody",
								subparam = {
									itemCustomDatas = "craft_need_items",
									result_out_itemid = "craftItem_cur_item",
									getMode = AI_FINDPOSITION_HAND_BAG,
									itemType = AI_FIND_CUSTOM
								}
							}
						},
						bt_node_craftItem_success
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "compound from bag"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 0,
									curValue = "craftItem_cur_item",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
									compareType = AIFunctionDefsGetDefByKey("compareType").notequal
								}
							}
						},
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_CraftingItemCompound",
										subparam = {
											compoundMode = 2,
											bbkey_out_craftTimes = "craftItem_craft_times",
											bbkey_targetItems = "craftItem_cur_item"
										}
									}
								},
								{
									node = "BTNodeFail",
									children = {
										node = "BTNodeSequence",
										children = {
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_commonJudge",
													subparam = {
														compareValue = 0,
														curValue = "craftItem_craft_times",
														judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
														compareType = AIFunctionDefsGetDefByKey("compareType").more
													}
												}
											},
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_commonPlayAction",
													subparam = {
														tipsBgName = "mob_3200_make",
														duration = 2,
														soundName = "crafting.ogg",
														animID = 100112
													}
												}
											}
										}
									}
								}
							}
						},
						{
							node = "BTNodeSuccess",
							children = {
								node = "BTNodeSequence",
								children = {
									{
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_commonJudge",
											subparam = {
												compareValue = 0,
												curValue = "craftItem_craft_times",
												judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
												compareType = AIFunctionDefsGetDefByKey("compareType").more
											}
										}
									},
									{
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_commonPlayAction",
											subparam = {
												tipsBgName = "mob_3200_make",
												duration = 2,
												soundName = "crafting.ogg",
												animID = 100112
											}
										}
									}
								}
							}
						},
						bt_node_craftItem_success
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 0,
									curValue = "craftItem_cur_item",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
									compareType = AIFunctionDefsGetDefByKey("compareType").notequal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_CraftingItemSplit",
								subparam = {
									bbkey_targetItem = "craftItem_cur_item",
									bbkey_out_materails = "craftItem_need_materials"
								}
							}
						},
						{
							node = "BTNodeSequence",
							param = {
								tip = "find materials"
							},
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonSetValue",
										subparam = {
											value = "craftItem_need_materials",
											key = "finditem_itemids",
											valueType = AIFunctionDefsGetDefByKey("valueType").value
										}
									}
								},
								bt_node_find_material
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_CraftingItemNext",
								subparam = {
									bbkey_out_first = "craftItem_cur_item",
									bbkey_targetItems = "craftItem_target_items"
								}
							}
						},
						{
							node = "BTNodeSuccess",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonTips",
									tip = "craftItem_cur_item",
									subparam = {
										content = "craftItem_cur_item",
										bbflag = 1
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 3,
									key = "finditem_idle_times",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				},
				bt_node_craftItem_fail
			}
		}
	}
}
local bt_fire_battle_is_guard = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").disposition,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					compareValue = DISPOSITION_BRAVE
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					compareValue = PROFESSION_MELEE_GUARD
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					compareValue = PROFESSION_REMOTE_GUARD
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					compareValue = PROFESSION_HUNTER
				}
			}
		}
	}
}
bt_check_remote_weapon = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 5,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").handItemType,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_GetBagData",
						subparam = {
							bbFirstItemId = "equipItemId",
							typeId = 9
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_EquipWeapon",
						subparam = {
							bbEquipItemId = "equipItemId",
							bbEquipItemNum = 1
						}
					}
				}
			}
		}
	}
}
bt_check_is_remote_profession = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					compareValue = PROFESSION_REMOTE_GUARD
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					compareValue = PROFESSION_HUNTER
				}
			}
		}
	}
}

local function enemyValidFunc(name)
	local t = {
		node = "BTNodeSequence",
		children = {
			{
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonJudge",
					subparam = {
						compareValue = 1,
						judgeType = AIFunctionDefsGetDefByKey("judgeType").isActorExist,
						compareType = AIFunctionDefsGetDefByKey("compareType").equal,
						extraValue = name
					}
				}
			},
			{
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonJudge",
					subparam = {
						compareValue = 1,
						judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
						compareType = AIFunctionDefsGetDefByKey("compareType").equal,
						extraValue = {
							AIFunctionDefsGetDefByKey("rangeType").view,
							name
						}
					}
				}
			}
		}
	}

	return t
end

local function fireFunc(target_name)
	local bt_fire_battle_target = {
		node = "BTNodeSelector",
		children = {
			{
				node = "BTNodeSequence",
				children = {
					{
						node = "BTNodeTaskLua",
						param = {
							script = "BTTask_commonJudge",
							subparam = {
								judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
								compareType = AIFunctionDefsGetDefByKey("compareType").equal,
								compareValue = PROFESSION_MELEE_GUARD
							}
						}
					},
					{
						node = "BTNodeSelector",
						children = {
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonJudge",
									subparam = {
										compareValue = 4,
										judgeType = AIFunctionDefsGetDefByKey("judgeType").handItemType,
										compareType = AIFunctionDefsGetDefByKey("compareType").equal
									}
								}
							},
							{
								node = "BTNodeSequence",
								children = {
									{
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_GetBagData",
											subparam = {
												bbFirstItemId = "equipItemId",
												typeId = 8
											}
										}
									},
									{
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_EquipWeapon",
											subparam = {
												bbEquipItemId = "equipItemId",
												bbEquipItemNum = 1
											}
										}
									}
								}
							}
						}
					},
					{
						node = "BTNodeSequence",
						children = {
							{
								node = "BTNTaskFollow",
								param = {
									speed = 1.3,
									minDistance = 2.5,
									bbkey_followobj = target_name
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_TurnToTarget",
									subparam = {
										bbTargetKey = target_name
									}
								}
							},
							{
								node = "BTNTaskAttack",
								param = {
									keeptick = 10,
									bbkey_attackobj = target_name
								}
							}
						}
					}
				}
			},
			{
				node = "BTNodeSequence",
				children = {
					bt_check_is_remote_profession,
					bt_check_remote_weapon,
					{
						node = "BTNTaskRangeAttack",
						param = {
							min_attack_time = 1,
							count = 1,
							power = 1,
							max_attack_time = 5,
							bbkey_attackobj = target_name,
							bbkey_attackrange = AIFunctionDefsGetDefByKey("longRangeAttackSearch")
						}
					}
				}
			}
		}
	}

	return bt_fire_battle_target
end

local function clearEnemyFunc(name)
	local t = {
		node = "BTNodeSequence",
		children = {
			{
				node = "BTNodeFail",
				children = {
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							valueType = AIFunctionDefsGetDefByKey("valueType").value,
							key = name,
							value = {
								actor = 0
							}
						}
					}
				}
			},
			{
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = false,
						valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
						extraValue = {
							ACTOR_ANIM_FLAG_SHOOT,
							false
						}
					}
				}
			}
		}
	}

	return t
end

local bt_fire_battle_valid_attack_behurt = enemyValidFunc("bbKeyBeHurtTargetObjId")
local bt_fire_battle_attack_behurt = fireFunc("bbKeyBeHurtTargetObjId")
local bt_fire_battle_clear_attack_behurt = clearEnemyFunc("bbKeyBeHurtTargetObjId")
local bt_fire_battle_valid_attack_enemy = enemyValidFunc("enemy_id")
local bt_fire_battle_attack_enemy = fireFunc("enemy_id")
local bt_fire_battle_clear_attack_enemy = clearEnemyFunc("enemy_id")
local bt_fire_battle_attack_target = fireFunc("bbKeyAttackTargetObjId")
local bt_fire_acttack_unfriendly_player = {
	node = "BTNodeBranch",
	children = {
		bt_fire_battle_valid_attack_behurt,
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNTaskFollow",
					param = {
						speed = 1.3,
						bbkey_followobj = "bbKeyBeHurtTargetObjId",
						minDistance = 2.5
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_TurnToTarget",
						subparam = {
							bbTargetKey = "bbKeyBeHurtTargetObjId"
						}
					}
				},
				{
					node = "BTNTaskAttack",
					param = {
						keeptick = 10,
						bbkey_attackobj = "bbKeyBeHurtTargetObjId"
					}
				}
			}
		},
		bt_fire_battle_clear_attack_behurt
	}
}
local bt_escape = {
	node = "BTNodeCondition",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_checkEscape",
				subparam = {
					range = 12,
					bbKeyTargetPos = "bbKeyEscapeTargetPos",
					bossRange = 32
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = true,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_FLEE,
										true
									}
								}
							}
						},
						bt_moveto_bbKeyEscapeTargetPos,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = false,
									valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
									extraValue = {
										ACTOR_ANIM_FLAG_FLEE,
										true
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						subparam = {
							duration = 5,
							effectID = "",
							soundName = "bb_escapeSoundName",
							animID = 200104
						}
					}
				}
			}
		}
	}
}
local bt_general_villager = {
	node = "BTNodeSelector",
	children = {
		bt_escape,
		bt_fire_acttack_unfriendly_player
	}
}
local bt_fire = {
	node = "BTNodeBranch",
	param = {
		tip = "bt_fire"
	},
	children = {
		bt_fire_battle_is_guard,
		{
			node = "BTNodeSelector",
			param = {
				tip = "bt_fire1"
			},
			children = {
				{
					node = "BTNodeBranch",
					children = {
						bt_fire_battle_valid_attack_behurt,
						bt_fire_battle_attack_behurt,
						bt_fire_battle_clear_attack_behurt
					}
				},
				{
					node = "BTNodeBranch",
					param = {
						tip = "bt_fire2"
					},
					children = {
						bt_fire_battle_valid_attack_enemy,
						bt_fire_battle_attack_enemy,
						bt_fire_battle_clear_attack_enemy
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "bt_fire3"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_checkAttack",
								subparam = {
									bbKeyTargetObjId = "bbKeyAttackTargetObjId",
									bbKeyTargetPos = "bbKeyAttackTargetPos",
									range = 16
								}
							}
						},
						bt_fire_battle_attack_target
					}
				}
			}
		},
		bt_general_villager
	}
}
local bt_need_Tamed_Eat_BagHaveFood = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包内有食物",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 3,
					extraValue = {
						1,
						true
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_putFoodInHand",
				desc = "把食物放在手上",
				subparam = {
					bbFoodId = ""
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 1
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_EAT,
						true
					}
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_EatHandFood",
				desc = "吃手上的食物"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = false,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_EAT,
						true
					}
				}
			}
		}
	}
}
local bt_need_Tamed_Eat_BagHaveNotFood = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有食物",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						1,
						true
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindPosByNeedType",
				desc = "获取需求箱子位置 ",
				subparam = {
					bbkey_targetpos = "BTTask_FindStoragePos",
					equipslot = 0,
					searchType = 2,
					bbkey_itemid = "finditem"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				CollideHorizontallyStop = false,
				speed = 1,
				minDistance = 1,
				bbkey_targetpos = "BTTask_FindStoragePos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				desc = "从箱子中取出一定数量的道具",
				subparam = {
					bbkey_one_takeid = "finditem",
					bbkey_in_boxpos = "BTTask_FindStoragePos",
					bbkey_one_takenum = 2
				}
			}
		}
	}
}
local bt_need_Tamed_Hungry_Ask = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				desc = "通用寻找目标位置叶子，所有的寻找目标位置都可用此叶子实现",
				subparam = {
					bbKeyTargetPos = "bbkey_targetpos",
					targetType = 3,
					range = 16,
					bbKeyTargetObjId = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNTaskFollow",
			param = {
				speed = 1.3,
				bbkey_followobj = "bbKeyTargetObjId",
				minDistance = 5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
				subparam = {
					tipsContentName = "bb_tamedFoodId",
					soundName = "hungry.ogg",
					effectID = "",
					tipsBgName = "",
					tipsType = ""
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_STAND_BY_HUNGER,
						true
					}
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 5
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = false,
					valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
					extraValue = {
						ACTOR_ANIM_FLAG_STAND_BY_HUNGER,
						true
					}
				}
			}
		}
	}
}
local bt_need_Tamed_Hungry_Pickup = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindDropFoodPos",
				desc = "搜寻范围内掉落食物的位置",
				subparam = {
					bbTargetIdKey = "find_food_targetid",
					bbPosKey = "find_food_pos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				speed = 1,
				bbkey_targetpos = "find_food_pos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_Pick",
				desc = "捡起掉落物到背包",
				subparam = {
					dropItemId = "find_food_targetid"
				}
			}
		}
	}
}
local find_food = {
	node = "BTNodeSimpleParallel",
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							key = "finditem_itemids",
							valueType = AIFunctionDefsGetDefByKey("valueType").value,
							value = GetInst("AIFunctionDefs"):GetToolCfg(6)
						}
					}
				},
				bt_node_find_item
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeSuccess",
					children = {
						node = "BTNodeTaskLua",
						param = {
							script = "BTTask_commonPlayAction",
							subparam = {
								duration = 3,
								tipsItemId = "bb_tamedFoodId"
							}
						}
					}
				}
			}
		}
	}
}
local bt_need_eat = {
	node = "BTNodeSelector",
	param = {
		tip = "need eat"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							curValue = "isEating",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 60,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
											compareType = AIFunctionDefsGetDefByKey("compareType").moreEqual
										}
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_commonSetValue",
											subparam = {
												value = 0,
												key = "isEating",
												valueType = AIFunctionDefsGetDefByKey("valueType").value
											}
										}
									}
								}
							}
						},
						bt_need_Tamed_Eat_BagHaveFood,
						{
							node = "BTNodeSimpleParallel",
							children = {
								{
									node = "BTNodeSelector",
									children = {
										find_food,
										{
											node = "BTNodeSequence",
											children = {
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_commonJudge",
														subparam = {
															compareValue = 0,
															judgeType = AIFunctionDefsGetDefByKey("judgeType").huggerStatus,
															compareType = AIFunctionDefsGetDefByKey("compareType").more
														}
													}
												},
												{
													node = "BTNodeSelector",
													children = {
														bt_need_Tamed_Hungry_Pickup,
														{
															node = "BTNodeSequence",
															children = {
																{
																	node = "BTNodeTaskLua",
																	param = {
																		script = "BTTask_commonJudge",
																		subparam = {
																			compareValue = 3,
																			judgeType = AIFunctionDefsGetDefByKey("judgeType").huggerStatus,
																			compareType = AIFunctionDefsGetDefByKey("compareType").moreEqual
																		}
																	}
																},
																{
																	node = "BTNodeSelector",
																	children = {
																		bt_need_Tamed_Hungry_Ask,
																		{
																			node = "BTNodeFail",
																			children = {
																				node = "BTNodeTaskLua",
																				param = {
																					script = "BTTask_commonPlayAction",
																					subparam = {
																						duration = 5,
																						effectID = "mob_3200_hungery",
																						soundName = "hungry.ogg",
																						animID = 100164
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										},
										bt_action_idle_stroll
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeSuccess",
											children = {
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_commonPlayAction",
													subparam = {
														duration = 3,
														tipsItemId = "bb_tamedFoodId"
													}
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_AskHelperForNeed",
												desc = "向帮手申请需求",
												subparam = {
													needType = 6
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 10,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").fullUp,
							compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							value = 1,
							key = "isEating",
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = 0,
						key = "isEating",
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_action_sleep = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindPosByNeedType",
						subparam = {
							bempty = true,
							equipslot = 0,
							searchType = 3,
							bbkey_targetpos = "bedpos"
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				speed = 1,
				minDistance = 0,
				bbkey_targetpos = "bedpos"
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 0,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBlockOccupyed,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							extraValue = "bedpos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBedBindWithOthers,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_sleepOnAndBindBed",
				subparam = {
					bb_bedpos = "bedpos"
				}
			}
		}
	}
}
local bt_action_stayingUpLate = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_PEventPlayAction",
						subparam = {
							type = 2,
							duration = 3,
							flag = true
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_PEventPlayAction",
						subparam = {
							type = 3,
							duration = 3,
							flag = true
						}
					}
				},
				bt_worship,
				bt_action_idle_stroll
			}
		}
	}
}
local bt_action_wakeup = {
	node = "BTNodeCondition",
	param = {
		tip = "bt_action_wakeup"
	},
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bedpos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 0,
									extraValue = "bedpos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithBedPoint,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_isReachTime",
								subparam = {
									timeType = AIFunctionDefsGetDefByKey("timeType").wakeUp
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_wakeup"
			}
		}
	}
}
local bt_need_sleep = {
	node = "BTNodeSelector",
	param = {
		tip = "sleep"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_isReachTime",
						subparam = {
							timeType = AIFunctionDefsGetDefByKey("timeType").stayUpLate
						}
					}
				},
				bt_action_stayingUpLate
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_isReachTime",
						subparam = {
							timeType = AIFunctionDefsGetDefByKey("timeType").sleep
						}
					}
				},
				{
					node = "BTNodeSimpleParallel",
					children = {
						{
							node = "BTNodeSelector",
							children = {
								bt_action_sleep,
								bt_action_idle_stroll,
								{
									node = "BTNodeWait",
									param = {
										wait = 1
									}
								}
							}
						},
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeCondition",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonJudge",
												subparam = {
													compareValue = 2,
													judgeType = AIFunctionDefsGetDefByKey("judgeType").stayBiome,
													compareType = AIFunctionDefsGetDefByKey("compareType").equal
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonPlayAction",
												subparam = {
													duration = 3,
													tipsItemId = 484
												}
											}
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonPlayAction",
										subparam = {
											duration = 3,
											tipsItemId = 828
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

local function modelScaleFunc(scale)
	local t = {
		node = "BTNodeTaskLua",
		param = {
			script = "BTTask_commonSetValue",
			tip = "cd current tick",
			subparam = {
				valueType = AIFunctionDefsGetDefByKey("valueType").modelScale,
				value = scale
			}
		}
	}

	return t
end

local bt_model_scale1 = modelScaleFunc(1)
local bt_model_scale2 = modelScaleFunc(1.1)
local bbkeyEnableWorship = "bbkeyEnableWorship"
local bt_worship_is_vaild = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1200,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").bufferDuration,
					compareType = AIFunctionDefsGetDefByKey("compareType").more
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_speedRatio",
				desc = "",
				subparam = {
					bbkeySpeedRatio = "bbkeySpeedRatio",
					value = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					valueType = AIFunctionDefsGetDefByKey("valueType").value,
					key = bbkeyEnableWorship
				}
			}
		},
		bt_model_scale1,
		{
			node = "BTNodeFail"
		}
	}
}
local bt_worship_exit = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_speedRatio",
				desc = "",
				subparam = {
					bbkeySpeedRatio = "bbkeySpeedRatio",
					value = 1
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				tip = "cd current tick",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").saveCdTick
				}
			}
		},
		bt_model_scale1,
		{
			node = "BTNodeFail"
		}
	}
}
local bt_worship_work = {
	node = "BTNodeBranch",
	param = {
		tip = "bt_worship_work"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isHaveWorshipBlock,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		bt_worship_is_vaild,
		bt_worship_exit
	}
}
local bt_worship_ani = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_PEventPlayAction",
				subparam = {
					type = 6,
					duration = 3,
					flag2 = true
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_PEventPlayAction",
				subparam = {
					type = 7,
					duration = 3,
					flag2 = true
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_PEventPlayAction",
				subparam = {
					type = 8,
					duration = 3,
					flag2 = false
				}
			}
		}
	}
}
local bt_worship_to_activation = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isHaveWorshipBlock,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 3600,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").cdDuration,
					compareType = AIFunctionDefsGetDefByKey("compareType").more
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				desc = "通用寻找目标位置叶子，所有的寻找目标位置都可用此叶子实现",
				subparam = {
					bbKeyTargetPos = "bbkey_targetpos",
					targetType = 3,
					range = 15,
					bbKeyTargetObjId = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_speedRatio",
				desc = "",
				subparam = {
					bbkeySpeedRatio = "bbkeySpeedRatio",
					value = 2
				}
			}
		},
		{
			node = "BTNTaskFollow",
			param = {
				speed = 1.3,
				bbkey_followobj = "bbKeyTargetObjId",
				minDistance = 3,
				bbkey_speed_ratio = "bbkeySpeedRatio"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "bbKeyTargetObjId"
				}
			}
		},
		bt_worship_ani,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 1,
					valueType = AIFunctionDefsGetDefByKey("valueType").value,
					key = bbkeyEnableWorship
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				tip = "cd current tick",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").saveCdTick
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				tip = "cd current tick",
				subparam = {
					value = true,
					valueType = AIFunctionDefsGetDefByKey("valueType").saveBufferTick
				}
			}
		},
		bt_model_scale2,
		{
			node = "BTNodeFail"
		}
	}
}
local bt_worship = {
	node = "BTNodeBranch",
	param = {
		tip = "bt_worship"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					curValue = bbkeyEnableWorship
				}
			}
		},
		bt_worship_work,
		bt_worship_to_activation
	}
}
local bt_warn = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					curValue = "bbkeyWarnThief",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "bbkeyWarnThief",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		},
		{
			node = "BTNTaskFollow",
			param = {
				speed = 1.3,
				bbkey_followobj = "bbKeyTargetObjId",
				minDistance = 2,
				bbkey_speed_ratio = "bbkeySpeedRatio"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 10
			}
		}
	}
}
local bt_temperature_cold = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isIceVillage,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = -3,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").temperature,
					compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 12313,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").equipItemId,
					compareType = AIFunctionDefsGetDefByKey("compareType").notequal
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						subparam = {
							duration = 3,
							tipsItemId = 12313
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_PEventPlayAction",
						subparam = {
							type = 9,
							duration = 3,
							flag = false
						}
					}
				}
			}
		}
	}
}
local bt_need = {
	node = "BTNodeSelector",
	param = {
		tip = "need"
	},
	children = {
		bt_need_sleep,
		bt_need_eat
	}
}
local bt_need_guard_player = {
	node = "BTNodeBranch",
	param = {
		tip = "need_guard_player"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isGuardForPlayer,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						subparam = {
							tipsItemId2 = 12711
						}
					}
				}
			}
		},
		bt_need_eat,
		bt_need
	}
}
local bt_interact_look_node = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					curValue = "greeted_act_id",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").more
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "greeted_obj_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					animID = "greeted_act_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "greeted_act_id",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		}
	}
}
local bt_action_idle_goHome = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					extraValue = AIFunctionDefsGetDefByKey("rangeType").village
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getVillagePos",
						subparam = {
							bb_villagepos = "villagepos"
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						speed = 1,
						bbkey_targetpos = "villagepos",
						minDistance = AIFunctionDefsGetDefByKey("villageRange") - 5
					}
				}
			}
		}
	}
}
local bt_action_idle_need = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").demand,
					compareType = AIFunctionDefsGetDefByKey("compareType").more
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 4,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").demand,
					compareType = AIFunctionDefsGetDefByKey("compareType").less
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getOwnerInfo",
				subparam = {
					bbKey_ownerID = "OwnerID",
					bbKey_ownerPos = "OwnerPos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 400,
					extraValue = "OwnerPos",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").targetDis,
					compareType = AIFunctionDefsGetDefByKey("compareType").less
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "OwnerID"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 3,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").demand,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 3,
									tipsItemId = 11056,
									soundName = "need",
									animID = 200206,
									tipsBgName = "mob_3200_bubble_do",
									tipsType = 1
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 1,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").demand,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 3,
									tipsItemId = 12851,
									soundName = "need",
									animID = 200206,
									tipsBgName = "mob_3200_bubble_do",
									tipsType = 1
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 2,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").demand,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								subparam = {
									duration = 3,
									tipsItemId = 12851,
									soundName = "need",
									animID = 200206,
									tipsBgName = "mob_3200_bubble_do",
									tipsType = 1
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_idle = {
	node = "BTNodeSequence",
	children = {
		bt_action_idle_goHome,
		{
			node = "BTNodeRandom",
			children = {
				bt_action_idle_Leisure,
				bt_action_idle_lookAround,
				bt_action_idle_stroll,
				bt_action_idle_sitWander,
				bt_action_idle_dance,
				bt_action_idle_sing,
				bt_action_idle_need
			}
		}
	}
}
local bt_action_idle_lazy = {
	node = "BTNodeSequence",
	param = {
		tip = "lazy"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 3,
					extraValue = 1000,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").randomValue,
					compareType = AIFunctionDefsGetDefByKey("compareType").lessEqual
				}
			}
		},
		bt_action_idle
	}
}
local bt_action_idle_stroll_for_guard_around_player = {
	node = "BTNodeSequence",
	param = {
		tip = "guard_around_player"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "find_bind_workPoint"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					extraValue = "find_bind_workPoint",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getRandStollPos",
								subparam = {
									bb_stollpos = "stollPos",
									bigCenterPos = "find_bind_workPoint",
									bigRange = {
										x = AIFunctionDefsGetDefByKey("guardStrollPlayerAroundRange"),
										y = AIFunctionDefsGetDefByKey("guardStrollPlayerAroundRange"),
										z = AIFunctionDefsGetDefByKey("guardStrollPlayerAroundRange")
									}
								}
							}
						},
						bt_moveto_stoll_pos
					}
				}
			}
		}
	}
}
local bt_action_idle_stroll_for_guard = {
	node = "BTNodeSequence",
	param = {
		tip = "guard"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getVillagePos",
				subparam = {
					bb_villagepos = "villagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "find_bind_workPoint"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "find_bind_workPoint",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").work
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 2,
										bbkey_targetpos = "find_bind_workPoint"
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											bb_stollpos = "stollPos",
											bigCenterPos = "find_bind_workPoint",
											bigRange = {
												x = AIFunctionDefsGetDefByKey("guardStrollRange"),
												y = AIFunctionDefsGetDefByKey("guardStrollRange"),
												z = AIFunctionDefsGetDefByKey("guardStrollRange")
											}
										}
									}
								},
								bt_moveto_stoll_pos
							}
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").village
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 2,
										bbkey_targetpos = "villagepos"
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											bb_stollpos = "stollPos",
											bigCenterPos = "villagepos",
											bigRange = {
												x = AIFunctionDefsGetDefByKey("villageRange"),
												y = AIFunctionDefsGetDefByKey("villageRange"),
												z = AIFunctionDefsGetDefByKey("villageRange")
											}
										}
									}
								},
								bt_moveto_stoll_pos
							}
						}
					}
				}
			}
		}
	}
}
local bt_transform_got_item = {
	node = "BTNodeSuccess",
	children = {
		node = "BTNodeSequence",
		children = {
			{
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonJudge",
					subparam = {
						judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
						compareType = AIFunctionDefsGetDefByKey("compareType").equal,
						compareValue = PROFESSION_WOODCUTTER
					}
				}
			},
			{
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_transformItem",
					subparam = {
						srcItemId = "bb_gotItemid",
						srcItemNum = "bb_gotItemNum"
					}
				}
			}
		}
	}
}
local bt_work_Tamed_Pick_Work_Drop = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindDropByList",
				desc = "搜寻范围内列表里的掉落物的位置",
				subparam = {
					bbPosKey = "find_drop_pos",
					listsKey = "toolsList",
					bbTargetIdKey = "find_drop_targetid"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				CollideHorizontallyStop = false,
				speed = 1,
				minDistance = 1,
				bbkey_targetpos = "find_drop_pos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_Pick",
				desc = "捡起掉落物到背包",
				subparam = {
					out_Itemnum = "bb_gotItemNum",
					out_Itemid = "bb_gotItemid",
					dropItemId = "find_drop_targetid"
				}
			}
		},
		bt_transform_got_item,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
				subparam = {
					duration = 0.5,
					animID = 100105
				}
			}
		}
	}
}
local bt_work_store_drop_totem = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-1-"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getVillagePos",
				desc = "获取村子绑定点位置",
				subparam = {
					bb_villagepos = "villagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-2-"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "通用判断叶子，所有的判断都可用此叶子实现",
				subparam = {
					compareValue = 1,
					judgeType = 44,
					compareType = 2,
					extraValue = "villagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-3-"
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindEmptyStoreByType",
						desc = "寻找某个寻范围内空箱子的位置",
						subparam = {
							type = 1,
							bbCenterpos = "villagepos",
							range = 16,
							bbTargetpos = "bbkey_targetpos"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonPlayAction",
						subparam = {
							duration = 3,
							tipsItemId = 801
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-4-"
				}
			}
		},
		bt_moveto_bbkey_targetpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-5-"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
				subparam = {
					duration = 1,
					animID = 100105
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-6-"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_storeItemByList",
				desc = "把列表里的物品往箱子里存放",
				subparam = {
					storeMode = 2,
					in_TargetPos = "bbkey_targetpos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonTips",
				subparam = {
					type = 1,
					contentType = 0,
					targetUin = 0,
					content = "放东西-7-"
				}
			}
		}
	}
}
local bt_work_store_drop_village = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getVillagePos",
				desc = "获取村子绑定点位置",
				subparam = {
					bb_villagepos = "villagepos"
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				{
					desc = "闲逛搜索箱子",
					node = "BTNodeLoop",
					param = {
						timeover = 30
					},
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeInversion",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_FindEmptyStoreByType",
												desc = "寻找某个寻范围内空箱子的位置",
												subparam = {
													type = 2,
													range = 16,
													bbTargetpos = "bbkey_targetpos"
												}
											}
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											rangeWidth = 8,
											centerPos = "villagepos",
											bb_stollpos = "stollPos",
											rangeHeight = 8
										}
									}
								},
								{
									node = "BTNodeSimpleParallel",
									children = {
										{
											node = "BTNTaskMoveTo",
											param = {
												CollideHorizontallyStop = false,
												speed = 1,
												minDistance = 2,
												bbkey_targetpos = "stollPos"
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonPlayAction",
												subparam = {
													duration = 3,
													tipsItemId = 801
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		},
		bt_moveto_bbkey_targetpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
				subparam = {
					duration = 1,
					animID = 100105
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_storeItemByList",
				desc = "把列表里的物品往箱子里存放",
				subparam = {
					storeMode = 2,
					in_TargetPos = "bbkey_targetpos"
				}
			}
		}
	}
}
local bt_work_Plant_Seed = {
	node = "BTNodeSequence",
	param = {
		tip = "plant seed"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "bbPlantTreesWorkPos"
				}
			}
		},
		{
			node = "BTNTaskPlant",
			param = {
				dist = 1600,
				speed = 1,
				block_pos_key = "bbPlantTreesWorkPos",
				plant_type = 2
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 0.5
			}
		}
	}
}
local bt_work_Plant_Trees = {
	node = "BTNodeSequence",
	param = {
		tip = "plant trees"
	},
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").handItemIsSapling,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_GetBagData",
						subparam = {
							typeId = 2
						}
					}
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 2,
									judgeType = AIFunctionDefsGetDefByKey("judgeType").handItemType,
									compareType = AIFunctionDefsGetDefByKey("compareType").notequal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_PutHandItemInBags",
								subparam = {}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_GetBagData",
								subparam = {
									bbFirstItemId = "equipItemId",
									typeId = 6
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_EquipWeapon",
								subparam = {
									bbEquipItemId = "equipItemId",
									bbEquipItemNum = 1
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "bbPlantTreesWorkPos"
				}
			}
		},
		{
			node = "BTNTaskPlant",
			param = {
				speed = 1,
				plant_type = 1,
				block_pos_key = "bbPlantTreesWorkPos",
				dist = 1600,
				isauto_change_land = 1
			}
		},
		{
			node = "BTNodeWait",
			param = {
				wait = 0.5
			}
		}
	}
}
local bt_rehack_tree = {
	node = "BTNodeSelector",
	param = {
		tip = "rehack"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							curValue = "bbHackTreeIng",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FindBlock",
										subparam = {
											rangeY = 20,
											range = 5,
											result_blockpos = "bbHackTreeTargetPos",
											findPositionType = 100,
											custom_centerPos = "bbHackTreesWorkPos",
											findBlockType = AI_FIND_WOOD_AND_LEAVE
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 4,
										bbkey_targetpos = "bbHackTreeTargetPos"
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeSequence",
										children = {
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_commonJudge",
													subparam = {
														compareValue = 1,
														judgeType = AIFunctionDefsGetDefByKey("judgeType").handItemType,
														compareType = AIFunctionDefsGetDefByKey("compareType").notequal
													}
												}
											},
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_PutHandItemInBags",
													subparam = {}
												}
											},
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_GetBagData",
													subparam = {
														bbFirstItemId = "equipItemId",
														typeId = 5
													}
												}
											},
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_EquipWeapon",
													subparam = {
														bbEquipItemId = "equipItemId",
														bbEquipItemNum = 1
													}
												}
											}
										}
									}
								},
								{
									node = "BTNTaskDigBlock",
									param = {
										dist = 6400,
										speed = 1,
										block_pos_key = "bbHackTreeTargetPos",
										dig_dist = 2000
									}
								},
								{
									node = "BTNodeWait",
									param = {
										wait = 0.5
									}
								}
							}
						},
						{
							node = "BTNodeFail",
							children = {
								bt_action_idle_stroll
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = 0,
						key = "bbHackTreeIng",
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_node_collide_crop = {
	node = "BTNodeSelector",
	param = {
		tip = "collide_crop"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							curValue = "bbHackTreeIng",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						node = "BTNodeSequence",
						children = {
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonJudge",
									subparam = {
										compareValue = 3,
										judgeType = AIFunctionDefsGetDefByKey("judgeType").handItemType,
										compareType = AIFunctionDefsGetDefByKey("compareType").notequal
									}
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_PutHandItemInBags",
									subparam = {}
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_GetBagData",
									subparam = {
										bbFirstItemId = "equipItemId",
										typeId = 7
									}
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_EquipWeapon",
									subparam = {
										bbEquipItemId = "equipItemId",
										bbEquipItemNum = 1
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getWorkPos",
						subparam = {
							bb_workpos = "bbHackTreesWorkPos"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindBlock",
						subparam = {
							rangeY = 5,
							result_blockpos = "bbHackTreeTargetPos",
							findPositionType = 100,
							custom_centerPos = "bbHackTreesWorkPos",
							findBlockType = AI_FIND_CROP,
							range = AIFunctionDefsGetDefByKey("workRange")
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						avoidWater = true,
						speed = 1,
						minDistance = 1,
						bbkey_targetpos = "bbHackTreeTargetPos"
					}
				},
				{
					node = "BTNTaskDigBlock",
					param = {
						dist = 6400,
						speed = 1,
						block_pos_key = "bbHackTreeTargetPos",
						dig_dist = 200
					}
				},
				{
					node = "BTNodeWait",
					param = {
						wait = 0.5
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_commonSetValue",
					subparam = {
						value = 0,
						key = "bbHackTreeIng",
						valueType = AIFunctionDefsGetDefByKey("valueType").value
					}
				}
			}
		}
	}
}
local bt_work_fell_wood_1 = {
	node = "BTNodeSelector",
	children = {
		bt_work_Plant_Trees,
		{
			node = "BTNodeSequence",
			children = {
				bt_is_can_store_item,
				bt_node_store_item
			}
		},
		bt_work_Tamed_Pick_Work_Drop,
		{
			node = "BTNodeSelector",
			children = {
				bt_rehack_tree,
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 2,
									range = 5,
									result_blockpos = "bbHackTreesWorkPos",
									rangeY = 20,
									findBlockType = AI_FIND_WOOD
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "bbHackTreeIng",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 4,
									result_blockpos = "bbHackTreesWorkPos",
									rangeY = 20,
									findBlockType = AI_FIND_WOOD,
									range = AIFunctionDefsGetDefByKey("workRange")
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "bbHackTreeIng",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work_fell_wood_2 = {
	node = "BTNodeSelector",
	children = {
		bt_work_Plant_Trees,
		{
			node = "BTNodeSequence",
			children = {
				bt_is_can_store_item,
				bt_node_store_item
			}
		},
		bt_work_Tamed_Pick_Work_Drop,
		{
			node = "BTNodeSelector",
			children = {
				bt_rehack_tree,
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 2,
									range = 5,
									result_blockpos = "bbHackTreesWorkPos",
									rangeY = 20,
									findBlockType = AI_FIND_WOOD
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "bbHackTreeIng",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 3,
									result_blockpos = "bbHackTreesWorkPos",
									rangeY = 20,
									findBlockType = AI_FIND_WOOD,
									range = AIFunctionDefsGetDefByKey("villageRange")
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "bbHackTreeIng",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work_collide_crops_1 = {
	node = "BTNodeSelector",
	children = {
		bt_work_Plant_Seed,
		{
			node = "BTNodeCondition",
			children = {
				bt_is_can_store_item,
				bt_node_store_item
			}
		},
		bt_work_Tamed_Pick_Work_Drop,
		{
			node = "BTNodeSelector",
			children = {
				bt_node_collide_crop,
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 4,
									result_blockpos = "bbHackTreesWorkPos",
									rangeY = 5,
									findBlockType = AI_FIND_CROP,
									range = AIFunctionDefsGetDefByKey("workRange")
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "bbHackTreeIng",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work_collide_crops_2 = {
	node = "BTNodeSelector",
	children = {
		bt_work_Plant_Seed,
		{
			node = "BTNodeCondition",
			children = {
				bt_is_can_store_item,
				bt_node_store_item
			}
		},
		bt_work_Tamed_Pick_Work_Drop,
		{
			node = "BTNodeSelector",
			children = {
				bt_node_collide_crop,
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindBlock",
								subparam = {
									findPositionType = 3,
									result_blockpos = "bbHackTreesWorkPos",
									rangeY = 5,
									findBlockType = AI_FIND_CROP,
									range = AIFunctionDefsGetDefByKey("villageRange")
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 1,
									key = "bbHackTreeIng",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_architect = {
	node = "BTNodeSelector",
	param = {
		nextstep = false,
		tip = "architect"
	},
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							curValue = "bbArchitectIng",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							value = 0,
							key = "bbMoveHeightFlags",
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getArchitectInfo",
						subparam = {
							bb_workpos = "find_bind_workPoint",
							blockid = "architectId",
							block_pos_key = "bbArchitectPos",
							blockdata = "architectData"
						}
					}
				},
				{
					node = "BTNodeSelector",
					param = {
						tip = "Selector1"
					},
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNTaskMoveTo",
										param = {
											avoidWater = true,
											speed = 1,
											minDistance = 2,
											bbkey_targetpos = "bbArchitectPos",
											bbkey_speed_ratio = "bbkeySpeedRatio"
										}
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeSelector",
										children = {
											{
												node = "BTNodeTaskLua",
												param = {
													script = "__USE_LOCAL_TABLE_",
													__USE_LOCAL_TABLE_ = ll_BTTask_getDisPos,
													subparam = {
														blockdist = 300,
														block_pos_key = "bbArchitectPos"
													}
												}
											},
											{
												node = "BTNodeSimpleParallel",
												children = {
													{
														node = "BTNodeTaskLua",
														param = {
															script = "BTTask_commonSetValue",
															subparam = {
																value = 1,
																key = "bbMoveHeightFlags",
																valueType = AIFunctionDefsGetDefByKey("valueType").value
															}
														}
													},
													{
														node = "BTNodeTaskLua",
														param = {
															script = "BTTask_tryGetJumpPos",
															subparam = {
																block_pos_key = "bbArchitectPos",
																bb_workpos = "find_bind_workPoint"
															}
														}
													}
												}
											}
										}
									}
								},
								{
									node = "BTNodeSimpleParallel",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_architectBluePrint",
												subparam = {
													blockdata = "architectData",
													block_pos_key = "bbArchitectPos",
													blockid = "architectId",
													bp_dig_dist = 600
												}
											}
										},
										{
											node = "BTNodeSimpleParallel",
											children = {
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_commonPlayAction",
														subparam = {
															duration = 1,
															animID = 100105
														}
													}
												}
											}
										}
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeCondition",
										children = {
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_commonJudge",
													subparam = {
														compareValue = 1,
														curValue = "bbMoveHeightFlags",
														judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
														compareType = AIFunctionDefsGetDefByKey("compareType").equal
													}
												}
											},
											{
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_tryGetJumpPos",
													subparam = {
														block_pos_key = "bbArchitectPos",
														bb_workpos = "find_bind_workPoint"
													}
												}
											}
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_setArchitectState",
										subparam = {
											bb_workpos = "find_bind_workPoint",
											state = 1,
											block_pos_key = "bbArchitectPos"
										}
									}
								},
								{
									node = "BTNodeWait",
									param = {
										wait = 0
									}
								}
							}
						},
						{
							node = "BTNodeFail",
							children = {
								node = "BTNodeSequence",
								children = {
									{
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_setArchitectState",
											subparam = {
												bb_workpos = "find_bind_workPoint",
												state = 2,
												block_pos_key = "bbArchitectPos"
											}
										}
									},
									bt_action_idle_stroll
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeFail",
			children = {
				node = "BTNodeSequence",
				children = {
					{
						node = "BTNodeTaskLua",
						param = {
							script = "BTTask_commonSetValue",
							subparam = {
								value = 0,
								key = "bbArchitectIng",
								valueType = AIFunctionDefsGetDefByKey("valueType").value
							}
						}
					},
					{
						node = "BTNodeSuccess",
						children = {
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = "architectId",
											judgeType = AIFunctionDefsGetDefByKey("judgeType").handItem,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_removeItem",
										subparam = {
											bbEquipItemId = "architectId",
											isequipweapon = true,
											bbEquipItemNum = 1
										}
									}
								}
							}
						}
					},
					{
						node = "BTNodeTaskLua",
						param = {
							script = "BTTask_commonSetValue",
							subparam = {
								value = 0,
								key = "architectId",
								valueType = AIFunctionDefsGetDefByKey("valueType").value
							}
						}
					}
				}
			}
		}
	}
}
local bt_architect_point = {
	node = "BTNodeSelector",
	param = {
		tip = "gzd"
	},
	children = {
		bt_architect,
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_checkBluePrint",
						tip = "checkBlue",
						subparam = {
							bb_workpos = "find_bind_workPoint"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						tip = "setIng",
						subparam = {
							value = 1,
							key = "bbArchitectIng",
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				}
			}
		}
	}
}
local bt_work_worker = {
	node = "BTNodeSequence",
	param = {
		tip = "wood cutter"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "find_bind_workPoint"
				}
			}
		},
		{
			node = "BTNodeBranch",
			param = {
				tip = "worker_Branch1"
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "find_bind_workPoint",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					param = {
						nextstep = false,
						tip = "jrgzd"
					},
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").bpWork
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonSetValue",
												subparam = {
													value = 0,
													key = "bbArchitectIng",
													valueType = AIFunctionDefsGetDefByKey("valueType").value
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonSetValue",
												subparam = {
													value = 0,
													key = "architectId",
													valueType = AIFunctionDefsGetDefByKey("valueType").value
												}
											}
										},
										{
											node = "BTNodeSelector",
											children = {
												{
													node = "BTNTaskMoveTo",
													param = {
														avoidWater = true,
														speed = 1,
														minDistance = 2,
														bbkey_targetpos = "find_bind_workPoint",
														bbkey_speed_ratio = "bbkeySpeedRatio"
													}
												}
											}
										}
									}
								}
							}
						},
						bt_architect_point,
						bt_action_idle_stroll
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										value = 0,
										key = "architectId",
										valueType = AIFunctionDefsGetDefByKey("valueType").value
									}
								}
							},
							node = "BTNodeFail",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										value = 0,
										key = "bbArchitectIng",
										valueType = AIFunctionDefsGetDefByKey("valueType").value
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_dead = {
	node = "BTNodeSequence",
	param = {
		tip = "dead"
	},
	children = {
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						desc = "通用判断叶子，所有的判断都可用此叶子实现",
						subparam = {
							compareValue = 4,
							compareType = 5,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").huggerStatus
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						desc = "通用判断叶子，所有的判断都可用此叶子实现",
						subparam = {
							compareValue = 4,
							compareType = 5,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").fatigueStatus
						}
					}
				}
			}
		},
		{
			node = "BTNodeRandom",
			children = {
				bt_action_idle_Leisure,
				bt_action_idle_lookAround,
				bt_action_idle_stroll,
				bt_action_idle_sitWander,
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonPlayAction",
								desc = "通用播放动作叶子，所有的播放动作都可用此叶子实现",
								subparam = {
									duration = 1.5,
									animID = 100124
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								desc = "通用设置值叶子，所有的设置值操作都可用此叶子实现",
								subparam = {
									extraValue = "",
									value = true,
									key = "",
									valueType = AIFunctionDefsGetDefByKey("valueType").isTraitor
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_freezing = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isFreezing,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		}
	}
}
local bt_need_help_thaw_other_villager = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").isOtherFreezing,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonFindTargetPos",
				desc = "通用寻找目标位置叶子，所有的寻找目标位置都可用此叶子实现",
				subparam = {
					bbKeyTargetPos = "bbkey_targetpos",
					targetType = 3,
					range = 5,
					bbKeyTargetObjId = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNTaskFollow",
			param = {
				speed = 1.3,
				bbkey_followobj = "bbKeyTargetObjId",
				minDistance = 3,
				bbkey_speed_ratio = "bbkeySpeedRatio"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "bbKeyTargetObjId"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 1,
					animID = 200212
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_DesertVillgerGossip",
				tip = "around_gossipState",
				subparam = {
					duration = 1,
					h = 128,
					w = 128,
					ico = "particles/texture/jiedong",
					gossiptype = 888
				}
			}
		}
	}
}
local bt_Interact_PlayAction = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断黑板【道具交互】状态",
				subparam = {
					compareValue = 0,
					curValue = "InteractEvent",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").more
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TurnToTarget",
				subparam = {
					bbTargetKey = "greeted_obj_id"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_PEventPlayAction",
				subparam = {
					type = "InteractEvent",
					duration = 2,
					flag = false
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonSetValue",
				subparam = {
					value = 0,
					key = "InteractEvent",
					valueType = AIFunctionDefsGetDefByKey("valueType").value
				}
			}
		}
	}
}
local bt_acton_Tamed_Check_Tool_AXE = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有工具",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						AI_FIND_AXE,
						true
					}
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_AskHelperForNeed",
					desc = "向帮手申请需求",
					subparam = {
						needType = 1
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindItemFromBox",
				subparam = {
					bbkey_out_iteminfo = "finditem_out_iteminfo",
					range = 16,
					bbkey_out_boxpos = "finditem_out_boxpos",
					findPositionType = 2,
					findCustomItems = "finditem_itemids",
					findItemType = AI_FIND_AXE
				}
			}
		},
		bt_moveto_finditem_out_boxpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				subparam = {
					bbkey_multi_iteminfos = "finditem_out_iteminfo",
					bbkey_in_boxpos = "finditem_out_boxpos",
					takeitemmode = 1
				}
			}
		}
	}
}
local bt_acton_Tamed_Check_Tool_SHOVEL = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有工具",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						AI_FIND_SHOVEL,
						true
					}
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_AskHelperForNeed",
					desc = "向帮手申请需求",
					subparam = {
						needType = 2
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindItemFromBox",
				subparam = {
					bbkey_out_iteminfo = "finditem_out_iteminfo",
					range = 16,
					bbkey_out_boxpos = "finditem_out_boxpos",
					findPositionType = 2,
					findCustomItems = "finditem_itemids",
					findItemType = AI_FIND_SHOVEL
				}
			}
		},
		bt_moveto_finditem_out_boxpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				subparam = {
					bbkey_multi_iteminfos = "finditem_out_iteminfo",
					bbkey_in_boxpos = "finditem_out_boxpos",
					takeitemmode = 1
				}
			}
		}
	}
}
local bt_acton_Tamed_Check_Tool_HOEL = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有工具",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						AI_FIND_HOEL,
						true
					}
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_AskHelperForNeed",
					desc = "向帮手申请需求",
					subparam = {
						needType = 3
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindItemFromBox",
				subparam = {
					bbkey_out_iteminfo = "finditem_out_iteminfo",
					range = 16,
					bbkey_out_boxpos = "finditem_out_boxpos",
					findPositionType = 2,
					findCustomItems = "finditem_itemids",
					findItemType = AI_FIND_HOEL
				}
			}
		},
		bt_moveto_finditem_out_boxpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				subparam = {
					bbkey_multi_iteminfos = "finditem_out_iteminfo",
					bbkey_in_boxpos = "finditem_out_boxpos",
					takeitemmode = 1
				}
			}
		}
	}
}
local bt_acton_Tamed_Check_Tool_MELEE_WEAPON = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有工具",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						AI_FIND_MELEE_WEAPON,
						true
					}
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_AskHelperForNeed",
					desc = "向帮手申请需求",
					subparam = {
						needType = 4
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindItemFromBox",
				subparam = {
					bbkey_out_iteminfo = "finditem_out_iteminfo",
					range = 16,
					bbkey_out_boxpos = "finditem_out_boxpos",
					findPositionType = 2,
					findCustomItems = "finditem_itemids",
					findItemType = AI_FIND_MELEE_WEAPON
				}
			}
		},
		bt_moveto_finditem_out_boxpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				subparam = {
					bbkey_multi_iteminfos = "finditem_out_iteminfo",
					bbkey_in_boxpos = "finditem_out_boxpos",
					takeitemmode = 1
				}
			}
		}
	}
}
local bt_acton_Tamed_Check_Tool_REMOTE_WEAPON = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				desc = "判断：背包中没有工具",
				subparam = {
					compareValue = 0,
					judgeType = 12,
					compareType = 2,
					extraValue = {
						AI_FIND_REMOTE_WEAPON,
						true
					}
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				node = "BTNodeTaskLua",
				param = {
					script = "BTTask_AskHelperForNeed",
					desc = "向帮手申请需求",
					subparam = {
						needType = 5
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_FindItemFromBox",
				subparam = {
					bbkey_out_iteminfo = "finditem_out_iteminfo",
					range = 16,
					bbkey_out_boxpos = "finditem_out_boxpos",
					findPositionType = 2,
					findCustomItems = "finditem_itemids",
					findItemType = AI_FIND_REMOTE_WEAPON
				}
			}
		},
		bt_moveto_finditem_out_boxpos,
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_TakeItemToPack",
				subparam = {
					bbkey_multi_iteminfos = "finditem_out_iteminfo",
					bbkey_in_boxpos = "finditem_out_boxpos",
					takeitemmode = 1
				}
			}
		}
	}
}
local bt_work_woodCutter = {
	node = "BTNodeSequence",
	param = {
		tip = "wood cutter"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getVillagePos",
				subparam = {
					bb_villagepos = "villagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "find_bind_workPoint"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "find_bind_workPoint",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					param = {
						tip = "wood cutter work pos"
					},
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").work
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonSetValue",
												subparam = {
													value = 0,
													key = "bbHackTreeIng",
													valueType = AIFunctionDefsGetDefByKey("valueType").value
												}
											}
										},
										{
											node = "BTNTaskMoveTo",
											param = {
												avoidWater = true,
												speed = 1,
												minDistance = 2,
												bbkey_targetpos = "find_bind_workPoint"
											}
										}
									}
								}
							}
						},
						bt_work_fell_wood_1,
						{
							node = "BTNodeRandom",
							children = {
								bt_action_idle_Leisure,
								bt_action_idle_lookAround,
								bt_action_idle_stroll,
								bt_action_idle_sitWander
							}
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").village
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 2,
										bbkey_targetpos = "villagepos"
									}
								}
							}
						},
						bt_work_fell_wood_2,
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											rangeWidth = 32,
											centerPos = "villagepos",
											bb_stollpos = "bbHackTreesWorkPos",
											rangeHeight = 2
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 2,
										bbkey_targetpos = "bbHackTreesWorkPos"
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work_farmer = {
	node = "BTNodeSequence",
	param = {
		tip = "farmer"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getVillagePos",
				subparam = {
					bb_villagepos = "villagepos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_getWorkPos",
				subparam = {
					bb_workpos = "bbHackTreesWorkPos"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							extraValue = "bbHackTreesWorkPos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBindWithWorkPoint,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").work
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonSetValue",
												subparam = {
													value = 0,
													key = "bbHackTreeIng",
													valueType = AIFunctionDefsGetDefByKey("valueType").value
												}
											}
										},
										{
											node = "BTNTaskMoveTo",
											param = {
												avoidWater = true,
												speed = 1,
												minDistance = 2,
												bbkey_targetpos = "bbHackTreesWorkPos"
											}
										}
									}
								}
							}
						},
						bt_work_collide_crops_1,
						{
							node = "BTNodeRandom",
							children = {
								bt_action_idle_Leisure,
								bt_action_idle_lookAround,
								bt_action_idle_stroll,
								bt_action_idle_sitWander
							}
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").isInRange,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = AIFunctionDefsGetDefByKey("rangeType").village
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 2,
										bbkey_targetpos = "villagepos"
									}
								}
							}
						},
						bt_work_collide_crops_2,
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRandStollPos",
										subparam = {
											rangeWidth = 32,
											centerPos = "villagepos",
											bb_stollpos = "bbHackTreesWorkPos",
											rangeHeight = 2
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										speed = 1,
										minDistance = 2,
										bbkey_targetpos = "bbHackTreesWorkPos"
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work_helper = {
	node = "BTNodeSelector",
	param = {
		tip = "helper"
	},
	children = {
		bt_node_craftItem_delivery,
		bt_node_craftItem,
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							curValue = "craft_working",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNTaskFollow",
					param = {
						speed = 1.3,
						bbkey_followobj = "craft_guest_target",
						minDistance = 2.5
					}
				},
				bt_node_set_craftItem
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_FindWorkTarget",
						subparam = {
							bbkey_out_needType = "craft_need_type",
							bbkey_out_targetId = "craft_guest_target",
							bbkey_out_needItems = "craft_need_items"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						subparam = {
							value = 1,
							key = "craft_working",
							valueType = AIFunctionDefsGetDefByKey("valueType").value
						}
					}
				}
			}
		},
		bt_action_idle_stroll
	}
}
local bt_work_meleeGuard = bt_action_idle_stroll_for_guard
local bt_work_remoteGuard = bt_action_idle_stroll_for_guard
local bt_work_time = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_isReachTime",
				subparam = {
					timeType = AIFunctionDefsGetDefByKey("timeType").work
				}
			}
		}
	}
}
bt_remote_weapon = {
	node = "BTNodeCondition",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").bagItemCount,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal,
					extraValue = {
						AI_FIND_REMOTE_WEAPON,
						true
					}
				}
			}
		},
		{
			node = "BTNodeSimpleParallel",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "finditem_itemids",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = GetInst("AIFunctionDefs"):GetToolCfg(5)
								}
							}
						},
						bt_node_find_item
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeSuccess",
							children = {
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonPlayAction",
									subparam = {
										duration = 3,
										tipsItemId = 12050
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_AskHelperForNeed",
								subparam = {
									needType = 5
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_work = {
	node = "BTNodeSelector",
	param = {
		tip = "work"
	},
	children = {
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_WOODCUTTER
						}
					}
				},
				{
					node = "BTNodeBranch",
					children = {
						bt_work_time,
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeCondition",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonJudge",
												subparam = {
													compareValue = 0,
													judgeType = AIFunctionDefsGetDefByKey("judgeType").bagItemCount,
													compareType = AIFunctionDefsGetDefByKey("compareType").equal,
													extraValue = {
														AI_FIND_AXE,
														true
													}
												}
											}
										},
										{
											node = "BTNodeSimpleParallel",
											children = {
												{
													node = "BTNodeSequence",
													children = {
														{
															node = "BTNodeTaskLua",
															param = {
																script = "BTTask_commonSetValue",
																subparam = {
																	key = "finditem_itemids",
																	valueType = AIFunctionDefsGetDefByKey("valueType").value,
																	value = GetInst("AIFunctionDefs"):GetToolCfg(1)
																}
															}
														},
														bt_node_find_item
													}
												},
												{
													node = "BTNodeSequence",
													children = {
														{
															node = "BTNodeSuccess",
															children = {
																node = "BTNodeTaskLua",
																param = {
																	script = "BTTask_commonPlayAction",
																	subparam = {
																		duration = 3,
																		tipsItemId = 11002
																	}
																}
															}
														},
														{
															node = "BTNodeTaskLua",
															param = {
																script = "BTTask_AskHelperForNeed",
																subparam = {
																	needType = 1
																}
															}
														}
													}
												}
											}
										}
									}
								},
								{
									node = "BTNodeCondition",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonJudge",
												desc = "判断：背包中有铲子工具",
												subparam = {
													compareValue = 0,
													judgeType = AIFunctionDefsGetDefByKey("judgeType").bagItemCount,
													compareType = AIFunctionDefsGetDefByKey("compareType").equal,
													extraValue = {
														AI_FIND_SHOVEL,
														true
													}
												}
											}
										},
										{
											node = "BTNodeSimpleParallel",
											children = {
												{
													node = "BTNodeSequence",
													children = {
														{
															node = "BTNodeTaskLua",
															param = {
																script = "BTTask_commonSetValue",
																subparam = {
																	key = "finditem_itemids",
																	valueType = AIFunctionDefsGetDefByKey("valueType").value,
																	value = GetInst("AIFunctionDefs"):GetToolCfg(2)
																}
															}
														},
														bt_node_find_item
													}
												},
												{
													node = "BTNodeSequence",
													children = {
														{
															node = "BTNodeSuccess",
															children = {
																node = "BTNodeTaskLua",
																param = {
																	script = "BTTask_commonPlayAction",
																	subparam = {
																		duration = 3,
																		tipsItemId = 11022
																	}
																}
															}
														},
														{
															node = "BTNodeTaskLua",
															param = {
																script = "BTTask_AskHelperForNeed",
																subparam = {
																	needType = 2
																}
															}
														}
													}
												}
											}
										}
									}
								},
								bt_work_woodCutter
							}
						},
						bt_action_idle
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_FARMER
						}
					}
				},
				{
					node = "BTNodeBranch",
					children = {
						bt_work_time,
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeCondition",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonJudge",
												subparam = {
													compareValue = 0,
													judgeType = AIFunctionDefsGetDefByKey("judgeType").bagItemCount,
													compareType = AIFunctionDefsGetDefByKey("compareType").equal,
													extraValue = {
														AI_FIND_HOEL,
														true
													}
												}
											}
										},
										{
											node = "BTNodeSimpleParallel",
											children = {
												{
													node = "BTNodeSequence",
													children = {
														{
															node = "BTNodeTaskLua",
															param = {
																script = "BTTask_commonSetValue",
																subparam = {
																	key = "finditem_itemids",
																	valueType = AIFunctionDefsGetDefByKey("valueType").value,
																	value = GetInst("AIFunctionDefs"):GetToolCfg(3)
																}
															}
														},
														bt_node_find_item
													}
												},
												{
													node = "BTNodeSequence",
													children = {
														{
															node = "BTNodeSuccess",
															children = {
																node = "BTNodeTaskLua",
																param = {
																	script = "BTTask_commonPlayAction",
																	subparam = {
																		duration = 3,
																		tipsItemId = 11032
																	}
																}
															}
														},
														{
															node = "BTNodeTaskLua",
															param = {
																script = "BTTask_AskHelperForNeed",
																subparam = {
																	needType = 3
																}
															}
														}
													}
												}
											}
										}
									}
								},
								bt_work_farmer
							}
						},
						bt_action_idle
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_HELPER
						}
					}
				},
				{
					node = "BTNodeBranch",
					children = {
						bt_work_time,
						bt_work_helper,
						bt_action_idle
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_MELEE_GUARD
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeCondition",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonJudge",
										subparam = {
											compareValue = 0,
											judgeType = AIFunctionDefsGetDefByKey("judgeType").bagItemCount,
											compareType = AIFunctionDefsGetDefByKey("compareType").equal,
											extraValue = {
												AI_FIND_MELEE_WEAPON,
												true
											}
										}
									}
								},
								{
									node = "BTNodeSimpleParallel",
									children = {
										{
											node = "BTNodeSequence",
											children = {
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_commonSetValue",
														subparam = {
															key = "finditem_itemids",
															valueType = AIFunctionDefsGetDefByKey("valueType").value,
															value = GetInst("AIFunctionDefs"):GetToolCfg(4)
														}
													}
												},
												bt_node_find_item
											}
										},
										{
											node = "BTNodeSequence",
											children = {
												{
													node = "BTNodeSuccess",
													children = {
														node = "BTNodeTaskLua",
														param = {
															script = "BTTask_commonPlayAction",
															subparam = {
																duration = 3,
																tipsItemId = 12003
															}
														}
													}
												},
												{
													node = "BTNodeTaskLua",
													param = {
														script = "BTTask_AskHelperForNeed",
														subparam = {
															needType = 4
														}
													}
												}
											}
										}
									}
								}
							}
						},
						bt_action_idle_stroll_for_guard_around_player,
						bt_work_meleeGuard
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_REMOTE_GUARD
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						bt_remote_weapon,
						bt_action_idle_stroll_for_guard_around_player,
						bt_work_remoteGuard
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_HUNTER
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						bt_remote_weapon,
						bt_work_Tamed_Pick_Work_Drop,
						{
							node = "BTNodeSequence",
							children = {
								bt_is_can_store_item,
								bt_node_store_item
							}
						},
						bt_action_idle_stroll_for_guard_around_player,
						bt_work_remoteGuard
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal,
							compareValue = PROFESSION_ARCHITECT
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						bt_work_worker,
						bt_action_idle
					}
				}
			}
		}
	}
}
local bt_tamed = {
	node = "BTNodeSelector",
	param = {
		tip = "tamed"
	},
	children = {
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isSleeping,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				bt_action_wakeup
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInWater,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "stroll_in_water"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getRandStollPos",
								subparam = {
									bb_stollpos = "stollPos"
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								speed = 1,
								bbkey_targetpos = "stollPos"
							}
						}
					}
				}
			}
		},
		bt_dead,
		bt_fire,
		bt_warn,
		bt_need_guard_player,
		bt_need_help_thaw_other_villager,
		bt_interact_look_node,
		bt_temperature_cold,
		bt_worship,
		bt_work,
		bt_action_idle
	}
}
local bt_dance_branch = {
	node = "BTNodeBranch",
	param = {
		tip = "bt_dance_branch"
	},
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = "bb_roundPlayer",
					curValue = 1,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSequence",
			param = {
				tip = ""
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonSetValue",
						desc = "设置跳舞",
						subparam = {
							value = true,
							valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
							extraValue = {
								ACTOR_ANIM_FLAG_DANCE,
								true
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_getRoundPlaying",
						desc = "",
						subparam = {
							bb_roundPlayer = 2
						}
					}
				}
			}
		},
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = "bb_roundPlayer",
							curValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = ""
					},
					children = {
						bt_action_idle_stroll,
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getRoundPlaying",
								desc = "",
								subparam = {
									bb_roundPlayer = 0
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_dance = {
	node = "BTNodeCondition",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = "bb_roundPlayer",
					curValue = 0,
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").notequal
				}
			}
		},
		{
			node = "BTNodeBranch",
			param = {
				tip = "bt_danceNew 22"
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = "bb_roundPlayer",
							curValue = 100,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "bt_branch sleep"
					},
					children = {
						{
							node = "BTNodeSequence",
							param = {
								tip = "is waked up"
							},
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonSetValue",
										tip = "waked 111",
										subparam = {
											value = true,
											valueType = AIFunctionDefsGetDefByKey("valueType").loopAction,
											extraValue = {
												ACTOR_ANIM_FLAG_WAKEUP,
												true
											}
										}
									}
								},
								{
									node = "BTNodeWait",
									param = {
										wait = 2
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_sleepOnAndBindBed",
										subparam = {
											bb_bedpos = "bedpos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getRoundPlaying",
										desc = "",
										subparam = {
											bb_roundPlayer = 0
										}
									}
								}
							}
						}
					}
				},
				bt_dance_branch
			}
		}
	}
}
local bt_untamed = {
	node = "BTNodeSelector",
	children = {
		bt_Untamed_Escape,
		bt_fire_acttack_unfriendly_player,
		bt_warn,
		bt_need_help_thaw_other_villager,
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInWater,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "stroll_in_water"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getRandStollPos",
								subparam = {
									bb_stollpos = "stollPos"
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								speed = 1,
								bbkey_targetpos = "stollPos"
							}
						}
					}
				}
			}
		},
		bt_dance,
		bt_Untamed_NeedTame,
		{
			node = "BTNodeFail"
		}
	}
}
local bt_tamed2 = {
	node = "BTNodeSelector",
	param = {
		tip = "bt_tamed new"
	},
	children = {
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 1,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isInWater,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeSequence",
					param = {
						tip = "stroll_in_water"
					},
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getRandStollPos",
								subparam = {
									bb_stollpos = "stollPos"
								}
							}
						},
						{
							node = "BTNTaskMoveTo",
							param = {
								speed = 1,
								bbkey_targetpos = "stollPos"
							}
						}
					}
				}
			}
		},
		bt_dead,
		bt_fire,
		bt_dance
	}
}
local bt_tamed_new = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = "bb_roundPlayer",
							curValue = 0,
							judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
							compareType = AIFunctionDefsGetDefByKey("compareType").notequal
						}
					}
				},
				bt_tamed2
			}
		},
		bt_tamed
	}
}
local bt_profession_is_have = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					judgeType = AIFunctionDefsGetDefByKey("judgeType").professionType,
					compareType = AIFunctionDefsGetDefByKey("compareType").more,
					compareValue = PROFESSION_NOT
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = 21,
							compareType = 2
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonTips",
						desc = "通用提示叶子",
						subparam = {
							type = 1,
							contentType = 0,
							targetUin = 0,
							content = "老哥快驯服我"
						}
					}
				},
				{
					node = "BTNodeFail"
				}
			}
		},
		{
			node = "BTNodeCondition",
			param = {
				tip = "untamed"
			},
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							judgeType = 21,
							compareType = 2
						}
					}
				},
				bt_untamed
			}
		}
	}
}
local bt_main = {
	node = "BTNodeSelector",
	children = {
		bt_freezing,
		{
			node = "BTNodeCondition",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 100,
							judgeType = 20,
							compareType = 1
						}
					}
				},
				bt_neardeath
			}
		},
		bt_Interact_PlayAction,
		bt_profession_is_have,
		bt_tamed_new
	}
}

return bt_main
