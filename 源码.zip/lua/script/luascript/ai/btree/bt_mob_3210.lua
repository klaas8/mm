local bt_fire_battle_attack_behurt = {
	node = "BTNodeSuccess",
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNTaskFollow",
					param = {
						bbkey_followobj = "bbKeyBeHurtTargetObjId",
						minDistance = 1.5,
						speed = 1.1,
						canTeleport = false
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_TurnToTarget",
						subparam = {
							bbTargetKey = "bbKeyBeHurtTargetObjId"
						}
					}
				},
				{
					node = "BTNTaskAttack",
					param = {
						keeptick = 30,
						bbkey_attackobj = "bbKeyBeHurtTargetObjId"
					}
				}
			}
		}
	}
}
local bt_fire_battle_attack_enemy = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "enemy_id",
					type = "actorIsInvalid"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							extraValue = "enemy_id",
							type = "actorInView"
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNTaskFollow",
									param = {
										bbkey_followobj = "enemy_id",
										minDistance = 2.5,
										speed = 1.3,
										canTeleport = false
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_TurnToTarget",
										subparam = {
											bbTargetKey = "enemy_id"
										}
									}
								},
								{
									node = "BTNTaskAttack",
									param = {
										keeptick = 30,
										bbkey_attackobj = "enemy_id"
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "enemy_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_active_fire = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "bbKeyBeHurtTargetObjId",
					type = "actorIsInvalid"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							extraValue = "bbKeyBeHurtTargetObjId",
							type = "actorInView"
						}
					}
				},
				bt_fire_battle_attack_behurt,
				{
					node = "BTNodeSuccess",
					children = {
						node = "BTNodeSequence",
						children = {
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_simpleFun",
									subparam = {
										extraValue = "ActorDesertBusInessMan",
										fun = "clearHateUin",
										attackActor = "bbKeyBeHurtTargetObjId"
									}
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonSetValue",
									subparam = {
										key = "bbKeyBeHurtTargetObjId",
										valueType = AIFunctionDefsGetDefByKey("valueType").value,
										value = {
											actor = 0
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_active_hate_fire = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isAttacking"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					extraValue = "ActorDesertBusInessMan",
					fun = "checkHateUinAndAttack"
				}
			}
		}
	}
}
local bt_fire = {
	node = "BTNodeSelector",
	children = {
		bt_active_fire,
		bt_fire_battle_attack_enemy,
		bt_active_hate_fire
	}
}
local bt_action_sleep = {
	node = "BTNodeSelector",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isSleeping"
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							reversal = true,
							type = "hourCompare",
							extraValue = {
								max = 19,
								min = 9
							}
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_standUp"
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getBedPos",
										subparam = {
											bb_bedpos = "bedpos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonCompare",
										subparam = {
											extraValue = "bedpos",
											type = "isUableBedPos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonSetValue",
										subparam = {
											value = 0,
											key = "bb_needResetGuardPos",
											valueType = AIFunctionDefsGetDefByKey("valueType").value
										}
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_FindPosByNeedType",
										subparam = {
											equipslot = 0,
											searchType = 11,
											bbkey_targetpos = "bedpos",
											bempty = true
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonSetValue",
										subparam = {
											value = 1,
											key = "bb_needResetGuardPos",
											valueType = AIFunctionDefsGetDefByKey("valueType").value
										}
									}
								}
							}
						}
					}
				},
				{
					node = "BTNTaskMoveTo",
					param = {
						avoidWater = true,
						minDistance = 2,
						speed = 1,
						bbkey_targetpos = "bedpos"
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonJudge",
						subparam = {
							compareValue = 0,
							extraValue = "bedpos",
							judgeType = AIFunctionDefsGetDefByKey("judgeType").isBlockOccupyed,
							compareType = AIFunctionDefsGetDefByKey("compareType").equal
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_sleepOnAndBindBed",
						subparam = {
							bb_bedpos = "bedpos"
						}
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_simpleFun",
						subparam = {
							extraValue = 1,
							fun = "informGuard"
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						node = "BTNodeSequence",
						children = {
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_commonJudge",
									subparam = {
										compareValue = 1,
										curValue = "bb_needResetGuardPos",
										judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
										compareType = AIFunctionDefsGetDefByKey("compareType").equal
									}
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_simpleFun",
									subparam = {
										bb_pitch = "pitchPos",
										fun = "findPitchPos",
										bb_bed = "bedpos",
										bb_pitchDir = "pitchDir"
									}
								}
							},
							{
								node = "BTNodeTaskLua",
								param = {
									script = "BTTask_simpleFun",
									subparam = {
										extraValue = 4,
										fun = "informGuard"
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_wakeup = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "ActorDesertBusInessMan",
					reversal = true,
					type = "isAvoidingStand"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isSleeping"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "hourCompare",
					extraValue = {
						max = 19,
						min = 9
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_wakeAndbedUnOccupied",
				subparam = {
					bb_bedpos = "bedpos"
				}
			}
		}
	}
}
local bt_MovetoPitch = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "hourCompare",
					extraValue = {
						max = 19,
						min = 9
					}
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									bb_pos = "pitchPos",
									range = 32,
									type = "isUsablePos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 0,
									key = "bb_needResetGuardPos",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindPosByNeedType",
								subparam = {
									equipslot = 0,
									searchType = 11,
									bbkey_targetpos = "bedpos",
									bempty = true
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									extraValue = "bedpos",
									fun = "setBedBind"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									bb_pitch = "pitchPos",
									fun = "findPitchPos",
									bb_bed = "bedpos",
									bb_pitchDir = "pitchDir"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									fun = "setMobWorkPos",
									workDir = "pitchDir",
									workPos = "pitchPos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									extraValue = 4,
									fun = "informGuard"
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_FindPlaneArea",
								subparam = {
									bb_pitch = "pitchPos",
									extraValue = {
										range = 8,
										w = 3,
										blockid = {
											3,
											4,
											5,
											6,
											12,
											13,
											14,
											0
										}
									}
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									fun = "setMobWorkPos",
									workDir = "pitchDir",
									workPos = "pitchPos"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = 3,
									key = "bb_needResetGuardPos",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				minDistance = 0.5,
				speed = 1,
				bbkey_targetpos = "pitchPos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_sitDown",
				subparam = {
					type = "ActorDesertBusInessMan"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_turnBodyByDir",
				subparam = {
					standDir = "pitchDir"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					extraValue = 0,
					fun = "informGuard"
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonJudge",
								subparam = {
									compareValue = 3,
									curValue = "bb_needResetGuardPos",
									judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
									compareType = AIFunctionDefsGetDefByKey("compareType").equal
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									extraValue = 1,
									fun = "informGuard"
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_action_idle_lookAround = {
	node = "BTNodeTaskLua",
	param = {
		script = "BTTask_LookAt",
		subparam = {
			waittimemin = 1,
			actorwaittime = 2,
			searchRange = 4,
			waittimemax = 4
		}
	}
}
local bt_specialSale = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 1,
					curValue = "bb_saleType",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									fun = "exchangeItemFormPlayer",
									bb_player = "greeted_obj_id",
									bb_saleNum = "saleItemNum",
									bb_sale = "saleItem",
									bb_exchangeNum = "exchangeItemNum",
									bb_exchange = "exchangeItem"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "greeted_obj_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "greeted_obj_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_camelSale = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonJudge",
				subparam = {
					compareValue = 2,
					curValue = "bb_saleType",
					judgeType = AIFunctionDefsGetDefByKey("judgeType").value,
					compareType = AIFunctionDefsGetDefByKey("compareType").equal
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									fun = "exchangeItemFormPlayer",
									bb_player = "greeted_obj_id",
									bb_saleNum = "saleItemNum",
									bb_sale = "saleItem",
									bb_exchangeNum = "exchangeItemNum",
									bb_exchange = "exchangeItem"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "greeted_obj_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "greeted_obj_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_interact = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					bb_exchange = "exchangeItem",
					fun = "normalTradeGetExchangeItem"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_standUp"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					animID = 100829,
					duration = 2.5,
					exchangeItemId = "exchangeItem",
					soundName = "ent.3210.accept"
				}
			}
		}
	}
}
local bt_pitch = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "hourCompare",
					extraValue = {
						max = 19,
						min = 9
					}
				}
			}
		},
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							type = "isOnGround"
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonCompare",
										subparam = {
											reversal = true,
											type = "isSitting"
										}
									}
								},
								bt_MovetoPitch
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonCompare",
										subparam = {
											type = "isSitting"
										}
									}
								},
								{
									node = "BTNodeSimpleParallel",
									children = {
										bt_action_idle_lookAround
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_judgeWorkPos = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isSitting"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isSleeping"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					bb_pos = "pitchPos",
					range = 3200,
					type = "isUsablePos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isPosOutRange",
					extraValue = {
						range = 2,
						comparePos = "pitchPos"
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_standUp"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_taskExplore",
				subparam = {
					stagePos = "bb_curToPos",
					explorePos = "pitchPos"
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				{
					node = "BTNTaskMoveTo",
					param = {
						avoidWater = false,
						minDistance = 0,
						speed = 1,
						bbkey_targetpos = "bb_curToPos"
					}
				}
			}
		}
	}
}
local bt_judgeSitWorkPos = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isSitting"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isSleeping"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					bb_pos = "pitchPos",
					range = 3200,
					type = "isUsablePos"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isPosOutRange",
					extraValue = {
						range = 2,
						comparePos = "pitchPos"
					}
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_standUp"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_taskExplore",
				subparam = {
					stagePos = "bb_curToPos",
					explorePos = "pitchPos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = false,
				minDistance = 0,
				speed = 1,
				bbkey_targetpos = "bb_curToPos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_sitDown",
				subparam = {
					type = "ActorDesertBusInessMan"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_turnBodyByDir",
				subparam = {
					standDir = "pitchDir"
				}
			}
		}
	}
}
local bt_free = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isToEnd"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_judgeWorkPos,
				bt_judgeSitWorkPos,
				bt_action_sleep,
				bt_pitch
			}
		}
	}
}
local bt_follow = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isFollow"
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									extraValue = "bb_followObj",
									fun = "setFollowObj"
								}
							}
						},
						{
							node = "BTNTaskFollow",
							param = {
								bbkey_followobj = "bb_followObj",
								minDistance = 2.5,
								speed = 1.2
							}
						}
					}
				}
			}
		}
	}
}
local bt_explore = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isToEnd"
				}
			}
		},
		{
			node = "BTNodeSuccess",
			children = {
				{
					node = "BTNodeSelector",
					children = {
						bt_follow,
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonCompare",
												subparam = {
													reversal = true,
													type = "isPosOutRange",
													extraValue = {
														range = 2,
														comparePos = "bb_explorePos"
													}
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													fun = "nextExplore"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "bb_explorePos",
													fun = "setExplorePos"
												}
											}
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "bb_explorePos",
													fun = "setExplorePos"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_taskExplore",
												subparam = {
													stagePos = "bb_curToPos",
													explorePos = "bb_explorePos"
												}
											}
										},
										{
											node = "BTNTaskMoveTo",
											param = {
												avoidWater = false,
												minDistance = 1,
												speed = 1,
												bbkey_targetpos = "bb_curToPos"
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_avoidStand = {
	node = "BTNodeBranch",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "ActorDesertBusInessMan",
					type = "isInStandStorm"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							extraValue = "ActorDesertBusInessMan",
							reversal = true,
							type = "isAvoidingStand"
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeSelector",
							children = {
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonCompare",
												subparam = {
													bb_pos = "bb_tentPos",
													reversal = true,
													range = 32,
													type = "isUsablePos"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_FindPlaneArea",
												subparam = {
													bb_pitch = "bb_tentPos",
													retType = 2,
													random = false,
													extraValue = {
														range = 5,
														w = 2,
														blockid = {
															3,
															4,
															5,
															6,
															12,
															13,
															14,
															0
														}
													}
												}
											}
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonCompare",
												subparam = {
													bb_pos = "bb_tentPos",
													range = 32,
													type = "isUsablePos"
												}
											}
										},
										{
											node = "BTNTaskMoveTo",
											param = {
												avoidWater = true,
												minDistance = 0,
												speed = 2,
												bbkey_targetpos = "bb_tentPos"
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													bedPos = "bb_tentPos",
													fun = "placeBed"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_sleepOnAndBindBed",
												subparam = {
													bb_bedpos = "bb_tentPos"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "ActorDesertBusInessMan",
													fun = "setAvoidStand",
													value = true
												}
											}
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													bedPos = "bb_tentPos",
													fun = "removeBed",
													extraValue = "ActorDesertBusInessMan"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_wakeup",
												subparam = {
													bb_bedpos = "bb_tentPos"
												}
											}
										},
										{
											node = "BTNodeFail",
											children = {
												node = "BTNodeTaskLua",
												param = {
													script = "BTTask_commonSetValue",
													subparam = {
														key = "bb_tentPos",
														valueType = AIFunctionDefsGetDefByKey("valueType").value,
														value = {
															z = 0,
															y = 0,
															x = 0
														}
													}
												}
											}
										}
									}
								}
							}
						},
						{
							node = "BTNodeSelector",
							param = {
								tip = "sit00000"
							},
							children = {
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "ActorDesertBusInessMan",
													fun = "findSitAvoidStand",
													avoidStandPos = "bb_sitAvoidPos"
												}
											}
										},
										{
											node = "BTNTaskMoveTo",
											param = {
												avoidWater = true,
												minDistance = 0,
												speed = 2,
												bbkey_targetpos = "bb_sitAvoidPos"
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_sitDown",
												subparam = {
													type = "ActorDesertBusInessMan"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "ActorDesertBusInessMan",
													fun = "setAvoidStand",
													value = true
												}
											}
										}
									}
								},
								{
									node = "BTNodeSuccess",
									children = {
										node = "BTNodeTaskLua",
										param = {
											script = "BTTask_commonSetValue",
											subparam = {
												key = "bb_sitAvoidPos",
												valueType = AIFunctionDefsGetDefByKey("valueType").value,
												value = {
													z = 0,
													y = 0,
													x = 0
												}
											}
										}
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSelector",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									type = "isSleeping"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									type = "isSitting"
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getBedPos",
										subparam = {
											bb_bedpos = "bb_tentPos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonCompare",
										subparam = {
											extraValue = "bb_tentPos",
											type = "isUableBedPos"
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										minDistance = 0,
										speed = 2,
										bbkey_targetpos = "bb_tentPos"
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_sleepOnAndBindBed",
										subparam = {
											bb_bedpos = "bb_tentPos"
										}
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							param = {
								tip = "sit111"
							},
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_simpleFun",
										subparam = {
											bedPos = "bb_tentPos",
											fun = "removeBed",
											extraValue = "ActorDesertBusInessMan"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_getBedPos",
										subparam = {
											bb_bedpos = "bb_sitAvoidPos"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonCompare",
										subparam = {
											bb_pos = "bb_sitAvoidPos",
											range = 32,
											type = "isUsablePos"
										}
									}
								},
								{
									node = "BTNTaskMoveTo",
									param = {
										avoidWater = true,
										minDistance = 0,
										speed = 2,
										bbkey_targetpos = "bb_sitAvoidPos"
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_sitDown",
										subparam = {
											type = "ActorDesertBusInessMan"
										}
									}
								}
							}
						},
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_simpleFun",
										subparam = {
											extraValue = "ActorDesertBusInessMan",
											fun = "setAvoidStand",
											value = false
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_simpleFun",
										subparam = {
											bedPos = "bb_tentPos",
											fun = "removeBed",
											extraValue = "ActorDesertBusInessMan"
										}
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_standUp"
									}
								}
							}
						}
					}
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonCompare",
								subparam = {
									extraValue = "ActorDesertBusInessMan",
									type = "isAvoidingStand"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_getBedPos",
								subparam = {
									bb_bedpos = "bb_tentPos"
								}
							}
						},
						{
							node = "BTNodeBranch",
							children = {
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_commonCompare",
										subparam = {
											extraValue = "bb_tentPos",
											type = "isUableBedPos"
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_wakeup",
												subparam = {
													bb_bedpos = "bb_tentPos"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													bedPos = "bb_tentPos",
													fun = "removeBed",
													extraValue = "ActorDesertBusInessMan"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonSetValue",
												subparam = {
													key = "bb_tentPos",
													valueType = AIFunctionDefsGetDefByKey("valueType").value,
													value = {
														z = 0,
														y = 0,
														x = 0
													}
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "ActorDesertBusInessMan",
													fun = "setAvoidStand",
													value = false
												}
											}
										}
									}
								},
								{
									node = "BTNodeSequence",
									children = {
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_standUp"
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_wakeup",
												subparam = {
													bb_bedpos = "bb_tentPos"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													bedPos = "bb_sitAvoidPos",
													fun = "removeBed",
													extraValue = "ActorDesertBusInessMan"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													bedPos = "bb_tentPos",
													fun = "removeBed",
													extraValue = "ActorDesertBusInessMan"
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_commonSetValue",
												subparam = {
													key = "bb_tentPos",
													valueType = AIFunctionDefsGetDefByKey("valueType").value,
													value = {
														z = 0,
														y = 0,
														x = 0
													}
												}
											}
										},
										{
											node = "BTNodeTaskLua",
											param = {
												script = "BTTask_simpleFun",
												subparam = {
													extraValue = "ActorDesertBusInessMan",
													fun = "setAvoidStand",
													value = false
												}
											}
										}
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeFail",
					children = {
						node = "BTNodeTaskLua",
						param = {
							script = "BTTask_simpleFun",
							subparam = {
								extraValue = "ActorDesertBusInessMan",
								fun = "setAvoidStand",
								value = false
							}
						}
					}
				}
			}
		}
	}
}
local bt_avoidStandMain = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					reversal = true,
					type = "isToEnd"
				}
			}
		},
		bt_avoidStand
	}
}
local bt_warn = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					camelPos = "bb_camelPos",
					fun = "getPickingCamelPos"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				avoidWater = true,
				minDistance = 3,
				speed = 1.5,
				bbkey_targetpos = "bb_camelPos"
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					fun = "informPlayerCloseUI"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					animID = 100827,
					duration = 1,
					soundName = "ent.3210.anger"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					extraValue = "ActorDesertBusInessMan",
					fun = "clearHateUin",
					attackActor = "bbKeyBeHurtTargetObjId"
				}
			}
		}
	}
}
local bt_warnMain = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isWarning"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_warn,
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_simpleFun",
						subparam = {
							extraValue = "ActorDesertBusInessMan",
							fun = "clearHateUin",
							attackActor = "bbKeyBeHurtTargetObjId"
						}
					}
				}
			}
		}
	}
}
local bt_main = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					type = "isOnGround"
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				bt_action_wakeup,
				bt_fire,
				bt_warnMain,
				bt_interact,
				bt_avoidStandMain,
				bt_explore,
				bt_free
			}
		}
	}
}

return bt_main
