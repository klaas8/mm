local bt_lootPlayerEquip = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "bbKeyBeHurtTargetObjId",
					type = "playerIsDead"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					player = "bbKeyBeHurtTargetObjId",
					target = "bb_equip",
					targetType = "bb_equipType",
					fun = "playerDropEquip"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					targetId = "bb_equipObjId",
					target = "bb_equip",
					targetPos = "bb_equipdPos",
					fun = "findDropItemNear"
				}
			}
		},
		{
			node = "BTNTaskMoveTo",
			param = {
				speed = 1,
				minDistance = 1,
				bbkey_targetpos = "bb_equipdPos",
				CollideHorizontallyStop = false
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_simpleFun",
				subparam = {
					dropItemId = "bb_equipObjId",
					targetType = "bb_equipType",
					fun = "mobEquipFromBackPack"
				}
			}
		}
	}
}
local bt_fire_battle_attack_behurt = {
	node = "BTNodeSuccess",
	children = {
		{
			node = "BTNodeSequence",
			children = {
				{
					node = "BTNTaskFollow",
					param = {
						speed = 1.1,
						bbkey_followobj = "bbKeyBeHurtTargetObjId",
						minDistance = 1.5,
						canTeleport = false
					}
				},
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_TurnToTarget",
						subparam = {
							bbTargetKey = "bbKeyBeHurtTargetObjId"
						}
					}
				},
				{
					node = "BTNTaskAttack",
					param = {
						bbkey_attackobj = "bbKeyBeHurtTargetObjId",
						keeptick = 30
					}
				}
			}
		}
	}
}
local bt_fire_battle_attack_enemy = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "enemy_id",
					type = "actorIsInvalid"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							extraValue = "enemy_id",
							type = "actorInView"
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						{
							node = "BTNodeSequence",
							children = {
								{
									node = "BTNTaskFollow",
									param = {
										speed = 1.3,
										bbkey_followobj = "enemy_id",
										minDistance = 2.5,
										canTeleport = false
									}
								},
								{
									node = "BTNodeTaskLua",
									param = {
										script = "BTTask_TurnToTarget",
										subparam = {
											bbTargetKey = "enemy_id"
										}
									}
								},
								{
									node = "BTNTaskAttack",
									param = {
										bbkey_attackobj = "enemy_id",
										keeptick = 30
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSuccess",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "enemy_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_active_fire = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "bbKeyBeHurtTargetObjId",
					type = "actorIsInvalid"
				}
			}
		},
		{
			node = "BTNodeBranch",
			children = {
				{
					node = "BTNodeTaskLua",
					param = {
						script = "BTTask_commonCompare",
						subparam = {
							extraValue = "bbKeyBeHurtTargetObjId",
							type = "actorInView"
						}
					}
				},
				bt_fire_battle_attack_behurt,
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeSuccess",
							children = {
								bt_lootPlayerEquip
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "bbKeyBeHurtTargetObjId",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_fire = {
	node = "BTNodeSelector",
	children = {
		bt_active_fire,
		bt_fire_battle_attack_enemy
	}
}
local bt_interact = {
	node = "BTNodeSequence",
	children = {
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonCompare",
				subparam = {
					extraValue = "greeted_obj_id",
					type = "actorIsExist"
				}
			}
		},
		{
			node = "BTNodeTaskLua",
			param = {
				script = "BTTask_commonPlayAction",
				subparam = {
					duration = 2.5,
					animID = 100894
				}
			}
		},
		{
			node = "BTNodeSelector",
			children = {
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									player = "greeted_obj_id",
									fun = "calculatePlayerEquip"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									value = "greeted_obj_id",
									key = "bbKeyBeHurtTargetObjId",
									valueType = AIFunctionDefsGetDefByKey("valueType").value
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "greeted_obj_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				},
				{
					node = "BTNodeSequence",
					children = {
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_simpleFun",
								subparam = {
									player = "greeted_obj_id",
									fun = "mobOpenContainer"
								}
							}
						},
						{
							node = "BTNodeTaskLua",
							param = {
								script = "BTTask_commonSetValue",
								subparam = {
									key = "greeted_obj_id",
									valueType = AIFunctionDefsGetDefByKey("valueType").value,
									value = {
										actor = 0
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
local bt_main = {
	node = "BTNodeSelector",
	children = {
		bt_fire,
		bt_interact
	}
}

return bt_main
