if not BTClass then
	assert(false)

	return
end

local BTBaseManagerClass = BTClass:Class("BTBaseManager")

function BTBaseManagerClass:constructor(classname, cfgPath)
	self.classname = classname
	self.cfgPath = cfgPath
	self.cfgs = {}
	self.pool = {}
	self.BTCommand = BTCommand
end

function BTBaseManagerClass:destructor()
	if self.pool then
		for _, ins in pairs(self.pool) do
			ins:delete()
		end

		self.pool = nil
	end

	self.cfgs = nil
end

function BTBaseManagerClass:CreateInstance(id, filename, ...)
	local cfg = self:LoadConfig(filename)

	return self:CreateInstanceByCfg(id, nil, filename, cfg, ...)
end

function BTBaseManagerClass:CreateInstanceByText(id, text, ...)
	local cfg, errorMsg = self:LoadConfigByText(text)

	if not cfg then
		return nil, errorMsg
	end

	return self:CreateInstanceByCfg(id, nil, nil, cfg, ...)
end

function BTBaseManagerClass:LoadConfigByText(text)
	if type(text) ~= "string" then
		return nil
	end

	local cfg, errorMsg = self.BTCommand:AIBTLoad(text)

	if not cfg then
		return nil, errorMsg
	end

	return cfg()
end

function BTBaseManagerClass:AIEditCreateInstance(id, defid, filename, treeid, ...)
	if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
		MiniLog("AIEditCreateInstance id ", id)
		MiniLog("AIEditCreateInstance filename ", filename)
	end

	local cfg = self:LoadAIEditConfig(filename)

	if cfg then
		cfg.treeid = treeid

		return self:CreateInstanceByCfg(id, defid, filename, cfg, ...)
	end
end

function BTBaseManagerClass:AIEditCreateInstanceByFiles(id, defid, filenames, ...)
	if type(filenames) ~= "table" then
		return nil
	end

	local filename = ""
	local cfgs = {
		iscfgs = true,
		data = {}
	}

	if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
		MiniLog("AIEditCreateInstance id ", id)
	end

	if #filenames == 1 then
		if type(filenames[1]) == "table" then
			local cfg = self:LoadAIEditConfig(filenames[1].file)

			if cfg then
				cfg.treeid = filenames[1].treeid

				return self:CreateInstanceByCfg(id, defid, filenames[1], cfg, ...)
			end
		else
			local cfg = self:LoadAIEditConfig(filenames[1])

			return self:CreateInstanceByCfg(id, defid, filenames[1], cfg, ...)
		end
	else
		for index, value in ipairs(filenames) do
			if type(value) == "table" then
				filename = filename .. "_" .. value.file
				local cfg = self:LoadAIEditConfig(value.file)

				if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
					MiniLog("AIEditCreateInstance filename ", value.file)
				end

				if cfg then
					cfg.treeid = value.treeid

					table.insert(cfgs.data, cfg)
				end
			else
				filename = filename .. "_" .. value
				local cfg = self:LoadAIEditConfig(value)

				if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
					MiniLog("AIEditCreateInstance filename ", value)
				end

				if cfg then
					table.insert(cfgs.data, cfg)
				end
			end
		end

		return self:CreateInstanceByCfg(id, defid, filename, cfgs, ...)
	end
end

function BTBaseManagerClass:CreateInstanceByCfg(id, defid, filename, cfg, ...)
	if not cfg then
		return nil
	end

	if self.pool[id] then
		print("BT ERROR : load " .. tostring(self.classname) .. " id is existed! id=" .. tostring(id) .. ", filename=" .. filename)

		return nil
	end

	if not self.classname or not BTClass[self.classname] then
		print("BT ERROR : load instance, class name is error! classname=" .. tostring(self.classname))

		return nil
	end

	local ins = BTClass[self.classname]:new(id, defid, cfg, filename, ...)

	if not ins then
		return nil
	end

	self.pool[id] = ins

	return ins
end

function BTBaseManagerClass:DestroyInstance(id)
	local ins = self.pool[id]

	if ins then
		ins:delete()

		self.pool[id] = nil
	end
end

function BTBaseManagerClass:LoadConfig(filename)
	if type(filename) ~= "string" then
		return nil
	end

	if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
		if string.match(filename, "UGCTask") then
			filename = "luascript." .. self.extraPath .. "." .. filename
		else
			filename = "luascript." .. self.cfgPath .. "." .. filename
		end

		package.loaded[filename] = nil
		local cfg = require(filename)
		local hotfixconfig = BehaviorTree_GetHotfixByFileName(filename)

		if hotfixconfig then
			for key, value in pairs(hotfixconfig) do
				cfg[key] = value
			end
		end

		return cfg
	end

	if self.cfgs[filename] then
		local cfg = self.cfgs[filename]

		return self.cfgs[filename]
	end

	local filepath = self.cfgPath .. "." .. filename
	local path = "luascript/" .. filepath:gsub("%.data$", ""):gsub("%.lua$", ""):gsub("%.", "/") .. ".lua"
	local cfg = nil

	if gFunc_isFileExist(path) then
		cfg = self.BTCommand:LoadConfig(self.cfgPath, filename)
	else
		cfg = self.BTCommand:LoadConfig(self.extraPath, filename)
	end

	if not cfg then
		return nil
	end

	local hotfixconfig = BehaviorTree_GetHotfixByFileName(filename)

	if hotfixconfig then
		for key, value in pairs(hotfixconfig) do
			cfg[key] = value
		end
	end

	self.cfgs[filename] = cfg

	return cfg
end

function BTBaseManagerClass:LoadAIEditConfig(filename)
	if type(filename) ~= "string" then
		return nil
	end

	if self.BTCommand:IsAbleUseConfig() and self.cfgs[filename] then
		return self.cfgs[filename]
	end

	local cfg = self.BTCommand:LoadAIEditConfig(filename)

	if not cfg then
		return nil
	end

	self.cfgs[filename] = cfg

	return cfg
end

function BTBaseManagerClass:GetInstance(id)
	return self.pool[id]
end

function BTBaseManagerClass:AddExtraPath(extraPath)
	self.extraPath = extraPath
end
