local AIFunctionDefs = Class("AIFunctionDefs")
local instance = nil

function AIFunctionDefsGetDefByKey(key)
	return GetInst("AIFunctionDefs"):GetDefByKey(key)
end

function AIFunctionDefs:GetInst()
	if instance == nil then
		instance = ClassList.AIFunctionDefs.instance()
	end

	return instance
end

function AIFunctionDefs:Init()
	self.define = {
		StrollLimitRange = 7,
		StrollRange = 10,
		villageStoreRange = 11,
		villageRange = 32,
		guardStrollPlayerAroundRange = 2,
		guardStrollRange = 10,
		bpWorkRange = 100,
		workRange = 32,
		oncePatrolTime = 100,
		pickDis = 2,
		dropRange = 8,
		searchRange = 16,
		interactDisToBlock = 3,
		interactDisToActor = 2,
		plantCropsRangeWithoutWorkpos = 16,
		plantCropsRangeWithWorkpos = 4,
		plantTreeRangeWithoutWorkpos = 16,
		plantTreeRangeWithWorkpos = 7,
		longRangeAttackSearch = 16,
		interactDisToItem = 4,
		rangeType = {
			work = 1,
			none = 0,
			bpWork = 5,
			view = 4,
			villageStore = 3,
			village = 2
		},
		compareType = {
			more = 3,
			equal = 2,
			less = 1,
			none = 0,
			notequal = 6,
			moreEqual = 5,
			lessEqual = 4
		},
		judgeType = {
			handItemIsSapling = 53,
			none = 0,
			handItemType = 51,
			isActorExist = 50,
			isHelperWorking = 49,
			isInRange = 48,
			randomValue = 47,
			isBedBindWithOthers = 46,
			isReachTime = 45,
			isBindWithVillagePoint = 44,
			isBindWithWorkPoint = 43,
			isBindWithBedPoint = 42,
			sitstate = 41,
			handItem = 40,
			modelScale = 39,
			longRangeDefense = 38,
			shortRangeDefense = 37,
			longRangeAttack = 36,
			shortRangeAttack = 35,
			curHp = 34,
			maxHp = 33,
			moveSpeed = 32,
			speedOfBreakingBlock = 31,
			hugger = 30,
			workBindPos = 29,
			bedBindPos = 28,
			faceId = 27,
			hairColor = 26,
			hairId = 25,
			foodByTamed = 24,
			demand = 23,
			emptygrid = 22,
			isTamed = 21,
			extremisVal = 20,
			favor = 19,
			disposition = 18,
			isBlockOccupyed = 17,
			targetDis = 16,
			isHaveBindPoint = 14,
			isCooling = 13,
			bagItemCount = 12,
			professionCount = 11,
			professionType = 10,
			isDefection = 9,
			fatigueStatus = 8,
			huggerStatus = 7,
			fullUp = 6,
			getUpTime = 5,
			isStayUpLate = 4,
			stayUpLateTime = 3,
			isSleeping = 2,
			sleepTime = 1,
			isInWater = 52,
			value = 100,
			isOtherFreezing = 63,
			isFreezing = 62,
			bufferDuration = 61,
			cdDuration = 60,
			equipItemId = 59,
			temperature = 58,
			isIceVillage = 57,
			isGuardForPlayer = 56,
			stayBiome = 55,
			handItemIsCropSeed = 54
		},
		valueType = {
			stayUpLateTime = 16,
			none = 0,
			isTraitor = 21,
			saveCdTick = 32,
			saveBufferTick = 33,
			isHaveWorshipBlock = 34,
			value = 100,
			modelScale = 30,
			longRangeDefense = 29,
			shortRangeDefense = 28,
			longRangeAttack = 27,
			shortRangeAttack = 26,
			curHp = 25,
			maxHp = 24,
			moveSpeed = 23,
			speedOfBreakingBlock = 19,
			hugger = 11,
			workBindPos = 10,
			bedBindPos = 9,
			faceId = 7,
			hairColor = 6,
			hairId = 5,
			foodByTamed = 2,
			demand = 1,
			extremisVal = 20,
			favor = 4,
			disposition = 3,
			fatigueStatus = 18,
			huggerStatus = 13,
			fullUp = 12,
			getUpTime = 14,
			isStayUpLate = 17,
			loopAction = 31,
			coolingTime = 22,
			sleepTime = 15,
			profession = 8
		},
		findTargetType = {
			block = 1,
			none = 0,
			player = 3,
			actor = 2
		},
		attackEnemyIds = {
			3101,
			3102,
			3105,
			3107,
			3103,
			3110,
			3112,
			3113,
			3114,
			3115,
			3116,
			3117,
			3118,
			3130,
			3131,
			3132,
			3413,
			3600,
			3107,
			3873,
			3874,
			3875,
			3876,
			3877,
			3872,
			3915
		},
		hunterAttackEnemyIds = {
			3101,
			3102,
			3105,
			3107,
			3103,
			3110,
			3112,
			3113,
			3114,
			3115,
			3116,
			3117,
			3118,
			3130,
			3131,
			3132,
			3413,
			3600,
			3107,
			3873,
			3874,
			3875,
			3876,
			3877,
			3872,
			3400,
			3401,
			3402,
			3403,
			3407,
			3409,
			3910,
			3912,
			3915
		},
		escapeEnemyIds = {
			3101,
			3102,
			3105,
			3107,
			3103,
			3110,
			3112,
			3113,
			3114,
			3115,
			3116,
			3117,
			3118,
			3130,
			3131,
			3132,
			3413,
			3600,
			3107,
			3873,
			3874,
			3875,
			3876,
			3877,
			3872,
			3915
		},
		escapeEnemyBossIds = {
			3517
		},
		timeType = {
			work = 5,
			none = 0,
			sleep = 3,
			offWork = 2,
			wakeUp = 1,
			stayUpLate = 4
		},
		playerAnimType = {
			none = 0,
			pose = 10,
			fallDown = 9,
			idle = 8,
			thanks = 7,
			success = 6,
			stretch = 5,
			angry = 4,
			cry = 3,
			question = 2,
			wave = 1
		},
		actorAnimType = {
			none = 0,
			clap = 200106,
			hug = 200103,
			fallDown = 100157,
			idle = 100130,
			thanks = 100131,
			stretch = 100163,
			question = 100162,
			wave = 100140
		},
		foodsList = {},
		toolsList = {
			200,
			201,
			202,
			203,
			204,
			205,
			251,
			254,
			212,
			213,
			214,
			215,
			216,
			217,
			253,
			256,
			229,
			230,
			234,
			236,
			239,
			241,
			11400,
			11404,
			378,
			386,
			380,
			383,
			382,
			579,
			11595,
			11596,
			11601,
			12500,
			12601,
			12602,
			12603,
			12604,
			12503,
			12607,
			332,
			333,
			334,
			335,
			336,
			337,
			338,
			339,
			340,
			341,
			342,
			343,
			11323,
			710,
			12508
		},
		famerToolsList = {
			229,
			230,
			234,
			236,
			239,
			241,
			11400,
			11404
		},
		cutterToolsList = {
			200,
			201,
			202,
			203,
			204,
			205,
			251,
			254,
			212,
			213,
			214,
			215,
			216,
			217,
			253,
			256,
			378,
			386,
			380,
			383,
			382,
			579,
			11595,
			11596,
			11601,
			12500,
			12601,
			12602,
			12603,
			12604,
			12503,
			12607,
			332,
			333,
			334,
			335,
			336,
			337,
			338,
			339,
			340,
			341,
			342,
			343,
			11323
		},
		hunterToolsList = {
			12532,
			12623,
			12516,
			11307,
			12497,
			12710,
			12518,
			11303,
			12516,
			11307,
			12522,
			12530,
			12520,
			12521
		},
		fishermanToolsList = {
			13621
		},
		operationType = {
			division = 4,
			none = 0,
			reduce = 2,
			add = 1,
			multi = 3
		},
		interactActionDef = {
			{
				effectName = "mob_3200_hungery",
				animID = 100164,
				soundName = "npc.hungry"
			},
			{
				effectName = "mob_3402_1",
				animID = 200202,
				soundName = "ent.3402.sleep"
			},
			{
				effectName = "",
				animID = 100163,
				soundName = "ent.3421.tired"
			},
			{
				bComposeSound = true,
				effectName = "mob_3200_music",
				soundName = "dance"
			},
			{
				bComposeSound = true,
				effectName = "mob_3200_music",
				soundName = "sing"
			},
			{
				faceId = 4,
				soundName = "ent.3233.happy",
				bComposeSound = true,
				effectName = "InteractTure",
				animID = 100155
			},
			{
				faceId = 4,
				soundName = "ent.3233.applaud",
				bComposeSound = true,
				effectName = "InteractTure",
				animID = 200210
			},
			{
				faceId = 4,
				soundName = "ent.3233.applaud",
				bComposeSound = true,
				effectName = "InteractTure",
				animID = 200210
			},
			{
				bComposeSound = true,
				effectName = "",
				animID = 200213,
				soundName = "ent.3200.freeze"
			},
			[1001] = {
				faceId = 1,
				soundName = "refuse",
				bComposeSound = true,
				effectName = "InteractFalse",
				animID = 200204
			},
			[1002] = {
				faceId = 1,
				soundName = "happy",
				bComposeSound = true,
				effectName = "InteractTure",
				animID = 200103
			},
			[1003] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "clear_prop",
				animID = 200103
			},
			[1004] = {
				faceId = 5,
				soundName = "cry",
				bComposeSound = true,
				effectName = "anim_100159",
				animID = 200159
			},
			[1005] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "item_12002_2",
				animID = 100131
			},
			[1006] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "item_12002_2",
				animID = 100131
			},
			[1007] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "item_12002_2",
				animID = 100131
			},
			[1008] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "BUFF_HP_R",
				animID = 100155
			},
			[1009] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "mob_3110_joint",
				animID = 100131
			},
			[1010] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "mob_3110_joint",
				animID = 100131
			},
			[1011] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "mob_3110_joint",
				animID = 100131
			},
			[1012] = {
				faceId = 4,
				soundName = "happy",
				bComposeSound = true,
				effectName = "mob_3110_joint",
				animID = 100131
			}
		},
		hungryReduceDef = {
			swim = 25,
			attack = 360,
			beHurt = 360,
			compound = 100,
			plant = 30,
			destory = 30,
			walk = 5
		},
		itemType = {
			{
				11001,
				11002,
				11003,
				11004
			},
			{
				11022,
				11023,
				11024
			},
			{
				11031,
				11032,
				11033,
				11034
			},
			{
				12001,
				12002,
				12003,
				12004,
				12005,
				11230,
				11569,
				12009,
				12010
			},
			{
				12002,
				12050,
				12281,
				12068
			},
			{
				12502,
				12540,
				12543
			}
		},
		itemTransformList = {
			[12602.0] = 11412,
			[12601.0] = 11409,
			[12604.0] = 11410,
			[12503.0] = 11406,
			[12603.0] = 11411,
			[12607.0] = 11408,
			[12500.0] = 11405
		},
		changeType = {
			change = 3,
			reduce = 2,
			add = 1
		}
	}

	self:initFoodsList()
end

function AIFunctionDefs:GetItemType(itemId, profession)
	if itemId == 12002 then
		if profession == 4 or profession == 6 then
			return 5
		else
			return 4
		end
	else
		local itemTypes = AIFunctionDefsGetDefByKey("itemType")

		for i = 1, #itemTypes do
			local aItemType = itemTypes[i]
			local isFind = false

			for j = 1, #aItemType do
				local aItemId = aItemType[j]

				if aItemId == itemId then
					isFind = true

					break
				end
			end

			if isFind then
				return i
			end
		end
	end

	return 0
end

function AIFunctionDefs:GetToolCfg(itemtype)
	local datas = AIFunctionDefsGetDefByKey("itemType")

	if not datas then
		return {}
	end

	local list = itemtype and datas[itemtype]

	if not list then
		return {}
	end

	local iteminfos = {}

	for _, itemid in ipairs(list) do
		table.insert(iteminfos, {
			num = 1,
			itemid = itemid
		})
	end

	return iteminfos
end

function AIFunctionDefs:GetDefByKey(key)
	return self.define[key]
end

function AIFunctionDefs:GetAnimIDByPlayer(playerAnimType)
	local playerAnimTypeEnum = self:GetDefByKey("playerAnimType")
	local actorAnimTypeEnum = self:GetDefByKey("actorAnimType")

	if playerAnimType == playerAnimTypeEnum.wave then
		return actorAnimTypeEnum.wave
	elseif playerAnimType == playerAnimTypeEnum.question then
		return actorAnimTypeEnum.question
	elseif playerAnimType == playerAnimTypeEnum.cry then
		return actorAnimTypeEnum.hug
	elseif playerAnimType == playerAnimTypeEnum.angry then
		return actorAnimTypeEnum.question
	elseif playerAnimType == playerAnimTypeEnum.stretch then
		return actorAnimTypeEnum.stretch
	elseif playerAnimType == playerAnimTypeEnum.success then
		return actorAnimTypeEnum.clap
	elseif playerAnimType == playerAnimTypeEnum.thanks then
		return actorAnimTypeEnum.thanks
	elseif playerAnimType == playerAnimTypeEnum.idle then
		return actorAnimTypeEnum.idle
	elseif playerAnimType == playerAnimTypeEnum.fallDown then
		return actorAnimTypeEnum.fallDown
	elseif playerAnimType == playerAnimTypeEnum.pose then
		return actorAnimTypeEnum.wave
	end

	return actorAnimTypeEnum.idle
end

function AIFunctionDefs:initFoodsList()
	local allFood = FoodDefCsv:GetAllDefForLua()

	for i, foodDef in pairs(allFood) do
		if foodDef and foodDef.ChoosePriority and foodDef.ChoosePriority > 0 then
			table.insert(self.define.foodsList, foodDef.ID)
		end
	end
end

function AIFunctionDefs_GetHungryReduceByType(type)
	local instance = GetInst("AIFunctionDefs")

	if instance.define.hungryReduceDef and instance.define.hungryReduceDef[type] then
		return instance.define.hungryReduceDef[type]
	end

	return 0
end
