if not BTClass then
	assert(false)

	return
end

if not BTClass.BTEnum then
	assert(false)

	return
end

if not BTClass.BTCommand then
	assert(false)

	return
end

if not BTClass.BTBaseManager then
	assert(false)

	return
end

local inslist = {
	"BTEnum",
	"BTCommand",
	"BTBaseManager"
}
local regtasklist = nil
local G_Manager = {}
local _AiCfgFenv_ = {}
local _hotfixInfo = {}
local _childbbfile = {}
local _AITreeNodeTemp = {}
local _AIBBTemp = {}
local _AITreeTemp = {}
local _BTGetValueManage, _BTSummonMessageManager = nil
local _controllerCache = {}
local _controllerCacheSize = 0
local _decodeInfoPool = {}

local function BTGetSummonMessageManagerIfExists()
	if _BTSummonMessageManager then
		return _BTSummonMessageManager
	end

	local summonMsgClass = ClassList and ClassList.BTSummonMessageManager
	local summonMsgMgr = summonMsgClass and summonMsgClass.GetInstIfExists and summonMsgClass:GetInstIfExists()

	if summonMsgMgr then
		_BTSummonMessageManager = summonMsgMgr
	end

	return summonMsgMgr
end

local function BTReleaseSummonMessageManagerCache()
	_BTSummonMessageManager = nil
end

function BehaviorTreeTickSummonMessage(sec)
	local summonMsgMgr = BTGetSummonMessageManagerIfExists()

	if summonMsgMgr and summonMsgMgr.OnTick then
		summonMsgMgr:OnTick(sec)
	end
end

local function BTClearSummonMessageManager()
	local summonMsgMgr = BTGetSummonMessageManagerIfExists()

	if summonMsgMgr then
		summonMsgMgr:Clear()
	end
end

local function BTReleaseSummonMessageManager()
	local summonMsgClass = ClassList and ClassList.BTSummonMessageManager

	if summonMsgClass and summonMsgClass.ReleaseInst then
		summonMsgClass:ReleaseInst()
	else
		local summonMsgMgr = BTGetSummonMessageManagerIfExists()

		if summonMsgMgr then
			summonMsgMgr:Clear()

			if summonMsgMgr.delete then
				summonMsgMgr:delete()
			end
		end
	end

	BTReleaseSummonMessageManagerCache()
end

local function BTClearSummonMessageTree(treeid, actorObjId)
	local summonMsgMgr = BTGetSummonMessageManagerIfExists()

	if summonMsgMgr then
		summonMsgMgr:ClearTree(treeid, actorObjId)
	end
end

local function BTClearSafeController(controller)
	if controller and not controller.__isSafeController and controller.safeController then
		controller.safeController = nil
	end
end

local function BTMakeSafeTarget(controller, targetType)
	return {
		getObjId = function ()
			if controller and controller.target and controller.target.getobjid then
				return controller.target.getobjid(targetType)
			end

			return 0
		end
	}
end

function BTEnsureSafeController(controller)
	if not controller then
		return nil
	end

	if controller.__isSafeController then
		return controller
	end

	if not BTIsSafeControllerEnabled() then
		BTClearSafeController(controller)

		return nil
	end

	if not controller.safeController then
		controller.safeController = {
			__isSafeController = true,
			target = {
				get = function (targetType)
					return BTMakeSafeTarget(controller, targetType)
				end,
				getobjid = function (targetType)
					if controller.target and controller.target.getobjid then
						return controller.target.getobjid(targetType)
					end

					return 0
				end
			}
		}
	end

	local safeController = controller.safeController

	if safeController.treeid ~= controller.treeid then
		safeController.treeid = controller.treeid
	end

	if safeController.bb ~= controller.bb then
		safeController.bb = controller.bb
	end

	if safeController.luabb ~= controller.luabb then
		safeController.luabb = controller.luabb
	end

	if safeController.taskparam ~= controller.taskparam then
		safeController.taskparam = controller.taskparam
	end

	if safeController.subparam ~= controller.subparam then
		safeController.subparam = controller.subparam
	end

	return safeController
end

function BTSelectControllerForExternal(controller)
	if BTIsSafeControllerEnabled() then
		return BTEnsureSafeController(controller)
	end

	BTClearSafeController(controller)

	return controller
end

function BehaviorTreeInit()
	local inslistsize = #inslist

	for i = 1, inslistsize do
		local insname = inslist[i]
		_G[insname] = BTClass[insname]:new()
	end

	_G.BTManager = BTClass.BTBaseManager:new("BTree", "ai.btree")
	_G.BBManager = BTClass.BTBaseManager:new("BTBlackboard", "ai.bb")
	_G.BTTaskMgr = BTClass.BTBaseManager:new("BTTask", "ai.task")
	_G.BTBBConfighMgr = BTClass.BTBaseManager:new("", "")
	G_Manager.BTManager = _G.BTManager
	G_Manager.BBManager = _G.BBManager
	G_Manager.BTTaskMgr = _G.BTTaskMgr
	G_Manager.BTBBConfighMgr = _G.BTBBConfighMgr
	_G.BTService = ClassList.BTService.new()
	local debugToggle = false

	if LuaInterface then
		debugToggle = IsOpenBtTreeDebug()
	end

	InitAiCfgFenv(debugToggle)
	G_Manager.BTTaskMgr:AddExtraPath("ai.ugctask")

	if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
		regtasklist = {}
		local configs = BTCommand:LoadConfig("ai.task", "_BTTaskReg_")

		for _, v in ipairs(configs) do
			local script = v.script

			if script then
				regtasklist[script] = true
			end
		end

		local configs = BTCommand:LoadConfig("ai.ugctask", "_BTTaskRegForUGC_")

		for _, v in ipairs(configs) do
			local script = v.script

			if script then
				regtasklist[script] = true
			end
		end
	end

	BehaviorTree_HotFixByFile()

	return GetOfficalDir()
end

function BehaviorTree_HotFixByFile()
	_hotfixInfo = {}
	local data = ns_hotfix and ns_hotfix.Ai_Fun

	if data and type(data) == "table" then
		for k, v in pairs(data) do
			local ok, funs = pcall(loadstring, v)

			if ok then
				local hotfuns = funs()

				for index, value in ipairs(hotfuns) do
					if value then
						table.insert(_hotfixInfo, value)
					else
						MiniLog(ok)
						MiniLog(k)
						MiniLog(v)
					end
				end
			end
		end
	end
end

function BehaviorTree_GetHotfixByFileName(filename)
	for index, value in ipairs(_hotfixInfo) do
		if value[filename] then
			return value[filename]
		end
	end

	return nil
end

function BehaviorTree_GetTempNode(treeid, nodeid)
	if treeid == nil then
		return
	end

	if _AITreeNodeTemp[treeid] and _AITreeNodeTemp[treeid][nodeid] then
		return _AITreeNodeTemp[treeid][nodeid]
	end

	return nil
end

function BehaviorTree_GetTreeTempNode(treeid)
	if treeid == nil then
		return
	end

	if _AITreeNodeTemp[treeid] then
		return _AITreeNodeTemp[treeid]
	end

	return nil
end

function BehaviorTree_AddTempNode(treeid, nodeid, node)
	if not treeid then
		return
	end

	if not _AITreeNodeTemp[treeid] then
		_AITreeNodeTemp[treeid] = {}
	end

	_AITreeNodeTemp[treeid][nodeid] = node
end

function BehaviorTree_GetTempBB(treeid)
	if treeid == nil then
		return
	end

	if treeid and _AIBBTemp[treeid] then
		return _AIBBTemp[treeid]
	end

	return nil
end

function BehaviorTree_AddTempBB(treeid, bb)
	if treeid == nil then
		return
	end

	if treeid then
		_AIBBTemp[treeid] = bb
	end
end

function BehaviorTree_GetTempTree(treeid)
	if treeid == nil then
		return
	end

	if _AITreeTemp[treeid] then
		return _AITreeTemp[treeid]
	end

	return nil
end

function BehaviorTree_AddTempTree(treeid, tree)
	if treeid == nil then
		return
	end

	_AITreeTemp[treeid] = tree
end

function BehaviorTreeRelease()
	BTReleaseSummonMessageManager()

	if _G.BTTaskMgr then
		_G.BTTaskMgr:delete()

		_G.BTTaskMgr = nil
	end

	if _G.BBManager then
		_G.BBManager:delete()

		_G.BBManager = nil
	end

	if _G.BTManager then
		_G.BTManager:delete()

		_G.BTManager = nil
	end

	if _G.BTService then
		_G.BTService:Release()

		_G.BTService = nil
	end

	if _G.BTBBConfighMgr then
		_G.BTBBConfighMgr:delete()

		_G.BTBBConfighMgr = nil
	end

	G_Manager = {}
	_AiCfgFenv_ = nil
	local inslistsize = #inslist

	for i = inslistsize, 1, -1 do
		local insname = inslist[i]

		if _G[insname] then
			_G[insname]:delete()

			_G[insname] = nil
		end
	end

	if GetInst("BTEventManager") then
		_childbbfile = {}

		GetInst("BTEventManager"):clear()
	end

	_childbbfile = {}
	_AIBBTemp = {}
	_AITreeTemp = {}
	_AITreeNodeTemp = {}
end

function BehaviorTreeAIReload()
	_childbbfile = {}

	BTClearSummonMessageManager()
	BTReleaseSummonMessageManagerCache()

	_AIBBTemp = {}
	_AITreeNodeTemp = {}

	if GetInst("BTEventManager") then
		GetInst("BTEventManager"):clear()
	end
end

function BehaviorTree_GetChildBBFiles(defid)
	return _childbbfile[defid]
end

local table = _G.table

function BehaviorTree_AddChildBBFile(defid, treeid, filename)
	local needcheck = true

	if not _childbbfile[defid] then
		_childbbfile[defid] = {}
		needcheck = false
	end

	if needcheck then
		for index, value in ipairs(_childbbfile[defid]) do
			if value.filename == filename then
				return
			end
		end
	end

	local value = {
		filename = filename,
		treeid = treeid
	}

	table.insert(_childbbfile[defid], value)
end

function InitAiCfgFenv(debugToggle)
	_AiCfgFenv_ = {}
	local GVMAIApi = class.AIApi.new(debugToggle)
	local GVMAIApiTb = {}

	local function Handler(method, obj)
		return function (vir, ...)
			return method(obj, ...)
		end
	end

	local list = GVMAIApi:getApiList()

	if list then
		for name, _ in pairs(list) do
			if GVMAIApi[name].__cls__ and class[GVMAIApi[name].__cls__] then
				local apiFnList = class[GVMAIApi[name].__cls__].template or {}
				local fnTb = {}
				GVMAIApiTb[name] = fnTb

				for fnName, fn in pairs(apiFnList) do
					if fnName ~= "constructor" then
						fnTb[fnName] = Handler(GVMAIApi[name][fnName], GVMAIApi[name])
					end
				end
			end
		end
	end

	_AiCfgFenv_.GVMAIApi = GVMAIApiTb
	_AiCfgFenv_.Mini = CreateParamsDef()

	if AIDefine.BTDataType then
		local tb = {}
		_AiCfgFenv_.BTDataType = tb

		for key, value in pairs(AIDefine.BTDataType) do
			tb[key] = value
		end
	end
end

function GetAiCfgFenv()
	return _AiCfgFenv_
end

function BehaviorTreeLoadBTree(id, btscript, btreeptr)
	local filename = GetBTreeConfig(btscript)

	if not filename then
		return false
	end

	local btree = G_Manager.BTManager:CreateInstance(id, filename, btreeptr)

	if not btree then
		return false
	end

	return true
end

function BehaviorTreeLoadBTreeByText(id, text, btreeptr)
	local btree, errorMsg = G_Manager.BTManager:CreateInstanceByText(id, text, btreeptr)

	if not btree then
		return false, errorMsg
	end

	return true, ""
end

local AIEditWorldType = {
	OWTYPE_EXTREMITY = 2,
	OWTYPE_RECORD = 9,
	OWTYPE_FREEMODE = 6,
	OWTYPE_GAMEMAKER_RUN = 5,
	OWTYPE_GAMEMAKER = 4,
	OWTYPE_CREATE_RUNGAME = 3,
	OWTYPE_CREATE = 1,
	OWTYPE_SINGLE = 0,
	OWTYPE_GAMEMAKER_STUDIO_EDIT = 10,
	OWTYPE_GAMEMAKER_STUDIO_RUN = 12,
	OWTYPE_GAMEMAKER_SANDBOXNODE_RUN = 11
}

function AIBehaviorTreeLoadBTree(id, defid, btscript, treeid, btreeptr)
	if WorldMgr and (WorldMgr:getGameMode() == AIEditWorldType.OWTYPE_GAMEMAKER and AccountManager and AccountManager:getMultiPlayer() == 0 or WorldMgr:getGameMode() == AIEditWorldType.OWTYPE_GAMEMAKER_STUDIO_EDIT) then
		return false
	end

	local btree = G_Manager.BTManager:AIEditCreateInstance(id, defid, btscript, treeid, btreeptr)

	if not btree then
		return false
	end

	return true
end

function AIBehaviorTreeLoadBTreeByFiles(id, defid, files, trees, btreeptr)
	if WorldMgr and (WorldMgr:getGameMode() == AIEditWorldType.OWTYPE_GAMEMAKER and AccountManager and AccountManager:getMultiPlayer() == 0 or WorldMgr:getGameMode() == AIEditWorldType.OWTYPE_GAMEMAKER_STUDIO_EDIT) then
		return false
	end

	local lfileinfos = {}

	for i = 0, files:size() - 1 do
		local info = {
			file = files[i],
			treeid = trees[i]
		}

		table.insert(lfileinfos, info)
	end

	local btree = G_Manager.BTManager:AIEditCreateInstanceByFiles(id, defid, lfileinfos, btreeptr)

	if not btree then
		return false
	end

	return true
end

function BehaviorTreeReleaseBTree(btreeid)
	local btree = G_Manager.BTManager:GetInstance(btreeid)
	local actorObjId = btree and btree.GetObjId and btree:GetObjId()

	BTClearSummonMessageTree(btreeid, actorObjId)
	G_Manager.BTManager:DestroyInstance(btreeid)

	if not _BTGetValueManage then
		_BTGetValueManage = GetInst("BTGetValueManage")
	end

	_BTGetValueManage:ReleaseFun(btreeid)
	GetInst("BTEventManager"):ClearTreeEventParam(btreeid)
	BTClearControllerCache(btreeid)
end

function ClearBTreeBlackboardCache(btreeid)
	local btree = G_Manager.BTManager:GetInstance(btreeid)

	GetInst("BTEventManager"):ClearTreeEventParam(btreeid)

	if btree then
		local bb = btree:GetBlackboard()

		if bb then
			bb:ClearCache()
		end
	end
end

function BehaviorTreeCreateTask(id, taskname, nodeptr)
	if IsOpenBtTreeDebug and IsOpenBtTreeDebug() and regtasklist and not regtasklist[taskname] then
		print("BT ERROR : not found in _BTTaskReg_.lua! taskname=" .. tostring(taskname))

		return false
	end

	return G_Manager.BTTaskMgr:CreateInstance(id, taskname, nodeptr) ~= nil
end

function BehaviorTreeCreateTaskByTemp(treeid, nodeid, tid, id, nodeptr)
	local tempnode = BehaviorTree_GetTempNode(treeid, nodeid)

	if not tempnode then
		return
	end

	if next(tempnode.getvals) ~= nil then
		if not _BTGetValueManage then
			_BTGetValueManage = GetInst("BTGetValueManage")
		end

		for key, value in pairs(tempnode.getvals) do
			local fid = _BTGetValueManage:Regfun(tid, value.func)
			local nodeinfo = {
				funid = fid,
				paramtype = value.paramtype,
				valtype = value.valtype
			}

			nodeptr:addGetValueNode(key, cjson.encode(nodeinfo))
		end
	end

	local ressult = BehaviorTreeCreateTask(id, tempnode.script, nodeptr)

	if not tempnode.subparam then
		return
	end

	if tempnode.script == "UGCTask_EventBeMsg" then
		local param1 = tempnode.subparam[1]

		if param1 and type(param1.val) == "string" and param1.val ~= "" then
			local eventName = param1.val

			GameVM.ScriptSupportEvent:addAICustomEventFunc(eventName, function (event)
				BTAddMsg(eventName, event)
			end)
		end
	end

	if tempnode.script == "UGCTask_EventReceiveSummonMsg" then
		local param1 = type(tempnode.subparam) == "table" and tempnode.subparam[1]
		local btree = G_Manager.BTManager:GetInstance(tid)

		if btree and btree.RegSummonMessageEvent and param1 then
			btree:RegSummonMessageEvent(param1, nodeptr)
		end
	end

	local btree = G_Manager.BTManager:GetInstance(tid)

	if btree then
		btree:regTriginfo(tempnode.script, nodeptr)
	end

	BehaviorTreeTaskSetSubparam(id, tempnode.subparam)
end

function BehaviorTreeTaskSetSubparam(id, subparam)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if task then
		task:SetSubparam(subparam)
	end
end

function BehaviorTreeDestroyTask(id)
	G_Manager.BTTaskMgr:DestroyInstance(id)
end

function BehaviorTreeBeginTask(id, btreeid)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if not task then
		return
	end

	local btree = G_Manager.BTManager:GetInstance(btreeid)

	if btree then
		task:Begin(btree)
	end
end

function BehaviorTreeEndTask(id)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if task then
		task:End()
	end
end

function BehaviorTreeExecTask(id)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if not task then
		return BTEnum.BTNODERESULT.FAIL
	end

	return task:Run()
end

function BehaviorTreeTaskClearState(id)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if task then
		task:ClearState()
	end
end

function BehaviorTreeOneRun(id, btreeid)
	return BehaviorTreeUpdateState(id, btreeid)
end

local function _ExecuteTaskWithTree(task, btree, eventData)
	if eventData ~= nil then
		task:SetEventData(eventData)
	end

	task:Begin(btree)

	local result = task:Run()

	task:End()

	return result
end

function BehaviorTreeUpdateState(id, btreeid)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if not task then
		return BTEnum.BTNODERESULT.FAIL
	end

	local btree = G_Manager.BTManager:GetInstance(btreeid)

	if not btree then
		return BTEnum.BTNODERESULT.FAIL
	end

	return _ExecuteTaskWithTree(task, btree, nil)
end

function BehaviorTreeOneEventRun(id, btreeid, eventinfo)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if not task then
		return BTEnum.BTNODERESULT.FAIL
	end

	local btree = G_Manager.BTManager:GetInstance(btreeid)

	if not btree then
		return BTEnum.BTNODERESULT.FAIL
	end

	local param = _G.observer_event_table(eventinfo)

	return _ExecuteTaskWithTree(task, btree, param)
end

local cjson = require("cjson")

function BehaviorTreeAINPCOneEventRun(id, btreeid, info)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if not task then
		return BTEnum.BTNODERESULT.FAIL
	end

	local btree = G_Manager.BTManager:GetInstance(btreeid)

	if not btree then
		return BTEnum.BTNODERESULT.FAIL
	end

	local param = cjson.decode(info)

	return _ExecuteTaskWithTree(task, btree, param)
end

function BehaviorTreeLuaOneEventRun(id, btreeid, node, event)
	local task = G_Manager.BTTaskMgr:GetInstance(id)
	local result = BTEnum.BTNODERESULT.FAIL

	if task then
		local btree = G_Manager.BTManager:GetInstance(btreeid)

		if btree and btree.this and btree.this:GetTarget() then
			result = _ExecuteTaskWithTree(task, btree, event)
		else
			return
		end
	end

	if node then
		node:setEventRunResult(result)
	end
end

function BehaviorTreeTaskSendDada(id)
	local task = G_Manager.BTTaskMgr:GetInstance(id)

	if task then
		return task:SendDataToDebug()
	end
end

function BehaviorTreeLoadBlackboard(id, btscript, blackboard)
	local filename = GetBlackboardConfig(btscript)

	if not filename then
		return false
	end

	local bb = G_Manager.BBManager:CreateInstance(id, filename, blackboard)

	if not bb then
		return false
	end

	local initFuncName = "InitBlackboard_" .. btscript
	local initFunc = _G[initFuncName]

	if initFunc then
		initFunc(bb)
	end

	return true
end

function BehaviorTreeLoadBlackboardByText(id, text, blackboard)
	local bb, errorMsg = G_Manager.BBManager:CreateInstanceByText(id, text, blackboard)

	if not bb then
		return false, errorMsg
	end

	return true, ""
end

function AIEditBehaviorTreeLoadBlackboard(id, defid, btscript, treeid, blackboard)
	local bb = G_Manager.BBManager:AIEditCreateInstance(id, defid, btscript, treeid, blackboard)

	if not bb then
		return false
	end

	return true
end

function AIEditBehaviorTreeLoadBlackboardByFiles(id, defid, files, trees, blackboard)
	local lfiles = {}

	for i = 0, files:size() - 1 do
		local info = {
			file = files[i],
			treeid = trees[i]
		}

		table.insert(lfiles, info)
	end

	local bb = G_Manager.BBManager:AIEditCreateInstanceByFiles(id, defid, lfiles, blackboard)

	if not bb then
		return false
	end

	return true
end

function BehaviorTreeReleaseBlackboard(id)
	G_Manager.BBManager:DestroyInstance(id)
end

function BehaviorTreeSetCacheBlackboard(id)
	local bb = G_Manager.BBManager:GetInstance(id)

	if bb then
		bb:SaveBBData()
	end
end

function BehaviorTreeBlackboardSetData(id, key, value)
	local bb = G_Manager.BBManager:GetInstance(id)

	if not bb then
		return false
	end

	return bb:SetData(key, value)
end

function BehaviorTreeBlackboardGetData(id, key)
	local bb = G_Manager.BBManager:GetInstance(id)

	if not bb then
		return nil
	end

	local result = bb:GetData(key)

	if type(result) == "table" and result.x and result.y and result.z then
		return {
			val = result
		}
	end

	return result
end

local function BTEncodeBool(luadata, value, isload, name)
	return luadata:SetValue_Bool(value ~= nil and value ~= false)
end

local function BTEncodeNumber(luadata, value, isload, name)
	return luadata:SetValue_Number(tonumber(value) or 0)
end

local function BTEncodeString(luadata, value, isload, name)
	return luadata:SetValue_String(type(value) == "string" and value or "")
end

local function BTEncodeVector3(luadata, value, isload, name)
	local x = 0
	local y = -1
	local z = 0

	if type(value) == "table" then
		x = tonumber(value.x) or 0
		y = tonumber(value.y) or -1
		z = tonumber(value.z) or 0
	end

	return luadata:SetValue_Vector3(x, y, z)
end

local function BTEncodeArrayNumber(luadata, value, isload, name)
	if type(value) ~= "table" or #value == 0 then
		luadata:SetValue_ArrayNumber(1)
		luadata:SetValue_ArrayNumber_ByIndex(0, 0)

		return true
	end

	local size = luadata:SetValue_ArrayNumber(#value)

	if not size then
		luadata:SetValue_ArrayNumber(1)
		luadata:SetValue_ArrayNumber_ByIndex(0, 0)

		return true
	end

	for i = 1, size do
		luadata:SetValue_ArrayNumber_ByIndex(i - 1, tonumber(value[i]) or 0)
	end

	return true
end

local function BTEncodeObject(luadata, value, isload, name)
	local objid = 0
	local vtype = type(value)

	if vtype == "table" then
		objid = tonumber(value.actor) or 0
	elseif vtype == "number" then
		objid = value
	end

	return luadata:SetValue_Object(objid)
end

local function BTEncodeItem(luadata, value, isload, name)
	local itemid = 0
	local num = 1
	local isgroup = false

	if type(value) == "table" then
		itemid = tonumber(value.itemid) or 0
		num = tonumber(value.num) or 1
		isgroup = value.isgroup ~= nil and value.isgroup and true or false
	end

	return luadata:SetValue_Item(itemid, num, isgroup)
end

local function BTEncodeArrayItem(luadata, value, isload, name)
	if type(value) ~= "table" or #value == 0 then
		luadata:SetValue_ArrayItem(1)
		luadata:SetValue_ArrayItem_ByIndex(0, 0, 0, false)

		return true
	end

	local size = luadata:SetValue_ArrayItem(#value)

	if not size then
		luadata:SetValue_ArrayItem(1)
		luadata:SetValue_ArrayItem_ByIndex(0, 0, 0, false)

		return true
	end

	for i = 1, size do
		local v = value[i]
		local itemid = 0
		local num = 1
		local isgroup = false
		local vtype = type(v)

		if vtype == "table" then
			itemid = tonumber(v.itemid) or 0
			num = tonumber(v.num) or 1
			isgroup = v.isgroup ~= nil and v.isgroup and true or false
		elseif vtype == "number" then
			itemid = v
		end

		luadata:SetValue_ArrayItem_ByIndex(i - 1, itemid, num, isgroup)
	end

	return true
end

local function BTEncodeArrayObject(luadata, value, isload, name)
	if type(value) ~= "table" or #value == 0 then
		luadata:SetValue_ArrayObject(1)
		luadata:SetValue_ArrayObject_ByIndex(0, 0)

		return true
	end

	local size = luadata:SetValue_ArrayObject(#value)

	if not size then
		luadata:SetValue_ArrayObject(1)
		luadata:SetValue_ArrayObject_ByIndex(0, 0)

		return true
	end

	for i = 1, size do
		local v = value[i]
		local objid = 0
		local vtype = type(v)

		if vtype == "table" then
			objid = tonumber(v.objid) or 0
		elseif vtype == "number" then
			objid = v
		end

		luadata:SetValue_ArrayObject_ByIndex(i - 1, objid)
	end

	return true
end

local function BTEncodeArrayString(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			local objid = v or ""
			arr[k] = objid
		end
	end

	local size = luadata:SetValue_ArrayString(#arr)
	local result = false

	if size and size > 0 then
		for i = 1, size do
			if type(arr[i]) ~= "string" then
				local k = 9
			end

			luadata:SetValue_ArrayString_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		luadata:SetValue_ArrayString(1)
		luadata:SetValue_ArrayString_ByIndex(0, "")

		result = true
	end

	return result
end

local function BTEncodePlayer(luadata, value, isload, name)
	local uin = 0

	if type(value) == "table" then
		if value.actor then
			uin = value.actor
		elseif value.uin then
			uin = value.uin
		end
	elseif type(value) == "number" then
		uin = value or 0
	end

	return luadata:SetValue_Player(uin)
end

local function BTEncodeArrayPlayer(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			local objid = v.uin or 0
			arr[k] = objid
		end
	end

	local size = luadata:SetValue_ArrayPlayer(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayPlayer_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayPlayer(1)
		luadata:SetValue_ArrayPlayer_ByIndex(0, 0)
	end

	return result
end

local function BTEncodeArrayVector3(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			local x = 0
			local y = 0
			local z = 0
			x = tonumber(v.x) or x
			y = tonumber(v.y) or y
			z = tonumber(v.z) or z
			arr[k] = {
				x = x,
				y = y,
				z = z
			}
		end

		local size = luadata:SetValue_ArrayVector3(#arr)

		if size then
			for i = 1, size do
				luadata:SetValue_ArrayVector3_ByIndex(i - 1, arr[i].x, arr[i].y, arr[i].z)
			end
		end
	else
		local size = luadata:SetValue_ArrayVector3(1)

		luadata:SetValue_ArrayVector3_ByIndex(0, 0, 0, 0)
	end

	return true
end

local function BTEncodeArea(luadata, value, isload, name)
	local areaid = 0

	if type(value) == "table" then
		if value.areaid then
			areaid = value.areaid or 0
		end
	elseif type(value) == "number" then
		areaid = value
	end

	return luadata:SetValue_Area(areaid)
end

local function BTEncodeArrayArea(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			local areaid = 0

			if v.areaid then
				areaid = v.areaid
			end

			arr[k] = areaid
		end
	end

	local size = luadata:SetValue_ArrayArea(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayArea_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		luadata:SetValue_ArrayArea(1)
		luadata:SetValue_ArrayArea_ByIndex(0, 0)

		result = true
	end

	return result
end

local function BTEncodeArrayBool(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			arr[k] = v or false
		end
	end

	local size = luadata:SetValue_ArrayBool(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayBool_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayBool(1)
		luadata:SetValue_ArrayBool_ByIndex(0, false)
	end

	return true
end

local function BTEncodeActorType(luadata, value, isload, name)
	local typeid = 0

	if type(value) == "table" and value.actorid then
		typeid = tonumber(value.actorid)
	elseif type(value) == "number" then
		typeid = value
	elseif type(value) == "string" then
		typeid = Service.Mod:GetCfgIdByAssetId(value) or 0
	end

	return luadata:SetValue_ActorType(typeid)
end

local function BTEncodeBlockType(luadata, value, isload, name)
	local typeid = 0

	if type(value) == "table" and value.blockid then
		typeid = tonumber(value.blockid)
	elseif type(value) == "number" then
		typeid = value
	elseif type(value) == "string" then
		typeid = Service.Mod:GetCfgIdByAssetId(value) or 0
	end

	return luadata:SetValue_BlockType(typeid)
end

local function BTEncodeItemType(luadata, value, isload, name)
	local typeid = 0

	if type(value) == "table" and value.itemid then
		typeid = tonumber(value.itemid)
	elseif type(value) == "number" then
		typeid = value
	elseif type(value) == "string" then
		typeid = Service.Mod:GetCfgIdByAssetId(value) or 0
	end

	return luadata:SetValue_ItemType(typeid)
end

local function BTEncodeEffectType(luadata, value, isload, name)
	local typeid = 0

	if type(value) == "table" and value.effectid then
		typeid = tonumber(value.effectid)
	elseif type(value) == "number" then
		typeid = value
	end

	return luadata:SetValue_EffectType(typeid)
end

local function BTEncodeArrayActorType(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			if type(v) == "number" then
				arr[k] = v
			elseif type(v) == "table" and v.actorid then
				arr[k] = v.actorid or 0
			elseif type(v) == "string" then
				arr[k] = Service.Mod:GetCfgIdByAssetId(v) or 0
			end
		end
	end

	local size = luadata:SetValue_ArrayActorType(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayType_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayActorType(1)
		luadata:SetValue_ArrayType_ByIndex(0, 0)
	end

	return result
end

local function BTEncodeArrayBlockType(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			if type(v) == "number" then
				arr[k] = v
			elseif type(v) == "table" and v.blockid then
				arr[k] = v.blockid or 0
			elseif type(v) == "string" then
				arr[k] = Service.Mod:GetCfgIdByAssetId(v) or 0
			end
		end
	end

	local size = luadata:SetValue_ArrayBlockType(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayType_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayBlockType(1)
		luadata:SetValue_ArrayType_ByIndex(0, 0)
	end

	return result
end

local function BTEncodeArrayItemType(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			if type(v) == "number" then
				arr[k] = v
			elseif type(v) == "table" and v.itemid then
				arr[k] = v.itemid or 0
			elseif type(v) == "string" then
				arr[k] = Service.Mod:GetCfgIdByAssetId(v) or 0
			end
		end
	end

	local size = luadata:SetValue_ArrayItemType(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayType_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayItemType(1)
		luadata:SetValue_ArrayType_ByIndex(0, 0)
	end

	return result
end

local function BTEncodeArrayEffectType(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			if type(v) == "number" then
				arr[k] = v
			elseif type(v) == "table" and v.effectid then
				arr[k] = v.effectid or 0
			end
		end
	end

	local size = luadata:SetValue_ArrayEffectType(#arr)
	local result = false

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayType_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayEffectType(1)
		luadata:SetValue_ArrayType_ByIndex(0, 0)
	end

	return result
end

local function BTEncodeTimer(luadata, value, isload, name)
	local timerid = nil

	if value and type(value) == "table" and value.timerid then
		timerid = tonumber(value.timerid)
	elseif type(value) == "number" then
		timerid = value
	else
		timerid = 0

		if isload and name then
			timerid = BTService:CreateTimer(name) or 0
		end
	end

	return luadata:SetValue_Timer(timerid)
end

local function BTEncodeArrayTimer(luadata, value, isload, name)
	local arr = {}

	if type(value) == "table" then
		for k, v in ipairs(value) do
			if type(v) == "number" then
				arr[k] = v
			elseif type(v) == "table" and v.timerid then
				arr[k] = v.timerid or 0
			end
		end
	end

	local result = false
	local size = luadata:SetValue_ArrayTimer(#arr)

	if size then
		for i = 1, size do
			luadata:SetValue_ArrayTimer_ByIndex(i - 1, arr[i])
		end

		result = true
	else
		result = true

		luadata:SetValue_ArrayTimer(1)
		luadata:SetValue_ArrayTimer_ByIndex(0, 0)
	end

	return result
end

local BTEncodeFuns = {
	[BTLuaDataType_Bool] = BTEncodeBool,
	[BTLuaDataType_Number] = BTEncodeNumber,
	[BTLuaDataType_String] = BTEncodeString,
	[BTLuaDataType_Vector3] = BTEncodeVector3,
	[BTLuaDataType_ArrayNumber] = BTEncodeArrayNumber,
	[BTLuaDataType_Object] = BTEncodeObject,
	[BTLuaDataType_Item] = BTEncodeItem,
	[BTLuaDataType_ArrayItem] = BTEncodeArrayItem,
	[BTLuaDataType_ArrayObject] = BTEncodeArrayObject,
	[BTLuaDataType_ArrayString] = BTEncodeArrayString,
	[BTLuaDataType_Player] = BTEncodePlayer,
	[BTLuaDataType_ArrayPlayer] = BTEncodeArrayPlayer,
	[BTLuaDataType_ArrayVector3] = BTEncodeArrayVector3,
	[BTLuaDataType_Area] = BTEncodeArea,
	[BTLuaDataType_ArrayArea] = BTEncodeArrayArea,
	[BTLuaDataType_ArrayBool] = BTEncodeArrayBool,
	[BTLuaDataType_ActorType] = BTEncodeActorType,
	[BTLuaDataType_ArrayActorType] = BTEncodeArrayActorType,
	[BTLuaDataType_BlockType] = BTEncodeBlockType,
	[BTLuaDataType_ArrayBlockType] = BTEncodeArrayBlockType,
	[BTLuaDataType_ItemType] = BTEncodeItemType,
	[BTLuaDataType_ArrayItemType] = BTEncodeArrayItemType,
	[BTLuaDataType_EffectType] = BTEncodeEffectType,
	[BTLuaDataType_ArrayEffectType] = BTEncodeArrayEffectType,
	[BTLuaDataType_Timer] = BTEncodeTimer,
	[BTLuaDataType_ArrayTimer] = BTEncodeArrayTimer
}

function BTDataEncodeLuaData(luadata, valtype, value, isload, name)
	if not luadata then
		if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
			print("BT ERROR! BTDataEncodeLuaData: luadata is nil")
		end

		return false
	end

	local fun = BTEncodeFuns[valtype]

	if not fun then
		if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
			print("BT ERROR! BTDataEncodeLuaData invalid valtype=" .. tostring(valtype) .. ", value=", value)
		end

		return false
	end

	local ok = fun(luadata, value, isload, name)

	if not ok and IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
		print("BT ERROR! BTDataEncodeLuaData encode failed, valtype=" .. tostring(valtype) .. ", value=", value)
	end

	return ok
end

local function BTDecodeBool(luadata, info)
	info.data = luadata:GetValue_Bool()
	info.strtype = "val"

	return true
end

local function BTDecodeNumber(luadata, info)
	info.data = luadata:GetValue_Number()
	info.strtype = "val"

	return true
end

local function BTDecodeString(luadata, info)
	info.data = luadata:GetValue_String()
	info.strtype = "val"

	return true
end

local function BTDecodeVector3(luadata, info)
	local result, x, y, z = luadata:GetValue_Vector3(0, 0, 0)

	if result then
		info.data = {
			x = x,
			y = y,
			z = z
		}
		result = true
		info.strtype = "pos"
	end

	return result
end

local function BTDecodeArrayNumber(luadata, info)
	local arr = luadata:GetValue_ArrNumber()
	local result = false

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			info.data[i] = luadata:GetValue_ArrayNumber_ByIndex(i - 1) or 0
		end

		result = true
		info.strtype = "valarray"
	end

	return result
end

local function BTDecodeObject(luadata, info)
	local result, obj = luadata:GetValue_Object(0)
	local result = false

	if obj then
		info.data = {
			actor = obj
		}
		result = true
		info.strtype = "actor"
	end

	return result
end

local function BTDecodeItem(luadata, info)
	local result, itemid, num, isgroup = luadata:GetValue_Item(0, 0, 0)

	if result then
		info.data = {
			itemid = itemid,
			num = num,
			isgroup = isgroup
		}
		result = true
		info.strtype = "item"
	end

	return result
end

local function BTDecodeArrayItem(luadata, info)
	local arr = luadata:GetValue_ArrItem()
	local result = false

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local iteminfo = luadata:GetValue_ArrayItem_ByIndex(i - 1)
			local itemid = iteminfo and iteminfo._itemid or 0
			local num = iteminfo and iteminfo._num or 1
			local isgroup = iteminfo and iteminfo._isgroup and true or false
			info.data[i] = {
				itemid = itemid,
				num = num,
				isgroup = isgroup
			}
		end

		info.strtype = "itemarray"
		result = true
	end

	return result
end

local function BTDecodeArrObject(luadata, info)
	local arr = luadata:GetValue_ArrObject()
	local result = false

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local objinfo = luadata:GetValue_ArrayObject_ByIndex(i - 1)
			local objid = objinfo and objinfo._objid or 0
			info.data[i] = {
				objid = objid
			}
		end

		info.strtype = "actorarray"
		result = true
	end

	return result
end

local function BTDecodeArrayPlayer(luadata, info)
	local arr = luadata:GetValue_ArrPlayer()
	local result = false

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local objinfo = luadata:GetValue_ArrayPlayer_ByIndex(i - 1)
			local uin = objinfo and objinfo._uin or 0
			info.data[i] = {
				uin = uin
			}
		end

		info.strtype = "playerarray"
		result = true
	end

	return result
end

local function BTDecodeArrayString(luadata, info)
	local result = false

	if luadata.Get_ArrStringSize then
		local num = luadata:Get_ArrStringSize()
		info.data = {}

		for i = 1, num do
			local objinfo = luadata:Get_ArrStringByIndex(i - 1)
			objinfo = objinfo or ""
			info.data[i] = objinfo
		end

		result = true
	else
		local arr = luadata:GetValue_ArrString()

		if arr then
			local size = arr._size
			info.data = {}

			for i = 1, size do
				local objinfo = nil

				if arr._arr[i - 1] then
					if arr._arr[i - 1]._str then
						objinfo = arr._arr[i - 1]._str
					else
						objinfo = arr._arr[i - 1]
					end
				else
					objinfo = ""
				end

				info.data[i] = objinfo
			end

			result = true
			info.strtype = "valarray"
		end
	end

	return result
end

local function BTDecodePlayer(luadata, info)
	local result, uin = luadata:GetValue_Player(0)

	if result then
		info.data = {
			uin = uin
		}
		result = true
		info.strtype = "player"
	end

	return result
end

local function BTDecodeArrayVector3(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrVecror3()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local vectorinfo = luadata:GetValue_ArrayVector3_ByIndex(i - 1)
			info.data[i] = {
				x = vectorinfo._x,
				y = vectorinfo._y,
				z = vectorinfo._z
			}
		end

		info.strtype = "posarray"
		result = true
	end

	return result
end

local function BTDecodeArea(luadata, info)
	local result = false
	local area = luadata:GetValue_Area()

	if area then
		info.data = {
			areaid = area._areaid
		}
		info.strtype = "area"
		result = true
	end

	return result
end

local function BTDecodeArrayArea(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayArea()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local areainfo = luadata:GetValue_ArrayArea_ByIndex(i - 1)
			info.data[i] = {
				areaid = areainfo._areaid
			}
		end

		info.strtype = "areaarray"
		result = true
	end

	return result
end

local function BTDecodeArrayBool(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayBool()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			info.data[i] = luadata:GetValue_ArrayBool_ByIndex(i - 1)
		end

		result = true
		info.strtype = "valarray"
	end

	return result
end

local function BTDecodeActorType(luadata, info)
	local result = false
	local typeinfo = luadata:GetValue_Type()

	if typeinfo then
		local id = typeinfo._type
		local resid = Service.Mod:GetAssetIdByCfg(ObjType.Mob, id)

		if resid and type(resid) == "string" and resid ~= "" then
			id = resid
		end

		info.data = {
			actorid = id
		}
		result = true
		info.strtype = "actortype"
	end

	return result
end

local function BTDecodeBlockType(luadata, info)
	local result = false
	local typeinfo = luadata:GetValue_Type()

	if typeinfo then
		local id = typeinfo._type
		local resid = Service.Mod:GetAssetIdByCfg(ObjType.Block, id)

		if resid and type(resid) == "string" and resid ~= "" then
			id = resid
		end

		info.data = {
			blockid = id
		}
		result = true
		info.strtype = "blocktype"
	end

	return result
end

local function BTDecodeItemType(luadata, info)
	local result = false
	local typeinfo = luadata:GetValue_Type()

	if typeinfo then
		local id = typeinfo._type
		local resid = Service.Mod:GetAssetIdByCfg(ObjType.Item, id)

		if resid and type(resid) == "string" and resid ~= "" then
			id = resid
		end

		info.data = {
			itemid = id
		}
		result = true
		info.strtype = "itemtype"
	end

	return result
end

local function BTDecodeEffectType(luadata, info)
	local result = false
	local typeinfo = luadata:GetValue_Type()

	if typeinfo then
		info.data = {
			effectid = typeinfo._type
		}
		result = true
		info.strtype = "effecttype"
	end

	return result
end

local function BTDecodeArrayActorType(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayType()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local id = luadata:GetValue_ArrayType_ByIndex(i - 1)._type
			local resid = Service.Mod:GetAssetIdByCfg(ObjType.Mob, id)

			if resid and resid ~= "" then
				id = resid
			end

			info.data[i] = {
				actorid = id
			}
		end

		result = true
		info.strtype = "array"
	end

	return result
end

local function BTDecodeArrayBlockType(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayType()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local id = luadata:GetValue_ArrayType_ByIndex(i - 1)._type
			local resid = Service.Mod:GetAssetIdByCfg(ObjType.Block, id)

			if resid and type(resid) == "string" and resid ~= "" then
				id = resid
			end

			info.data[i] = {
				blockid = id
			}
		end

		result = true
		info.strtype = "array"
	end

	return result
end

local function BTDecodeArrayItemType(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayType()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			local id = luadata:GetValue_ArrayType_ByIndex(i - 1)._type
			local resid = Service.Mod:GetAssetIdByCfg(ObjType.Item, id)

			if resid and type(resid) == "string" and resid ~= "" then
				id = resid
			end

			info.data[i] = {
				itemid = id
			}
		end

		result = true
		info.strtype = "array"
	end

	return result
end

local function BTDecodeArrayEffectType(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayType()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			info.data[i] = {
				effectid = luadata:GetValue_ArrayType_ByIndex(i - 1)._type
			}
		end

		result = true
		info.strtype = "array"
	end

	return result
end

local function BTDecodeTimer(luadata, info)
	local result = false
	local timer = luadata:GetValue_Timer()

	if timer then
		info.data = {
			timerid = timer._timerid
		}
		result = true
		info.strtype = "timer"
	end

	return result
end

local function BTDecodeArrayTimer(luadata, info)
	local result = false
	local arr = luadata:GetValue_ArrayTimer()

	if arr then
		local size = arr._size
		info.data = {}

		for i = 1, size do
			info.data[i] = {
				timerid = luadata:GetValue_ArrayTimer_ByIndex(i - 1)._timerid
			}
		end

		result = true
		info.strtype = "timerarray"
	end

	return result
end

local BTDecodeFuns = {
	[BTLuaDataType_Bool] = BTDecodeBool,
	[BTLuaDataType_Number] = BTDecodeNumber,
	[BTLuaDataType_String] = BTDecodeString,
	[BTLuaDataType_Vector3] = BTDecodeVector3,
	[BTLuaDataType_ArrayNumber] = BTDecodeArrayNumber,
	[BTLuaDataType_Object] = BTDecodeObject,
	[BTLuaDataType_Item] = BTDecodeItem,
	[BTLuaDataType_ArrayItem] = BTDecodeArrayItem,
	[BTLuaDataType_ArrayObject] = BTDecodeArrObject,
	[BTLuaDataType_ArrayString] = BTDecodeArrayString,
	[BTLuaDataType_Player] = BTDecodePlayer,
	[BTLuaDataType_ArrayPlayer] = BTDecodeArrayPlayer,
	[BTLuaDataType_ArrayVector3] = BTDecodeArrayVector3,
	[BTLuaDataType_Area] = BTDecodeArea,
	[BTLuaDataType_ArrayArea] = BTDecodeArrayArea,
	[BTLuaDataType_ArrayBool] = BTDecodeArrayBool,
	[BTLuaDataType_ActorType] = BTDecodeActorType,
	[BTLuaDataType_ArrayActorType] = BTDecodeArrayActorType,
	[BTLuaDataType_BlockType] = BTDecodeBlockType,
	[BTLuaDataType_ArrayBlockType] = BTDecodeArrayBlockType,
	[BTLuaDataType_ItemType] = BTDecodeItemType,
	[BTLuaDataType_ArrayItemType] = BTDecodeArrayItemType,
	[BTLuaDataType_EffectType] = BTDecodeEffectType,
	[BTLuaDataType_ArrayEffectType] = BTDecodeArrayEffectType,
	[BTLuaDataType_Timer] = BTDecodeTimer,
	[BTLuaDataType_ArrayTimer] = BTDecodeArrayTimer
}

function BTDataDecodeLuaData(luadata)
	if not luadata then
		return false, nil, ""
	end

	local valtype = luadata:GetType()

	if not valtype or valtype == BTLuaDataType_Idle then
		return false, nil, ""
	end

	local fun = BTDecodeFuns[valtype]

	if not fun then
		if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
			print("BT WARNING: Unknown decode valtype=" .. tostring(valtype))
		end

		return false, nil, ""
	end

	local info = _decodeInfoPool[#_decodeInfoPool]

	if info then
		_decodeInfoPool[#_decodeInfoPool] = nil
	else
		info = {}
	end

	local ok = fun(luadata, info)
	local data = info.data
	local strtype = info.strtype
	info.data = nil
	info.strtype = nil
	local poolSize = #_decodeInfoPool

	if poolSize < 50 then
		_decodeInfoPool[poolSize + 1] = info
	end

	return ok, data, strtype
end

local BTStrToType = {
	[AIDefine.ValueType.String] = BTLuaDataType_String,
	[AIDefine.ValueType.Number] = BTLuaDataType_Number,
	[AIDefine.ValueType.Boolean] = BTLuaDataType_Bool,
	[AIDefine.ValueType.Vector3] = BTLuaDataType_Vector3,
	[AIDefine.ValueType.Object] = BTLuaDataType_Object,
	[AIDefine.ValueType.Item] = BTLuaDataType_Item,
	[AIDefine.ValueType.ArrayNumber] = BTLuaDataType_ArrayNumber,
	[AIDefine.ValueType.ArrayItem] = BTLuaDataType_ArrayItem,
	[AIDefine.ValueType.ArrayObject] = BTLuaDataType_ArrayObject,
	[AIDefine.ValueType.ArrayString] = BTLuaDataType_ArrayString,
	[AIDefine.ValueType.Player] = BTLuaDataType_Player,
	[AIDefine.ValueType.ArrayPlayer] = BTLuaDataType_ArrayPlayer,
	[AIDefine.ValueType.ArrayVector3] = BTLuaDataType_ArrayVector3,
	[AIDefine.ValueType.Area] = BTLuaDataType_Area,
	[AIDefine.ValueType.ArrayArea] = BTLuaDataType_ArrayArea,
	[AIDefine.ValueType.ArrayBool] = BTLuaDataType_ArrayBool,
	[AIDefine.ValueType.ActorType] = BTLuaDataType_ActorType,
	[AIDefine.ValueType.ArrayActorType] = BTLuaDataType_ArrayActorType,
	[AIDefine.ValueType.BlockType] = BTLuaDataType_BlockType,
	[AIDefine.ValueType.ArrayBlockType] = BTLuaDataType_ArrayBlockType,
	[AIDefine.ValueType.ItemType] = BTLuaDataType_ItemType,
	[AIDefine.ValueType.ArrayItemType] = BTLuaDataType_ArrayItemType,
	[AIDefine.ValueType.EffectType] = BTLuaDataType_EffectType,
	[AIDefine.ValueType.ArrayEffectType] = BTLuaDataType_ArrayEffectType,
	[AIDefine.ValueType.Timer] = BTLuaDataType_Timer,
	[AIDefine.ValueType.ArrayTimer] = BTLuaDataType_ArrayTimer
}

function BTExecGetValue(code, param, treeid)
	local luadata = code:GetLuadata()

	if not luadata then
		return
	end

	local lparam = cjson.decode(param)

	if lparam == nil or lparam.funid == nil then
		return
	end

	if not _BTGetValueManage then
		_BTGetValueManage = GetInst("BTGetValueManage")
	end

	local fun = _BTGetValueManage:GetFun(treeid, lparam.funid)

	if not fun then
		return
	end

	local btree = G_Manager.BTManager:GetInstance(treeid)

	if not btree then
		return
	end

	local controller = BTExecGetController(btree, treeid)
	local result = fun({
		controller = controller
	})
	result = _BTGetValueManage:DealReesul(lparam.valtype, result)

	BTDataEncodeLuaData(luadata, BTStrToType[lparam.valtype], result)
end

function BTIsExitGetValueFun(param, treeid)
	local lparam = StrToTable(param)

	if not lparam.funid then
		return false
	end

	if not _BTGetValueManage then
		_BTGetValueManage = GetInst("BTGetValueManage")
	end

	local fun = _BTGetValueManage:GetFun(treeid, lparam.funid)

	return fun ~= nil
end

function BTClearControllerCache(treeid)
	if treeid and _controllerCache[treeid] then
		_controllerCache[treeid] = nil
		_controllerCacheSize = _controllerCacheSize - 1
	end
end

function BTExecGetController(btree, treeid)
	if not btree then
		return nil
	end

	local controller = treeid and _controllerCache[treeid]
	local blackboard = btree:GetBlackboard()
	local targetf = btree:GetTargetF()
	local luabb = btree:GetLuaBB()

	if controller then
		controller._blackboard = blackboard
		controller._targetf = targetf
		controller.luabb = luabb
		controller.treeid = treeid
	else
		controller = {
			_blackboard = blackboard,
			_targetf = targetf,
			luabb = luabb,
			treeid = treeid,
			bb = {
				set = function (key, data)
					return controller._blackboard and key and controller._blackboard:SetData(key, data)
				end,
				get = function (key)
					if type(key) ~= "string" then
						return key
					end

					return controller._blackboard and controller._blackboard:GetData(key)
				end,
				getGroupRandomValue = function (key)
					if controller._blackboard then
						return controller._blackboard:GetGroupRandomValue(key)
					end

					return false
				end,
				getGroupData = function (key, index)
					if controller._blackboard then
						return controller._blackboard:GetGroupDataByIndex(key, index)
					end

					return false
				end
			},
			target = {
				get = function (type)
					return controller._targetf and controller._targetf(type)
				end,
				getobjid = function (type)
					if controller._targetf then
						local obj = controller._targetf(type)

						if obj then
							return obj:getObjId()
						end
					end

					return 0
				end
			}
		}

		if treeid and not _controllerCache[treeid] and _controllerCacheSize < 100 then
			_controllerCache[treeid] = controller
			_controllerCacheSize = _controllerCacheSize + 1
		end
	end

	return BTSelectControllerForExternal(controller)
end

function BTGetAiID(actorDefID)
	if GetInst("AILibDBManager") then
		local str = GetInst("AILibDBManager"):GetActorBindedProjectUUID(actorDefID)

		if str == nil then
			str = ""
		end

		return str
	end

	return ""
end

function BTGetAiDir(uuid)
	if GetInst("AIEditorUIHelper") then
		return GetInst("AIEditorUIHelper"):GetCurMapExecutableTree(uuid)
	end

	return ""
end

function BTDebugBegainSendData()
	if GetInst("BTDebugDataManage") then
		return GetInst("BTDebugDataManage"):begainSendData()
	end

	return 0
end

function BTDebugAddValue(id, val)
	local ok, data, strtype = BTDataDecodeLuaData(val)

	if ok and GetInst("BTDebugDataManage") then
		GetInst("BTDebugDataManage"):addData(id, data, strtype)
	end
end

function BTDebugEndSendData(treeid, nodeid, id)
	if GetInst("BTDebugDataManage") then
		GetInst("BTDebugDataManage"):EndSendData(treeid, nodeid, id)
	end
end

function BTGetMsgValById(msgid, valid, treeid)
	return GetInst("BTEventManager"):GetEventParam(msgid, valid, treeid)
end

function BTAddMsg(msgid, param)
	GetInst("BTEventManager"):AddEvent(msgid, param)
end

function BTNewAddMsg(msgid, ...)
	local prams = {
		...
	}

	GetInst("BTEventManager"):AddEvent(msgid, prams)
end

function BTNewAddTeamActorBeHeatMsg(jsonarry)
	if jsonarry and jsonarry ~= "" then
		local info = cjson.toTable(jsonarry)

		if info then
			for i = 1, #info do
				if info[i] and info[i].id then
					BTAddMsg(info[i].id, info[i])
				end
			end
		end
	end
end

function InitTreeSendDada(treeid)
	local btree = G_Manager.BTManager:GetInstance(treeid)

	if btree then
		btree:InitSendDebugdata()
	end
end

function GetAreaRectRangeByAreaId(areaId)
	local code, posbeg, posend = BTService:GetSSObj("Area"):getAreaRectRange(areaId)

	if code == ErrorCode.OK then
		return posbeg.x, posbeg.y, posbeg.z, posend.x, posend.y, posend.z
	end

	return 0, 0, 0, 0, 0, 0
end

function GetBtreeDirByUUID(uuid)
	if GetInst("AIEditorUIHelper") then
		return GetInst("AIEditorUIHelper"):GetCurMapExecutableTree(uuid)
	end

	return ""
end

function BTActorChangeTree(btreeID, bindedBtUUID, actorObjID)
	if GetInst("AIEditorInterface") then
		GetInst("AIEditorInterface"):AIDebugChangeActorTree(btreeID, bindedBtUUID, actorObjID)
	end
end

function BTGetTreeList()
	local treeList = GetInst("AIEditorUIHelper"):GetRealAllAIProjectInPlugin()

	return treeList
end

function BTGetTreeNameByTreeid(treeid)
	local treelit = BTGetTreeList()

	if treelit then
		for index, value in ipairs(treelit) do
			if value.uuid == treeid then
				return value.Name
			end
		end
	end

	return ""
end

function BTIsCommandTree(treeid)
	if UGCGetInst("UGCMgr"):CurWorldIsTool3() then
		return true
	end

	return false
end

function BTGetTreeConfig(treeid, isCreate)
	if isCreate then
		local cfg = {
			treeid = {
				hide = true,
				type = ScriptParamType.String,
				default = treeid
			},
			isEnable = {
				default = true,
				hide = true,
				type = ScriptParamType.Bool
			}
		}

		return cfg, true
	end

	local dir = GetBtreeDirByUUID(treeid)
	local path = ""

	if string.len(dir) > 0 then
		path = dir .. "/bbconfig.lua"

		if not gFunc_isStdioFileExistFull(path) then
			local cfg = {
				treeid = {
					hide = true,
					type = ScriptParamType.String,
					default = treeid
				},
				isEnable = {
					default = true,
					hide = true,
					type = ScriptParamType.Bool
				}
			}

			return cfg, true
		end
	else
		return nil, false
	end

	local cfg = _G.BTBBConfighMgr:LoadAIEditConfig(path)

	if cfg then
		local result = {}

		if #cfg > 0 then
			for index, value in ipairs(cfg) do
				result[value.key] = value
			end

			if result.type then
				result.type = SceneTreeDefine:DataTypeToSPType(result.type)

				if result.type == ScriptParamType.Array then
					result.itemtype = SceneTreeDefine:DataTypeToSPType(result.itemtype)

					if type(result.default) == "table" then
						result.default = Mini.Array(ParamHelper.ParamEnumToType(result.itemtype), unpack(result.default))
					end
				end
			end
		else
			for k, value in pairs(cfg) do
				if value.type then
					value.type = SceneTreeDefine:DataTypeToSPType(value.type)

					if value.type == ScriptParamType.Array then
						value.itemType = SceneTreeDefine:DataTypeToSPType(value.itemType)

						if type(value.default) == "table" then
							value.default = Mini.Array(ParamHelper.ParamEnumToType(value.itemType), unpack(value.default))
						end
					end
				end
			end

			result = cfg
		end

		result.treeid = {
			hide = true,
			type = ScriptParamType.String,
			default = treeid
		}
		result.isEnable = {
			default = true,
			hide = true,
			type = ScriptParamType.Bool
		}

		return result, true
	end

	return nil, false
end

function BTGetBBConfig(treeid)
	local dir = GetBtreeDirByUUID(treeid)
	local path = ""

	if string.len(dir) > 0 then
		path = dir .. "/blackboard.lua"

		if not gFunc_isStdioFileExistFull(path) then
			return nil
		end
	else
		return nil
	end

	local cfg = _G.BTBBConfighMgr:LoadAIEditConfig(path)

	return cfg, false
end

function IsOfficalTree(uuid)
	local offpath = GetInst("AIEditorUIHelper"):GetOfficalAIPath()
	local codepath = offpath .. "/" .. uuid .. "/code"

	if gFunc_isStdioDirExist(codepath) then
		return true
	end

	return false
end

function GetOfficalDir()
	if GetInst("AIEditorUIHelper") and GetInst("AIEditorUIHelper").GetOfficalAIPath then
		local result = GetInst("AIEditorUIHelper"):GetOfficalAIPath()

		if result then
			return result
		end
	end

	return ""
end

function GMOpenDebugView()
	if GetInst("AIEditorInterface") then
		GetInst("AIEditorInterface"):GMOpenDebugView()
	end
end

function GMClosenDebugView()
	if GetInst("AIEditorInterface") then
		GetInst("AIEditorInterface"):GMClosenDebugView()
	end
end

function IsOpenBtTreeDebug()
	if not LuaInterface or not LuaInterface:isdebug() then
		return false
	end

	return false
end
