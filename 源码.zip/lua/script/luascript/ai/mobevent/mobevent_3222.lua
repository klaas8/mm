if not BTClass then
	assert(false)

	return
end

if not BTClass.MobEventBase then
	assert(false)

	return
end

local MobEventClass = BTClass:Class("MobEvent_3222", nil, BTClass.MobEventBase)

function MobEventClass:constructor(mobid, cppmob)
	BTClass.MobEventBase.constructor(self, mobid, cppmob)
end

function MobEventClass:destructor()
	BTClass.MobEventBase.destructor(self)
end

function MobEventClass:OnNewBeHurt(param)
	print("MobEvent (" .. tostring(self.mobid) .. ") -> override [OnNewBeHurt]")

	if param.toobjid and param.toobjid ~= 0 then
		if not CurWorld or not GetWorldActorMgr(CurWorld) then
			return
		end

		self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
			actor = param.toobjid
		})
		self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
			x = param.x,
			y = param.y,
			z = param.z
		})

		local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

		if isSleeping then
			AIFunctionMgr:setSleeping(self.cppmob, false)
			AIFunctionMgr:setFaceId(self.cppmob, 1)
		end

		local isSiting = AIFunctionMgr:getSitState(self.cppmob)

		if isSiting then
			AIFunctionMgr:setSitting(self.cppmob, false)
		end

		self.cppmob:ResetBTree()
	end
end

function MobEventClass:OnInteractEvent(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnInteractEvent]")

	local actor_e = {
		actor = param.itemnum
	}

	self:SetDataToBlackBoard("greeted_obj_id", actor_e)
	self.cppmob:ResetBTree()
end
