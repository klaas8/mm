if not BTClass then
	assert(false)

	return
end

if not BTClass.MobEventBase then
	assert(false)

	return
end

local MobEventClass = BTClass:Class("MobEvent_3915", nil, BTClass.MobEventBase)

function MobEventClass:constructor(mobid, cppmob)
	BTClass.MobEventBase.constructor(self, mobid, cppmob)
end

function MobEventClass:destructor()
	BTClass.MobEventBase.destructor(self)
end

function MobEventClass:OnNewBeHurt(param)
	print("MobEvent (" .. tostring(self.mobid) .. ") -> override [OnNewBeHurt]")

	if param.toobjid and param.toobjid ~= 0 then
		if not CurWorld or not GetWorldActorMgr(CurWorld) then
			return
		end

		local attackObj = GetWorldActorMgr(CurWorld):findActorByWID(param.toobjid)

		if not attackObj then
			return
		end

		local curEnemyId = self:GetDataFromBlackBoard("bbKeyBeHurtTargetObjId")
		local ok, subparam = pcall(JSON.decode, JSON, curEnemyId)

		if ok and type(subparam) == "table" then
			curEnemyId = subparam.actor

			if curEnemyId then
				if param.toobjid ~= curEnemyId and not GetWorldActorMgr(CurWorld):findActorByWID(curEnemyId) then
					self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
						actor = param.toobjid
					})
					self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
						x = param.x,
						y = param.y,
						z = param.z
					})
				end
			else
				self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
					actor = param.toobjid
				})
				self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
					x = param.x,
					y = param.y,
					z = param.z
				})
			end
		else
			self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
				actor = param.toobjid
			})
			self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
				x = param.x,
				y = param.y,
				z = param.z
			})
		end
	end

	local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

	if isSleeping then
		AIFunctionMgr:setSleeping(self.cppmob, false)
		AIFunctionMgr:stopEffect(self.cppmob, "mob_3402_1")
		AIFunctionMgr:setFaceId(self.cppmob, 1)
		self.cppmob:ResetBTree()
	end

	local isSiting = AIFunctionMgr:getSitState(self.cppmob)

	if isSiting then
		AIFunctionMgr:setSitting(self.cppmob, false)
		self.cppmob:ResetBTree()
	end
end

function MobEventClass:OnInteractEvent(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnInteractEvent]")
	self:SetDataToBlackBoard("InteractEvent", param.itemid + 1000)

	local actor_e = {
		actor = param.itemnum
	}

	self:SetDataToBlackBoard("greeted_obj_id", actor_e)
	self.cppmob:ResetBTree()
end

function MobEventClass:OnBeFed(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnBeFed]")
	self:SetDataToBlackBoard("BeFed", param.toolid)
	self.cppmob:ResetBTree()
end

function MobEventClass:OnBeGreetedBy(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnBeGreetedBy]")

	if AIFunctionMgr:isSleeping(self.cppmob) == true then
		print("self.cppmob is sleeping, stop greet event.-------------------")

		return
	end

	local actor_e = {
		actor = param.toobjid
	}

	self:SetDataToBlackBoard("greeted_obj_id", actor_e)

	local actorAct = GetInst("AIFunctionDefs"):GetAnimIDByPlayer(param.act)

	self:SetDataToBlackBoard("greeted_act_id", actorAct)
	self.cppmob:ResetBTree()
end

function MobEventClass:OnReqHelp(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnReqHelp]")

	local function updateBBData(param)
		self:SetDataToBlackBoard("enemy_id", {
			actor = param.toobjid
		})
		self:SetDataToBlackBoard("enemy_pos", {
			x = param.x,
			y = param.y,
			z = param.z
		})
		self:SetDataToBlackBoard("helper_id", {
			actor = param.helperobjid
		})
	end

	local curEnemyId = self:GetDataFromBlackBoard("enemy_id")
	local ok, subparam = pcall(JSON.decode, JSON, curEnemyId)

	if ok and type(subparam) == "table" then
		curEnemyId = subparam.actor

		if curEnemyId then
			if param.toobjid ~= curEnemyId and CurWorld and not GetWorldActorMgr(CurWorld):findMobByWID(curEnemyId) then
				updateBBData(param)
				self.cppmob:ResetBTree()
			end
		else
			updateBBData(param)
			self.cppmob:ResetBTree()
		end
	else
		updateBBData(param)
		self.cppmob:ResetBTree()
	end
end

function MobEventClass:OnPlaying(param)
	local bb_roundPlayer = self:GetDataFromBlackBoard("bb_roundPlayer")

	if bb_roundPlayer and bb_roundPlayer ~= 0 then
		return
	end

	local pos = self.cppmob:getPosition()

	if GetInst("MusicAdventurePlayer"):checkNearMusicPlayer(pos.x, pos.y, pos.z, param.toobjid) == false then
		return
	end

	local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

	if isSleeping then
		self:SetDataToBlackBoard("bb_roundPlayer", 100)
		self.cppmob:ResetBTree()
	else
		self:SetDataToBlackBoard("bb_roundPlayerID", param.toobjid)
		self:SetDataToBlackBoard("bb_roundPlayer", 1)
		self.cppmob:ResetBTree()
	end
end

function MobEventClass:OnStopPlaying(param)
	local bb_roundPlayerID = self:GetDataFromBlackBoard("bb_roundPlayerID")

	if bb_roundPlayerID == param.toobjid then
		self:SetDataToBlackBoard("bb_roundPlayerID", 0)
		self:SetDataToBlackBoard("bb_roundPlayer", 0)

		local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

		if not isSleeping then
			self.cppmob:ResetBTree()
		end
	end
end
