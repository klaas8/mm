if not BTClass then
	assert(false)

	return
end

local MobEventClass = BTClass:Class("MobEventBase")

function MobEventClass:constructor(mobid, cppmob)
	self.mobid = mobid
	self.cppmob = cppmob
end

function MobEventClass:destructor()
	self.cppmob = nil
end

function MobEventClass:SetDataToBlackBoard(key, value)
	local bbid = self.cppmob:GetBlackboardID()

	return BehaviorTreeBlackboardSetData(bbid, key, value)
end

function MobEventClass:GetDataFromBlackBoard(key)
	local bbid = self.cppmob:GetBlackboardID()

	return BehaviorTreeBlackboardGetData(bbid, key)
end
