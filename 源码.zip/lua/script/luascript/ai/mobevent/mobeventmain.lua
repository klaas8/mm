if not BTClass then
	assert(false)

	return
end

if not BTClass.MobEventMgr then
	assert(false)

	return
end

function CreateMobEventManager()
	_G.MobEventMgr = BTClass.MobEventMgr:new()
end

function DestroyMobEventManager()
	_G.MobEventMgr:delete()

	_G.MobEventMgr = nil
end

function LoadMobEvent(mobid, cppmob, cppmobevent)
	return _G.MobEventMgr:CreateMobEvent(mobid, cppmob, cppmobevent)
end

function ReleaseMobEvent(objid)
	if _G.MobEventMgr then
		_G.MobEventMgr:DestroyMobEvent(objid)
	end
end

function OnMobEvent(objid, eventname, obevent)
	return _G.MobEventMgr:OnMobEvent(objid, eventname, obevent)
end
