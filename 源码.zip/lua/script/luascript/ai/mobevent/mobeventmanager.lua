if not BTClass then
	assert(false)

	return
end

if not loadwwwcache then
	assert(false)

	return
end

local MobEventMgrClass = BTClass:Class("MobEventMgr")
MobEventMgrClass.cfgPath = "ai.mobevent."

function MobEventMgrClass:constructor()
	self.pool = {}
	self.cfgs = {}
end

function MobEventMgrClass:destructor()
	for k, v in pairs(self.pool) do
		if v then
			v:delete()
		end
	end

	self.pool = nil
	self.cfgs = nil
end

function MobEventMgrClass:CreateMobEvent(mobid, cppmob, cppmobevent)
	local objid = cppmob:getObjId()

	if objid == 0 then
		return false
	end

	local mobevent = nil
	local mobeventname = _G.MobEventConfig[mobid]

	if mobeventname and not BTClass[mobeventname] then
		self:LoadMobEventConfig(mobeventname)
	end

	if mobeventname and BTClass[mobeventname] then
		mobevent = BTClass[mobeventname]:new(mobid, cppmob)
	else
		mobevent = BTClass.MobEventBase:new(mobid, cppmob)
	end

	if not mobevent then
		return false
	end

	self.pool[objid] = mobevent

	self:RegMobAllEvents(mobevent, cppmobevent)

	return true
end

function MobEventMgrClass:DestroyMobEvent(objid)
	if not objid or objid == 0 then
		return
	end

	local mobevent = self.pool[objid]

	if mobevent then
		mobevent:delete()

		self.pool[objid] = nil
	end
end

function MobEventMgrClass:LoadMobEventConfig(filename)
	if type(filename) ~= "string" then
		return
	end

	local path = self.cfgPath .. filename

	loadwwwcache(path)
end

function MobEventMgrClass:RegMobAllEvents(mobevent, cppmobevent)
	for eventname, callbackname in pairs(MobEventCallbacks) do
		if mobevent[callbackname] then
			cppmobevent:RegEvent(eventname)
		end
	end
end

function MobEventMgrClass:OnMobEvent(objid, eventname, obevent)
	local mobevent = self.pool[objid]

	if not mobevent then
		return false
	end

	local funcname = MobEventCallbacks[eventname]

	if not funcname or not mobevent[funcname] then
		print("AE ERROR : on mob event failed! objid=" .. tostring(objid) .. ", eventname=" .. tostring(eventname))

		return false
	end

	local param = observer_event_table(obevent)

	if not param or not next(param) then
		return false
	end

	if param.eventobjid ~= objid then
		return true
	end

	mobevent[funcname](mobevent, param)

	return true
end
