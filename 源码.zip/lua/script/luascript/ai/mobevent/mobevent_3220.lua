if not BTClass then
	assert(false)

	return
end

if not BTClass.MobEventBase then
	assert(false)

	return
end

local MobEventClass = BTClass:Class("MobEvent_3220", nil, BTClass.MobEventBase)

function MobEventClass:constructor(mobid, cppmob)
	BTClass.MobEventBase.constructor(self, mobid, cppmob)
end

function MobEventClass:destructor()
	BTClass.MobEventBase.destructor(self)
end

function MobEventClass:OnNewBeHurt(param)
	print("MobEvent (" .. tostring(self.mobid) .. ") -> override [OnNewBeHurt]")

	if param.toobjid and param.toobjid ~= 0 then
		if not CurWorld or not GetWorldActorMgr(CurWorld) then
			return
		end

		self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
			actor = param.toobjid
		})
		self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
			x = param.x,
			y = param.y,
			z = param.z
		})

		local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

		if isSleeping then
			AIFunctionMgr:setSleeping(self.cppmob, false)
			AIFunctionMgr:setFaceId(self.cppmob, 1)
		end

		local isSiting = AIFunctionMgr:getSitState(self.cppmob)

		if isSiting then
			AIFunctionMgr:setSitting(self.cppmob, false)
		end

		self.cppmob:ResetBTree()
	end
end

function MobEventClass:OnReqHelp(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnReqHelp]")

	local function updateBBData(param)
		self:SetDataToBlackBoard("enemy_id", {
			actor = param.toobjid
		})
		self:SetDataToBlackBoard("enemy_pos", {
			x = param.x,
			y = param.y,
			z = param.z
		})
		self:SetDataToBlackBoard("helper_id", {
			actor = param.helperobjid
		})
	end

	local curEnemyId = self:GetDataFromBlackBoard("enemy_id")
	local ok, subparam = pcall(JSON.decode, JSON, curEnemyId)

	if ok and type(subparam) == "table" then
		curEnemyId = subparam.actor

		if curEnemyId then
			if param.toobjid ~= curEnemyId and CurWorld and not GetWorldActorMgr(CurWorld):findMobByWID(curEnemyId) then
				updateBBData(param)
			end
		else
			updateBBData(param)
		end
	else
		updateBBData(param)
	end

	local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

	if isSleeping then
		AIFunctionMgr:setSleeping(self.cppmob, false)
		AIFunctionMgr:setFaceId(self.cppmob, 1)
	end

	local isSiting = AIFunctionMgr:getSitState(self.cppmob)

	if isSiting then
		AIFunctionMgr:setSitting(self.cppmob, false)
	end

	self.cppmob:ResetBTree()
end
