if not BTClass then
	assert(false)

	return
end

if not BTClass.MobEventBase then
	assert(false)

	return
end

local MobEventClass = BTClass:Class("MobEvent_3208", nil, BTClass.MobEventBase)

function MobEventClass:constructor(mobid, cppmob)
	BTClass.MobEventBase.constructor(self, mobid, cppmob)
end

function MobEventClass:destructor()
	BTClass.MobEventBase.destructor(self)
end

function MobEventClass:OnNewBeHurt(param)
	print("MobEvent (" .. tostring(self.mobid) .. ") -> override [OnNewBeHurt]")

	if param.toobjid and param.toobjid ~= 0 then
		if not CurWorld or not GetWorldActorMgr(CurWorld) then
			return
		end

		local attackObj = GetWorldActorMgr(CurWorld):findActorByWID(param.toobjid)

		if not attackObj then
			return
		end

		local curEnemyId = self:GetDataFromBlackBoard("bbKeyBeHurtTargetObjId")
		local ok, subparam = pcall(JSON.decode, JSON, curEnemyId)

		if ok and type(subparam) == "table" then
			curEnemyId = subparam.actor

			if curEnemyId then
				if param.toobjid ~= curEnemyId and not GetWorldActorMgr(CurWorld):findActorByWID(curEnemyId) then
					self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
						actor = param.toobjid
					})
					self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
						x = param.x,
						y = param.y,
						z = param.z
					})
				end
			else
				self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
					actor = param.toobjid
				})
				self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
					x = param.x,
					y = param.y,
					z = param.z
				})
			end
		else
			self:SetDataToBlackBoard("bbKeyBeHurtTargetObjId", {
				actor = param.toobjid
			})
			self:SetDataToBlackBoard("bbKeyBeHurtTargetPos", {
				x = param.x,
				y = param.y,
				z = param.z
			})
		end
	end

	local isSleeping = AIFunctionMgr:isSleeping(self.cppmob)

	if isSleeping then
		AIFunctionMgr:setDesertVillagerSleeping(self.cppmob, false)
	end

	self.cppmob:ResetBTree()
end

function MobEventClass:OnBeGreetedBy(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnBeGreetedBy]")

	if AIFunctionMgr:isSleeping(self.cppmob) == true then
		print("self.cppmob is sleeping, stop greet event.-------------------")

		return
	end

	local actor_e = {
		actor = param.toobjid
	}

	if CurWorld then
		local player = GetWorldActorMgr(CurWorld):findPlayerByUin(param.toobjid)

		if player:getFollowByVillager() and AIFunctionMgr:getDesertGossipState(self.cppmob) == false then
			self:SetDataToBlackBoard("followstate", 1)
		end
	end

	self:SetDataToBlackBoard("followobjid", actor_e)
	self:SetDataToBlackBoard("greeted_obj_id", actor_e)

	local actorAct = GetInst("AIFunctionDefs"):GetAnimIDByPlayer(param.act)

	self:SetDataToBlackBoard("greeted_act_id", actorAct)
	self.cppmob:ResetBTree()
end

function MobEventClass:OnReqHelp(param)
	print("MobEvent (" .. tostring(param) .. ") -> override [OnReqHelp]")

	local function updateBBData(param)
		self:SetDataToBlackBoard("enemy_id", {
			actor = param.toobjid
		})
		self:SetDataToBlackBoard("enemy_pos", {
			x = param.x,
			y = param.y,
			z = param.z
		})
		self:SetDataToBlackBoard("helper_id", {
			actor = param.helperobjid
		})
	end

	local curEnemyId = self:GetDataFromBlackBoard("enemy_id")
	local ok, subparam = pcall(JSON.decode, JSON, curEnemyId)

	if ok and type(subparam) == "table" then
		curEnemyId = subparam.actor

		if curEnemyId then
			if param.toobjid ~= curEnemyId and CurWorld and not GetWorldActorMgr(CurWorld):findMobByWID(curEnemyId) then
				updateBBData(param)
			end
		else
			updateBBData(param)
		end
	else
		updateBBData(param)
	end

	self.cppmob:ResetBTree()
end
