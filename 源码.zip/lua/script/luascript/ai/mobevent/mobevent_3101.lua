if not BTClass then
	assert(false)

	return
end

if not BTClass.MobEventBase then
	assert(false)

	return
end

local _mobid_ = 3101
local MobEventClass = BTClass:Class("MobEvent_" .. tostring(_mobid_), nil, BTClass.MobEventBase)

function MobEventClass:constructor(mobid, cppmob)
	BTClass.MobEventBase.constructor(self, mobid, cppmob)
end

function MobEventClass:destructor()
	BTClass.MobEventBase.destructor(self)
end
