local BTDebugDataManage = ClassEx("BTDebugDataManage")
local instance = nil

function BTDebugDataManage:GetInst()
	if instance == nil then
		instance = ClassList.BTDebugDataManage.instance()
	end

	return instance
end

function BTDebugDataManage:Init()
	self.dataid = 0
	self.data = {}
end

function BTDebugDataManage:reset()
	self.dataid = 0
end

function BTDebugDataManage:begainSendData()
	if self.dataid >= 200000000 then
		self.dataid = 0
	end

	self.dataid = self.dataid + 1
	self.data[self.dataid] = {}

	return self.dataid
end

function BTDebugDataManage:addData(id, val, strtype)
	if self.data[id] ~= nil then
		local param = {
			valtype = strtype,
			val = val
		}

		table.insert(self.data[id], param)
	end
end

function BTDebugDataManage:DealSendToDebugData(data)
	local function actorfuncation(val)
		if CurWorld and CurWorld.getActorMgr and val.actor then
			local actormgr = GetCurWorldActorMgr()

			if actormgr then
				local name = ""
				local actor = actormgr:findActorByWID(val.actor)

				if actor then
					if actor:getObjType() == OBJ_TYPE_MONSTER then
						name = actor:getActorName()
					elseif actor:getObjType() == OBJ_TYPE_ROLE then
						name = actor:getNickname()
					elseif actor:getObjType() == OBJ_TYPE_DROPITEM then
						local itemobj = tolua.cast(actor, "ClientItem")

						if itemobj then
							local itemid = itemobj:getItemID()
							local info = DefMgr:getItemDef(itemid)

							if info then
								name = info.Name
							end
						end
					elseif actor:getObjType() == OBJ_TYPE_COBBLE or actor:getObjType() == OBJ_TYPE_THROWABLE or actor:getObjType() == OBJ_TYPE_HOOK or actor:getObjType() == OBJ_TYPE_LASER or actor:getObjType() == OBJ_TYPE_COCONUT_PRO or actor:getObjType() == OBJ_TYPE_FISHHOOK or actor:getObjType() == OBJ_TYPE_ARROW or actor:getObjType() == OBJ_TYPE_THORNBALL or actor:getObjType() == OBJ_TYPE_BLOCK_LASER or actor:getObjType() == OBJ_TYPE_VEHICLE then
						local projectile = tolua.cast(actor, "ClientActorProjectile")

						if projectile then
							local itemid = projectile:GetItemId()
							local info = DefMgr:getItemDef(itemid)

							if info then
								name = info.Name
							end
						end
					else
						name = actor:getActorName()
					end
				end

				return {
					valtype = "actor",
					val = {
						name = name,
						actor = val.actor
					}
				}
			end
		end

		return {}
	end

	local function valfuncation(val)
		return {
			valtype = "val",
			val = val
		}
	end

	local function posfuncation(val)
		return {
			valtype = "pos",
			val = val
		}
	end

	local function areafuncation(val)
		return {
			valtype = "area",
			val = val
		}
	end

	local function arrayfuncation(val)
		return {
			valtype = "array"
		}
	end

	local function itemfuncation(val)
		if DefMgr and DefMgr.getItemDef and val.itemid and val.num then
			if type(val.itemid) == "string" then
				val.itemid = Service.Mod:GetCfgIdByAssetId(val.itemid)
			end

			if val.itemid <= 0 then
				return {
					valtype = "item",
					val = {
						name = "",
						itemid = val.itemid,
						num = val.num
					}
				}
			end

			local itemdef = DefMgr:getItemDef(val.itemid)
			local name = ""

			if itemdef then
				name = itemdef.Name
			end

			return {
				valtype = "item",
				val = {
					name = name,
					itemid = val.itemid,
					num = val.num
				}
			}
		end

		return {}
	end

	local function playerfuncation(val)
		if CurWorld and CurWorld.getActorMgr and val.uin then
			local actormgr = GetCurWorldActorMgr()

			if actormgr then
				local palyer = actormgr:findPlayerByUin(val.uin)
				local name = ""

				if palyer then
					name = palyer:getNickname()
				end

				return {
					valtype = "player",
					val = {
						name = name,
						vuin = val.uin
					}
				}
			end
		end

		return {}
	end

	local function playersfuncation(val)
		if CurWorld and CurWorld.getActorMgr and val then
			local actormgr = GetCurWorldActorMgr()

			if actormgr then
				local name = ""

				for index = 1, #val do
					local uin = val[index]
					local palyer = actormgr:findPlayerByUin(uin)

					if palyer then
						if name ~= "" then
							name = name + ","
						end

						name = name + palyer:getNickname()
					end
				end

				return {
					valtype = "players",
					val = {
						name = name,
						vuins = val
					}
				}
			end
		end

		return {}
	end

	local function itemtypefuncation(val)
		if DefMgr and DefMgr.getItemDef and val.itemid then
			if type(val.itemid) == "string" then
				val.itemid = Service.Mod:GetCfgIdByAssetId(val.itemid)
			end

			if val.itemid <= 0 then
				return {
					valtype = "itemtype",
					val = {
						name = "",
						itemid = val.itemid
					}
				}
			end

			local itemdef = DefMgr:getItemDef(val.itemid)
			local name = ""

			if itemdef then
				name = itemdef.Name
			end

			return {
				valtype = "itemtype",
				val = {
					name = name,
					itemid = val.itemid
				}
			}
		end

		return {}
	end

	local function blocktypefuncation(val)
		if DefMgr and DefMgr.getBlockDef and val.blockid then
			local itemdef = DefMgr:getBlockDef(val.blockid)
			local name = ""

			if itemdef then
				name = itemdef.Name
			end

			return {
				valtype = "blocktype",
				val = {
					name = name,
					blockid = val.blockid
				}
			}
		end

		return {}
	end

	local function actortypefuncation(val)
		if DefMgr and DefMgr.getMonsterDef and val.actorid then
			local MonsterDef = DefMgr:getMonsterDef(val.actorid)
			local name = ""

			if MonsterDef then
				name = MonsterDef.Name
			end

			return {
				valtype = "actortype",
				val = {
					name = name,
					actorid = val.actorid
				}
			}
		end

		return {}
	end

	local function timerfuncation(val)
		return {
			valtype = "timer",
			val = val
		}
	end

	local function effecttypefuncation(val)
		if DefMgr and DefMgr.getParticleDef and val and val.effectid then
			local name = ""

			if type(val.effectid) == "number" then
				local itemdef = nil
				itemdef = DefMgr:getParticleDef(val.effectid)

				if itemdef then
					name = itemdef.Name
				end
			elseif type(val.effectid) == "string" then
				name = val.effectid
			end

			return {
				valtype = "effecttype",
				val = {
					name = name,
					effectid = val.effectid
				}
			}
		end

		return {}
	end

	local function arrayfuncation(val)
		return {
			valtype = "array"
		}
	end

	local function enumfuncation(val)
		return {
			valtype = "enum"
		}
	end

	local function objtypefuncation(val)
		if type(val) == "table" then
			local objid = val[2]
			local name = nil

			if val[1] == 730002 then
				local def = ModEditorMgr:getMonsterDefById(objid) or DefMgr:getMonsterDef(objid)

				if def then
					name = def.Name
				end
			elseif val[1] == 730003 then
				local itemdef = ModEditorMgr:getItemDefById(objid) or ModEditorMgr:getBlockItemDefById(objid) or DefMgr:getItemDef(objid)

				if itemdef and itemdef.Name then
					name = itemdef.Name
				end
			end

			return {
				valtype = "val",
				val = name
			}
		elseif type(val) == "string" then
			return {
				valtype = "enum"
			}
		end

		return {
			valtype = "val",
			val = val
		}
	end

	local funtable = {
		actor = actorfuncation,
		valfuncation = valfuncation,
		pos = posfuncation,
		area = areafuncation,
		array = arrayfuncation,
		item = itemfuncation,
		player = playerfuncation,
		players = playersfuncation,
		itemtype = itemtypefuncation,
		blocktype = blocktypefuncation,
		actortype = actortypefuncation,
		timer = timerfuncation,
		effecttype = effecttypefuncation,
		enum = enumfuncation,
		objtype = objtypefuncation
	}
	local result = {}

	for key, value in pairs(data) do
		if type(value) == "table" and next(value) == nil then
			table.insert(result, {})
		elseif value.valtype and funtable[value.valtype] then
			table.insert(result, funtable[value.valtype](value.val))
		else
			table.insert(result, value)
		end
	end

	return result
end

function BTDebugDataManage:EndSendData(treeid, nodeid, id)
	if self.data[id] ~= nil then
		local senddata = self:DealSendToDebugData(self.data[id])

		GetInst("AIEditorInterface"):BTreePassRuntimeParam(treeid, nodeid, senddata)

		if IsOpenBtTreeDebug and IsOpenBtTreeDebug() then
			MiniLog("EndSendData  ", treeid, nodeid, TableToStr(senddata))
		end
	end
end
