return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local bbkey = result[1]
		local taskpram = lcontroller.taskparam
		taskpram.bbkey = bbkey

		if lcontroller:isNeedSendDebug() then
			local senddata = {}
			local sendval = {}

			if taskpram.bbkey then
				sendval.valtype = "getName"
			end

			table.insert(senddata, sendval)
			lcontroller.sendValToDebug(senddata)
		end
	end,
	run = function ()
		local targetObj = controller.target.get()
		local taskpram = controller.taskparam

		if not taskpram.bbkey then
			return controller.success()
		end

		local bbkey = taskpram.bbkey
		local eventparm = taskpram.eventParam

		if eventparm and eventparm.toobjid then
			if type(bbkey) == "table" then
				if bbkey.func and type(bbkey.func) == "function" then
					bbkey.func({
						value = eventparm.toobjid,
						controller = controller
					})
				end
			else
				local settype = controller.bb.set(taskpram.bbkey, {
					actor = eventparm.toobjid
				})
			end

			return controller.success()
		end

		return controller.fail()
	end
}
