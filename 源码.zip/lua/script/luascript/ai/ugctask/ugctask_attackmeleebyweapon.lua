local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local weaponId, targetObjId, frequency, distance, speed = nil

		if TEST_TEST_TEST then
			distance = 0
			frequency = 1
			targetObjId = CurMainPlayer:getObjId()
			weaponId = 12013
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 5, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4,
					5
				})
			end

			speed = result[5]
			distance = result[4]
			frequency = result[3]
			targetObjId = result[2]
			weaponId = result[1]
		end

		if speed == nil then
			speed = 1
		end

		lcontroller.taskparam.ugc_weaponId = weaponId
		lcontroller.taskparam.ugc_targetObjId = targetObjId
		lcontroller.taskparam.ugc_frequency = frequency
		lcontroller.taskparam.ugc_distance = distance
		lcontroller.taskparam.ugc_speed = speed

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = weaponId or 0
				}
			}
			local data2 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data3 = {
				valtype = "val",
				val = frequency
			}
			local data4 = {
				valtype = "val",
				val = distance
			}
			local data5 = {
				valtype = "val",
				val = speed
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4,
				data5
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		if not GameplayTagUtils:IsNormalAttackEnabled(selfActor) then
			return false
		end

		local targetObjId = controller.taskparam.ugc_targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		local dis_min = selfActor:getLocoMotion().m_BoundSize + targetActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local dis_max = selfActor:getViewDist()
		local distance = controller.taskparam.ugc_distance
		local attack_dis = math.clamp(distance * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.cache_attackDis = attack_dis
		local t_pos = targetActor:getPosition()

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.cache_targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.cache_path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.cache_path then
				return true
			else
				return false
			end
		else
			controller.taskparam.cache_targetPos = nil
			controller.taskparam.cache_path = nil

			return true
		end
	end,
	onbeg = function ()
		local selfActor = controller.target.get()
		local weaponId = controller.taskparam.ugc_weaponId

		if AIFunctionMgr:getBagItemCount(selfActor, weaponId, false) <= 0 then
			AIFunctionMgr:addItemToBags(selfActor, weaponId, 1)
		end

		AIFunctionMgr:equipWeapon(selfActor, weaponId, 1)

		if controller.taskparam.cache_targetPos then
			local targetObjId = controller.taskparam.ugc_targetObjId
			local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
			local path_range = btget_path_range()
			local speed = controller.taskparam.ugc_speed

			if targetActor and controller.taskparam.cache_path then
				selfActor:getNavigator():newTryMoveTo(controller.taskparam.cache_path, speed, path_range)

				controller.taskparam.cache_path = nil

				selfActor:keepLookAt(targetActor, 10, 10)
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.ugc_targetObjId
		local attack_dis = controller.taskparam.cache_attackDis

		if controller.taskparam.cache_targetPos then
			local t_pos = controller.taskparam.cache_targetPos
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

					if not targetActor or not targetActor:alive() then
						return true
					end

					return Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) then
			return controller.fail()
		end

		if not selfActor:isUnsighted() and not ActorComponentCallModule(selfActor, "ActorVision", "canSeeInAICache", targetActor) then
			return controller.fail()
		end

		if not selfActor:isAttacking() then
			selfActor:attackActor(targetActor)
		end

		if selfActor:getDefID() == 3915 then
			local itemId = selfActor:getEquipItem(EQUIP_WEAPON)

			if itemId == 0 then
				ActorComponentCallModule(selfActor, "SoundComponent", "playSound", "ent.3915.attack1", selfActor:getSoundVolume(), selfActor:getSoundPitch())
			elseif itemId == 12069 then
				ActorComponentCallModule(selfActor, "SoundComponent", "playSound", "ent.3915.attack2", selfActor:getSoundVolume(), selfActor:getSoundPitch())
			elseif itemId == 12316 then
				ActorComponentCallModule(selfActor, "SoundComponent", "playSound", "ent.3915.attack3", selfActor:getSoundVolume(), selfActor:getSoundPitch())
			end
		end

		local frequency = controller.taskparam.ugc_frequency

		controller.wait(frequency)

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.ugc_targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
		local speed = controller.taskparam.ugc_speed

		if not targetActor or not targetActor:alive() then
			return false
		end

		selfActor:keepLookAt(targetActor, 30, 30)

		if controller.taskparam.cache_targetPos then
			local t_pos = controller.taskparam.cache_targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
				t_pos = targetActor:getPosition()
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, speed, path_range) then
					controller.taskparam.cache_targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()
		selfActor:stopLookAt()

		controller.taskparam.cache_targetPos = nil
		controller.taskparam.cache_path = nil
		controller.taskparam.cache_attackDis = nil
	end
}
