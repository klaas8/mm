return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local pos = controller.taskparam.pos

		if not pos then
			return controller.fail()
		end

		local x = pos.x
		local y = pos.y
		local z = pos.z
		local ret = AIFunctionMgr:IsStonePotCooked(selfActor, x, y, z)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid",
			"buffid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local pos = result[1]
		lcontroller.taskparam.pos = pos

		if lcontroller:isNeedSendDebug() then
			local data2 = {
				valtype = "pos",
				val = pos
			}

			lcontroller.sendValToDebug({
				data2
			})
		end
	end
}
