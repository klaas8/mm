return {
	will = function ()
		if not controller.taskparam.pos or not controller.taskparam.speed or not controller.taskparam.time then
			return false
		end

		local actor = controller.target.get()

		if not actor or actor:isDead() or actor:needClear() then
			return false
		end

		local world = actor:getWorld()

		if not world then
			return false
		end

		if type(controller.taskparam.pos) ~= "table" then
			return false
		end

		local pos = controller.taskparam.pos

		if pos.x == 0 and pos.y == 0 and pos.y == 0 then
			return false
		end

		controller.taskparam.oldpos = controller.taskparam.pos
		local c_pos = actor:getPosition()
		local realr = controller.taskparam.speed * controller.taskparam.time

		if realr > 70 then
			realr = 70
		end

		local b_x, b_y, b_z = CoordDivBlock(c_pos.x, c_pos.y, c_pos.z)
		local curr = math.sqrt((b_x - pos.x) * (b_x - pos.x) + (b_y - pos.y) * (b_y - pos.y) + (b_z - pos.z) * (b_z - pos.z))
		local realpos = nil

		if b_x == controller.taskparam.pos.x and b_y == controller.taskparam.pos.y and b_z == controller.taskparam.pos.z then
			realpos = {
				x = b_x + realr,
				y = b_y,
				z = b_z
			}
		else
			local function getRandomValue(angelMin, angelMax)
				local rand = tostring(os.time()):reverse():sub(1, 7)

				math.randomseed(rand)

				return math.random(angelMin, angelMax)
			end

			local function getAngelPos(angel)
				local vx = controller.taskparam.pos.x - b_x
				local vz = controller.taskparam.pos.z - b_z
				local r = math.sqrt(vx * vx + vz * vz)
				vx = vx / r
				vz = vz / r
				local radians = angel * math.pi / 180
				local cosAngle = math.cos(radians)
				local sinAngle = math.sin(radians)
				local tempx = vx * cosAngle - vz * sinAngle
				local tempz = vx * sinAngle + vz * cosAngle

				return {
					x = tempx * realr + b_x,
					y = b_y,
					z = tempz * realr + b_z
				}
			end

			local function getRandomPosClassification()
				local allPosArray = {}

				for i = 90, 270 do
					local p = getAngelPos(i)

					table.insert(allPosArray, p)
				end

				local posWaterSurfaceArr = {}
				local posWaterInnerArr = {}
				local posWaterNotArr = {}

				local function isWater(pos)
					return world:isBlockLiquid(pos.x, pos.y, pos.z)
				end

				for _, pos in ipairs(allPosArray) do
					local blockPos = {
						x = math.floor(pos.x),
						y = math.floor(pos.y),
						z = math.floor(pos.z)
					}

					if isWater(blockPos) then
						local topPos = {
							x = blockPos.x,
							y = blockPos.y + 1,
							z = blockPos.z
						}

						if isWater(topPos) then
							table.insert(posWaterInnerArr, blockPos)
						else
							table.insert(posWaterSurfaceArr, blockPos)
						end
					else
						table.insert(posWaterNotArr, blockPos)
					end
				end

				local function getRandomIndex(total)
					if total <= 0 then
						return nil
					end

					return getRandomValue(1, total)
				end

				local function pickRandomPos(posArr)
					local idx = getRandomIndex(#posArr)

					if not idx then
						return nil
					end

					return posArr[idx]
				end

				local function pickRandomPos2(posArr1, posArr2)
					local size1 = #posArr1
					local total = size1 + #posArr2
					local idx = getRandomIndex(total)

					if not idx then
						return nil
					end

					if idx <= size1 then
						return posArr1[idx]
					end

					return posArr2[idx - size1]
				end

				local function pickRandomPos3(posArr1, posArr2, posArr3)
					local size1 = #posArr1
					local size2 = #posArr2
					local total = size1 + size2 + #posArr3
					local idx = getRandomIndex(total)

					if not idx then
						return nil
					end

					if idx <= size1 then
						return posArr1[idx]
					elseif idx <= size1 + size2 then
						return posArr2[idx - size1]
					end

					return posArr3[idx - size1 - size2]
				end

				local waterSurface = actor:NavAdditionalWaterSurface()
				local waterInner = actor:NavAdditionalWaterInner()
				local waterOnly = actor:NavAdditionalWaterOnly()

				if waterOnly then
					if waterSurface and not waterInner then
						return pickRandomPos(posWaterSurfaceArr)
					elseif not waterSurface and waterInner then
						return pickRandomPos(posWaterInnerArr)
					elseif waterSurface and waterInner then
						return pickRandomPos2(posWaterSurfaceArr, posWaterInnerArr)
					end
				elseif waterSurface and not waterInner then
					return pickRandomPos2(posWaterSurfaceArr, posWaterNotArr)
				elseif not waterSurface and waterInner then
					return pickRandomPos2(posWaterInnerArr, posWaterNotArr)
				elseif waterSurface and waterInner then
					return pickRandomPos3(posWaterSurfaceArr, posWaterInnerArr, posWaterNotArr)
				end
			end

			if (actor:IsAquaticComponent() or actor:IsMobComponent()) and actor:EnableNavAdditionalWater() then
				realpos = getRandomPosClassification()
			end

			realpos = realpos or getAngelPos(getRandomValue(90, 270))
		end

		controller.taskparam.realPos = realpos

		if actor:getNavigator() then
			local x, y, z = BlockBottomCoord(realpos.x, realpos.y, realpos.z)
			local path_range = btget_path_range()
			controller.taskparam.path = actor:getNavigator():newCanMoveTo(x, y, z, path_range)

			return controller.taskparam.path ~= nil
		else
			controller.taskparam.path = nil

			return false
		end
	end,
	onbeg = function ()
		local actor = controller.target.get()
		controller.taskparam.lastYaw = nil
		local c_pos = actor:getPosition()
		local targetPos = controller.taskparam.realPos
		local b_x, b_y, b_z = CoordDivBlock(c_pos.x, c_pos.y, c_pos.z)

		if b_x == targetPos.x and b_y == targetPos.y and b_z == targetPos.z then
			return
		end

		local speed = controller.taskparam.speed
		local path_range = btget_path_range()
		controller.taskparam.lastStopState = actor.IsStopBodyRotation
		local changeToward = controller.taskparam.changeToward

		if not changeToward then
			local locoMotion = actor:getLocoMotion()

			if locoMotion then
				controller.taskparam.lastYaw = locoMotion:getRotateYaw()
			end
		end

		actor.IsStopBodyRotation = not changeToward

		if controller.taskparam.path then
			actor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
		end
	end,
	run = function ()
		local actor = controller.target.get()

		if actor:getNavigator() then
			if not actor:getNavigator():noPath() then
				controller.wait_until(function ()
					return actor:getNavigator():noPath()
				end)
			end
		else
			return controller.fail()
		end

		return controller.success()
	end,
	onend = function ()
		local actor = controller.target.get()

		if actor:getNavigator() then
			actor:getNavigator():clearPathEntity()
		end

		local lastStopState = controller.taskparam.lastStopState

		BTService:RestoreSavedYaw(actor, controller.taskparam)

		if lastStopState ~= nil then
			actor.IsStopBodyRotation = lastStopState
		end

		controller.taskparam.lastStopState = nil
	end,
	release = function ()
		local actor = controller.target.get()
		local lastStopState = controller.taskparam.lastStopState
		controller.taskparam.lastStopState = nil

		BTService:RestoreSavedYaw(actor, controller.taskparam)

		if actor and lastStopState ~= nil then
			actor.IsStopBodyRotation = lastStopState
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetPos = result[1]
		local speed = result[2]
		local time = result[3]
		local changeToward = result[4]
		lcontroller.taskparam.pos = targetPos
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.time = time

		if changeToward == nil then
			changeToward = false
			lcontroller.taskparam.changeToward = false
		else
			lcontroller.taskparam.changeToward = changeToward
		end

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = targetPos
			}
			local data2 = {
				valtype = "val",
				val = speed
			}
			local data3 = {
				valtype = "val",
				val = time
			}
			local data4 = {
				valtype = "val",
				val = changeToward
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
