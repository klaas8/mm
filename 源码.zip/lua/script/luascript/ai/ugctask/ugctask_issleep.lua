return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local param_left = controller.taskparam.param_left

		if param_left == nil then
			return controller.fail()
		end

		local selfActor = controller.target.get()

		if selfActor == nil or not selfActor:alive() then
			return controller.fail()
		end

		local lefActor = AIFunctionMgr:getActorByObjId(selfActor, param_left)

		if lefActor == nil or not lefActor:alive() then
			return controller.fail()
		end

		local ret = AIFunctionMgr:IsSleep(lefActor)

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local param_left = result[1]
		lcontroller.taskparam.param_left = param_left

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = param_left or 0
				}
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
