return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local timerId = controller.taskparam.timerId
		local isReset = controller.taskparam.reset

		if isReset == nil or timerId == nil then
			return controller.fail()
		end

		local ret = false

		if isReset then
			ret = BTService:StartForwardTimer(timerId)

			BTService:ShowTimerTips({
				1000051626
			}, timerId, "", true)
		else
			local isPlaying = BTService:TimerIsPlaying(timerId)

			if isPlaying then
				ret = true
			elseif BTService:TimerIsPause(timerId) then
				ret = BTService:ResumeTimer(timerId)
			else
				ret = BTService:StartForwardTimer(timerId)

				BTService:ShowTimerTips({
					1000051626
				}, timerId, "", true)
			end
		end

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"timerId",
			"reset"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local timerId = result[1]
		local reset = result[2]
		lcontroller.taskparam.timerId = timerId
		local newreset = reset == "==" and true or false
		lcontroller.taskparam.reset = newreset

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "timer",
				val = {
					timerid = timerId
				}
			}
			local data2 = {
				valtype = "enum",
				val = reset
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
