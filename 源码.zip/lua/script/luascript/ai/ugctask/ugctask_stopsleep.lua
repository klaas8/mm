return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local obj = result[1]
		lcontroller.taskparam.obj = obj

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end,
	run = function ()
		local selfObj = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfObj, controller.taskparam.obj)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local ret = AIFunctionMgr:StopSleep(targetActor)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end
}
