return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local actor = result[1]
		local bbkey = result[2]
		local taskpram = lcontroller.taskparam
		taskpram.bbkey = bbkey
		taskpram.actor = actor

		if lcontroller:isNeedSendDebug() then
			local senddata = {}

			if taskpram.actor then
				local sendval = {
					valtype = "getName"
				}

				table.insert(senddata, sendval)
			end

			local sendval = {}

			if taskpram.bbkey then
				sendval.valtype = "getName"
			end

			table.insert(senddata, sendval)
			lcontroller.sendValToDebug(senddata)
		end
	end,
	run = function ()
		local taskpram = controller.taskparam

		if taskpram.bbkey == nil or taskpram.actor == nil then
			return controller.fail()
		end

		local toobj = taskpram.eventParam.toobjid
		local eventobj = taskpram.eventParam.eventobjid

		if toobj == nil or eventobj == nil or eventobj ~= taskpram.actor then
			return controller.fail()
		end

		local targetActor = {
			actor = toobj
		}

		if type(taskpram.bbkey) == "table" then
			if taskpram.bbkey.func and type(taskpram.bbkey.func) == "function" then
				taskpram.bbkey.func({
					value = toobj,
					controller = controller
				})
			end
		else
			controller.bb.set(taskpram.bbkey, targetActor)
		end

		return controller.success()
	end
}
