return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local msgId = tonumber(result[1])
		local senderBbKey = result[2]
		lcontroller.taskparam.msgId = msgId
		lcontroller.taskparam.senderBbKey = senderBbKey

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = msgId or 0
			}
			local data2 = nil

			if type(senderBbKey) == "string" and senderBbKey ~= "" then
				data2 = {
					valtype = "val",
					val = lcontroller.bb.getName(senderBbKey)
				}
			else
				data2 = {
					valtype = "getName"
				}
			end

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	run = function ()
		local taskparam = controller.taskparam
		local eventParam = taskparam and taskparam.eventParam
		local eventMsgId = eventParam and tonumber(eventParam.msgId)
		local msgId = eventParam and tonumber(eventParam.receiverMsgIdSnapshot)
		msgId = msgId or taskparam and tonumber(taskparam.msgId)

		if not msgId or msgId <= 0 or not eventMsgId or eventMsgId ~= msgId then
			return controller.fail()
		end

		local senderBbKey = taskparam and taskparam.senderBbKey

		if senderBbKey and senderBbKey ~= "" then
			local senderObjId = eventParam and tonumber(eventParam.senderObjId)

			if not senderObjId or senderObjId <= 0 then
				return controller.fail()
			end

			if type(senderBbKey) == "table" then
				if type(senderBbKey.func) == "function" then
					senderBbKey.func({
						value = senderObjId,
						controller = controller
					})
				end
			else
				controller.bb.set(senderBbKey, {
					actor = senderObjId
				})
			end
		end

		return controller.success()
	end
}
