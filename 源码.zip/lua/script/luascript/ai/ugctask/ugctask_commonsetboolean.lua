return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local bbkey = controller.taskparam.bbkey
		local bbvalue = controller.taskparam.bbvalue

		if type(bbvalue) ~= "boolean" then
			return controller.fail()
		end

		if type(bbkey) == "table" then
			if bbkey.func and type(bbkey.func) == "function" then
				bbkey.func({
					value = bbvalue,
					controller = controller
				})
			end
		else
			controller.bb.set(bbkey, bbvalue)
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local bbkey = result[1]
		local bbvalue = result[2]
		lcontroller.taskparam.bbkey = bbkey
		lcontroller.taskparam.bbvalue = lBTService:GetBoolVal(bbvalue)

		if lcontroller:isNeedSendDebug() then
			local data1 = nil

			if type(bbkey) == "string" then
				data1 = {
					valtype = "val",
					val = lcontroller.bb.getName(bbkey)
				}
			else
				data1 = {
					valtype = "getName"
				}
			end

			local data2 = {
				valtype = "val",
				val = bbvalue
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
