local function buildActorTypeSet(source)
	local result = {}

	for _, value in ipairs(source) do
		if type(value) == "table" and value.actorid then
			if type(value.actorid) == "string" then
				result[BTService:ResidToId(value.actorid)] = true
			else
				result[value.actorid] = true
			end
		else
			if type(value) == "string" then
				result[BTService:ResidToId(value)] = true
			end

			result[value] = true
		end
	end

	return result
end

return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local range = result[1]
		local actorTypeGroup = result[2]
		local bbkey = result[3]
		local taskParam = lcontroller.taskparam
		taskParam.range = range
		taskParam.bbkey = bbkey
		local actorTypeSet = {}

		if actorTypeGroup and actorTypeGroup.size then
			local size = actorTypeGroup:size()

			for i = 0, size - 1 do
				actorTypeSet[actorTypeGroup[i]] = true
			end
		elseif type(actorTypeGroup) == "table" then
			actorTypeSet = buildActorTypeSet(actorTypeGroup)
		else
			local itemTypes = lBTService:GetGroupData(actorTypeGroup, VARTYPE.CreatureTypeGroup, lcontroller)

			if type(itemTypes) == "table" then
				actorTypeSet = buildActorTypeSet(itemTypes)
			end
		end

		taskParam.actorType_table = actorTypeSet

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = range
			}
			local data2 = {
				valtype = "getName"
			}
			local data3 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end,
	run = function ()
		local taskParam = controller.taskparam

		if not taskParam.range or not taskParam.actorType_table or not taskParam.bbkey then
			return controller.fail()
		end

		local range = taskParam.range
		local bbkey = taskParam.bbkey
		local actorTypeSet = taskParam.actorType_table

		if not next(actorTypeSet) then
			return controller.fail()
		end

		local eventParam = taskParam.eventParam

		if not eventParam or not eventParam.toobjid or not eventParam.itemid or not actorTypeSet[eventParam.itemid] or range < eventParam.itemnum then
			return controller.fail()
		end

		local toobjid = eventParam.toobjid

		if type(bbkey) == "table" then
			if type(bbkey.func) == "function" then
				bbkey.func({
					value = toobjid,
					controller = controller
				})
			end
		else
			controller.bb.set(bbkey, {
				actor = toobjid
			})
		end

		return controller.success()
	end
}
