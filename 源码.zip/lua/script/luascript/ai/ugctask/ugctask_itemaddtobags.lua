return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local itemId = controller.taskparam.itemId
		local itemNum = controller.taskparam.itemNum

		if not CheckItemScriptUse(itemId) then
			return controller.fail()
		end

		local addedNum = AIFunctionMgr:addItemToBags(obj, itemId, itemNum or 1)

		if addedNum > 0 then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"itemId",
			"itemNum"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local itemId = result[1]
		local itemNum = result[2]
		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.itemNum = itemNum

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = itemNum
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
