return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	onwait = function ()
		if not controller.taskparam.playskil then
			local actor = controller.target.get()
			local objid = controller.taskparam.objid
			local targetActor = AIFunctionMgr:getActorByObjId(actor, objid)

			if not targetActor then
				return false
			end

			local t_pos = targetActor:getPosition()
			local id = controller.taskparam.id
			local ret = AIFunctionMgr:CheckPosAndSkillDist(actor, id, t_pos)

			if ret then
				actor:getNavigator():clearPathEntity()
			elseif actor:getNavigator():noPath() then
				local path_range = btget_path_range()
				local path = actor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

				if path then
					actor:getNavigator():newTryMoveTo(path, 1, path_range)

					return true
				else
					return false
				end
			end

			if actor:getNavigator():noPath() then
				local id = controller.taskparam.id
				local ret = true

				if not AIFunctionMgr:SkillIsPlaying(obj, id) then
					ret = AIFunctionMgr:PlaySkill(obj, id, targetActor)
				end

				controller.taskparam.playskil = true

				if ret then
					return true
				else
					return false
				end
			end
		end

		return true
	end,
	run = function ()
		local obj = controller.target.get()
		local objid = controller.taskparam.objid
		local id = controller.taskparam.id

		if not objid or not id or string.len(id) <= 0 then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(obj, objid)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			return controller.fail()
		end

		local t_pos = targetActor:getPosition()
		local ret = AIFunctionMgr:CheckPosAndSkillDist(obj, id, t_pos)

		if ret then
			if obj:getObjId() ~= objid and controller.taskparam.isrote then
				AIFunctionMgr:ActorRotatePos(obj, t_pos)
			end

			local ret = true

			if not AIFunctionMgr:SkillIsPlaying(obj, id) then
				ret = AIFunctionMgr:PlaySkill(obj, id, targetActor)
			end

			controller.taskparam.playskil = true

			if ret then
				controller.wait_until(function ()
					local tobj = controller.target.get()

					if not tobj or tobj:isDead() or tobj:needClear() then
						return true
					end

					local isplaying = AIFunctionMgr:SkillIsPlaying(tobj, id)

					return not isplaying
				end)

				return controller.success()
			end

			return controller.fail()
		else
			local path_range = btget_path_range()
			local path = obj:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if path then
				controller.taskparam.playskil = false

				obj:getNavigator():newTryMoveTo(path, 1, path_range)
				controller.wait_until(function ()
					return controller.taskparam.playskil
				end)

				if controller.taskparam.playskil then
					controller.wait_until(function ()
						local tobj = controller.target.get()

						if not tobj or tobj:isDead() or tobj:needClear() then
							return true
						end

						local isplaying = AIFunctionMgr:SkillIsPlaying(tobj, id)

						return not isplaying
					end)
				end
			else
				return controller.fail()
			end
		end

		return controller.success()
	end,
	onend = function ()
		local obj = controller.target.get()
		local id = controller.taskparam.id

		if obj and id then
			AIFunctionMgr:StopSkill(obj, id)
		end

		controller.taskparam.playskil = false
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objid = result[1]
		local id = result[2]
		local isrote = result[3]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.id = id
		lcontroller.taskparam.isrote = isrote == nil and true or isrote == "true" and true or false

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = id
			}
			local data3 = {
				valtype = "val",
				val = lcontroller.taskparam.isrote
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
