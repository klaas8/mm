return {
	will = function ()
		local obj = controller.target.get()
		local range = controller.taskparam.range
		local tag = controller.taskparam.tag

		if not obj or not obj:alive() or not range or not tag then
			return false
		end

		return true
	end,
	onbeg = function ()
		local obj = controller.target.get()
		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(obj)
		local range = controller.taskparam.range
		local tag = controller.taskparam.tag
		local ret = false
		local targetId = 0
		local px = 0
		local py = 0
		local pz = 0
		local searchType = controller.taskparam.searchType
		searchType = searchType or 2
		ret, targetId = AIFunctionMgr:newfindNearestObjIdBySpecifyType(0, obj, 1, range, 999, 3, 0, 0, false, 0, tag, searchType)
		local targetObj = AIFunctionMgr:getActorByObjId(obj, targetId)

		if ret and targetObj then
			local pos = targetObj:getPosition()
			local pos_x = pos.x
			local pos_y = pos.y
			local pos_z = pos.z

			if not obj:TryGetPathToPos(pos_x, pos_y, pos_z) then
				return
			end

			if obj:getNavigator() then
				local path_range = btget_path_range()

				obj:getNavigator():tryMoveTo(pos_x, pos_y, pos_z, 1, path_range)
			end

			controller.taskparam.targetId = targetId
			controller.taskparam.targetPos = {
				x = pos_x,
				y = pos_y,
				z = pos_z
			}
		end
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get("living")

		if not selfobj or not selfobj:alive() then
			return controller.fail()
		end

		if not GameplayTagUtils:IsPickItemEnabled(selfobj) then
			return controller.fail()
		end

		local range = controller.taskparam.range
		local target_pos = controller.taskparam.targetPos

		if not target_pos then
			return controller.fail()
		end

		local pickDistance = controller.taskparam.pickDistance

		if target_pos then
			local checkTag = Pos3SquareDistToPos3(selfobj:getPosition(), target_pos) <= pickDistance

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfobj:getPosition(), target_pos) <= pickDistance or selfobj:getNavigator():noPath()
				end)
				selfobj:getNavigator():clearPathEntity()
			end
		end

		local ret = Pos3SquareDistToPos3(selfobj:getPosition(), target_pos) <= pickDistance * 3

		if not ret then
			return controller.fail()
		end

		local ss_actor = BTService:GetSSObj("Actor")
		local targetObj = AIFunctionMgr:getActorByObjId(selfobj, controller.taskparam.targetId)

		if targetObj ~= nil then
			local itemId = targetObj.GetItemId and targetObj:GetItemId() or 0
			local itemNum = targetObj.getDropItemNum and targetObj:getDropItemNum() or 0

			if AIFunctionMgr:checkPutItem(selfobj, itemId, itemNum) then
				can_do_pick = true

				AIFunctionMgr:playSound(selfobj, "npc.pick", 1, 1, 2)
				AIFunctionMgr:pickItem(selfobj, targetObj)

				return controller.success()
			end
		end

		return controller.fail()
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local pickDistance = controller.taskparam.pickDistance

			if pickDistance < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) and selfActor:getNavigator():noPath() then
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local range = result[1]
		local tag = result[2]
		local searchType = result[3]
		lcontroller.taskparam.searchType = searchType
		local debugtag = ""
		local needSendDebug = lcontroller:isNeedSendDebug()
		lcontroller.taskparam.tag, debugtag = lBTService:DealTagToArrayData(tag, needSendDebug, lcontroller.taskparam.tag)
		lcontroller.taskparam.range = range
		lcontroller.taskparam.pickDistance = 40000

		if needSendDebug then
			local data1 = {
				valtype = "val",
				val = range
			}
			local data2 = {
				valtype = "enum"
			}
			local data3 = {
				valtype = "val",
				val = debugtag
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
