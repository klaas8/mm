local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId, distance, speed, changeToward = nil

		if TEST_TEST_TEST then
			changeToward = true
			speed = 1
			distance = 1
			targetObjId = CurMainPlayer:getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 4, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4
				})
			end

			changeToward = result[4]
			speed = result[3]
			distance = result[2]
			targetObjId = result[1]
			changeToward = changeToward == "==" and true or false
		end

		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.changeToward = changeToward

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = distance
			}
			local data3 = {
				valtype = "val",
				val = speed
			}
			local data4 = {
				valtype = "val",
				val = changeToward
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()
		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)

		if not selfActor or selfActor:isDead() or selfActor:needClear() then
			return false
		end

		local targetObjId = controller.taskparam.targetObjId

		if not targetObjId then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noTarget"
				}

				controller.sendMsgToAi(selfActor, "UGCTask_FollowTarget", errinfo)
			end

			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "targetNoExit",
					targetObjId = targetObjId
				}

				controller.sendMsgToAi(selfActor, "UGCTask_FollowTarget", errinfo)
			end

			return false
		end

		local t_pos = targetActor:getPosition()
		local distance = controller.taskparam.distance

		if math.pow(distance * BLOCK_SIZE, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.targetActor = targetActor
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path == nil and controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noTargetReachable",
					targetObjId = targetObjId,
					x = t_pos.x,
					y = t_pos.y,
					z = t_pos.z
				}

				controller.sendMsgToAi(selfActor, "UGCTask_FollowTarget", errinfo)
			end

			return controller.taskparam.path ~= nil
		else
			controller.taskparam.targetPos = nil
			controller.taskparam.path = nil
			local changeToward = controller.taskparam.changeToward

			if changeToward then
				AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)
			end

			return true
		end
	end,
	onbeg = function ()
		controller.taskparam.lastYaw = nil
		local t_pos = controller.taskparam.targetPos

		if not t_pos then
			return
		end

		local selfActor = controller.target.get()
		controller.taskparam.lastStopState = selfActor.IsStopBodyRotation
		local changeToward = controller.taskparam.changeToward

		if not changeToward then
			local locoMotion = selfActor:getLocoMotion()

			if locoMotion then
				controller.taskparam.lastYaw = locoMotion:getRotateYaw()
			end
		end

		selfActor.IsStopBodyRotation = not changeToward
		local speed = controller.taskparam.speed
		local path_range = btget_path_range()

		if controller.taskparam.path then
			selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
		end
	end,
	run = function ()
		local t_pos = controller.taskparam.targetPos

		if not t_pos then
			return controller.success()
		end

		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local distance = controller.taskparam.distance
		local dis = distance * BLOCK_SIZE
		local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(dis, 2) or selfActor:getNavigator():noPath()

		if not checkTag then
			controller.wait_until(function ()
				local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

				if not targetActor or not targetActor:alive() then
					return true
				end

				return Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) <= math.pow(dis, 2) or selfActor:getNavigator():noPath()
			end)
		end

		if controller.taskparam.needErrInfo then
			local errinfo = {
				info = "followTargetSuccess",
				targetObjId = targetObjId
			}

			controller.sendMsgToAi(selfActor, "UGCTask_FollowTarget", errinfo)
		end

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		local t_pos = controller.taskparam.targetPos
		local distance = controller.taskparam.distance
		local dis = distance * BLOCK_SIZE

		if math.pow(dis, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
			t_pos = targetActor:getPosition()
			local speed = controller.taskparam.speed
			local path_range = btget_path_range()

			if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, speed, path_range) then
				controller.taskparam.targetPos = {
					x = t_pos.x,
					y = t_pos.y,
					z = t_pos.z
				}

				return true
			else
				return false
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()

		local lastStopState = controller.taskparam.lastStopState

		BTService:RestoreSavedYaw(selfActor, controller.taskparam)

		if lastStopState ~= nil then
			selfActor.IsStopBodyRotation = lastStopState
		end

		controller.taskparam.lastStopState = nil
		controller.taskparam.targetActor = nil
		controller.taskparam.targetPos = nil
	end,
	release = function ()
		local selfActor = controller.target.get()
		local lastStopState = controller.taskparam.lastStopState
		controller.taskparam.lastStopState = nil

		BTService:RestoreSavedYaw(selfActor, controller.taskparam)

		if selfActor and lastStopState ~= nil then
			selfActor.IsStopBodyRotation = lastStopState
		end
	end
}
