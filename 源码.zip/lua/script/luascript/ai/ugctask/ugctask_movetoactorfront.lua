local Task = {
	ARRIVE_DISTANCE = 0.5 * BLOCK_SIZE,
	REPATH_DISTANCE = 0.5 * BLOCK_SIZE
}

function Task.IsActorValid(actor)
	return actor and actor:alive() and not actor:isDead() and not actor:needClear()
end

function Task.GetActorFrontPos(actor, distanceBlock)
	if not Task.IsActorValid(actor) then
		return nil
	end

	local pos = actor:getPosition()
	local locoMotion = actor:getLocoMotion()

	if not pos or not locoMotion then
		return nil
	end

	local dirX, _, dirZ = PitchYaw2Direction(locoMotion:getRotateYaw(), 0)
	local distance = math.max(0, tonumber(distanceBlock) or 0) * BLOCK_SIZE

	return {
		x = pos.x + dirX * distance,
		y = pos.y,
		z = pos.z + dirZ * distance
	}
end

function Task.IsNearPos(actor, targetPos)
	if not Task.IsActorValid(actor) or not targetPos then
		return false
	end

	return Pos3SquareDistToPos3(actor:getPosition(), targetPos) <= Task.ARRIVE_DISTANCE * Task.ARRIVE_DISTANCE
end

function Task.IsMoveFinished(actor, targetPos)
	if Task.IsNearPos(actor, targetPos) then
		return true
	end

	if not targetPos or not Task.IsActorValid(actor) then
		return false
	end

	local navigator = actor:getNavigator()

	return navigator and navigator:noPath() or false
end

function Task.NeedRepath(oldPos, newPos)
	if not oldPos or not newPos then
		return false
	end

	return Pos3SquareDistToPos3(oldPos, newPos) > Task.REPATH_DISTANCE * Task.REPATH_DISTANCE
end

function Task.RotateActorToTarget(actor, targetActor)
	if not Task.IsActorValid(actor) or not Task.IsActorValid(targetActor) then
		return false
	end

	local locoMotion = actor:getLocoMotion()
	local actorPos = actor:getPosition()
	local targetPos = targetActor:getPosition()

	if not locoMotion or not actorPos or not targetPos then
		return false
	end

	local dirX = targetPos.x - actorPos.x
	local dirZ = targetPos.z - actorPos.z

	if math.abs(dirX) < 0.001 and math.abs(dirZ) < 0.001 then
		return true
	end

	local yaw = Direction2PitchYaw(dirX, 0, dirZ)

	locoMotion:setRotateYaw(WrapAngleTo180(yaw))

	return true
end

function Task.ResolveTargetActor(ctrl, selfActor)
	if not ctrl or not ctrl.taskparam or not Task.IsActorValid(selfActor) then
		return nil
	end

	local targetObjId = ctrl.taskparam.targetObjId

	if not targetObjId then
		return nil
	end

	local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

	if Task.IsActorValid(targetActor) then
		return targetActor
	end

	return nil
end

function Task.TryMoveToFront(ctrl, selfActor, targetActor)
	if not ctrl or not ctrl.taskparam or not Task.IsActorValid(selfActor) or not Task.IsActorValid(targetActor) then
		return false
	end

	local frontPos = Task.GetActorFrontPos(targetActor, ctrl.taskparam.frontDistance)

	if not frontPos then
		return false
	end

	ctrl.taskparam.targetPos = frontPos

	if Task.IsNearPos(selfActor, frontPos) then
		ctrl.taskparam.path = nil

		return true
	end

	local pathRange = btget_path_range()
	local path = selfActor:getNavigator():newCanMoveTo(frontPos.x, frontPos.y, frontPos.z, pathRange)

	if not path then
		return false
	end

	ctrl.taskparam.path = path

	return true
end

function Task.send_debug_data()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam then
		return
	end

	local lBTService = BTService
	local result = nil

	if lBTService:IsSubparamReuseEnabled() then
		result = lBTService:GetSubparamOutputBuffer(ctrl)

		lBTService:GetSubparamInto(ctrl, 4, result)
	else
		result = btget_subparam(ctrl, {
			1,
			2,
			3,
			4
		})
	end

	local targetObjId = result[1]
	local frontDistance = result[2]
	local speed = result[3]
	local changeToward = result[4]
	ctrl.taskparam.targetObjId = targetObjId
	ctrl.taskparam.frontDistance = tonumber(frontDistance) or 1
	ctrl.taskparam.speed = tonumber(speed) or 1
	ctrl.taskparam.changeToward = changeToward == "==" and true or false

	if ctrl:isNeedSendDebug() then
		local data1 = {
			valtype = "actor",
			val = {
				actor = targetObjId or 0
			}
		}
		local data2 = {
			valtype = "val",
			val = ctrl.taskparam.frontDistance
		}
		local data3 = {
			valtype = "val",
			val = ctrl.taskparam.speed
		}
		local data4 = {
			valtype = "enum",
			val = ctrl.taskparam.changeToward
		}

		ctrl.sendValToDebug({
			data1,
			data2,
			data3,
			data4
		})
	end
end

function Task.will()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return false
	end

	local selfActor = ctrl.target.get()

	if not Task.IsActorValid(selfActor) then
		return false
	end

	local targetActor = Task.ResolveTargetActor(ctrl, selfActor)

	if not targetActor then
		return false
	end

	if Task.TryMoveToFront(ctrl, selfActor, targetActor) then
		ctrl.taskparam.targetActor = targetActor

		return true
	end

	return false
end

function Task.onbeg()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return
	end

	local selfActor = ctrl.target.get()

	if not Task.IsActorValid(selfActor) then
		return
	end

	ctrl.taskparam.lastStopState = selfActor.IsStopBodyRotation
	ctrl.taskparam.lastYaw = nil

	if not ctrl.taskparam.changeToward then
		local locoMotion = selfActor:getLocoMotion()

		if locoMotion then
			ctrl.taskparam.lastYaw = locoMotion:getRotateYaw()
		end
	end

	selfActor.IsStopBodyRotation = not ctrl.taskparam.changeToward

	if ctrl.taskparam.path then
		selfActor:getNavigator():newTryMoveTo(ctrl.taskparam.path, ctrl.taskparam.speed, btget_path_range())

		ctrl.taskparam.path = nil
	end
end

function Task.run()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return false
	end

	local selfActor = ctrl.target.get()

	if not Task.IsActorValid(selfActor) then
		return ctrl.fail()
	end

	if not Task.IsMoveFinished(selfActor, ctrl.taskparam.targetPos) then
		ctrl.wait_until(function ()
			if not Task.IsActorValid(selfActor) then
				ctrl.taskparam.moveFailed = true

				return true
			end

			local targetActor = Task.ResolveTargetActor(ctrl, selfActor)

			if not targetActor then
				ctrl.taskparam.targetMissing = true

				return true
			end

			local frontPos = Task.GetActorFrontPos(targetActor, ctrl.taskparam.frontDistance)

			if not frontPos then
				ctrl.taskparam.targetMissing = true

				return true
			end

			if Task.NeedRepath(ctrl.taskparam.targetPos, frontPos) then
				if selfActor:getNavigator():tryMoveTo(frontPos.x, frontPos.y, frontPos.z, ctrl.taskparam.speed, btget_path_range()) then
					ctrl.taskparam.targetPos = frontPos

					return false
				end

				ctrl.taskparam.moveFailed = true

				return true
			end

			return Task.IsMoveFinished(selfActor, ctrl.taskparam.targetPos)
		end)
	end

	if ctrl.taskparam.targetMissing or ctrl.taskparam.moveFailed then
		return ctrl.fail()
	end

	if not Task.IsActorValid(selfActor) then
		return ctrl.fail()
	end

	local targetActor = Task.ResolveTargetActor(ctrl, selfActor)

	if not targetActor then
		return ctrl.fail()
	end

	if not Task.IsMoveFinished(selfActor, ctrl.taskparam.targetPos) then
		return ctrl.fail()
	end

	local navigator = selfActor:getNavigator()

	if navigator then
		navigator:clearPathEntity()
	end

	if ctrl.taskparam.changeToward then
		selfActor.IsStopBodyRotation = false

		Task.RotateActorToTarget(selfActor, targetActor)
	end

	return ctrl.success()
end

function Task.onend()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return
	end

	local selfActor = ctrl.target.get()

	if Task.IsActorValid(selfActor) then
		selfActor:getNavigator():clearPathEntity()

		local lastStopState = ctrl.taskparam.lastStopState

		BTService:RestoreSavedYaw(selfActor, ctrl.taskparam)

		if lastStopState ~= nil then
			selfActor.IsStopBodyRotation = lastStopState
		end

		ctrl.taskparam.lastStopState = nil
	end

	ctrl.taskparam.targetActor = nil
	ctrl.taskparam.targetPos = nil
	ctrl.taskparam.path = nil
	ctrl.taskparam.targetMissing = nil
	ctrl.taskparam.moveFailed = nil
end

function Task.release()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return
	end

	local selfActor = ctrl.target.get()
	local lastStopState = ctrl.taskparam.lastStopState
	ctrl.taskparam.lastStopState = nil

	BTService:RestoreSavedYaw(selfActor, ctrl.taskparam)

	if Task.IsActorValid(selfActor) and lastStopState ~= nil then
		selfActor.IsStopBodyRotation = lastStopState
	end
end

return Task
