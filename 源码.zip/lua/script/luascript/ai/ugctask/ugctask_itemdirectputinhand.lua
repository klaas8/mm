local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local itemId = nil

		if TEST_TEST_TEST then
			itemId = 12009
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 1, result)
			else
				result = btget_subparam(lcontroller, {
					1
				})
			end

			itemId = result[1]
		end

		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.ugc_itemId = itemId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local itemId = controller.taskparam.ugc_itemId
		local weaponId = selfActor:getEquipItem(EQUIP_WEAPON)

		if weaponId == itemId then
			return controller.success()
		end

		if not CheckItemScriptUse(itemId) then
			return controller.fail()
		end

		if AIFunctionMgr:getBagItemCount(selfActor, itemId, false) <= 0 then
			AIFunctionMgr:addItemToBags(selfActor, itemId, 1)
		end

		local result = AIFunctionMgr:equipWeapon(selfActor, itemId, 1)

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
