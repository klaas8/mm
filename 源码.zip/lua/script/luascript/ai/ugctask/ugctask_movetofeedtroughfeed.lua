return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local distance = result[1]
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.dist = 0.1

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = distance
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local distance = controller.taskparam.distance

		if distance == nil then
			return false
		end

		local ret, movex, movey, movez, x, y, z = AIFunctionMgr:GetNearestFeedTrough(selfActor, distance, 0, 0, 0, 0, 0, 0)

		if not ret then
			return false
		end

		controller.taskparam.targetPos = {
			x = movex,
			y = movey,
			z = movez
		}
		controller.taskparam.eatPos = {
			x = x,
			y = y,
			z = z
		}
		local path_range = btget_path_range()
		local dis_min = 10
		local dis_max = selfActor:getViewDist()
		local dis = controller.taskparam.dist
		local attack_dis = math.clamp(dis * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.attackDis = attack_dis
		local t_pos = controller.taskparam.targetPos

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.targetPos = nil

			return true
		end
	end,
	onbeg = function ()
		if controller.taskparam.targetPos then
			local selfActor = controller.target.get()
			local path_range = btget_path_range()

			if selfActor and controller.taskparam.path then
				selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, 1, path_range)

				controller.taskparam.path = nil
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()
		local attack_dis = controller.taskparam.attackDis

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local eatPos = controller.taskparam.eatPos

		if not BTService:IsXYZ(eatPos) then
			return controller.fail()
		end

		local haveFood = AIFunctionMgr:FeedTroughHaveFood(selfActor, eatPos.x, eatPos.y, eatPos.z)

		if not haveFood then
			return controller.fail()
		end

		local roteposx, roteposy, roteposz = BlockCenterCoord(eatPos.x, eatPos.y, eatPos.z)

		AIFunctionMgr:rotateBodyToPos(selfActor, roteposx, roteposy, roteposz)

		local ret = AIFunctionMgr:EatFeedTroughFood(selfActor, eatPos.x, eatPos.y, eatPos.z)

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if controller.taskparam.targetPos then
			local eatPos = controller.taskparam.eatPos
			local haveFood = AIFunctionMgr:FeedTroughHaveFood(selfActor, eatPos.x, eatPos.y, eatPos.z)

			if not haveFood then
				return false
			end

			local t_pos = controller.taskparam.targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()

		controller.taskparam.targetPos = nil
		controller.taskparam.eatPos = nil
		controller.taskparam.attackDis = nil
	end
}
