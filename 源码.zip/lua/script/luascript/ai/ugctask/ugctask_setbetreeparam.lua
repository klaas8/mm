return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local targetObjId = controller.taskparam.targetObjId
		local treeid = controller.taskparam.treeid
		local bbkey = controller.taskparam.bbkey
		local value = controller.taskparam.value

		if targetObjId == nil or treeid == nil or bbkey == nil or value == nil then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local ret = Service.Actor:SetBtreeVarValue(targetObjId, bbkey, value)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	onend = function ()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetObjId = result[1]
		local treeid = result[2]
		local bbkey = result[3]
		local value = result[4]

		if type(value) == "string" and value == "true" then
			value = true
		elseif type(value) == "string" and value == "false" then
			value = false
		end

		lcontroller.taskparam.treeid = treeid
		lcontroller.taskparam.bbkey = bbkey
		lcontroller.taskparam.value = value
		lcontroller.taskparam.targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "getName"
			}
			local data3 = {
				valtype = "getName"
			}
			local data4 = {
				valtype = "val",
				val = value
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
