return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid1 = controller.taskparam.objid1
		local objid2 = controller.taskparam.objid2
		local campType = controller.taskparam.campType

		if type(campType) ~= "string" then
			return controller.fail()
		end

		local realCampType = _G.BTServiceEnum[campType]

		if not realCampType then
			local ct = utils.split(campType_, ".")

			if ct then
				realCampType = _G[ct[1]][ct[2]]
			end
		end

		if not realCampType then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor1 = AIFunctionMgr:getActorByObjId(selfActor, objid1)
		local targetActor2 = AIFunctionMgr:getActorByObjId(selfActor, objid2)

		if not targetActor1 or not targetActor2 then
			return controller.fail()
		end

		if not targetActor1.getTeam or not targetActor2.getTeam then
			return controller.fail()
		end

		local teamType = targetActor1:getTeamType(targetActor2)

		if teamType == realCampType then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid1",
			"objid2",
			"campType"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objid1 = result[1]
		local objid2 = result[2]
		local campType = result[3]
		lcontroller.taskparam.objid1 = objid1
		lcontroller.taskparam.objid2 = objid2
		lcontroller.taskparam.campType = campType

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid1 or 0
				}
			}
			local data2 = {
				valtype = "actor",
				val = {
					actor = objid2 or 0
				}
			}
			local data3 = {
				valtype = "val",
				val = campType
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
