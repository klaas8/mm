return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local objbbkey = controller.taskparam.objbbkey
		local itembbkey = controller.taskparam.itembbkey
		local eventparm = controller.taskparam.eventParam

		if eventparm and objbbkey and itembbkey then
			local targetActor = {
				actor = eventparm.toobjid
			}
			local item = {
				itemid = eventparm.itemid
			}

			if type(objbbkey) == "table" then
				if objbbkey.func and type(objbbkey.func) == "function" then
					objbbkey.func({
						value = eventparm.toobjid,
						controller = controller
					})
				end
			else
				controller.bb.set(objbbkey, targetActor)
			end

			if type(itembbkey) == "table" then
				if itembbkey.func and type(itembbkey.func) == "function" then
					itembbkey.func({
						value = eventparm.item,
						controller = controller
					})
				end
			else
				controller.bb.set(itembbkey, item)
			end
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objbbkey = result[1]
		local itembbkey = result[2]
		lcontroller.taskparam.objbbkey = objbbkey
		lcontroller.taskparam.itembbkey = itembbkey

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "getName"
			}
			local data2 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
