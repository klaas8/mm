local function LocalXZSqDist(p1, p2)
	if not p1 or not p2 then
		return 999999
	end

	local dx = (p1.x or 0) - (p2.x or 0)
	local dz = (p1.z or 0) - (p2.z or 0)

	return dx * dx + dz * dz
end

local function IsValidBlockPos(pos)
	return pos and type(pos) == "table" and pos.x ~= nil and pos.y ~= nil and pos.z ~= nil
end

local function IsPetNestBlockId(blockId)
	if not blockId then
		return false
	end

	return blockId == BLOCK_PET_NEST or blockId == BLOCK_NEW_PET_NEST or blockId == BLOCK_MULTI_PET_NEST
end

local sNestExtendPos = {
	{
		{
			0,
			0
		},
		{
			1,
			0
		},
		{
			0,
			-1
		},
		{
			1,
			-1
		}
	},
	{
		{
			0,
			0
		},
		{
			-1,
			0
		},
		{
			0,
			1
		},
		{
			-1,
			1
		}
	},
	{
		{
			0,
			0
		},
		{
			1,
			0
		},
		{
			0,
			1
		},
		{
			1,
			1
		}
	},
	{
		{
			0,
			0
		},
		{
			-1,
			0
		},
		{
			0,
			-1
		},
		{
			-1,
			-1
		}
	}
}

local function FindMultiNestCorePos(world, nestpos)
	if not world or not nestpos then
		return nil
	end

	local bx = nestpos.x
	local by = nestpos.y
	local bz = nestpos.z
	local data = world:getBlockData(bx, by, bz) or 0
	local dir = bit.band(data, 3)

	for y = 0, 1 do
		for i = 1, 4 do
			local ox = sNestExtendPos[dir + 1][i][1]
			local oz = sNestExtendPos[dir + 1][i][2]
			local cx = bx - ox
			local cy = by - y
			local cz = bz - oz

			if world:getBlockID(cx, cy, cz) == BLOCK_MULTI_PET_NEST then
				local cdata = world:getBlockData(cx, cy, cz) or 0

				if bit.band(cdata, 4) == 0 then
					return {
						x = cx,
						y = cy,
						z = cz
					}, bit.band(cdata, 3)
				end
			end
		end
	end

	return nil
end

local sNestStandPos = {
	{
		{
			-1,
			0
		},
		{
			-1,
			-1
		},
		{
			-1,
			1
		},
		{
			-1,
			-2
		},
		{
			0,
			1
		},
		{
			0,
			-2
		},
		{
			1,
			1
		},
		{
			1,
			-2
		},
		{
			2,
			1
		},
		{
			2,
			-2
		},
		{
			2,
			0
		},
		{
			2,
			-1
		}
	},
	{
		{
			1,
			0
		},
		{
			1,
			1
		},
		{
			1,
			-1
		},
		{
			1,
			2
		},
		{
			0,
			-1
		},
		{
			0,
			2
		},
		{
			1,
			-1
		},
		{
			1,
			2
		},
		{
			2,
			-1
		},
		{
			2,
			0
		},
		{
			2,
			1
		},
		{
			2,
			2
		}
	},
	{
		{
			0,
			-1
		},
		{
			1,
			-1
		},
		{
			-1,
			-1
		},
		{
			2,
			-1
		},
		{
			-1,
			0
		},
		{
			2,
			0
		},
		{
			-1,
			1
		},
		{
			2,
			1
		},
		{
			-1,
			2
		},
		{
			0,
			2
		},
		{
			1,
			2
		},
		{
			2,
			2
		}
	},
	{
		{
			0,
			1
		},
		{
			-1,
			1
		},
		{
			1,
			1
		},
		{
			-2,
			1
		},
		{
			1,
			0
		},
		{
			-2,
			0
		},
		{
			1,
			-1
		},
		{
			-2,
			-1
		},
		{
			1,
			-2
		},
		{
			0,
			-2
		},
		{
			-1,
			-2
		},
		{
			-2,
			-2
		}
	}
}

local function PickMultiNestDoorPos(pet, corePos, dir, path_range)
	if not pet or not corePos then
		return nil
	end

	local nav = pet:getNavigator()

	if not nav then
		return nil
	end

	local d = (dir or 0) + 1
	local y = corePos.y

	for i = 1, 12 do
		local off = sNestStandPos[d][i]
		local x = corePos.x + off[1]
		local z = corePos.z + off[2]
		local px, py, pz = BlockBottomCoord(x, y, z)
		local path = nav:newCanMoveTo(px, py, pz, path_range)

		if path then
			return {
				x = px,
				y = py,
				z = pz
			}, path
		end
	end

	return nil
end

local function TryGetNestPosByActorPos(world, pet)
	if not world or not pet then
		return nil
	end

	local pos = pet:getPosition()

	if not pos then
		return nil
	end

	local bx, by, bz = CoordDivBlock(pos.x, pos.y, pos.z)

	for dy = -2, 2 do
		local y = by + dy
		local bid = world:getBlockID(bx, y, bz)

		if IsPetNestBlockId(bid) then
			return {
				x = bx,
				y = y,
				z = bz
			}
		end
	end

	return nil
end

return {
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local objid = controller.taskparam.petobjid

		if not objid or objid <= 0 then
			return false
		end

		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or not pet:alive() then
			return false
		end

		local pworld = pet:getWorld()

		if not pworld then
			return false
		end

		local nestpos = nil

		if AIFunctionMgr:IsPetInNest(pet) then
			local realNestPos = TryGetNestPosByActorPos(pworld, pet)

			if not IsValidBlockPos(realNestPos) then
				return false
			end

			if not IsPetNestBlockId(pworld:getBlockID(realNestPos.x, realNestPos.y, realNestPos.z)) then
				return false
			end

			nestpos = realNestPos
			controller.taskparam.nestpos = realNestPos
			local ok = AIFunctionMgr:UnbindToPetNest(pet, nestpos.x, nestpos.y, nestpos.z)

			if not ok then
				return false
			end
		end

		if not IsValidBlockPos(nestpos) then
			local pos = pet:getPosition()

			if not pos then
				return false
			end

			local bx, by, bz = CoordDivBlock(pos.x, pos.y, pos.z)
			nestpos = {
				x = bx,
				y = by,
				z = bz
			}
			controller.taskparam.nestpos = nestpos
		end

		local range = controller.taskparam.range or 4
		local tryCount = controller.taskparam.tryCount or 10
		local t_pos = {
			z = 0,
			x = 0,
			y = 0
		}
		local path_range = btget_path_range()
		controller.taskparam.path = nil
		controller.taskparam.targetPos = nil
		controller.taskparam.exitDoorPos = nil
		local centerPos = nestpos
		local nestBlockId = pworld:getBlockID(nestpos.x, nestpos.y, nestpos.z)

		if nestBlockId == BLOCK_MULTI_PET_NEST then
			local corePos, dir = FindMultiNestCorePos(pworld, nestpos)

			if corePos then
				centerPos = corePos
				local doorPos = PickMultiNestDoorPos(pet, corePos, dir, path_range)

				if doorPos then
					controller.taskparam.exitDoorPos = doorPos
					controller.taskparam.path = nil
				end
			end
		end

		for _ = 1, tryCount do
			t_pos.x, t_pos.y, t_pos.z = AIFunctionMgr:GetRandStrollPos(pet, t_pos.x, t_pos.y, t_pos.z, centerPos.x, centerPos.y, centerPos.z, range, range)

			if t_pos.x ~= centerPos.x or t_pos.y ~= centerPos.y or t_pos.z ~= centerPos.z then
				local x, y, z = BlockBottomCoord(t_pos.x, t_pos.y, t_pos.z)
				local path = pet:getNavigator():landCanMoveTo(x, y, z, path_range)

				if path then
					if not controller.taskparam.exitDoorPos then
						controller.taskparam.path = path
					end

					controller.taskparam.targetPos = {
						x = x,
						y = y,
						z = z
					}

					break
				end
			end
		end

		if not controller.taskparam.targetPos then
			return false
		end

		if not controller.taskparam.path and not controller.taskparam.exitDoorPos then
			return false
		end

		local dis_min = 25
		local dis_max = pet:getViewDist()
		controller.taskparam.approachDis = math.clamp(0.5 * BLOCK_SIZE, dis_min, dis_max)

		return true
	end,
	onbeg = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return
		end

		local objid = controller.taskparam.petobjid
		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or not pet:alive() then
			return
		end

		local speed = controller.taskparam.speed or 1
		local path_range = btget_path_range()

		if controller.taskparam.exitDoorPos then
			local doorPos = controller.taskparam.exitDoorPos
			controller.taskparam.exitDoorPos = nil

			pet:setPosition(doorPos.x, (doorPos.y or 0) + 10, doorPos.z)
			pet:getNavigator():clearPathEntity()
		end

		if controller.taskparam.path then
			pet:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
		else
			local targetPos = controller.taskparam.targetPos

			if targetPos then
				pet:getNavigator():tryMoveTo(targetPos.x, targetPos.y, targetPos.z, speed, path_range)
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local objid = controller.taskparam.petobjid
		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or not pet:alive() then
			return controller.fail()
		end

		local targetPos = controller.taskparam.targetPos

		if not targetPos then
			return controller.fail()
		end

		local approachDis = controller.taskparam.approachDis or 0.5 * BLOCK_SIZE
		local checkTag = LocalXZSqDist(pet:getPosition(), targetPos) <= math.pow(approachDis, 2) or pet:getNavigator():noPath()

		if not checkTag then
			controller.wait_until(function ()
				if not pet or tolua.isnull(pet) or not pet:alive() then
					return true
				end

				return LocalXZSqDist(pet:getPosition(), targetPos) <= math.pow(approachDis, 2) or pet:getNavigator():noPath()
			end)
			pet:getNavigator():clearPathEntity()
		end

		if math.pow(approachDis, 2) < LocalXZSqDist(pet:getPosition(), targetPos) then
			return controller.fail()
		end

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local objid = controller.taskparam.petobjid
		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or tolua.isnull(pet) or not pet:alive() then
			return false
		end

		local targetPos = controller.taskparam.targetPos
		local approachDis = controller.taskparam.approachDis or 1 * BLOCK_SIZE

		if targetPos and math.pow(approachDis, 2) < LocalXZSqDist(pet:getPosition(), targetPos) and not pet:getNavigator():noPath() then
			local path_range = btget_path_range()

			if pet:getNavigator():tryMoveTo(targetPos.x, targetPos.y, targetPos.z, 1, path_range) then
				return true
			else
				return false
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		if selfActor and selfActor:alive() then
			local objid = controller.taskparam.petobjid
			local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

			if pet and pet:alive() then
				pet:getNavigator():clearPathEntity()
			end
		end

		controller.taskparam.targetPos = nil
		controller.taskparam.path = nil
		controller.taskparam.approachDis = nil
		controller.taskparam.exitDoorPos = nil
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local petobjid = result[1]
		lcontroller.taskparam.petobjid = petobjid

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = petobjid or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
