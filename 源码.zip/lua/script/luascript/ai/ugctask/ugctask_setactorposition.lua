return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local pos = controller.taskparam.pos

		if not objid or not pos then
			return controller.fail()
		end

		local px = pos.x and pos.x * 100
		local py = pos.y and pos.y * 100
		local pz = pos.z and pos.z * 100

		if not px or not py or not pz then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local locomotion = targetActor:getLocoMotion()

		if locomotion then
			locomotion:gotoPosition(WCoord(px, py, pz))

			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid",
			"pos"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local pos = result[2]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.pos = pos

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "pos",
				val = pos
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
