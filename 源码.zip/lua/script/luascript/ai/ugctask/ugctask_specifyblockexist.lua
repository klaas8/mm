return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local blockid = controller.taskparam.blockid
		local position = controller.taskparam.position

		if not position or not blockid then
			return controller.fail()
		end

		local x = position.x
		local y = position.y
		local z = position.z
		local world = CurWorld
		local actor = controller.target.get()

		if actor then
			world = actor:getWorld()
		end

		if Service and Service.Block then
			local cblockid = Service.Block:GetBlockID(x, y, z, world:getCurMapID())

			if cblockid and blockid == cblockid then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local position = result[1]
		local blockid = result[2]
		lcontroller.taskparam.position = position
		lcontroller.taskparam.blockid = blockid
		local data1 = {
			valtype = "pos",
			val = position
		}
		local data2 = {
			valtype = "blocktype",
			val = {
				blockid = blockid
			}
		}

		lcontroller.sendValToDebug({
			data1,
			data2
		})
	end
}
