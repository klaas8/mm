return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)
		local slot = controller.taskparam.slot

		if type(slot) == "string" then
			slot = tonumber(slot)
		end

		if slot >= 8000 then
			slot = slot - 8000
		end

		if slot == nil or slot < EQUIP_HEAD or MAX_EQUIP_SLOTS <= slot then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "paramErrNoSlot",
					slot = slot
				}

				controller.sendMsgToAi(selfActor, "UGCTask_UnequipItemToInventory", errinfo)
			end

			return controller.fail()
		end

		local ret, errinfo = AIFunctionMgr:UnequipItemToInventory(selfActor, slot, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfActor, "UGCTask_UnequipItemToInventory", errinfo)
		end

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local slot = result[1]
		lcontroller.taskparam.slot = slot

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = slot or 0
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
