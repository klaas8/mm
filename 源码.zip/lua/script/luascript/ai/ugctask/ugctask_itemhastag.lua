return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local itemid = controller.taskparam.itemid
		local tag = controller.taskparam.tag
		local cmpEnumType = controller.taskparam.cmpEnumType

		if not itemid or not tag or not cmpEnumType then
			return controller.fail()
		end

		if type(itemid) == "string" then
			itemid = Service.Mod:GetCfgIdByAssetId(itemid)
		end

		if itemid <= 0 then
			return controller.fail()
		end

		local searchType = controller.taskparam.searchType
		searchType = searchType or 2
		local ret = AIFunctionMgr:ItemHasTag(itemid, tag, searchType)

		if cmpEnumType == "==" then
			if ret then
				return controller.success()
			end
		elseif cmpEnumType == "~=" and not ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local itemid = result[1]
		local cmpEnumType = result[2]
		local tag = result[3]
		local searchType = result[4]
		lcontroller.taskparam.searchType = searchType
		lcontroller.taskparam.itemid = itemid
		lcontroller.taskparam.cmpEnumType = cmpEnumType
		local debugtag = ""
		local needSendDebug = lcontroller:isNeedSendDebug()
		lcontroller.taskparam.tag, debugtag = lBTService:DealTagToArrayData(tag, needSendDebug)

		if needSendDebug and itemid > 0 then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemid or 0
				}
			}
			local data2 = {
				valtype = "getName",
				val = cmpEnumType
			}
			local data3 = {
				valtype = "enum"
			}
			local data4 = {
				valtype = "val",
				val = debugtag
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
