return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local soundId = controller.taskparam.soundId
		local pos = controller.taskparam.pos

		if not soundId or not pos or type(pos) ~= "table" then
			return controller.fail()
		end

		local ret = ErrorCode.FAILED

		if Service and Service.World then
			ret = Service.World:StopSoundEffectOnPos(pos, soundId)
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local pos = result[1]
		local soundId = result[2]
		lcontroller.taskparam.pos = pos
		lcontroller.taskparam.soundId = soundId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = pos
			}
			local data2 = {
				valtype = "sound",
				val = {
					effectid = soundId
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
