return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local teamid = controller.taskparam.teamid

		if not objid or not teamid then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetObj = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetObj then
			return controller.fail()
		end

		local actorLiving = tolua.cast(targetObj, "ActorLiving")

		if not actorLiving then
			return controller.fail()
		end

		actorLiving:setTeam(teamid)

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local teamid = result[2]
		lcontroller.taskparam.objid = objid
		local realTeamId = lBTService:GetFactorType(teamid)
		lcontroller.taskparam.teamid = realTeamId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid
				}
			}
			local data2 = {
				valtype = "enum",
				val = realTeamId
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
