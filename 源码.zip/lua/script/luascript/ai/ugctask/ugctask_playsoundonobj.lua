return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local soundId = controller.taskparam.soundId
		local volume = controller.taskparam.volume
		local obj = controller.taskparam.obj
		local loop = controller.taskparam.loop
		local stopall = controller.taskparam.stopall

		if not soundId or not volume or not obj or loop == nil then
			return controller.fail()
		end

		local ret = ErrorCode.FAILED

		if stopall then
			ActorComponentCallModule(selfActor, "SoundComponent", "stopSoundByTrigger", "")
		end

		if Service and Service.Actor then
			local world = CurWorld

			if selfActor then
				world = selfActor:getWorld()
			end

			ret = Service.Actor:PlaySoundEffectById(obj, soundId, volume, 1, loop, world:getCurMapID())
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 5, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4,
				5
			})
		end

		local obj = result[1]
		local soundId = result[2]
		local volume = result[3]
		local loop = result[4]
		local stopall = result[5]

		if type(stopall) == "string" then
			if stopall == "==" then
				stopall = true
			else
				stopall = false
			end
		else
			stopall = false
		end

		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.soundId = soundId
		lcontroller.taskparam.volume = volume
		lcontroller.taskparam.stopall = stopall
		local newLoop = lBTService:GetBoolVal(loop)
		lcontroller.taskparam.loop = newLoop

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "sound",
				val = {
					effectid = soundId
				}
			}
			local data3 = {
				valtype = "val",
				val = volume
			}
			local data4 = {
				valtype = "val",
				val = newLoop
			}
			local data5 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4,
				data5
			})
		end
	end
}
