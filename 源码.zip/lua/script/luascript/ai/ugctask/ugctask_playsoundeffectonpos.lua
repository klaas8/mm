return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local soundId = controller.taskparam.soundId
		local volume = controller.taskparam.volume
		local position = controller.taskparam.position
		local loop = controller.taskparam.loop

		if type(position) ~= "table" then
			return controller.fail()
		end

		local ret = ErrorCode.FAILED

		if Service and Service.World then
			local world = CurWorld
			local actor = controller.target.get()

			if actor then
				world = actor:getWorld()
			end

			ret = Service.World:PlaySoundEffectOnPos(position, soundId, volume, 1, loop, world:getCurMapID())
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetPos = result[1]
		local soundId = result[2]
		local volume = result[3]
		local loop = result[4]
		lcontroller.taskparam.position = targetPos
		lcontroller.taskparam.soundId = soundId
		lcontroller.taskparam.volume = volume
		local newLoop = lBTService:GetBoolVal(loop)
		lcontroller.taskparam.loop = newLoop

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = targetPos
			}
			local data2 = {
				valtype = "sound",
				val = {
					effectid = soundId
				}
			}
			local data3 = {
				valtype = "val",
				val = volume
			}
			local data4 = {
				valtype = "val",
				val = newLoop
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
