local function extractItemTypes(source)
	local result = {}

	for _, value in ipairs(source) do
		if type(value) == "table" and value.itemid then
			if type(value.itemid) == "string" then
				result[BTService:ResidToId(value.itemid)] = true
			else
				result[value.itemid] = true
			end
		else
			if type(value) == "string" then
				result[BTService:ResidToId(value)] = true
			end

			result[value] = true
		end
	end

	return result
end

return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local param_obj = controller.taskparam.param_obj
		local param_group_set = controller.taskparam.param_group_set

		if not param_obj or not param_group_set then
			return controller.fail()
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, param_obj)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			return controller.fail()
		end

		local itemType = AIFunctionMgr:GetHoldItemId(targetActor)

		if param_group_set[itemType] then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local param_obj = result[1]
		local param_group = result[2]
		lcontroller.taskparam.param_obj = param_obj
		local group_set = nil

		if param_group and param_group.size then
			group_set = {}
			local size = param_group:size()

			for i = 0, size - 1 do
				group_set[param_group[i]] = true
			end
		elseif type(param_group) == "table" then
			group_set = extractItemTypes(param_group)
		else
			local itemTypes = lBTService:GetGroupData(param_group, VARTYPE.ITEMTYPEGROUP, lcontroller)

			if type(itemTypes) == "table" then
				group_set = extractItemTypes(itemTypes)
			else
				group_set = {}
			end
		end

		lcontroller.taskparam.param_group_set = group_set

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = param_obj or 0
				}
			}
			local data2 = {
				valtype = "getName",
				val = param_group
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
