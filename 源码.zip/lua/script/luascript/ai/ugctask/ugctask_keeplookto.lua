return {
	run = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local targetObjId = controller.taskparam.targetObjId
		local time = controller.taskparam.time
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() or time == nil then
			return controller.fail()
		end

		local ret = selfActor:KeepLookAtActor(targetActor)

		if not ret then
			return controller.fail()
		end

		controller.wait(time)
		selfActor:StopLookAtActor()

		return controller.success()
	end,
	onend = function ()
		local selfActor = controller.target.get("living")

		selfActor:StopLookAtActor()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local targetObjId = result[1]
		local time = result[2]
		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.time = time

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = time
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
