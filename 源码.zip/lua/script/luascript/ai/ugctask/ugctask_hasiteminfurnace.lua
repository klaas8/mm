return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local item = controller.taskparam.item

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		local pos = controller.taskparam.pos

		if not pos or not item then
			return controller.fail()
		end

		local x = pos.x
		local y = pos.y
		local z = pos.z
		local ret = AIFunctionMgr:HasItemInFurnace(selfActor, item, x, y, z)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid",
			"buffid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local pos = result[1]
		local item = result[2]
		lcontroller.taskparam.pos = pos
		lcontroller.taskparam.item = item

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = pos
			}
			local data2 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
