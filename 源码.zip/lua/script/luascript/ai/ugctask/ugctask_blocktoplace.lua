return {
	will = function ()
		local pos = controller.taskparam.position
		local blockid = controller.taskparam.blockid

		if type(pos) ~= "table" or not blockid then
			return false
		end

		if not pos.x or not pos.y or not pos.z then
			return false
		end

		local selfMob = controller.target.get("living")

		if not selfMob or not selfMob:alive() then
			return false
		end

		if not GameplayTagUtils:IsPlaceCubeEnabled(selfMob) then
			return false
		end

		return true
	end,
	onbeg = function ()
		local actor = controller.target.get()
		local pos = controller.taskparam.position
		local x, y, z = BlockBottomCoord(pos.x, pos.y, pos.z)
		local path_range = btget_path_range()

		actor:getNavigator():tryMoveTo(x, y, z, 1.2, path_range)

		controller.taskparam.targetPos = {
			x = x,
			y = y,
			z = z
		}
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local targetPos = controller.taskparam.targetPos
		local maxdistance = math.pow(BLOCK_SIZE * 2.5, 2)
		local distance = PosSquareDistanceToPos(selfobj:getPosition(), targetPos)

		while not selfobj:getNavigator():noPath() or maxdistance < distance do
			if distance <= maxdistance or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), targetPos)

			controller.wait()
		end

		local face = controller.taskparam.face
		local pos = controller.taskparam.position
		local blockid = controller.taskparam.blockid
		local x = pos.x
		local y = pos.y
		local z = pos.z
		local ret = false
		local objtype = selfobj:getObjType()
		local bigtype = GameActorTypeToObjType[objtype]

		if bigtype == OBJ_TYPE.OBJTYPE_CREATURE then
			local selfMob = tolua.cast(selfobj, "ClientMob")

			if selfMob and selfMob.placeBlock then
				if not CheckItemScriptUse(blockid) then
					return controller.fail()
				end

				ret = selfMob:placeBlock(blockid, x, y, z, face or 0)
			end
		else
			local world = CurWorld
			local actor = controller.target.get()

			if actor then
				world = actor:getWorld()
			end

			local result = Service.Block:PlaceBlock(blockid, x, y, z, face or 0, world:getCurMapID())

			if result then
				ret = true
			end
		end

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local position = result[1]
		local blockid = result[2]
		local face = result[3]
		blockid = lBTService:ResidToId(blockid)
		lcontroller.taskparam.position = position
		lcontroller.taskparam.blockid = blockid
		local realFace = lBTService:GetFactorType(face)
		lcontroller.taskparam.face = realFace

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = position
			}
			local data2 = {
				valtype = "blocktype",
				val = {
					blockid = blockid
				}
			}
			local data3 = {
				valtype = "enum",
				val = realFace
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
