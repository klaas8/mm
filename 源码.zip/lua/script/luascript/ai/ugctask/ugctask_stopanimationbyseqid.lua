local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local seqId = result[1]
		lcontroller.taskparam.ugc_seqId = seqId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = seqId
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()
		local seq = controller.taskparam.ugc_seqId

		if seq == nil or not selfActor or not selfActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local seq = controller.taskparam.ugc_seqId

		if seq == nil or not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		selfActor:skillStopAnim(seq, 0, false)

		return controller.success()
	end,
	onend = function ()
	end
}
