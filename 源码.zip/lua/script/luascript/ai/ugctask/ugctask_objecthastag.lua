return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid

		if not objid then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			return controller.fail()
		end

		local tag = controller.taskparam.tag
		local cmpEnumType = controller.taskparam.cmpEnumType

		if not cmpEnumType or not tag then
			return controller.fail()
		end

		local searchType = controller.taskparam.searchType
		searchType = searchType or 2
		local ret = AIFunctionMgr:ObjHasTag(targetActor, tag, searchType)

		if cmpEnumType == "==" then
			if ret then
				return controller.success()
			end
		elseif cmpEnumType == "~=" and not ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local objid = result[1]
		local cmpEnumType = result[2]
		local tag = result[3]
		local searchType = result[4]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.cmpEnumType = cmpEnumType
		lcontroller.taskparam.searchType = searchType
		local debugtag = ""
		local needSendDebug = lcontroller:isNeedSendDebug()
		lcontroller.taskparam.tag, debugtag = lBTService:DealTagToArrayData(tag, needSendDebug, lcontroller.taskparam.tag)

		if needSendDebug then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "getName",
				val = cmpEnumType
			}
			local data3 = {
				valtype = "enum"
			}
			local data4 = {
				valtype = "val",
				val = debugtag
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
