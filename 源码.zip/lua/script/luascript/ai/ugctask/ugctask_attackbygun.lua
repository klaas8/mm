local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local itemId = result[1]
		local objid = result[2]
		local distance = result[3]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.needtime = true
		itemId = lBTService:ResidToId(itemId)

		if not lcontroller.taskparam.ballcount then
			lcontroller.taskparam.ballcount = 0
		end

		lcontroller.taskparam.needGetGuninfo = false

		if lcontroller.taskparam.itemId == nil then
			lcontroller.taskparam.ballcount = 0
			lcontroller.taskparam.needGetGuninfo = true
		elseif lcontroller.taskparam.itemId ~= itemId then
			lcontroller.taskparam.ballcount = 0
			lcontroller.taskparam.needGetGuninfo = true
		end

		lcontroller.taskparam.itemId = itemId

		if not lcontroller.taskparam.gunState then
			lcontroller.taskparam.gunState = 1
		end

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId or 0
				}
			}
			local data2 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data3 = {
				valtype = "val",
				val = distance
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end,
	will = function ()
		local objid = controller.taskparam.objid

		if not objid or objid <= -1 then
			return false
		end

		local itemId = controller.taskparam.itemId
		local distance = controller.taskparam.distance

		if not itemId or not distance then
			return false
		end

		local selfObj = controller.target.get("living")
		local targetObj = AIFunctionMgr:getActorByObjId(selfObj, objid)

		if not targetObj or not targetObj:alive() then
			return false
		end

		if not GameplayTagUtils:IsNormalAttackEnabled(selfObj) then
			return false
		end

		local position = targetObj:getPosition()
		local currdist = PosSquareDistanceToPos(selfObj:getPosition(), position)

		if math.pow(BLOCK_SIZE * distance, 2) < currdist then
			return false
		else
			controller.taskparam.targetPos = nil
		end

		return true
	end,
	onbeg = function ()
		local selfObj = controller.target.get()
		local weaponId = controller.taskparam.itemId

		if not AIFunctionMgr:isEquipGun(selfObj, weaponId) then
			AIFunctionMgr:EquipGun(selfObj, weaponId)
		end

		local objid = selfObj:getObjId()

		if controller.taskparam.needGetGuninfo or controller.taskparam.maxAmmo == nil then
			local result, maxAmmo, range, reloadPhaseTime, rpm = AIFunctionMgr:GetGunInfo(selfObj, 0, 0, 0, 0)

			if rpm == 0 then
				rpm = 1
			end

			controller.taskparam.rpm = 1 / rpm
			controller.taskparam.phaseTime = reloadPhaseTime
			controller.taskparam.maxAmmo = maxAmmo
		end

		local targetPos = controller.taskparam.targetPos
		selfObj.IsStopBodyRotation = false

		if targetPos ~= nil then
			local path_range = btget_path_range()
			local x = targetPos.x
			local y = targetPos.y
			local z = targetPos.z

			selfObj:getNavigator():tryMoveTo(x, y, z, 1.2, path_range)
		end

		controller.taskparam.isSkip = false
		controller.taskparam.hitHeadRate = 0
		controller.taskparam.hitRate = 1
		controller.taskparam.reloadAdvanceProb = 0
		controller.taskparam.reloadSpeedRate = 0.4

		if controller.taskparam.worldobj == nil then
			controller.taskparam.worldobj = UGCGetInst("GameObjectMgr"):GetWorld()

			if controller.taskparam.worldobj then
				local cmp = controller.taskparam.worldobj:GetComponent("ZombieSurvivalAttributesMgr")

				if cmp then
					controller.taskparam.WorldCmp = cmp

					if cmp.GetHitHeadRate then
						controller.taskparam.GetHitHeadRate = cmp.GetHitHeadRate
					end

					if cmp.GetHitRate then
						controller.taskparam.GetHitRate = cmp.GetHitRate
					end

					if cmp.GetReloadAdvanceProb then
						controller.taskparam.GetReloadAdvanceProb = cmp.GetReloadAdvanceProb
					end

					if cmp.GetReloadSpeedRate then
						controller.taskparam.GetReloadSpeedRate = cmp.GetReloadSpeedRate
					end
				end
			end
		end

		if controller.taskparam.WorldCmp and controller.taskparam.WorldCmp:IsValid() then
			if controller.taskparam.GetHitHeadRate then
				local result = controller.taskparam.GetHitHeadRate(controller.taskparam.WorldCmp, objid)

				if result ~= nil then
					controller.taskparam.hitHeadRate = result
				end
			end

			if controller.taskparam.GetHitRate then
				local result = controller.taskparam.GetHitRate(controller.taskparam.WorldCmp, objid)

				if result ~= nil then
					controller.taskparam.hitRate = result
				end
			end

			if controller.taskparam.GetReloadAdvanceProb then
				local result = controller.taskparam.GetReloadAdvanceProb(controller.taskparam.WorldCmp, objid)

				if result ~= nil then
					controller.taskparam.reloadAdvanceProb = result
				end
			end

			if controller.taskparam.GetReloadSpeedRate then
				local result = controller.taskparam.GetReloadSpeedRate(controller.taskparam.WorldCmp, objid)

				if result ~= nil then
					controller.taskparam.reloadSpeedRate = result
				end
			end
		end

		if controller.taskparam.selfobj == nil then
			controller.taskparam.selfobj = Service.GameObject:FindObject(objid)

			if controller.taskparam.selfobj then
				local cmp = controller.taskparam.selfobj:GetComponent("ZombieSurvival")

				if cmp then
					controller.taskparam.selfobjcmp = cmp

					if cmp.IsSkipReload then
						controller.taskparam.selfobjIsSkipReload = cmp.IsSkipReload
					end
				end
			end
		end

		if controller.taskparam.selfobjcmp then
			local result = controller.taskparam.selfobjIsSkipReload(controller.taskparam.selfobjcmp)

			if result ~= nil then
				controller.taskparam.isSkip = result
			end
		end
	end,
	run = function ()
		local selfObj = controller.target.get()
		local targetPos = controller.taskparam.targetPos

		if targetPos ~= nil then
			local distance = controller.taskparam.distance
			local distance_ = math.pow(BLOCK_SIZE * distance, 2)
			local currdist = PosSquareDistanceToPos(selfObj:getPosition(), targetPos)

			if distance_ < currdist then
				return controller.fail()
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfObj, controller.taskparam.objid)
		local targetObjid = controller.taskparam.objid

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local controllerSelfobj = controller.taskparam.selfobj
		local lenth = 0

		if controller.taskparam.pretime then
			lenth = controller.taskparam.currenttime - controller.taskparam.pretime
			controller.taskparam.pretime = controller.taskparam.currenttime
		else
			controller.taskparam.pretime = controller.taskparam.currenttime
		end

		if lenth > 1 then
			lenth = 0
		end

		local ballcount = controller.taskparam.ballcount
		local maxAmmo = controller.taskparam.maxAmmo
		local phaseTime = controller.taskparam.phaseTime
		local rpm = controller.taskparam.rpm
		local reloadSpeedRate = controller.taskparam.reloadSpeedRate

		if reloadSpeedRate ~= nil then
			rpm = rpm * reloadSpeedRate
		end

		local sendcount = 1

		if lenth > 0 and rpm > 0 then
			if not controller.taskparam.lasttime then
				controller.taskparam.lasttime = 0
			end

			sendcount = math.floor((controller.taskparam.lasttime + lenth) / rpm)

			if sendcount > 0 then
				controller.taskparam.lasttime = lenth + controller.taskparam.lasttime - sendcount * rpm
			else
				controller.taskparam.lasttime = 0
				sendcount = 1
			end
		else
			controller.taskparam.lasttime = 0
		end

		local function reload()
			local objid = selfObj:getObjId()

			if controllerSelfobj then
				controllerSelfobj:PushCustomEvent("SurvivalReloadBullet")
			end

			controller.taskparam.ballcount = 0
			ballcount = controller.taskparam.ballcount

			AIFunctionMgr:PlayGunAction(selfObj, 3)
			controller.wait(phaseTime)
		end

		if not controller.taskparam.isSkip then
			if ballcount >= maxAmmo / 2 then
				local reloadAdvanceProb = controller.taskparam.reloadAdvanceProb

				if reloadAdvanceProb ~= nil then
					local result = BTGetRandValue(1, 100)

					if result < reloadAdvanceProb then
						reload()
					end
				end
			end

			if maxAmmo <= ballcount then
				reload()
			end
		end

		local aattackTypes = std.vector_int_()
		local tattackType = {}
		local hitRate = controller.taskparam.hitRate
		local hitHeadRate = controller.taskparam.hitHeadRate

		for i = 0, sendcount - 1 do
			attackType = 1

			if hitRate ~= nil then
				local result = BTGetRandValue(1, 100)

				if result < hitRate then
					if hitHeadRate ~= nil then
						result = BTGetRandValue(1, 100)

						if result < hitHeadRate then
							attackType = 2
						end
					end
				else
					attackType = 0
				end
			end

			aattackTypes:push_back(attackType)
			table.insert(tattackType, attackType)
		end

		if controllerSelfobj and #tattackType > 0 then
			controllerSelfobj:PushCustomEvent("SurvivalAttackResult", tattackType)
		end

		targetActor = AIFunctionMgr:getActorByObjId(selfObj, targetObjid)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfObj, targetActor)

		local ret = AIFunctionMgr:DoGunAttacks(selfObj, targetActor, aattackTypes)

		if ret then
			controller.taskparam.ballcount = ballcount + sendcount

			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
		local selfObj = controller.target.get()

		selfObj:getNavigator():clearPathEntity()
	end
}
