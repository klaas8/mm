return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local moveType = controller.taskparam.moveType

		if objid <= 0 then
			return controller.fail()
		end

		local selfObj = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfObj, objid)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			return controller.fail()
		end

		if targetActor.setFlying then
			targetActor:setFlying(moveType == MOVETYPE.FLY)

			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid",
			"moveType"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local moveType = result[2]
		lcontroller.taskparam.objid = objid
		moveType = lBTService:GetFactorType(moveType)
		lcontroller.taskparam.moveType = moveType

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "enum",
				val = moveType
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
