local TEST_TEST_TEST = false
local once = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId, particleId = nil

		if TEST_TEST_TEST then
			particleId = 1232
			targetObjId = CurMainPlayer:getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 2, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2
				})
			end

			particleId = result[2]
			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId
		lcontroller.taskparam.ugc_particleId = particleId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "effecttype",
				val = {
					effectid = particleId
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	will = function ()
		if TEST_TEST_TEST then
			if once then
				return false
			end

			once = true
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local particleId = controller.taskparam.ugc_particleId
		local ret = false

		if Service and Service.Actor then
			ret = Service.Actor:StopBodyEffectById(controller.taskparam.ugc_targetObjId, particleId)
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
