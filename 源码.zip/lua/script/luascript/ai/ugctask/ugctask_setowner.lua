return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor then
			return controller.fail()
		end

		local ownerObj = controller.taskparam.ownerObj
		local setobj = controller.taskparam.setobj

		if not setobj or not ownerObj then
			return controller.fail()
		end

		local setobjActor = AIFunctionMgr:getActorByObjId(selfActor, setobj)
		local owner = AIFunctionMgr:getActorByObjId(selfActor, ownerObj)

		if not owner or not setobjActor then
			return controller.fail()
		end

		local ret = AIFunctionMgr:SetOwner(setobjActor, owner)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local setobj = result[1]
		local ownerObj = result[2]
		lcontroller.taskparam.ownerObj = ownerObj
		lcontroller.taskparam.setobj = setobj

		if lcontroller:isNeedSendDebug() then
			local data2 = {
				valtype = "actor",
				val = {
					actor = ownerObj or 0
				}
			}
			local data1 = {
				valtype = "actor",
				val = {
					actor = setobj or 0
				}
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
