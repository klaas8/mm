return {
	run = function ()
		if not controller.taskparam.range then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local ret = AIFunctionMgr:SurvivalPick(selfActor, controller.taskparam.range)

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local range = result[1]
		lcontroller.taskparam.range = range

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = range
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
