return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local obj = result[1]
		local isUnsighted = result[2]
		isUnsighted = isUnsighted == "==" and true or false
		lcontroller.taskparam.isUnsighted = isUnsighted
		lcontroller.taskparam.obj = obj

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = isUnsighted
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	run = function ()
		if controller.taskparam.isUnsighted == nil or not controller.taskparam.obj then
			return controller.fail()
		end

		local selfObj = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfObj, controller.taskparam.obj)

		if not targetActor then
			return controller.fail()
		end

		targetActor:setUnsighted(not controller.taskparam.isUnsighted)

		return controller.success()
	end
}
