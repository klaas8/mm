return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local id = controller.taskparam.id
		local graphicsType = controller.taskparam.graphicsType

		if objid == nil or id == nil or graphicsType == nil then
			return controller.fail()
		end

		local actor = controller.target.get()
		local world = CurWorld

		if actor then
			world = actor:getWorld()
		end

		local ret = false

		if GraphicsManager and GraphicsManager.haveGraphics then
			ret = GraphicsManager:haveGraphics(objid, id, graphicsType)
		elseif world and world.haveGraphics then
			ret = world:haveGraphics(objid, id, graphicsType)
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objid = result[1]
		local id = result[2]
		local graphicsType = result[3]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.id = id
		lcontroller.taskparam.graphicsType = lBTService:GetEnumValue(graphicsType)

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = id
			}
			local data3 = {
				valtype = "enum",
				val = graphicsType
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
