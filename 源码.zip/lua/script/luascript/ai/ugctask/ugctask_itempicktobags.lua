return {
	onbeg = function ()
		local obj = controller.target.get()
		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(obj)
		local range = controller.taskparam.range
		local itemId = controller.taskparam.itemId
		local ret = false
		local targetId = 0
		local px = 0
		local py = 0
		local pz = 0
		ret, targetId, px, py, pz = AIFunctionMgr:GetNearestActorPos(obj, itemId, 0, 2, range, 0, 0, 0)

		if ret then
			local pos_x, pos_y, pos_z = BlockBottomCoord(px, py, pz)

			if not obj:TryGetPathToPos(pos_x, pos_y, pos_z) then
				if controller.taskparam.needErrInfo then
					local errinfo = {
						info = "noTargetReachable",
						itemid = itemId,
						range = range,
						x = pos_x,
						y = pos_y,
						z = pos_z
					}

					controller.sendMsgToAi(obj, "UGCTask_ItemPickToBags", errinfo)
				end

				return
			end

			if obj:getNavigator() then
				local path_range = btget_path_range()

				obj:getNavigator():tryMoveTo(pos_x, pos_y, pos_z, 1, path_range)
			end

			controller.taskparam.targetId = targetId
			controller.taskparam.targetPos = {
				x = pos_x,
				y = pos_y,
				z = pos_z
			}
		elseif controller.taskparam.needErrInfo then
			local errinfo = {
				info = "noTarget",
				itemid = itemId,
				range = range
			}

			controller.sendMsgToAi(obj, "UGCTask_ItemPickToBags", errinfo)
		end
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get("living")

		if not selfobj or not selfobj:alive() then
			return controller.fail()
		end

		if not GameplayTagUtils:IsPickItemEnabled(selfobj) then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noPickItemTag"
				}

				controller.sendMsgToAi(selfobj, "UGCTask_ItemPickToBags", errinfo)
			end

			return controller.fail()
		end

		local range = controller.taskparam.range
		local itemId = controller.taskparam.itemId
		local target_pos = controller.taskparam.targetPos

		if not target_pos then
			return controller.fail()
		end

		local pickDistance = controller.taskparam.pickDistance

		if target_pos then
			local checkTag = Pos3SquareDistToPos3(selfobj:getPosition(), target_pos) <= pickDistance

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfobj:getPosition(), target_pos) <= pickDistance or selfobj:getNavigator():noPath()
				end)
				selfobj:getNavigator():clearPathEntity()
			end
		end

		local ret = Pos3SquareDistToPos3(selfobj:getPosition(), target_pos) <= pickDistance * 3

		if not ret then
			return controller.fail()
		end

		local ss_actor = BTService:GetSSObj("Actor")
		local ret, targetObj = ss_actor:getActorByObjid(controller.taskparam.targetId)

		if ret == ErrorCode.OK and targetObj ~= nil then
			local itemId = targetObj.GetItemId and targetObj:GetItemId() or 0
			local itemNum = targetObj.getDropItemNum and targetObj:getDropItemNum() or 0

			if AIFunctionMgr:checkPutItem(selfobj, itemId, itemNum) then
				can_do_pick = true

				AIFunctionMgr:playSound(selfobj, "npc.pick", 1, 1, 2)
				AIFunctionMgr:pickItem(selfobj, targetObj)

				if controller.taskparam.needErrInfo then
					local errinfo = {
						info = "pickSuccess",
						itemid = itemId,
						range = range,
						itemNum = itemNum
					}

					controller.sendMsgToAi(selfobj, "UGCTask_ItemPickToBags", errinfo)
				end

				return controller.success()
			elseif controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noBagSpace",
					itemid = itemId,
					range = range
				}

				controller.sendMsgToAi(selfobj, "UGCTask_ItemPickToBags", errinfo)
			end
		elseif controller.taskparam.needErrInfo then
			local errinfo = {
				info = "targetNoExit",
				itemid = itemId,
				range = range,
				targetId = controller.taskparam.targetId
			}

			controller.sendMsgToAi(selfobj, "UGCTask_ItemPickToBags", errinfo)
		end

		return controller.fail()
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local pickDistance = controller.taskparam.pickDistance

			if pickDistance < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) and selfActor:getNavigator():noPath() then
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"range",
			"itemId"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local range = result[1]
		local itemId = result[2]
		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.range = range
		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.pickDistance = 100 * BLOCK_SIZE

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = range
			}
			local data2 = {
				valtype = "itemtype",
				val = {
					itemid = itemId
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
