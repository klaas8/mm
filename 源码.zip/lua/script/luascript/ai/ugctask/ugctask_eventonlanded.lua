local function extractParamValue(param)
	if type(param) == "function" then
		return param.get()
	else
		return param
	end
end

return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		return controller.success()
	end
}
