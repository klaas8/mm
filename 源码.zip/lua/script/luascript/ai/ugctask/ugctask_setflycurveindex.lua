return {
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local obj = result[1]
		local index = result[2]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.index = index

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "var",
				val = index
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local objid = controller.taskparam.obj
		local index = controller.taskparam.index

		if objid == nil or index == nil then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if targetActor and targetActor:alive() then
			local moveComp = targetActor:getMoveComponent()

			if moveComp then
				moveComp:SetCurflyCurveIndex(index - 1)

				return controller.success()
			end
		end

		return controller.fail()
	end
}
