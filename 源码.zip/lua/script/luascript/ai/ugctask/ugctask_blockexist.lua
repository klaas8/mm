return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local position = controller.taskparam.position

		if type(position) ~= "table" then
			return controller.fail()
		end

		local x = position.x
		local y = position.y
		local z = position.z
		local world = CurWorld
		local actor = controller.target.get()

		if actor then
			world = actor:getWorld()
		end

		local blockid = Service.Block:GetBlockID(x, y, z, world:getCurMapID())

		if blockid and blockid ~= 0 and blockid ~= BLOCK_PLANTSPACE_OXYGEN then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local position = result[1]
		lcontroller.taskparam.position = position

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = position
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
