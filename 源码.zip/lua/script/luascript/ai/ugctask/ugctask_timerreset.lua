return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local timerId = controller.taskparam.timerId
		local ret = BTService:StopTimer(timerId)

		if ret then
			ret = BTService:StartForwardTimer(timerId)

			if ret then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"timerId"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local timerId = result[1]
		lcontroller.taskparam.timerId = timerId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "timer",
				val = {
					timerid = timerId
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
