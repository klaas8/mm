return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local bbkey = controller.taskparam.bbkey
		local areaId = controller.taskparam.bbareaId

		if not bbkey or not areaId or areaId < 0 then
			return controller.fail()
		end

		local result = false

		if type(bbkey) == "table" then
			if bbkey.func and type(bbkey.func) == "function" then
				result = bbkey.func({
					value = areaId,
					controller = controller
				})
			end
		else
			result = controller.bb.set(bbkey, {
				areaid = areaId
			})
		end

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local bbkey = result[1]
		local areaId = result[2]
		lcontroller.taskparam.bbkey = bbkey
		lcontroller.taskparam.bbareaId = areaId

		if lcontroller:isNeedSendDebug() then
			local data1 = nil

			if type(bbkey) == "string" then
				data1 = {
					valtype = "val",
					val = lcontroller.bb.getName(bbkey)
				}
			else
				data1 = {
					valtype = "getName"
				}
			end

			local data2 = {
				valtype = "area",
				val = lBTService:GetAreaDebugData(areaId)
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
