return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local ret = AIFunctionMgr:HandToBag(selfActor)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	onend = function ()
	end,
	send_debug_data = function ()
		local k = 5
	end
}
