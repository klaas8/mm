return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local targetObjIds = controller.taskparam.targetObjIds
		local attrType = controller.taskparam.attrType
		local operateType = controller.taskparam.operateType
		local attrValue = controller.taskparam.attrValue

		if not targetObjIds or not attrType or not operateType or not attrValue then
			return controller.fail()
		end

		local success = false

		for index = 1, #targetObjIds do
			local targetObj = {
				objType = "Player",
				actor = targetObjIds[index]
			}
			local ret = BTService:ChangeObjAttr(targetObj, attrType, attrValue, operateType)

			if ret == ErrorCode.OK then
				success = true
			else
				return controller.fail()
			end
		end

		if success then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"targetObjs",
			"attrType",
			"operateType",
			"attrValue"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetObjIds = result[1]
		local attrType = result[2]
		local operateType = result[3]
		local attrValue = result[4]
		local targetObjIds_table = {}

		if type(targetObjIds) == "string" then
			local players = lBTService:GetGroupData(targetObjIds, VARTYPE.PLAYERGROUP, lcontroller)

			if type(players) == "table" then
				if #players > 0 then
					for index, value in ipairs(players) do
						if type(value) == "table" and value.uin then
							table.insert(targetObjIds_table, value.uin)
						else
							table.insert(targetObjIds_table, value)
						end
					end
				end
			else
				targetObjIds_table = players
			end
		elseif targetObjIds and targetObjIds.size then
			local size = targetObjIds:size()

			for i = 0, size - 1 do
				table.insert(targetObjIds_table, targetObjIds[i])
			end
		elseif type(targetObjIds) == "table" then
			if #targetObjIds > 0 then
				for index, value in ipairs(targetObjIds) do
					if value and value.uin then
						table.insert(targetObjIds_table, value.uin)
					end
				end
			end
		else
			local players = lBTService:GetGroupData(targetObjIds, VARTYPE.PLAYERGROUP, lcontroller)

			if type(players) == "table" and #players > 0 then
				for index, value in ipairs(players) do
					if value and value.uin then
						table.insert(targetObjIds_table, value.uin)
					else
						table.insert(targetObjIds_table, value)
					end
				end
			end
		end

		lcontroller.taskparam.targetObjIds = targetObjIds_table
		lcontroller.taskparam.attrType = attrType
		lcontroller.taskparam.operateType = operateType
		lcontroller.taskparam.attrValue = attrValue

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "players",
				val = targetObjIds_table
			}
			local data2 = {
				valtype = "enum",
				val = attrType
			}
			local data3 = {
				valtype = "enum",
				val = operateType
			}
			local data4 = {
				valtype = "val",
				val = attrValue
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
