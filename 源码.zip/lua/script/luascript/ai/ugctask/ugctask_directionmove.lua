return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local direction = controller.taskparam.direction
		local speed = controller.taskparam.speed
		local time = controller.taskparam.time

		if direction == nil or speed == nil or time == nil then
			return controller.fail()
		end

		local ret = false

		if type(direction) == "number" or type(direction) == "string" then
			direction = tonumber(direction)

			if direction == nil then
				return controller.fail()
			end

			ret = selfActor:getNavigator():SetDirectionMove(direction, speed)
		elseif type(direction) == "table" and direction.x ~= nil and direction.y ~= nil and direction.z ~= nil then
			ret = selfActor:getNavigator():SetDirectionMove(direction.x, direction.y, direction.z, speed)
		else
			return controller.fail()
		end

		if not ret then
			return controller.fail()
		end

		controller.wait(time)
		selfActor:getNavigator():StopDirectionMove()

		return controller.success()
	end,
	onend = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return
		end

		selfActor:getNavigator():clearPathEntity()

		controller.taskparam.direction = nil
		controller.taskparam.speed = nil
		controller.taskparam.time = nil
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local direction = result[1]
		local speed = result[2]
		local time = result[3]
		lcontroller.taskparam.direction = direction
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.time = time

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "getName"
			}
			local data2 = {
				valtype = "val",
				val = speed
			}
			local data3 = {
				valtype = "val",
				val = time
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
