return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local item = result[1]
		local isadd = result[2]
		isadd = isadd == "==" and true or false
		lcontroller.taskparam.item = item
		lcontroller.taskparam.isadd = isadd

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "item",
				val = {
					num = 1,
					itemid = item or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = isadd
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	run = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() or not controller.taskparam.item then
			return controller.fail()
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)

		if not GameplayTagUtils:IsUseItemEnabled(selfActor) then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noUseItemTag"
				}

				controller.sendMsgToAi(selfActor, "UGCTask_EatFood", errinfo)
			end

			return controller.fail()
		end

		local weaponId = controller.taskparam.item

		if AIFunctionMgr:getBagItemCount(selfActor, weaponId, false) <= 0 and controller.taskparam.isadd then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noBagItem",
					itemid = weaponId
				}

				controller.sendMsgToAi(selfActor, "UGCTask_EatFood", errinfo)
			end

			return controller.fail()
		end

		if AIFunctionMgr:getBagItemCount(selfActor, weaponId, false) <= 0 and not controller.taskparam.isadd then
			AIFunctionMgr:addItemToBags(selfActor, weaponId, 1)
		end

		AIFunctionMgr:equipWeapon(selfActor, weaponId, 1)

		local ret, errinfo = AIFunctionMgr:ActorEat(selfActor, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfActor, "UGCTask_EatFood", errinfo)
		end

		if not ret then
			return controller.fail()
		end

		controller.wait(2)

		if selfActor:isPlayer() then
			selfActor:stopAnim(SEQ_EAT)
		else
			selfActor:stopAnim(SEQ_MOBEAT)
		end

		return controller.success()
	end,
	onend = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return
		end

		if selfActor:isPlayer() then
			selfActor:stopAnim(SEQ_EAT)
		else
			selfActor:stopAnim(SEQ_MOBEAT)
		end
	end
}
