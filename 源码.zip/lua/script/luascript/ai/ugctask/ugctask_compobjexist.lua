return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid

		if not objid then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local objid = result[1]
		lcontroller.taskparam.objid = objid

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
