local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local itemId = nil

		if TEST_TEST_TEST then
			itemId = 12319
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 1, result)
			else
				result = btget_subparam(lcontroller, {
					1
				})
			end

			itemId = result[1]
		end

		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.ugc_itemId = itemId or 0

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end,
	will = function ()
		local selfActor = controller.target.get("mob")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local toolDef = DefMgr:getToolDef(controller.taskparam.ugc_itemId)

		if not toolDef then
			return false
		end

		local itemId = AIFunctionMgr:GetHoldItemId(selfActor)

		if itemId ~= controller.taskparam.ugc_itemId then
			if AIFunctionMgr:getBagItemCount(selfActor, controller.taskparam.ugc_itemId, false) <= 0 then
				AIFunctionMgr:addItemToBags(selfActor, controller.taskparam.ugc_itemId, 1)
			end

			AIFunctionMgr:equipWeapon(selfActor, controller.taskparam.ugc_itemId, 1)
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get("mob")

		selfActor:setInDefanceState(true)

		local itemId = AIFunctionMgr:GetHoldItemId(selfActor)

		if itemId >= 540000 and itemId <= 545000 then
			AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_LEFTDEFENSE, true)
		else
			AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_DEFENSE, true)
		end

		return controller.success()
	end,
	onend = function ()
	end
}
