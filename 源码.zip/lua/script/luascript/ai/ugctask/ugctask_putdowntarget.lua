return {
	send_debug_data = function ()
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		if ActorComponentCallModule(targetActor, "RiddenComponent", "isRiding") then
			return false
		end

		if ActorComponentCallModule(selfActor, "RiddenComponent", "isRidden") then
			local targetObjId = ActorComponentCallModule(selfActor, "RiddenComponent", "getRiddenByActorID", 0) or 0
			local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

			if targetActor and targetActor:alive() then
				controller.taskparam.cache_targetActor = targetActor

				return true
			end
		end

		return false
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get("living")
		local targetActor = controller.taskparam.cache_targetActor

		targetActor:mountActor_mob(nil)
		AIFunctionMgr:setFlagBit(selfActor, ACTORFLAG_AI_HOLD, false)

		return controller.success()
	end,
	onend = function ()
		controller.taskparam.cache_targetActor = nil
	end
}
