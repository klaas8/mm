return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local num = controller.taskparam.num
		local item = controller.taskparam.item

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		if num == nil or item == nil then
			return controller.fail()
		end

		if not CheckItemScriptUse(item) then
			return controller.fail()
		end

		local ret, errMsg = AIFunctionMgr:CraftOnTheGo(selfActor, item, num, "")

		controller.sendMsgToAi(selfActor, "UGCTask_CraftOnTheGo", errMsg)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local num = result[1]
		local item = result[2]
		lcontroller.taskparam.num = num
		lcontroller.taskparam.item = item

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = num
			}
			local data2 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
