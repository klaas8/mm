return {
	{
		desc = "条件节点 数值类型比较",
		script = "UGCTask_CompNumber",
		subparam = {
			param_right = "number",
			param_left = "number",
			compareType = "<=~>"
		}
	},
	{
		desc = "条件节点 布尔值类型比较",
		script = "UGCTask_CompBoolean",
		subparam = {
			param_right = "boolean",
			param_left = "boolean",
			compareType = "==/~="
		}
	},
	{
		desc = "条件节点 字符串类型比较",
		script = "UGCTask_CompString",
		subparam = {
			param_right = "string",
			param_left = "string",
			compareType = "==/~="
		}
	},
	{
		desc = "条件节点 对象类型比较",
		script = "UGCTask_CompObject",
		subparam = {
			param_right = "objid",
			param_left = "objid",
			compareType = "==/~="
		}
	},
	{
		desc = "条件节点 位置类型比较",
		script = "UGCTask_CompPosition",
		subparam = {
			param_right = "{x, y, z}",
			param_left = "{x, y, z}",
			compareType = "==/~="
		}
	},
	{
		desc = "条件节点 位置是否在区域内",
		script = "UGCTask_CompPosInArea",
		subparam = {
			areaId = 739819391,
			compareType = 2,
			position = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "条件节点 对象存在判断",
		script = "UGCTask_CompObjExist",
		subparam = {
			objid = "objid"
		}
	},
	{
		desc = "条件节点 对象类型判断",
		script = "UGCTask_CompObjType",
		subparam = {
			objId = "objid",
			objType = "objtype",
			compareType = "==/~="
		}
	},
	{
		desc = "条件节点 单位间队伍关系判断",
		script = "UGCTask_CompObjTeam",
		subparam = {
			campType = "中立/敌对",
			objid2 = "objid",
			objid1 = "objid"
		}
	},
	{
		desc = "条件节点 方块存在判断",
		script = "UGCTask_BlockExist",
		subparam = {
			position = {
				x = x,
				y = y,
				z = z
			}
		}
	},
	{
		desc = "条件节点 Buff存在判断",
		script = "UGCTask_BuffExist",
		subparam = {
			objid = 100,
			buffid = 123
		}
	},
	{
		desc = "条件节点 指定方块存在判断",
		script = "UGCTask_SpecifyBlockExist",
		subparam = {
			blockType = 100,
			position = {
				x = x,
				y = y,
				z = z
			}
		}
	},
	{
		desc = "条件节点 是否为虚空之夜",
		script = "UGCTask_IsVoidNight",
		subparam = {}
	},
	{
		desc = "条件节点 星尘之境传送祭坛任一点被激活",
		script = "UGCTask_IsStardustRealmTeleportAltarAnyPointActivated",
		subparam = {
			range = 10
		}
	},
	{
		desc = "条件节点 星尘之境传送祭坛全部点被激活",
		script = "UGCTask_IsStardustRealmTeleportAltarAllPointsActivated",
		subparam = {
			range = 10
		}
	},
	{
		desc = "条件节点 最近星尘之境遗迹已解锁",
		script = "UGCTask_IsNearestStardustRealmRelicUnlocked",
		subparam = {
			range = 10
		}
	},
	{
		desc = "条件节点 对象手持道具类型判断",
		script = "UGCTask_CompTypeHandItem",
		subparam = {
			itemId = 0,
			compareType = true,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "条件节点 是否处于举盾防御状态",
		script = "UGCTask_IsInShieldDefence",
		subparam = {}
	},
	{
		desc = "条件节点 是否为抱起状态",
		script = "UGCTask_IsPickup",
		subparam = {}
	},
	{
		desc = "条件节点 对象队伍判断",
		script = "UGCTask_IsTeam",
		subparam = {
			targetObj = {
				actor = objid
			},
			teamid = teamid
		}
	},
	{
		desc = "通用赋值节点",
		script = "UGCTask_CommonSetValue",
		subparam = {
			bbkey = "bbkey",
			bbvalue = "bbvalue"
		}
	},
	{
		desc = "Bool赋值节点",
		script = "UGCTask_CommonSetBoolean",
		subparam = {
			bbkey = "bbkey",
			bbvalue = "bbvalue"
		}
	},
	{
		desc = "区域赋值节点",
		script = "UGCTask_CommonSetArea",
		subparam = {
			bbkey = "bbkey",
			bbvalue = "bbvalue"
		}
	},
	{
		desc = "对象赋值节点",
		script = "UGCTask_CommonSetObject",
		subparam = {
			bbkey = "bbkey",
			bbvalue = "bbvalue"
		}
	},
	{
		desc = "位置赋值节点",
		script = "UGCTask_CommonSetPosition",
		subparam = {
			bbkey = "bbkey",
			bbvalue = "bbvalue"
		}
	},
	{
		desc = "寻找最近目标玩家及位置",
		script = "UGCTask_FindNearestPlayer",
		subparam = {
			range = 5,
			bbret_targetpos = {
				x,
				y,
				z
			},
			bbret_targetobj = {
				actor = 10001
			}
		}
	},
	{
		desc = "在指定位置上播放粒子特效",
		script = "UGCTask_PlayParticleEffectOnPos",
		subparam = {
			particleId = 1000,
			scale = 1,
			position = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "在对象身上播放粒子特效",
		script = "UGCTask_PlayParticleEffectOnBody",
		subparam = {
			particleId = 0,
			scale = 1,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "在指定位置上关闭粒子特效",
		script = "UGCTask_StopParticleEffectOnPos",
		subparam = {
			particleId = 1000,
			position = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "在对象身上关闭粒子特效",
		script = "UGCTask_StopParticleEffectOnBody",
		subparam = {
			particleId = 0,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "在指定位置上播放音频效果",
		script = "UGCTask_PlaySoundEffectOnPos",
		subparam = {
			volume = 1,
			soundId = 10001,
			position = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "骑乘目标",
		script = "UGCTask_RideTarget",
		subparam = {
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "击败目标",
		script = "UGCTask_KillTarget",
		subparam = {
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "移除目标",
		script = "UGCTask_RemoveTarget",
		subparam = {
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "抱起目标",
		script = "UGCTask_PickupTarget",
		subparam = {
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "放下目标",
		script = "UGCTask_PutdownTarget",
		subparam = {}
	},
	{
		desc = "播放动画",
		script = "UGCTask_PlayAnimationBySeqId",
		subparam = {
			seqId = 100100
		}
	},
	{
		desc = "举盾防御-激活",
		script = "UGCTask_ShieldDefenceEnable",
		subparam = {
			itemId = 12319
		}
	},
	{
		desc = "举盾防御-取消",
		script = "UGCTask_ShieldDefenceDisable",
		subparam = {}
	},
	{
		desc = "技能：万象天引",
		script = "UGCTask_SkillGravitationBomb",
		subparam = {
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "运行正向计时器",
		script = "UGCTask_TimerStart",
		subparam = {
			timerId = 1
		}
	},
	{
		desc = "暂停计时器",
		script = "UGCTask_TimerPause",
		subparam = {
			timerId = 1
		}
	},
	{
		desc = "恢复计时器",
		script = "UGCTask_TimerResume",
		subparam = {
			timerId = 1
		}
	},
	{
		desc = "重置计时器",
		script = "UGCTask_TimerReset",
		subparam = {
			timerId = 1
		}
	},
	{
		desc = "移动到指定位置",
		script = "UGCTask_MoveToPos",
		subparam = {
			changeToward = true,
			speed = 1,
			pos = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "移动到随机位置",
		script = "UGCTask_MoveToPosRandom",
		subparam = {
			changeToward = true,
			speed = 1
		}
	},
	{
		desc = "跟随目标移动",
		script = "UGCTask_FollowTarget",
		subparam = {
			speed = 1,
			changeToward = true,
			distance = 5,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "移动到对象前方",
		script = "UGCTask_MoveToActorFront",
		subparam = {
			frontDistance = 1,
			speed = 1,
			changeToward = true,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "绕圈",
		script = "UGCTask_OrbitCenter",
		subparam = {
			radiusBlock = 3,
			circleCount = 1,
			speedScale = 1,
			centerPos = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "设置朝向",
		script = "UGCTask_RotateTo",
		subparam = {
			duration = 1,
			pos = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "远程攻击-投掷",
		script = "UGCTask_AttackRanged",
		subparam = {
			frequency = 1,
			itemId = 12002,
			speed = 1,
			distance = 10,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "远程攻击-武器",
		script = "UGCTask_AttackRangedByWeapon",
		subparam = {
			frequency = 1,
			speed = 1.2,
			itemId = 12002,
			projId = 0,
			distance = 5,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "远程攻击-武器蓄力",
		script = "UGCTask_AttackRangedCharged",
		subparam = {
			projectileId = 12051,
			weaponId = 12050,
			frequency = 1,
			distance = 8,
			speed = 1,
			chargedTime = 1,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "近战攻击",
		script = "UGCTask_AttackMelee",
		subparam = {
			frequency = 0.5,
			speed = 1,
			distance = 2.5,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "近战攻击-武器",
		script = "UGCTask_AttackMeleeByWeapon",
		subparam = {
			frequency = 0.5,
			weaponId = 12005,
			speed = 1,
			distance = 2.5,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "近战攻击-连击",
		script = "UGCTask_AttackMeleeCombo",
		subparam = {
			comboNum = 5,
			weaponId = 12005,
			distance = 1,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "近战攻击-连击-第N段",
		script = "UGCTask_AttackMeleeComboIndex",
		subparam = {
			isReset = false,
			weaponId = 12005,
			comboIndex = 5,
			distance = 1,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "改变对象属性",
		script = "UGCTask_ChangeActorAttr",
		subparam = {
			operateType = 3,
			attrValue = 99,
			targetObj = {
				actor = objid
			},
			attrType = CREATUREATTR
		}
	},
	{
		desc = "改变生物属性",
		script = "UGCTask_ChangeMobAttr",
		subparam = {
			operateType = 3,
			attrValue = 99,
			targetObj = {
				actor = objid
			},
			attrType = CREATUREATTR
		}
	},
	{
		desc = "改变玩家属性",
		script = "UGCTask_ChangePlayerAttr",
		subparam = {
			operateType = 3,
			attrValue = 99,
			targetObj = {
				actor = objid
			},
			attrType = CREATUREATTR
		}
	},
	{
		desc = "改变对象外观",
		script = "UGCTask_ChangeActorModel",
		subparam = {
			modleName = "mob_3409",
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "替换对象",
		script = "UGCTask_ChangeActor",
		subparam = {
			hpPercent = true,
			actorId = 3206,
			targetObj = {
				actor = objid
			}
		}
	},
	{
		desc = "把背包内的道具放在手上",
		script = "UGCTask_ItemPutInHand",
		subparam = {
			itemId = 100
		}
	},
	{
		desc = "生成道具并直接放入背包",
		script = "UGCTask_ItemAddToBags",
		subparam = {
			itemId = 100
		}
	},
	{
		desc = "生成道具直接放在手上",
		script = "UGCTask_ItemDirectPutInHand",
		subparam = {
			itemId = 100
		}
	},
	{
		desc = "从背包中存储物品到指定位置",
		script = "UGCTask_ItemStoreToPos",
		subparam = {
			itemNum = 5,
			itemId = 100,
			targetPos = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "拾取周边X格内道具到背包",
		script = "UGCTask_ItemPickToBags",
		subparam = {
			itemId = 100,
			range = 10
		}
	},
	{
		desc = "挖方块 靠近指定位置并挖掘",
		script = "UGCTask_NewDigBlock",
		subparam = {
			blockpos = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "被攻击事件节点",
		script = "UGCTask_EventBeHurt",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "与来自玩家的道具交互",
		script = "UGCTask_EventBeInteract",
		subparam = {
			itemId = 100
		}
	},
	{
		desc = "动作节点 放置方块",
		script = "UGCTask_BlockToPlace",
		subparam = {
			face = "东南西北",
			blockid = 100,
			position = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "动作节点 替换方块",
		script = "UGCTask_BlockToReplace",
		subparam = {
			face = "东南西北",
			blockid = 100,
			position = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "动作节点 破坏方块",
		script = "UGCTask_BlockToDestroy",
		subparam = {
			position = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "动作节点 与方块交互",
		script = "UGCTask_BlockToTrigger",
		subparam = {
			position = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "动作节点 给予对象状态",
		script = "UGCTask_BuffToAdd",
		subparam = {
			keepsec = "持续时长",
			objid = "objid",
			repeat_ = "是否持续",
			buff = buffid
		}
	},
	{
		desc = "动作节点 移除对象状态",
		script = "UGCTask_BuffToRemove",
		subparam = {
			objid = "objid",
			buff = buffid
		}
	},
	{
		desc = "动作节点 替换对象状态",
		script = "UGCTask_BuffToReplace",
		subparam = {
			repeat_ = "是否持续",
			keepsec = "持续时长",
			objid = "objid",
			curbuff = buffid,
			repbuff = buffid
		}
	},
	{
		desc = "动作节点  设置队伍",
		script = "UGCTask_ChangeTeam",
		subparam = {
			objid = "objid",
			teamid = teamid
		}
	},
	{
		desc = "播放音效事件节点",
		script = "UGCTask_EventBePlaySound",
		subparam = {
			soundid = 111,
			obj = "objid",
			dis = 10,
			bbkey = "11"
		}
	},
	{
		desc = "收到广播消息事件节点",
		script = "UGCTask_EventBeMsg",
		subparam = {
			msgid = 1,
			params = {}
		}
	},
	{
		desc = "发送广播消息事件节点",
		script = "UGCTask_SendMsg",
		subparam = {
			msgid = 1,
			params = {}
		}
	},
	{
		desc = "发送召集消息",
		script = "UGCTask_SendSummonMsg",
		subparam = {
			msgId = 1,
			receiveCooldownSec = 15,
			sendCooldownSec = 3,
			range = 10
		}
	},
	{
		desc = "向对象发送召集消息",
		script = "UGCTask_SendSummonMsgToActor",
		subparam = {
			sendCooldownSec = 3,
			receiveCooldownSec = 15,
			targetObjId = 0,
			msgId = 1
		}
	},
	{
		desc = "接收召集消息事件节点",
		script = "UGCTask_EventReceiveSummonMsg",
		subparam = {
			senderBbKey = "11",
			msgId = 1
		}
	},
	{
		desc = "远离某个点",
		script = "UGCTask_LeavePos",
		subparam = {
			changeToward = true,
			speed = 1,
			pos = {}
		}
	},
	{
		desc = "区域点随机移动",
		script = "UGCTask_AreaRandomMove",
		subparam = {
			changeToward = true,
			speed = 1,
			areaid = {}
		}
	},
	{
		desc = "点组移动",
		script = "UGCTask_PathMove",
		subparam = {
			isResetCurentindex = false,
			speed = 1,
			iswhile = true,
			pathid = 11
		}
	},
	{
		desc = "变更对象移动方式",
		script = "UGCTask_ChangMoveType",
		subparam = {
			moveType = "fly",
			objid = {
				actor = 1
			}
		}
	},
	{
		desc = "破坏区域内的方块",
		script = "UGCTask_BlockDestroyInArea",
		subparam = {
			frequency = 0.5,
			areaId = 739819391,
			canDrop = false
		}
	},
	{
		desc = "挖掘区域内的方块",
		script = "UGCTask_BlockDigInArea",
		subparam = {
			frequency = 0.5,
			areaId = 739819391,
			canDrop = false
		}
	},
	{
		desc = "创建生物",
		script = "UGCTask_CreateMobByPos",
		subparam = {
			actorId = 0,
			position = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "动作节点  设置死亡道具的掉落概率",
		script = "UGCTask_SetDieDropItemRate",
		subparam = {
			itemNum = 0,
			itemId = 0,
			dropRate = 0
		}
	},
	{
		desc = "动作节点  播放动画表情",
		script = "UGCTask_PlayBodyEffect",
		subparam = {
			objid = 100,
			efftype = 123
		}
	},
	{
		desc = "动作节点  设置生物位置",
		script = "UGCTask_SetActorPosition",
		subparam = {
			objid = 100,
			position = {
				x,
				y,
				z
			}
		}
	},
	{
		desc = "在对象身上创建平面图文信息",
		script = "UGCTask_CreateGraphics",
		subparam = {
			yoffest = 2,
			objid = 100,
			xoffest = 1,
			info = {}
		}
	},
	{
		desc = "在对象身上打开UI界面",
		script = "UGCTask_OpenUIView",
		subparam = {
			objid = 1,
			uiname = ""
		}
	},
	{
		desc = "朝位置使用技能",
		script = "UGCTask_PlaySkillByPos",
		subparam = {
			subparam = {
				id = "",
				pos = {
					y = 1,
					z = 2,
					x = 1
				}
			}
		}
	},
	{
		desc = "朝目标使用技能",
		script = "UGCTask_PlaySkillByTarget",
		subparam = {
			subparam = {
				objid = 1,
				id = ""
			}
		}
	},
	{
		desc = "切换行为树",
		script = "UGCTask_ChangeTree",
		subparam = {
			treeid = ""
		}
	},
	{
		desc = "旧的设置生物移动方式",
		script = "UGCTask_SetMoveType",
		subparam = {
			movetype = "1",
			isOpen = false,
			objid = 0
		}
	},
	{
		desc = "当被玩家点击",
		script = "UGCTask_EvntClickActor",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "设置生物血条显示与隐藏",
		script = "UGCTask_SetHpVisible",
		subparam = {
			isNo = true,
			obj = ""
		}
	},
	{
		desc = "在对象播放音频效果",
		script = "UGCTask_PlaySoundOnObj",
		subparam = {
			obj = 123,
			volume = 1,
			soundId = 10001,
			isLoop = true
		}
	},
	{
		desc = "在对象停止音频效果",
		script = "UGCTask_StopSoundOnObj",
		subparam = {
			soundId = 10001,
			obj = 123
		}
	},
	{
		desc = "在位置停止音频效果",
		script = "UGCTask_StopSoundOnPos",
		subparam = {
			soundId = 10001,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "向前跳跃",
		script = "UGCTask_Jump",
		subparam = {
			obj = 123
		}
	},
	{
		desc = "枪械攻击",
		script = "UGCTask_AttackByGun",
		subparam = {
			projId = 0,
			itemId = 12002,
			distance = 5,
			targetObj = {
				actor = 1
			}
		}
	},
	{
		desc = "改变生物组属性",
		script = "UGCTask_ChangeMobListAttr",
		subparam = {
			attrValue = "number",
			attrType = 1,
			operateType = 1,
			targetObjs = {
				{
					actor = 1
				}
			}
		}
	},
	{
		desc = "改变玩家组属性",
		script = "UGCTask_ChangePlayerListAttr",
		subparam = {
			attrType = 1,
			operateType = 1,
			attrValue = "number",
			targetObj = {
				{
					player = 1
				}
			}
		}
	},
	{
		desc = "吃东西",
		script = "UGCTask_EatFood",
		subparam = {
			isadd = false,
			item = 123
		}
	},
	{
		desc = "睡觉",
		script = "UGCTask_Sleep",
		subparam = {
			time = 1000,
			obj = 123
		}
	},
	{
		desc = "击开生物",
		script = "UGCTask_KnockOff",
		subparam = {
			obj = 123,
			motion = 7,
			dist = 7
		}
	},
	{
		desc = "生物设置生物是否受阻",
		script = "UGCTask_SetUnsighted",
		subparam = {
			isUnsighted = 1
		}
	},
	{
		desc = "设置生物属性",
		script = "UGCTask_CommonSetAttr",
		subparam = {
			cmpName = "",
			value = 1,
			property = "",
			targetObj = {
				actor = 1
			}
		}
	},
	{
		desc = "幸存者拾取",
		script = "UGCTask_SurvivalPick",
		subparam = {
			rang = 1,
			obj = 1
		}
	},
	{
		desc = "在对象身上删除平面图文信息",
		script = "UGCTask_RemoveGraphics",
		subparam = {
			id = 1,
			graphicsType = 1,
			objid = 1
		}
	},
	{
		desc = "条件节点 判断图文信息是否存在",
		script = "UGCTask_CompGraphicsExit",
		subparam = {
			id = 1,
			obj = 1,
			graphicsType = 1
		}
	},
	{
		desc = "停止移动",
		script = "UGCTask_StopMove",
		subparam = {
			obj = 11
		}
	},
	{
		desc = "当队友被攻击时候",
		script = "UGCTask_EvntTeamActorBeHeurt",
		subparam = {
			rang = 1,
			bbkey = "11"
		}
	},
	{
		desc = "近战攻击设备",
		script = "UGCTask_AttackBlock",
		subparam = {
			distance = 2.5
		}
	},
	{
		desc = "条件节点 设备存在判断",
		script = "UGCTask_CompBlockExist",
		subparam = {
			dist = 1
		}
	},
	{
		desc = "设置飞行高度",
		script = "UGCTask_SetFlyHeight",
		subparam = {
			hright = 1,
			obj = 1
		}
	},
	{
		desc = "设置打开门",
		script = "UGCTask_SetOpenDoor",
		subparam = {
			obj = 1
		}
	},
	{
		desc = "停止动画",
		script = "UGCTask_StopAnimationBySeqId",
		subparam = {
			seqId = 100100
		}
	},
	{
		desc = "条件节点内部使用",
		script = "UGCTask_CompNumberAndExit",
		subparam = {}
	},
	{
		desc = "通用UGC设置道具类型",
		script = "UGCTask_CommonSetItemType",
		subparam = {}
	},
	{
		desc = "通用UGC设置特效类型",
		script = "UGCTask_CommonSetEffectType",
		subparam = {}
	},
	{
		desc = "设置生物类型",
		script = "UGCTask_CommonSetActorType",
		subparam = {}
	},
	{
		desc = "通用UGC设置方块类型",
		script = "UGCTask_CommonSetBlockType",
		subparam = {}
	},
	{
		desc = "开关生物移动能力",
		script = "UGCTask_SetMoveAbility",
		subparam = {}
	},
	{
		desc = "设置生物移动模式",
		script = "UGCTask_SetMovementMode",
		subparam = {}
	},
	{
		desc = "改变属性事件节点",
		script = "UGCTask_EventChangeAttr",
		subparam = {}
	},
	{
		desc = "添加状态事件节点",
		script = "UGCTask_EventAddBuff",
		subparam = {}
	},
	{
		desc = "进入区域",
		script = "UGCTask_EventAreaIn",
		subparam = {}
	},
	{
		desc = "离开区域",
		script = "UGCTask_EventAreaOut",
		subparam = {}
	},
	{
		desc = "移除状态事件节点",
		script = "UGCTask_EventRemoveBuff",
		subparam = {}
	},
	{
		desc = "执行相应属性函数",
		script = "UGCTask_CommonSetComponent",
		subparam = {
			targetObj = {}
		}
	},
	{
		desc = "设置组件属性",
		script = "UGCTask_CommonSetComponentProperty",
		subparam = {}
	},
	{
		desc = "新骑乘目标",
		script = "UGCTask_NewRideTarget",
		subparam = {
			iscontrl = false,
			isCloseAi = false,
			targetObj = {
				actor = 1
			}
		}
	},
	{
		desc = "下骑乘",
		script = "UGCTask_DistMount",
		subparam = {}
	},
	{
		desc = "条件节点 区域存在判断",
		script = "UGCTask_CompAreaExist",
		subparam = {}
	},
	{
		desc = "条件节点 部件存在判断",
		script = "UGCTask_CompPartExist",
		subparam = {}
	},
	{
		desc = "当主人被攻击",
		script = "UGCTask_EventHostBeHurt",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "当被玩家碰撞",
		script = "UGCTask_EventPlayerCollide",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "当玩家播放指定动作",
		script = "UGCTask_EventPlayerPlayAction",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "当玩家操作道具",
		script = "UGCTask_EventPlayerItem",
		subparam = {
			bbkey = "11",
			itemEvent = 3270002,
			range = 10
		}
	},
	{
		desc = "指定生物被击败",
		script = "UGCTask_EventActorDie",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "当生物被碰撞",
		script = "UGCTask_EventActorCollide",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "当生物被碰撞(过滤玩家)",
		script = "UGCTask_EventActorCollideFilterPlayer",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "使用道具",
		script = "UGCTask_UseItem",
		subparam = {
			item = "itemid",
			num = 1,
			targetObjId = 1
		}
	},
	{
		desc = "道具给其它对象",
		script = "UGCTask_GiveItem",
		subparam = {}
	},
	{
		desc = "手上道具移动到背包",
		script = "UGCTask_HandItemMoveToBag",
		subparam = {}
	},
	{
		desc = "扔出掉落物",
		script = "UGCTask_DropItem",
		subparam = {}
	},
	{
		desc = "创建掉落物",
		script = "UGCTask_CreateItem",
		subparam = {}
	},
	{
		desc = "朝方向移动",
		script = "UGCTask_DirectionMove",
		subparam = {}
	},
	{
		desc = "看向目标",
		script = "UGCTask_KeepLookTo",
		subparam = {}
	},
	{
		desc = "持续朝向对象",
		script = "UGCTask_LookAtObject",
		subparam = {}
	},
	{
		desc = "修改行为树属性",
		script = "UGCTask_SetBeTreeParam",
		subparam = {}
	},
	{
		desc = "条件节点 掉落物存在判断",
		script = "UGCTask_CompItemExist",
		subparam = {
			objid = "objid"
		}
	},
	{
		desc = "条件节点 投掷物存在判断",
		script = "UGCTask_CompProjectileExist",
		subparam = {
			objid = "objid"
		}
	},
	{
		desc = "设置掉落物",
		script = "UGCTask_SetClientItem",
		subparam = {}
	},
	{
		desc = "设置投掷物",
		script = "UGCTask_SetProjectile",
		subparam = {}
	},
	{
		desc = "移动到喂食槽吃饲料",
		script = "UGCTask_MoveToFeedTroughFeed",
		subparam = {}
	},
	{
		desc = "移动到孵化巢孵化",
		script = "UGCTask_MoveToNestStartIncubation",
		subparam = {}
	},
	{
		desc = "条件节点 是否在使用激光笔",
		script = "UGCTask_IsUsingLaserPointer",
		subparam = {}
	},
	{
		desc = "立刻拾取投掷物",
		script = "UGCTask_PickupThrowableItem",
		subparam = {}
	},
	{
		desc = "条件节点 是否跟随",
		script = "UGCTask_CompFollowState",
		subparam = {}
	},
	{
		desc = "开始睡觉",
		script = "UGCTask_StartSleep",
		subparam = {
			obj = 123
		}
	},
	{
		desc = "停止睡觉",
		script = "UGCTask_StopSleep",
		subparam = {
			obj = 123
		}
	},
	{
		desc = "条件节点 是否在睡觉",
		script = "UGCTask_IsSleep",
		subparam = {}
	},
	{
		desc = "条件节点 玩家是否第一次进入村庄",
		script = "UGCTask_IsPlayerFirstEnterVillage",
		subparam = {
			targetPlayerObjId = {
				actor = objid
			}
		}
	},
	{
		desc = "发送广播消息到AI节点",
		script = "UGCTask_SendToAI",
		subparam = {
			msginfo = "消息内容"
		}
	},
	{
		desc = "接收ai消息节点",
		script = "UGCTask_EventAiNPC",
		subparam = {
			bbkey = "11"
		}
	},
	{
		desc = "发送房间消息事件节点",
		script = "UGCTask_SendMsgToRoom",
		subparam = {
			msginfo = "消息内容"
		}
	},
	{
		desc = "装备道具",
		script = "UGCTask_EquipItem",
		subparam = {
			item = 123
		}
	},
	{
		desc = "从箱子中拿取道具",
		script = "UGCTask_TakeItemFromBox",
		subparam = {
			item = 123,
			num = 1,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "在随身制作道具",
		script = "UGCTask_CraftOnTheGo",
		subparam = {
			item = 123,
			num = 1
		}
	},
	{
		desc = "在制作台制作道具",
		script = "UGCTask_CraftAtWorkshop",
		subparam = {
			item = 123,
			num = 1,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "条件节点 是否有足够的材料",
		script = "UGCTask_HasEnoughMaterials",
		subparam = {
			item = 123
		}
	},
	{
		desc = "条件节点 背包中是否有足够的材料",
		script = "UGCTask_CheckBagItemNum",
		subparam = {
			item = 123,
			num = 1
		}
	},
	{
		desc = "和方块交互",
		script = "UGCTask_InteractBlock",
		subparam = {
			item = 123,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "条件节点 是否在燃烧",
		script = "UGCTask_IsCampfireBurning",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "条件节点 是否在烹饪",
		script = "UGCTask_IsStonePotCooked",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "获取石锅食物",
		script = "UGCTask_GetStonePotFood",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "获取熔炉燃料",
		script = "UGCTask_FetchFurnaceFuel",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "获取熔炉原料",
		script = "UGCTask_GetFurnaceRawMaterial",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "获取熔炉产物",
		script = "UGCTask_GetFurnaceProduct",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "条件节点 是否在熔炉中有物品",
		script = "UGCTask_HasItemInFurnace",
		subparam = {
			item = 123,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "添加物品到熔炉",
		script = "UGCTask_AddItemToFurnace",
		subparam = {
			num = 1,
			item = 123,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "起床",
		script = "UGCTask_WakeUp",
		subparam = {}
	},
	{
		desc = "睡觉",
		script = "UGCTask_SleepInBed",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "脱下道具",
		script = "UGCTask_UnequipItemToInventory",
		subparam = {
			slot = 1
		}
	},
	{
		desc = "从篝火上获取食物",
		script = "UGCTask_GetCampfireMeat",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "装备标签道具",
		script = "UGCTask_EquipTagItem",
		subparam = {
			tag = "tag"
		}
	},
	{
		desc = "抢夺对象手持道具",
		script = "UGCTask_StealHeldItem",
		subparam = {
			targetObjId = 0,
			putInHand = true
		}
	},
	{
		desc = "道具是否存在标签",
		script = "UGCTask_ItemHasTag",
		subparam = {
			itemid = 123,
			tag = "tag"
		}
	},
	{
		desc = "对象是否存在标签",
		script = "UGCTask_ObjectHasTag",
		subparam = {
			objid = 123,
			tag = "tag"
		}
	},
	{
		desc = "从背包中存储标签道具到指定位置",
		script = "UGCTask_TagItemStoreToPos",
		subparam = {
			tag = "tag",
			num = 1,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "从箱子中拿取标签道具",
		script = "UGCTask_TakeTagItemFromBox",
		subparam = {
			tag = "tag",
			num = 1,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "方块是否存在标签",
		script = "UGCTask_BlockHasTag",
		subparam = {
			tag = "tag",
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "设置生物主人",
		script = "UGCTask_SetOwner",
		subparam = {
			ownerObj = {
				actor = 1
			}
		}
	},
	{
		desc = "添加饲料到喂食槽",
		script = "UGCTask_AddFeedToFeeder",
		subparam = {
			item = 123,
			num = 1,
			range = 1
		}
	},
	{
		desc = "当子生物被攻击时",
		script = "UGCTask_EventChildrenBeHeurtEvent",
		subparam = {
			bbkey = "11",
			range = 1
		}
	},
	{
		desc = "当玩家输入字符串时",
		script = "UGCTask_EventPlayerInputString",
		subparam = {
			bbkey = "11",
			inputString = "输入字符串",
			range = 1
		}
	},
	{
		desc = "生物是否在水中",
		script = "UGCTask_InWater",
		subparam = {
			act = 123
		}
	},
	{
		desc = "拾取标签道具",
		script = "UGCTask_PickTagItem",
		subparam = {
			tag = "tag",
			range = 10
		}
	},
	{
		desc = "设置Avatar部件模型",
		script = "UGCTask_SetAvatarModel",
		subparam = {
			nAnchorId = 1,
			model = "1",
			actor = 1
		}
	},
	{
		desc = "开始蓝图工作台",
		script = "UGCTask_StartBlueprintWorkbench",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "存储所有物品到指定位置",
		script = "UGCTask_StoreAllToPos",
		subparam = {
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "当玩家与生物交互时",
		script = "UGCTask_EventBePlayerInteract",
		subparam = {
			objid = 100,
			itemid = 100
		}
	},
	{
		desc = "填充蓝图工作台物品",
		script = "UGCTask_FillBlueprintWorkbenchItems",
		subparam = {
			num = 1,
			item = 123,
			pos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "使生物取消被骑乘状态",
		script = "UGCTask_CancelRidden",
		subparam = {
			nAnchorId = 1
		}
	},
	{
		desc = "生物交互生物",
		script = "UGCTask_MobInteractMob",
		subparam = {
			targetObj = {
				actor = 1
			},
			object = {
				actor = 1
			}
		}
	},
	{
		desc = "条件节点 宠物是否在窝内",
		script = "UGCTask_IsPetInNest",
		subparam = {
			actor = 1
		}
	},
	{
		desc = "动作节点 宠物入窝",
		script = "UGCTask_PetGoIntoNest",
		subparam = {
			petobjid = 1,
			nestpos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "动作节点 宠物出窝",
		script = "UGCTask_PetGoOutOfNest",
		subparam = {
			petobjid = 1,
			nestpos = {
				y = 0,
				z = 0,
				x = 0
			}
		}
	},
	{
		desc = "条件节点 检查持有的物品类型是否在组中",
		script = "UGCTask_CompHeldItemTypeInGroup",
		subparam = {
			itemGroup = "string",
			itemType = "1000"
		}
	},
	{
		desc = "当生物被玩家点击",
		script = "UGCTask_EvntBeClick",
		subparam = {
			clickType = "left",
			bbkey = "11"
		}
	},
	{
		desc = "生物上岸",
		script = "UGCTask_EventOnLanded",
		subparam = {}
	},
	{
		desc = "范围内指定生物类型被攻击",
		script = "UGCTask_EventRangeCreatureTypeAttacked",
		subparam = {
			actorType = "11",
			range = 10
		}
	},
	{
		desc = "范围内指定生物类型组被攻击",
		script = "UGCTask_EventRangeCreatureTypeGroupAttacked",
		subparam = {
			actorTypeGroup = "11",
			range = 10
		}
	},
	{
		desc = "设置水中悬浮开启与关闭",
		script = "UGCTask_SetSuspensionEnable",
		subparam = {
			isNo = true,
			obj = 1
		}
	},
	{
		desc = "设置生物飞行曲线编号",
		script = "UGCTask_SetFlyCurveIndex",
		subparam = {
			index = 0,
			obj = 1
		}
	}
}
