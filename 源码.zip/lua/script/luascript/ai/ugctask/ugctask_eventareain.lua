return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local bbkey = result[1]
		lcontroller.taskparam.bbkey = bbkey
	end,
	run = function ()
		local taskpram = controller.taskparam

		if taskpram.bbkey == taskpram.eventParam.areaid then
			return controller.success()
		end

		return controller.fail()
	end
}
