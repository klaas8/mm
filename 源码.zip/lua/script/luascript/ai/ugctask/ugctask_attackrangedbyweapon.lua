local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local itemId, projId, objid, frequency, distance, speed = nil

		if TEST_TEST_TEST then
			distance = 5
			frequency = 1
			objid = CurMainPlayer:getObjId()
			projId = 15074
			itemId = 12005
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 6, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4,
					5,
					6
				})
			end

			speed = result[6]
			distance = result[5]
			frequency = result[4]
			objid = result[3]
			projId = result[2]
			itemId = result[1]
		end

		if speed == nil then
			speed = 1.2
		end

		itemId = lBTService:ResidToId(itemId)
		projId = lBTService:ResidToId(projId)
		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.projId = projId
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.frequency = frequency
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.speed = speed

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId or 0
				}
			}
			local data2 = {
				valtype = "itemtype",
				val = {
					projId = projId or 0
				}
			}
			local data3 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data4 = {
				valtype = "val",
				val = frequency
			}
			local data5 = {
				valtype = "val",
				val = distance
			}
			local data6 = {
				valtype = "val",
				val = speed
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4,
				data5,
				data6
			})
		end
	end,
	will = function ()
		local objid = controller.taskparam.objid

		if not objid or objid <= -1 then
			return false
		end

		local itemId = controller.taskparam.itemId
		local projId = controller.taskparam.projId
		local frequency = controller.taskparam.frequency
		local distance = controller.taskparam.distance

		if not itemId or not projId or not frequency or not distance then
			return false
		end

		local selfObj = controller.target.get("living")
		local targetObj = AIFunctionMgr:getActorByObjId(selfObj, objid)

		if not targetObj or not targetObj:alive() then
			return false
		end

		if not GameplayTagUtils:IsNormalAttackEnabled(selfObj) then
			return false
		end

		local position = targetObj:getPosition()
		local currdist = PosSquareDistanceToPos(selfObj:getPosition(), position)

		if math.pow(BLOCK_SIZE * distance, 2) < currdist then
			controller.taskparam.targetPos = position
		else
			controller.taskparam.targetPos = nil
		end

		return true
	end,
	onbeg = function ()
		local selfObj = controller.target.get()
		local weaponId = controller.taskparam.itemId

		if AIFunctionMgr:getBagItemCount(selfObj, weaponId, false) <= 0 then
			AIFunctionMgr:addItemToBags(selfObj, weaponId, 1)
		end

		AIFunctionMgr:equipWeapon(selfObj, weaponId, 1)

		local targetPos = controller.taskparam.targetPos
		local speed = controller.taskparam.speed

		if targetPos ~= nil then
			local path_range = btget_path_range()
			local x = targetPos.x
			local y = targetPos.y
			local z = targetPos.z

			selfObj:getNavigator():tryMoveTo(x, y, z, speed, path_range)
		end
	end,
	run = function ()
		local selfObj = controller.target.get()
		local targetPos = controller.taskparam.targetPos

		if targetPos ~= nil then
			local distance = controller.taskparam.distance
			local distance_ = math.pow(BLOCK_SIZE * distance, 2)
			local currdist = PosSquareDistanceToPos(selfObj:getPosition(), targetPos)

			while not selfObj:getNavigator():noPath() or distance_ < currdist do
				if currdist <= distance_ or selfObj:getNavigator():noPath() then
					break
				end

				currdist = PosSquareDistanceToPos(selfObj:getPosition(), targetPos)

				controller.wait()
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfObj, controller.taskparam.objid)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfObj, targetActor)

		if not selfObj:isUnsighted() and not ActorComponentCallModule(selfObj, "ActorVision", "canSeeInAICache", targetActor) then
			return controller.fail()
		end

		selfObj:stopAnim(SEQ_ATTACK)
		selfObj:playAttackSound()
		selfObj:playAnim(SEQ_ATTACK)

		local projId = controller.taskparam.projId

		selfObj:doProjectileAttack(targetActor, projId, 1, 0, 1, 1)

		local itemId = AIFunctionMgr:GetHoldItemId(selfObj)
		local gundef = DefMgr:getGunDef(itemId)

		if gundef and gundef.ContinuousFire == 2 then
			controller.wait()
		end

		local frequency = controller.taskparam.frequency

		controller.wait(frequency)

		return controller.success()
	end,
	onend = function ()
		local selfObj = controller.target.get()

		selfObj:getNavigator():clearPathEntity()
	end
}
