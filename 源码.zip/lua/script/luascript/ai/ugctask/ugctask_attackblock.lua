local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local distance = result[1]
		local frequency = result[2]
		local aggressivity = result[3]
		local dist = result[4]
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.frequency = frequency
		lcontroller.taskparam.aggressivity = aggressivity
		lcontroller.taskparam.dist = dist

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = distance
			}
			local data2 = {
				valtype = "val",
				val = frequency
			}
			local data3 = {
				valtype = "val",
				val = aggressivity
			}
			local data4 = {
				valtype = "val",
				val = dist
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()
		local distance = controller.taskparam.distance
		local frequency = controller.taskparam.frequency
		local aggressivity = controller.taskparam.aggressivity
		local dist2 = controller.taskparam.dist

		if not selfActor or distance == nil or frequency == nil or aggressivity == nil or dist2 == nil then
			return false
		end

		if controller.taskparam.worldobj == nil then
			controller.taskparam.worldobj = UGCGetInst("GameObjectMgr"):GetWorld()

			if controller.taskparam.worldobj then
				local cmp = controller.taskparam.worldobj:GetComponent("ZombieFacilityMgr")

				if cmp then
					controller.taskparam.ZombieFacilityMgr = cmp

					if cmp.GetNearestFacility then
						controller.taskparam.GetNearestFacility = cmp.GetNearestFacility
					end

					if cmp.UpdateFacilityDurable then
						controller.taskparam.UpdateFacilityDurable = cmp.UpdateFacilityDurable
					end
				end
			end
		end

		local pos = selfActor:getPosition()
		local rpos = {
			x = pos.x,
			y = pos.y,
			z = pos.z
		}
		rpos.x, rpos.y, rpos.z = CoordDivBlock(rpos.x, rpos.y, rpos.z)
		local ret, result = nil

		if controller.taskparam.ZombieFacilityMgr and controller.taskparam.GetNearestFacility then
			ret, result = controller.taskparam.GetNearestFacility(controller.taskparam.ZombieFacilityMgr, rpos, distance)

			if type(ret) == "table" and (not ret or not ret[1]) then
				return false
			end

			if type(ret) == "boolean" and (not ret or not result) then
				return false
			end
		end

		if not ret then
			return false
		end

		local deviceinfo = {}

		if type(ret) == "table" then
			local temp = ret[2]
			deviceinfo.minPos = {}
			deviceinfo.size = temp.size

			if deviceinfo.minPos.x == nil then
				local x = temp.minPos[1]
				local y = temp.minPos[2]
				local z = temp.minPos[3]
				deviceinfo.minPos.x = x
				deviceinfo.minPos.y = y
				deviceinfo.minPos.z = z
			end

			deviceinfo.isCamp = temp.isCamp
			deviceinfo.minDeviceId = temp.minDeviceId
		elseif result then
			deviceinfo.minPos = {}
			deviceinfo.size = result.size
			local x = result.minPos[1]
			local y = result.minPos[2]
			local z = result.minPos[3]
			deviceinfo.minPos.x = x
			deviceinfo.minPos.y = y
			deviceinfo.minPos.z = z
			deviceinfo.isCamp = result.isCamp
			deviceinfo.minDeviceId = result.minDeviceId
		end

		local lpos = {}

		if deviceinfo.isCamp then
			lpos = BTCalCampMiniPos(deviceinfo, rpos)
		else
			lpos = BTCalDeviceMiniPos(deviceinfo, rpos)
		end

		if not lpos then
			return false
		end

		lpos.x, lpos.y, lpos.z = BlockBottomCoord(lpos.x, lpos.y, lpos.z)
		controller.taskparam.deid = deviceinfo.minDeviceId
		local deid = controller.taskparam.deid
		controller.taskparam.rotePos = lpos
		controller.taskparam.devinfo = deviceinfo
		local dist = Pos3SquareDistToPos3(selfActor:getPosition(), lpos)
		dist2 = math.pow(BLOCK_SIZE * dist2, 2)

		if dist2 < dist then
			controller.taskparam.targetPos = lpos
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(lpos.x, lpos.y, lpos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.targetPos = nil

			return true
		end

		return true
	end,
	onbeg = function ()
		if controller.taskparam.targetPos then
			local selfActor = controller.target.get()
			local path_range = btget_path_range()

			if selfActor and controller.taskparam.path then
				selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, 1, path_range)

				controller.taskparam.path = nil
			end
		end
	end,
	onwait = function ()
		local actor = controller.target.get()

		if actor:getNavigator():noPath() and controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local path_range = btget_path_range()
			local path = actor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if path then
				actor:getNavigator():newTryMoveTo(path, 1, path_range)
			else
				return false
			end
		end

		return true
	end,
	run = function ()
		local selfActor = controller.target.get()
		local deid = controller.taskparam.deid
		local frequency = controller.taskparam.frequency
		local aggressivity = controller.taskparam.aggressivity
		local dist2 = controller.taskparam.dist

		if not deid or frequency == nil or aggressivity == nil then
			return controller.fail()
		end

		local t_pos = controller.taskparam.targetPos

		if t_pos then
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(BLOCK_SIZE * dist2, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(BLOCK_SIZE * dist2, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local deviceinfo = controller.taskparam.devinfo
		local lpos = nil
		local pos = selfActor:getPosition()
		local rpos = {
			x = pos.x,
			y = pos.y,
			z = pos.z
		}
		rpos.x, rpos.y, rpos.z = CoordDivBlock(rpos.x, rpos.y, rpos.z)

		if deviceinfo.isCamp then
			lpos = BTCalCampMiniPos(deviceinfo, rpos)
		else
			lpos = BTCalDeviceMiniPos(deviceinfo, rpos)
		end

		local dist = PosSquareDistanceToPos(rpos, lpos)

		if dist > dist2 * dist2 then
			return controller.fail()
		end

		if Pos3SquareDistToPos3(rpos, lpos) >= 1 then
			local wcoord = WCoord:new_local()
			wcoord.x = deviceinfo.minPos.x
			wcoord.y = deviceinfo.minPos.y
			wcoord.z = deviceinfo.minPos.z

			if AIFunctionMgr:AttackBlockRayCheck(selfActor, wcoord) then
				return controller.fail()
			end
		end

		AIFunctionMgr:rotateBodyToPos(selfActor, controller.taskparam.rotePos.x, controller.taskparam.rotePos.y, controller.taskparam.rotePos.z)
		selfActor:stopAnim(SEQ_ATTACK)
		selfActor:playAnim(SEQ_ATTACK)

		if controller.taskparam.ZombieFacilityMgr and controller.taskparam.UpdateFacilityDurable then
			controller.taskparam.UpdateFacilityDurable(controller.taskparam.ZombieFacilityMgr, deid, aggressivity * -1)
			controller.wait(frequency)

			return controller.success()
		end

		return controller.fail()
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()
		selfActor:stopLookAt()

		controller.taskparam.targetPos = nil
		controller.taskparam.attackDis = nil
	end
}
