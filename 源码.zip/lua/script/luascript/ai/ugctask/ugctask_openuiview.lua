return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local uiname = controller.taskparam.uiname

		if not objid or not uiname then
			return controller.fail()
		end

		local ret = BTService:GetSSObj("Player"):openUIView(objid, uiname)

		if ret == ErrorCode.OK then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local uiname = result[2]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.uiname = uiname

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = uiname
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
