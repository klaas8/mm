return {
	send_debug_data = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local result = Service.Actor:DisMountActor(selfActor:getObjId())

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
