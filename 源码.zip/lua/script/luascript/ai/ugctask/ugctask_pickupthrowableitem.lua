return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local projectile = controller.taskparam.projectile

		if projectile == nil then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, projectile)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		local ret = AIFunctionMgr:PickupThrowableItem(selfActor, projectile)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local projectile = result[1]
		lcontroller.taskparam.projectile = projectile

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = projectile or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
