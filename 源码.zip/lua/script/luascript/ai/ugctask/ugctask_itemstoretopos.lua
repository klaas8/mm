return {
	onbeg = function ()
		local selfobj = controller.target.get()
		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfobj)
		local param_keys = {
			"itemId",
			"itemNum",
			"targetPos"
		}
		local targetPos = controller.taskparam.targetPos

		if type(targetPos) ~= "table" then
			local ret_, newpos = BTService:GetPositionData(targetPos)

			if ret_ == ErrorCode.OK then
				targetPos = newpos
			else
				if controller.taskparam.needErrInfo then
					local errinfo = {
						info = "targetPosErr"
					}

					controller.sendMsgToAi(selfobj, "UGCTask_ItemStoreToPos", errinfo)
				end

				return controller.fail()
			end
		end

		local speed = 1
		local posx = targetPos.x or 0
		local posy = targetPos.y or 0
		local posz = targetPos.z or 0
		local pos_x, pos_y, pos_z = BlockBottomCoord(posx, posy, posz)
		local path_range = btget_path_range()

		selfobj:getNavigator():tryMoveTo(pos_x, pos_y, pos_z, speed, path_range)

		controller.taskparam.newTargetPos = {
			x = pos_x,
			y = pos_y,
			z = pos_z
		}
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local newTargetPos = controller.taskparam.newTargetPos

		if not newTargetPos then
			return controller.fail()
		end

		local itemId = controller.taskparam.itemId
		local itemNum = controller.taskparam.itemNum
		local targetPos = controller.taskparam.targetPos
		local hasNum = AIFunctionMgr:getItemCountByBags(selfobj, itemId)

		if hasNum == 0 or hasNum < itemNum then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noItem",
					hasNum = hasNum,
					itemid = itemId,
					itemNum = itemNum
				}

				controller.sendMsgToAi(selfobj, "UGCTask_ItemStoreToPos", errinfo)
			end

			return controller.fail()
		end

		local distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

		while not selfobj:getNavigator():noPath() or distance > BLOCK_SIZE * 100 do
			if distance <= BLOCK_SIZE or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

			controller.wait()
		end

		local posx = targetPos.x or 0
		local posy = targetPos.y or 0
		local posz = targetPos.z or 0
		local result, errinfo = AIFunctionMgr:StoreItem(selfobj, posx, posy, posz, itemId, itemNum, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfobj, "UGCTask_ItemStoreToPos", errinfo)
		end

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"itemId",
			"itemNum",
			"targetPos"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local itemNum = result[1]
		local itemId = result[2]
		local position = result[3]
		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.itemNum = itemNum
		lcontroller.taskparam.targetPos = position

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = itemNum
			}
			local data2 = {
				valtype = "itemtype",
				val = {
					itemid = itemId
				}
			}
			local data3 = {
				valtype = "pos",
				val = position
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
