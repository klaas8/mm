local TEST_TEST_TEST = false
local once = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetPos, particleId = nil

		if TEST_TEST_TEST then
			particleId = 1022
			targetPos = {
				y = 7,
				x = 0,
				z = 0
			}
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 2, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2
				})
			end

			particleId = result[2]
			targetPos = result[1]
		end

		lcontroller.taskparam.ugc_position = targetPos
		lcontroller.taskparam.ugc_particleId = particleId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = targetPos
			}
			local data2 = {
				valtype = "effecttype",
				val = {
					effectid = particleId
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	will = function ()
		if TEST_TEST_TEST then
			if once then
				return false
			end

			once = true
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		if type(controller.taskparam.ugc_position) ~= "table" then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local position = controller.taskparam.ugc_position
		local particleId = controller.taskparam.ugc_particleId
		local ret = ErrorCode.FAILED

		if Service and Service.World then
			local posx = position.x or 0
			local posy = position.y or 0
			local posz = position.z or 0
			ret = Service.World:StopParticleOnPos(posx, posy, posz, particleId)
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
