return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objId = controller.taskparam.objId
		local compareType = controller.taskparam.compareType
		local objType = controller.taskparam.objType
		local objResid = controller.taskparam.objResid

		if not objType then
			return controller.fail()
		end

		if not compareType then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objId)

		if not targetActor then
			return controller.fail()
		end

		if objResid ~= nil then
			local targetResid = targetActor:getDefID()

			if compareType == "==" then
				if objResid == targetResid then
					return controller.success()
				end
			elseif compareType == "~=" and objResid ~= targetResid then
				return controller.success()
			end
		else
			local objType_ = targetActor:getObjType()
			local targetObjtype = GameActorTypeToObjType[objType_]

			if targetObjtype ~= nil then
				if compareType == "==" then
					if objType == targetObjtype then
						return controller.success()
					end
				elseif compareType == "~=" and objType ~= targetObjtype then
					return controller.success()
				end
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objId",
			"compareType",
			"objType"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objId = result[1]
		local compareType = result[2]
		local objType = result[3]
		lcontroller.taskparam.objId = objId
		lcontroller.taskparam.compareType = compareType

		if type(objType) == "table" then
			local nobjType = lBTService:GetFactorType(objType[1])
			lcontroller.taskparam.objType = nobjType
			lcontroller.taskparam.objResid = objType[2]
		else
			local nobjType = lBTService:GetFactorType(objType)
			lcontroller.taskparam.objType = nobjType
		end

		if lcontroller:isNeedSendDebug() then
			local realResid = lcontroller.taskparam.objResid
			local realObjType = lcontroller.taskparam.objType
			local data1 = {
				valtype = "actor",
				val = {
					actor = objId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = compareType
			}
			local data3 = {
				valtype = "objtype",
				val = objType
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
