local function ResolveObjId(value)
	if type(value) == "table" then
		return tonumber(value.actor or value.objid or value.objId)
	end

	return tonumber(value)
end

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetObjId = ResolveObjId(result[1])
		local msgId = tonumber(result[2])
		local sendCooldownSec = tonumber(result[3])
		local receiveCooldownSec = tonumber(result[4])
		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.msgId = msgId
		lcontroller.taskparam.sendCooldownSec = sendCooldownSec
		lcontroller.taskparam.receiveCooldownSec = receiveCooldownSec

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = msgId or 0
			}
			local data3 = {
				valtype = "val",
				val = sendCooldownSec or 0
			}
			local data4 = {
				valtype = "val",
				val = receiveCooldownSec or 0
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local taskparam = controller.taskparam
		local targetObjId = ResolveObjId(taskparam.targetObjId)

		if not targetObjId or targetObjId <= 0 or not taskparam.msgId or taskparam.msgId <= 0 or not taskparam.sendCooldownSec or taskparam.sendCooldownSec < 0 or not taskparam.receiveCooldownSec or taskparam.receiveCooldownSec < 0 then
			return controller.fail()
		end

		local queuedReceiverCount = GetInst("BTSummonMessageManager"):SendToActor(selfActor, targetObjId, taskparam.msgId, taskparam.sendCooldownSec, taskparam.receiveCooldownSec)

		if queuedReceiverCount and queuedReceiverCount > 0 then
			return controller.success()
		end

		return controller.fail()
	end
}
