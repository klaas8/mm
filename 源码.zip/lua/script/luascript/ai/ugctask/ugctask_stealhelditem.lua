return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local targetObjId = controller.taskparam.targetObjId
		local putInHand = controller.taskparam.putInHand

		if type(targetObjId) == "string" then
			targetObjId = tonumber(targetObjId)
		end

		if type(putInHand) == "string" then
			putInHand = putInHand == "==" or putInHand == "true" or putInHand == "1"
		elseif putInHand then
			putInHand = true
		else
			putInHand = false
		end

		if targetObjId == nil or targetObjId <= 0 then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local ret = AIFunctionMgr:StealActorHandItem(selfActor, targetObjId, putInHand)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local targetObjId = result[1]
		local putInHand = result[2]

		if type(targetObjId) == "string" then
			targetObjId = tonumber(targetObjId)
		end

		if type(putInHand) == "string" then
			putInHand = putInHand == "==" or putInHand == "true" or putInHand == "1"
		elseif putInHand then
			putInHand = true
		else
			putInHand = false
		end

		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.putInHand = putInHand

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
