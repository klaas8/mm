return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local targetObjIds = controller.taskparam.targetObjIds
		local attrType = controller.taskparam.attrType
		local operateType = controller.taskparam.operateType
		local attrValue = controller.taskparam.attrValue

		if not targetObjIds or not attrType or not operateType or not attrValue then
			return controller.fail()
		end

		local success = false

		if targetObjIds.size then
			local size = targetObjIds:size()

			for i = 0, size - 1 do
				local targetObj = {
					objType = "Mob",
					actor = targetObjIds[i]
				}
				local ret = BTService:ChangeObjAttr(targetObj, attrType, attrValue, operateType)

				if ret == ErrorCode.OK then
					success = true
				end
			end
		elseif type(targetObjIds) == "table" and #targetObjIds > 0 then
			for index, value in ipairs(targetObjIds) do
				local targetObj = {
					objType = "Mob",
					actor = value.objid
				}
				local ret = BTService:ChangeObjAttr(targetObj, attrType, attrValue, operateType)

				if ret == ErrorCode.OK then
					success = true
				end
			end
		end

		if success then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"targetObj",
			"attrType",
			"operateType",
			"attrValue"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetObjIds = result[1]
		local attrType = result[2]
		local operateType = result[3]
		local attrValue = result[4]
		lcontroller.taskparam.targetObjIds = targetObjIds
		lcontroller.taskparam.attrType = attrType
		lcontroller.taskparam.operateType = operateType
		lcontroller.taskparam.attrValue = attrValue

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actors"
			}
			local data2 = {
				valtype = "enum",
				val = attrType
			}
			local data3 = {
				valtype = "enum",
				val = operateType
			}
			local data4 = {
				valtype = "val",
				val = attrValue
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
