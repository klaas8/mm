return {
	will = function ()
		local selfActor = controller.target.get("mob")

		if not selfActor or not selfActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get("mob")

		selfActor:setInDefanceState(false)

		local itemId = AIFunctionMgr:GetHoldItemId(selfActor)

		if itemId >= 540000 and itemId <= 545000 then
			AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_LEFTDEFENSE, false)
		else
			AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_DEFENSE, false)
		end

		return controller.success()
	end,
	onend = function ()
	end
}
