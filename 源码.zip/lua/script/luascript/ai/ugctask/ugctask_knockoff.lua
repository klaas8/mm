return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local obj = result[1]
		local dist = result[2]
		local motion = result[3]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.dist = dist
		lcontroller.taskparam.motion = motion

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = dist
			}
			local data3 = {
				valtype = "val",
				val = motion
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end,
	will = function ()
		local objid = controller.taskparam.obj

		if not objid or objid <= -1 then
			return false
		end

		local distance = controller.taskparam.dist

		if not controller.taskparam.motion or not distance then
			return false
		end

		local selfObj = controller.target.get()
		local targetObj = AIFunctionMgr:getActorByObjId(selfObj, objid)

		if not targetObj or not targetObj:alive() then
			return false
		end

		local position = targetObj:getPosition()
		local currdist = PosSquareDistanceToPos(selfObj:getPosition(), position)

		if math.pow(BLOCK_SIZE * distance, 2) < currdist then
			controller.taskparam.targetPos = position
		else
			controller.taskparam.targetPos = nil
		end

		return true
	end,
	onbeg = function ()
		local selfObj = controller.target.get()
		local targetPos = controller.taskparam.targetPos

		if targetPos ~= nil then
			local path_range = btget_path_range()
			local x = targetPos.x
			local y = targetPos.y
			local z = targetPos.z

			selfObj:getNavigator():tryMoveTo(x, y, z, 1.2, path_range)
		end
	end,
	run = function ()
		local selfObj = controller.target.get()
		local targetPos = controller.taskparam.targetPos

		if targetPos ~= nil then
			local distance = controller.taskparam.dist
			local distance_ = math.pow(BLOCK_SIZE * distance, 2)
			local currdist = PosSquareDistanceToPos(selfObj:getPosition(), targetPos)

			while not selfObj:getNavigator():noPath() or distance_ < currdist do
				if currdist <= distance_ or selfObj:getNavigator():noPath() then
					break
				end

				currdist = PosSquareDistanceToPos(selfObj:getPosition(), targetPos)

				controller.wait()
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfObj, controller.taskparam.obj)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfObj, targetActor)

		if not selfObj:isUnsighted() and not ActorComponentCallModule(selfObj, "ActorVision", "canSeeInAICache", targetActor) then
			return controller.fail()
		end

		selfObj:stopAnim(SEQ_ATTACK)
		selfObj:playAttackSound()
		selfObj:playAnim(SEQ_ATTACK)

		if AIFunctionMgr:KnockOff(selfObj, targetActor, controller.taskparam.motion) then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
		local selfObj = controller.target.get()

		selfObj:getNavigator():clearPathEntity()
	end
}
