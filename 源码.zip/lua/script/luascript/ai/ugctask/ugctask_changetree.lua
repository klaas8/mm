return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local treeid = controller.taskparam.treeid

		if not treeid then
			return controller.fail()
		end

		local dir = GetBtreeDirByUUID(treeid)

		if string.len(dir) <= 0 then
			return controller.fail()
		end

		local treepath = dir .. "/btree.lua"
		local bbpath = dir .. "/blackboard.lua"
		local actor = controller.target.get()
		local ret = AIFunctionMgr:ChangeBtree(actor, treeid, treepath, bbpath)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local treeid = result[1]
		lcontroller.taskparam.treeid = treeid

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = treeid
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
