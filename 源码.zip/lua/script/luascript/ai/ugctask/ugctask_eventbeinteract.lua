return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local itemId = controller.taskparam.itemId
		local bbkey = controller.taskparam.bbkey
		local isUsing = controller.taskparam.isUsing

		if not itemId or itemId <= 0 or not bbkey then
			return controller.fail()
		end

		local eventparm = controller.taskparam.eventParam

		if eventparm and itemId == eventparm.itemid then
			local targetActor = {
				actor = eventparm.toobjid
			}

			if type(bbkey) == "table" then
				if bbkey.func and type(bbkey.func) == "function" then
					bbkey.func({
						value = eventparm.toobjid,
						controller = controller
					})
				end
			else
				controller.bb.set(bbkey, targetActor)
			end

			if isUsing then
				AIFunctionMgr:ConsumeHandItem(selfActor, eventparm.toobjid)
			end

			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local itemId = result[1]
		local bbkey = result[2]
		local isUsing = result[3]
		itemId = lBTService:ResidToId(itemId)

		if isUsing == nil then
			isUsing = false
		elseif isUsing == "==" then
			isUsing = true
		else
			isUsing = false
		end

		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.bbkey = bbkey
		lcontroller.taskparam.isUsing = isUsing

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId or 0
				}
			}
			local data2 = {
				valtype = "getName"
			}
			local data3 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
