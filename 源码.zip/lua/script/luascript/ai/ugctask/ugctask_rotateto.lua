return {
	will = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local actor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not actor then
			return false
		end

		controller.taskparam.targetObj = actor

		return true
	end,
	onbeg = function ()
		local actor = controller.taskparam.targetObj

		if not actor or actor:isDead() or actor:needClear() then
			return false
		end

		local actorPos = actor:getPosition()
		local targetPos = controller.taskparam.targetPos
		local target_x = targetPos.x * 100
		local target_y = targetPos.y * 100
		local target_z = targetPos.z * 100
		local dir = {
			x = target_x - actorPos.x,
			y = target_y - actorPos.y,
			z = target_z - actorPos.z
		}
		local yaw_dst, pitch_dst = Direction2PitchYaw(dir.x, dir.y, dir.z)
		controller.taskparam.yaw_dst = WrapAngleTo180(yaw_dst)
		controller.taskparam.pitch_dst = WrapAngleTo180(pitch_dst)
		controller.taskparam.t = 0
	end,
	run = function ()
		local actor = controller.taskparam.targetObj

		if actor.IsStopBodyRotation then
			actor.IsStopBodyRotation = false
		end

		local yaw_dst = controller.taskparam.yaw_dst
		local pitch_dst = controller.taskparam.pitch_dst
		local targetObjId = controller.taskparam.targetObjId
		local selfActor = controller.target.get()
		actor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
		local locoMotion = actor:getLocoMotion()

		while controller.taskparam.t <= controller.taskparam.duration do
			actor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

			if not actor or actor:isDead() or actor:needClear() or not actor:alive() then
				return controller.fail()
			end

			local locoMotion = actor:getLocoMotion()

			if not locoMotion then
				return controller.fail()
			end

			local duration = controller.taskparam.duration

			if duration == 0 then
				duration = 0.001
			end

			local yaw_src = WrapAngleTo180(locoMotion:getRotateYaw())
			local pitch_src = WrapAngleTo180(locoMotion:getRotatePitch())
			yaw_src = WrapAngleToSameSign(yaw_src, yaw_dst)
			local rotateYaw = math.lerp(yaw_src, yaw_dst, controller.taskparam.t / duration)

			actor:getBody():lerpRotateTo(rotateYaw)
			locoMotion:setRotatePitch(math.lerp(pitch_src, pitch_dst, controller.taskparam.t / duration))

			local t = controller.taskparam.t
			controller.taskparam.t = controller.taskparam.t + 0.05

			controller.wait()
		end

		return controller.success()
	end,
	onend = function ()
		controller.taskparam.t = 0
		controller.taskparam.duration = 0
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local targetObjId = result[1]
		local targetPos = result[2]
		local duration = result[3]
		lcontroller.taskparam.targetPos = targetPos
		lcontroller.taskparam.duration = duration
		lcontroller.taskparam.targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "pos",
				val = targetPos
			}
			local data3 = {
				valtype = "val",
				val = duration
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
