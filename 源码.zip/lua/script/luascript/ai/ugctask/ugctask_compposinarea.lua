return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local position = controller.taskparam.position
		local cmpEnumType = controller.taskparam.cmpEnumType
		local areaId = controller.taskparam.areaId

		if not BTService:IsXYZ(position) then
			return controller.fail()
		end

		if not cmpEnumType then
			return controller.fail()
		end

		local ret = false
		ret = BTService:PosInArea(areaId, position)

		if cmpEnumType == "==" then
			if ret then
				return controller.success()
			end
		elseif cmpEnumType == "~=" and not ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local newpos = result[1]
		local cmpEnumType = result[2]
		local areaId = result[3]
		lcontroller.taskparam.position = newpos
		lcontroller.taskparam.cmpEnumType = cmpEnumType
		lcontroller.taskparam.areaId = areaId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = newpos
			}
			local data2 = {
				valtype = "enum",
				val = cmpEnumType
			}
			local data3 = {
				valtype = "area",
				val = lBTService:GetAreaDebugData(areaId)
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
