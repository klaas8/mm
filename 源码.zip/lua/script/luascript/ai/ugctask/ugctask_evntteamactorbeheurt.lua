return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local rang = result[1]
		local bbkey = result[2]
		local taskpram = lcontroller.taskparam
		taskpram.rang = rang
		taskpram.bbkey = bbkey

		if lcontroller:isNeedSendDebug() then
			local senddata = {}
			local sendval = {}

			table.insert(senddata, {
				valtype = "val",
				val = rang
			})

			if taskpram.bbkey then
				sendval.valtype = "getName"
			end

			table.insert(senddata, sendval)
			lcontroller.sendValToDebug(senddata)
		end
	end,
	run = function ()
		local taskpram = controller.taskparam
		local rang = controller.taskparam.rang

		if not taskpram.bbkey or rang == nil then
			return controller.fail()
		end

		local selfObj = controller.target.get()
		local eventparm = taskpram.eventParam
		local trang = eventparm.hurtlv

		if trang <= rang then
			local targetActor = {
				actor = eventparm.toobjid
			}

			if type(taskpram.bbkey) == "table" then
				if taskpram.bbkey.func and type(taskpram.bbkey.func) == "function" then
					taskpram.bbkey.func({
						value = eventparm.toobjid,
						controller = controller
					})
				end
			else
				controller.bb.set(taskpram.bbkey, targetActor)
			end

			return controller.success()
		end

		return controller.fail()
	end
}
