return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor then
			return controller.fail()
		end

		local setobj = controller.taskparam.setobj
		local nAnchorId = controller.taskparam.nAnchorId

		if type(nAnchorId) == "string" then
			nAnchorId = tonumber(nAnchorId)
		end

		local model = controller.taskparam.model

		if not setobj or not nAnchorId or not model then
			return controller.fail()
		end

		local setobjActor = AIFunctionMgr:getActorByObjId(selfActor, setobj)

		if not setobjActor then
			return controller.fail()
		end

		local ret = AIFunctionMgr:SetAvatarModel(setobjActor, nAnchorId, model)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local actor = result[1]
		local nAnchorId = result[2]
		local model = result[3]
		lcontroller.taskparam.setobj = actor
		lcontroller.taskparam.nAnchorId = nAnchorId
		lcontroller.taskparam.model = model

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = actor or 0
				}
			}
			local data2 = {
				valtype = "enum",
				val = nAnchorId
			}
			local data3 = {
				valtype = "enum",
				val = model
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
