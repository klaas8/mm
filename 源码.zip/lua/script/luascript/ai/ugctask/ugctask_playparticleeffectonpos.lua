local TEST_TEST_TEST = false
local once = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetPos, particleId, scale = nil

		if TEST_TEST_TEST then
			scale = 1
			particleId = 1022
			targetPos = {
				y = 7,
				x = 0,
				z = 0
			}
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 3, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3
				})
			end

			scale = result[3]
			particleId = result[2]
			targetPos = result[1]
		end

		lcontroller.taskparam.ugc_position = targetPos
		lcontroller.taskparam.ugc_particleId = particleId
		lcontroller.taskparam.ugc_scale = scale

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = targetPos
			}
			local data2 = {
				valtype = "effecttype",
				val = {
					effectid = particleId
				}
			}
			local data3 = {
				valtype = "val",
				val = scale
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end,
	will = function ()
		if TEST_TEST_TEST then
			if once then
				return false
			end

			once = true
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		if type(controller.taskparam.ugc_position) ~= "table" then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local position = controller.taskparam.ugc_position
		local particleId = controller.taskparam.ugc_particleId
		local scale = controller.taskparam.ugc_scale
		local actor = controller.target.get()
		local world = CurWorld

		if actor then
			world = actor:getWorld()
		end

		local ret = false

		if Service and Service.World then
			local posx = position.x or 0
			local posy = position.y or 0
			local posz = position.z or 0
			local local_scale = scale or 1
			ret = Service.World:PlayParticle({
				x = posx,
				y = posy,
				z = posz
			}, particleId, nil, nil, nil, {
				x = local_scale,
				y = local_scale,
				z = local_scale
			}, world:getCurMapID())
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
