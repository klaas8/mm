return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local parttype = controller.taskparam.parttype

		if not parttype then
			return controller.fail()
		end

		local selfActor = controller.target.get()

		if not AIFunctionMgr.PartIsExit then
			return controller.fail()
		end

		local result = AIFunctionMgr:PartIsExit(selfActor, parttype)

		if not result then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"parttype"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local parttype = result[1]
		lcontroller.taskparam.parttype = parttype

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = parttype
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
