return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local pathid = result[1]
		local speed = result[2]
		local iswhile = result[3]
		local isResetCurentindex = result[4]
		lcontroller.taskparam.pathid = pathid
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.isWhile = lBTService:GetBoolVal(iswhile)
		lcontroller.taskparam.ugc_isResetCurentindex = lBTService:GetBoolVal(isResetCurentindex)

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "msg",
				val = pathid
			}
			local data2 = {
				valtype = "val",
				val = speed
			}
			local data3 = {
				valtype = "enum",
				val = iswhile
			}
			local data4 = {
				valtype = "enum",
				val = isResetCurentindex
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end,
	will = function ()
		local actor = controller.target.get()

		if not actor or actor:isDead() or actor:needClear() then
			return false
		end

		local pathid = controller.taskparam.pathid
		local iswhile = controller.taskparam.isWhile

		if not pathid or iswhile == nil or controller.taskparam.speed == nil or type(controller.taskparam.speed) ~= "number" then
			return false
		end

		local points = BTService:GetGroupData(pathid, VARTYPE.SITEGROUP, controller)

		if type(points) ~= "table" or #points == 0 then
			return false
		end

		if iswhile then
			local tempWhilePos = {}

			for i = #points - 1, 1, -1 do
				table.insert(tempWhilePos, points[i])
			end

			for _, v in ipairs(tempWhilePos) do
				table.insert(points, v)
			end
		end

		controller.taskparam.num = #points
		controller.taskparam.poss = points

		if controller.taskparam.ugc_isResetCurentindex then
			controller.taskparam.curentindex = 1
		else
			controller.taskparam.curentindex = controller.taskparam.curentindex or 1

			if controller.taskparam.num <= controller.taskparam.curentindex then
				controller.taskparam.curentindex = 1
			end
		end

		local path_range = btget_path_range()
		local index = controller.taskparam.curentindex
		local x, y, z = BlockBottomCoord(points[index].x, points[index].y, points[index].z)
		controller.taskparam.path = actor:getNavigator():newCanMoveTo(x, y, z, path_range)

		if controller.taskparam.path then
			return true
		else
			return false
		end
	end,
	onbeg = function ()
		local actor = controller.target.get()
		local points = controller.taskparam.poss
		local index = controller.taskparam.curentindex
		local x, y, z = BlockBottomCoord(points[index].x, points[index].y, points[index].z)
		local speed = controller.taskparam.speed
		local path_range = btget_path_range()

		if controller.taskparam.path then
			actor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
		end
	end,
	run = function ()
		local actor = controller.target.get()

		controller.wait_until(function ()
			local index = controller.taskparam.curentindex
			local num = controller.taskparam.num

			return actor:getNavigator():noPath() and num <= index
		end)

		return controller.success()
	end,
	onwait = function ()
		local index = controller.taskparam.curentindex
		local points = controller.taskparam.poss
		local path_range = btget_path_range()
		local actor = controller.target.get()
		local speed = controller.taskparam.speed

		if actor:getNavigator():noPath() then
			actor:getNavigator():clearPathEntity()

			controller.taskparam.curentindex = index + 1
			index = controller.taskparam.curentindex

			if index <= #points then
				local pos = points[index]
				local x, y, z = BlockBottomCoord(pos.x, pos.y, pos.z)
				controller.taskparam.path = actor:getNavigator():newCanMoveTo(x, y, z, path_range)

				if controller.taskparam.path then
					actor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

					controller.taskparam.path = nil
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local actor = controller.target.get()

		actor:getNavigator():clearPathEntity()
	end
}
