return {
	will = function ()
		local selfobj = controller.target.get()
		local num = controller.taskparam.num
		local targetPos = controller.taskparam.targetPos
		local tag = controller.taskparam.tag

		if not selfobj or not selfobj:alive() or not num or not tag then
			return false
		end

		if not BTService:IsXYZ(targetPos) then
			local ret_, newpos = BTService:GetPositionData(targetPos)

			if ret_ == ErrorCode.OK then
				targetPos = newpos
			else
				return false
			end
		end

		local speed = 1
		local posx = targetPos.x or 0
		local posy = targetPos.y or 0
		local posz = targetPos.z or 0
		local pos_x, pos_y, pos_z = BlockBottomCoord(posx, posy, posz)
		local path_range = btget_path_range()

		selfobj:getNavigator():tryMoveTo(pos_x, pos_y, pos_z, speed, path_range)

		controller.taskparam.newTargetPos = {
			x = pos_x,
			y = pos_y,
			z = pos_z
		}

		return true
	end,
	onbeg = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local newTargetPos = controller.taskparam.newTargetPos

		if not newTargetPos then
			return controller.fail()
		end

		local num = controller.taskparam.num
		local targetPos = controller.taskparam.targetPos
		local tag = controller.taskparam.tag

		if not num or not targetPos or not tag then
			return controller.fail()
		end

		local searchType = controller.taskparam.searchType
		searchType = searchType or 2
		local hasNum = AIFunctionMgr:getTagItemCountByBags(selfobj, tag, searchType)

		if hasNum == 0 then
			return controller.fail()
		end

		local distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

		while not selfobj:getNavigator():noPath() or distance > BLOCK_SIZE * 100 do
			if distance <= BLOCK_SIZE or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

			controller.wait()
		end

		local posx = targetPos.x or 0
		local posy = targetPos.y or 0
		local posz = targetPos.z or 0
		local result = AIFunctionMgr:StoreItemByTag(selfobj, posx, posy, posz, tag, num, searchType)

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local pos = result[1]
		local num = result[2]
		local tag = result[3]
		local searchType = result[4]
		lcontroller.taskparam.searchType = searchType
		lcontroller.taskparam.targetPos = pos
		lcontroller.taskparam.num = num
		local debugtag = ""
		local needSendDebug = lcontroller:isNeedSendDebug()
		lcontroller.taskparam.tag, debugtag = lBTService:DealTagToArrayData(tag, needSendDebug, lcontroller.taskparam.tag)

		if needSendDebug then
			local data1 = {
				valtype = "pos",
				val = pos
			}
			local data2 = {
				valtype = "val",
				val = num
			}
			local data3 = {
				valtype = "enum"
			}
			local data4 = {
				valtype = "val",
				val = debugtag
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
