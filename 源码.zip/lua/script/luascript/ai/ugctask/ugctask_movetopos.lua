return {
	will = function ()
		local actor = controller.target.get()

		if not actor or actor:isDead() or actor:needClear() or not actor:getLocoMotion() then
			return false
		end

		local targetPos = controller.taskparam.pos

		if type(targetPos) ~= "table" then
			return false
		end

		local c_pos = actor:getPosition()
		local b_x, b_y, b_z = CoordDivBlock(c_pos.x, c_pos.y, c_pos.z)

		if b_x == targetPos.x and b_y == targetPos.y and b_z == targetPos.z then
			return true
		end

		local x, y, z = nil

		if actor:IsMobComponent() then
			x, y, z = BlockBottomCoord(targetPos.x, targetPos.y, targetPos.z)
		else
			x, y, z = BlockCenterCoord(targetPos.x, targetPos.y, targetPos.z)
		end

		local path_range = btget_path_range()
		controller.taskparam.path = actor:getNavigator():newCanMoveTo(x, y, z, path_range)

		if controller.taskparam.path then
			return true
		else
			return false
		end
	end,
	onbeg = function ()
		local actor = controller.target.get()
		local changeToward = controller.taskparam.changeToward
		controller.taskparam.lastYaw = nil

		if not changeToward then
			local locoMotion = actor:getLocoMotion()

			if locoMotion then
				controller.taskparam.lastYaw = locoMotion:getRotateYaw()
			end
		end

		if actor.IsStopBodyRotation == changeToward then
			actor.IsStopBodyRotation = not changeToward
		end

		local speed = controller.taskparam.speed
		local path_range = btget_path_range()

		if controller.taskparam.path then
			actor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
			controller.taskparam.curRetryCount = 3
		end
	end,
	run = function ()
		local actor = controller.target.get()
		local lcontroller = controller

		if actor:IsInNavigating() then
			controller.wait_until(function ()
				return not actor:IsInNavigating()
			end)
		end

		local navigator = actor:getNavigator()
		local locoMotion = actor:getLocoMotion()
		local actorBound = ternary(actor:IsMobComponent(), locoMotion:GetBoundSize(), math.max(locoMotion:GetBoundSize(), locoMotion:GetBoundHeight() * 0.5))
		local targetPos = lcontroller.taskparam.pos
		local targetActorPosX, targetActorPosY, targetActorPosZ = BlockCenterCoord(targetPos.x, targetPos.y, targetPos.z)
		local retryCount = lcontroller.taskparam.curRetryCount or 0

		while true do
			local curActorPos = actor:getPosition()
			local dist = 0

			if actor:IsMobComponent() then
				dist = btget_Pos_Dist(curActorPos.x, 0, curActorPos.z, targetActorPosX, 0, targetActorPosZ)
			else
				dist = btget_Pos_Dist(curActorPos.x, curActorPos.y, curActorPos.z, targetActorPosX, targetActorPosY, targetActorPosZ)
			end

			local reachDist = btget_MovPos_Threshold() * BLOCK_SIZE + actorBound

			if dist < reachDist then
				return lcontroller.success()
			end

			if retryCount <= 0 then
				return controller.fail()
			end

			retryCount = retryCount - 1
			lcontroller.taskparam.curRetryCount = retryCount

			navigator:clearPathEntity()

			local x, y, z = nil

			if actor:IsMobComponent() then
				x, y, z = BlockBottomCoord(targetPos.x, targetPos.y, targetPos.z)
			else
				x, y, z = BlockCenterCoord(targetPos.x, targetPos.y, targetPos.z)
			end

			local pathRange = btget_path_range()
			local retryPath = navigator:newCanMoveTo(x, y, z, pathRange)

			if retryPath then
				navigator:newTryMoveTo(retryPath, controller.taskparam.speed, pathRange)
				lcontroller.wait_until(function ()
					return not actor:IsInNavigating()
				end)
			end
		end
	end,
	onend = function ()
		local actor = controller.target.get()

		actor:getNavigator():clearPathEntity()
		BTService:RestoreSavedYaw(actor, controller.taskparam)

		actor.IsStopBodyRotation = false
		controller.taskparam.curRetryCount = nil
	end,
	release = function ()
		local actor = controller.target.get()
		local shouldRestoreRotation = actor and controller.taskparam.lastYaw ~= nil

		BTService:RestoreSavedYaw(actor, controller.taskparam)

		if shouldRestoreRotation then
			actor.IsStopBodyRotation = false
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local targetPos = result[1]
		local speed = result[2]
		local changeToward = result[3]
		changeToward = changeToward == "==" and true or false
		lcontroller.taskparam.pos = targetPos
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.changeToward = changeToward

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = targetPos
			}
			local data2 = {
				valtype = "val",
				val = speed
			}
			local data3 = {
				valtype = "enum",
				val = changeToward
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
