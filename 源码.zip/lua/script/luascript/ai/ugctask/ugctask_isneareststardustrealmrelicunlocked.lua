return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local range = controller.taskparam.range

		if not selfActor or not selfActor:alive() or range == nil then
			return controller.fail()
		end

		local ret = AIFunctionMgr:IsNearestStardustRealmRelicUnlocked(selfActor, range)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local range = result[1]
		lcontroller.taskparam.range = range

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = range
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
