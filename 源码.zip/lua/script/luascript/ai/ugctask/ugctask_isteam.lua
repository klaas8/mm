local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local targetObjId, teamid = nil

		if TEST_TEST_TEST then
			teamid = 36
			targetObjId = CurMainPlayer:getObjId()
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 2, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2
				})
			end

			teamid = result[2]
			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId
		local realTeamId = lBTService:GetFactorType(teamid)
		lcontroller.taskparam.ugc_teamid = realTeamId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId
				}
			}
			local data2 = {
				valtype = "enum",
				val = realTeamId
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	run = function ()
		local targetObjId = controller.taskparam.ugc_targetObjId
		local teamid = controller.taskparam.ugc_teamid

		if not targetObjId or not teamid then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor then
			return controller.fail()
		end

		if not targetActor.getTeam then
			return controller.fail()
		end

		local actorLiving = tolua.cast(targetActor, "ActorLiving")

		if not actorLiving then
			return controller.fail()
		end

		if actorLiving:getTeam() == teamid then
			return controller.success()
		else
			return controller.fail()
		end
	end
}
