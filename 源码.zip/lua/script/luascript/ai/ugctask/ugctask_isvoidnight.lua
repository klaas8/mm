return {
	send_debug_data = function ()
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		if WorldMgr and WorldMgr.isVoidNight and WorldMgr:isVoidNight() then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
