return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local item = controller.taskparam.item
		local num = controller.taskparam.num
		local offset = controller.taskparam.offset

		if item == nil or num == nil or offset == nil then
			return controller.fail()
		end

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		if num <= 0 then
			return controller.fail()
		end

		if not CheckItemScriptUse(item) then
			return controller.fail()
		end

		local ret = AIFunctionMgr:CreateDropItem(selfActor, item, num, offset.x, offset.y, offset.z)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	onend = function ()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local num = result[1]
		local item = result[2]
		local offset = result[3]
		lcontroller.taskparam.num = num
		lcontroller.taskparam.item = item
		lcontroller.taskparam.offset = offset

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = num
			}
			local data2 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}
			local data3 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
