return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local item = controller.taskparam.item
		local num = controller.taskparam.num

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		if item == nil or num == nil then
			return controller.fail()
		end

		local curnum = AIFunctionMgr:getBagItemCount(selfActor, item)

		if curnum < num then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local num = result[1]
		local item = result[2]
		lcontroller.taskparam.num = num
		lcontroller.taskparam.item = item

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = num
			}
			local data2 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
