return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local obj = result[1]
		lcontroller.taskparam.obj = obj

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end,
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.obj

		if not objid then
			return controller.fail()
		end

		local obj = controller.target.get()
		local actor = AIFunctionMgr:getActorByObjId(obj, objid)

		if actor then
			actor:getNavigator():clearPathEntity()

			return controller.success()
		else
			return controller.fail()
		end
	end
}
