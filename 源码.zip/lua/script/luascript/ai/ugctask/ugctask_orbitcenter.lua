local Task = {}
local ORBIT_STATE_RUNNING = 1
local ORBIT_STATE_FINISHED = 2

function Task.IsActorValid(actor)
	return actor and actor:alive() and not actor:isDead() and not actor:needClear()
end

function Task.IsValidPos(pos)
	if type(pos) ~= "table" then
		return false
	end

	local x = tonumber(pos.x)
	local y = tonumber(pos.y)
	local z = tonumber(pos.z)

	if x == nil or y == nil or z == nil then
		return false
	end

	return x ~= 0 or y ~= 0 or z ~= 0
end

function Task.send_debug_data()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam then
		return
	end

	local lBTService = BTService
	local result = nil

	if lBTService:IsSubparamReuseEnabled() then
		result = lBTService:GetSubparamOutputBuffer(ctrl)

		lBTService:GetSubparamInto(ctrl, 4, result)
	else
		result = btget_subparam(ctrl, {
			1,
			2,
			3,
			4
		})
	end

	local centerPos = result[1]
	local radiusBlock = result[2]
	local speedScale = result[3]
	local circleCount = result[4]
	ctrl.taskparam.centerPos = centerPos
	ctrl.taskparam.radiusBlock = tonumber(radiusBlock) or 3
	ctrl.taskparam.speedScale = tonumber(speedScale) or 1
	ctrl.taskparam.circleCount = tonumber(circleCount) or 1

	if ctrl:isNeedSendDebug() then
		local data1 = {
			valtype = "pos",
			val = centerPos
		}
		local data2 = {
			valtype = "val",
			val = ctrl.taskparam.radiusBlock
		}
		local data3 = {
			valtype = "val",
			val = ctrl.taskparam.speedScale
		}
		local data4 = {
			valtype = "val",
			val = ctrl.taskparam.circleCount
		}

		ctrl.sendValToDebug({
			data1,
			data2,
			data3,
			data4
		})
	end
end

function Task.will()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return false
	end

	local selfActor = ctrl.target.get()

	if not Task.IsActorValid(selfActor) then
		return false
	end

	local centerPos = ctrl.taskparam.centerPos
	local radiusBlock = tonumber(ctrl.taskparam.radiusBlock)
	local speedScale = tonumber(ctrl.taskparam.speedScale)
	local circleCount = tonumber(ctrl.taskparam.circleCount)

	return Task.IsValidPos(centerPos) and radiusBlock and radiusBlock > 0 and speedScale and speedScale > 0 and circleCount and circleCount > 0
end

function Task.onbeg()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return
	end

	ctrl.taskparam.orbitStarted = nil
	ctrl.taskparam.orbitStartFailed = nil
	local selfActor = ctrl.target.get()

	if not Task.IsActorValid(selfActor) then
		ctrl.taskparam.orbitStartFailed = true

		return
	end

	local navigator = selfActor:getNavigator()

	if navigator then
		navigator:clearPathEntity()

		if navigator.StopDirectionMove then
			navigator:StopDirectionMove()
		end
	end

	local centerPos = ctrl.taskparam.centerPos
	local ok = AIFunctionMgr:StartOrbitCenter(selfActor, tonumber(centerPos.x), tonumber(centerPos.y), tonumber(centerPos.z), tonumber(ctrl.taskparam.radiusBlock), tonumber(ctrl.taskparam.speedScale), tonumber(ctrl.taskparam.circleCount))
	ctrl.taskparam.orbitStarted = ok and true or nil
	ctrl.taskparam.orbitStartFailed = not ok
end

function Task.run()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return false
	end

	if ctrl.taskparam.orbitStartFailed then
		return ctrl.fail()
	end

	local selfActor = ctrl.target.get()

	if not Task.IsActorValid(selfActor) then
		return ctrl.fail()
	end

	local state = AIFunctionMgr:GetOrbitCenterState(selfActor)

	if state ~= ORBIT_STATE_FINISHED then
		ctrl.wait_until(function ()
			if not Task.IsActorValid(selfActor) then
				ctrl.taskparam.orbitFailed = true

				return true
			end

			local curState = AIFunctionMgr:GetOrbitCenterState(selfActor)

			if curState == ORBIT_STATE_FINISHED then
				return true
			end

			if curState ~= ORBIT_STATE_RUNNING then
				ctrl.taskparam.orbitFailed = true

				return true
			end

			return false
		end)
	end

	if ctrl.taskparam.orbitFailed then
		return ctrl.fail()
	end

	if not Task.IsActorValid(selfActor) then
		return ctrl.fail()
	end

	if AIFunctionMgr:GetOrbitCenterState(selfActor) ~= ORBIT_STATE_FINISHED then
		return ctrl.fail()
	end

	return ctrl.success()
end

function Task.onend()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return
	end

	local selfActor = ctrl.target.get()

	if Task.IsActorValid(selfActor) then
		AIFunctionMgr:StopOrbitCenter(selfActor)
	end

	ctrl.taskparam.orbitStarted = nil
	ctrl.taskparam.orbitStartFailed = nil
	ctrl.taskparam.orbitFailed = nil
end

return Task
