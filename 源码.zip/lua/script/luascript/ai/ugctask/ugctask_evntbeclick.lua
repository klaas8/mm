return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local clickType = tonumber(result[1])
		local bbkey = result[2]
		local taskParam = lcontroller.taskparam
		taskParam.bbkey = bbkey
		taskParam.clickType = clickType

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "enum",
				val = clickType
			}
			local data2 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	run = function ()
		local taskParam = controller.taskparam

		if not taskParam.clickType or not taskParam.bbkey then
			return controller.fail()
		end

		local clickType = taskParam.clickType
		local eventParam = taskParam.eventParam

		if not eventParam then
			return controller.fail()
		end

		local isSuccess = false

		if clickType == 2 then
			if not eventParam.touchEvtIsMobile and (eventParam.touchEvtPCMouseKey == 0 or eventParam.touchEvtPCMouseKey == 1) or eventParam.touchEvtIsMobile and (eventParam.touchEvtLayer == 0 or eventParam.touchEvtLayer == 1) then
				isSuccess = true
			end
		elseif not eventParam.touchEvtIsMobile and clickType == eventParam.touchEvtPCMouseKey or eventParam.touchEvtIsMobile and clickType == eventParam.touchEvtLayer then
			isSuccess = true
		end

		if not isSuccess then
			return controller.fail()
		end

		local eventobj = eventParam.toobjid

		if not eventobj then
			return controller.fail()
		end

		local targetActor = {
			uin = eventobj
		}

		if type(taskParam.bbkey) == "table" then
			if type(taskParam.bbkey.func) == "function" then
				taskParam.bbkey.func({
					value = eventobj,
					controller = controller
				})
			end
		else
			controller.bb.set(taskParam.bbkey, targetActor)
		end

		return controller.success()
	end
}
