return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local actor = controller.taskparam.targetObjId
		local num = controller.taskparam.num
		local item = controller.taskparam.item

		if actor == nil or num == nil or item == nil then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, actor)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)

			if item == nil then
				return controller.fail()
			end
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		local result = AIFunctionMgr:ConsumeItem(targetActor, item, num)

		if result then
			return controller.success()
		end

		return controller.fail()
	end,
	onend = function ()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local targetObjId = result[1]
		local num = result[2]
		local item = result[3]
		lcontroller.taskparam.item = item
		lcontroller.taskparam.num = num
		lcontroller.taskparam.targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = num
			}
			local data3 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
