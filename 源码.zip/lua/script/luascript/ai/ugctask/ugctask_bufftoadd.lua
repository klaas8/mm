return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local buff = controller.taskparam.buff

		if not objid or not buff then
			return controller.fail()
		end

		local buffid, bufflv = BTService:getBuffData(buff)

		if not buffid then
			return controller.fail()
		end

		local keeps = controller.taskparam.keeps
		local repeat_ = controller.taskparam.repeat_

		if type(repeat_) == "nil" then
			return controller.fail()
		end

		keeps = tonumber(keeps) or -1

		if repeat_ then
			keeps = 0
		elseif keeps > 0 then
			keeps = keeps * 20
		end

		local ret = BTService:GetSSObj("Buff"):addBuff(objid, buffid, bufflv, keeps)

		if ret == ErrorCode.OK then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local objid = result[1]
		local buff = result[2]
		local repeat_ = result[3]
		local keeps = result[4]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.buff = buff
		lcontroller.taskparam.repeat_ = lBTService:GetBoolVal(repeat_)
		lcontroller.taskparam.keeps = keeps

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid
				}
			}
			local data2 = {
				valtype = "def",
				val = {
					defid = buff or 0
				}
			}
			local data3 = {
				valtype = "val",
				val = repeat_
			}
			local data4 = {
				valtype = "val",
				val = keeps
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
