return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local tag = controller.taskparam.tag

		if tag == nil then
			return controller.fail()
		end

		local searchType = controller.taskparam.searchType
		searchType = searchType or 2
		local ret = AIFunctionMgr:EquipItemByTag(selfActor, tag, searchType)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local tag = result[1]
		local searchType = result[2]
		lcontroller.taskparam.searchType = searchType
		local debugtag = ""
		local needSendDebug = lcontroller:isNeedSendDebug()
		lcontroller.taskparam.tag, debugtag = lBTService:DealTagToArrayData(tag, needSendDebug, lcontroller.taskparam.tag)

		if needSendDebug then
			local data1 = {
				valtype = "enum"
			}
			local data2 = {
				valtype = "val",
				val = debugtag
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
