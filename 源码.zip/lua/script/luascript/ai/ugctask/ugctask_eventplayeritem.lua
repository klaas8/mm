local Task = {}

function Task.GetObjPosition(obj)
	if not obj or type(obj.getPosition) ~= "function" then
		return nil
	end

	local pos = obj:getPosition()

	if pos.x ~= nil and pos.y ~= nil and pos.z ~= nil then
		return {
			x = pos.x,
			y = pos.y,
			z = pos.z
		}
	end

	return nil
end

function Task.GetPlayerByUin(actor, uin)
	if not actor or type(actor.getWorld) ~= "function" then
		return nil
	end

	local world = actor:getWorld()

	if not world then
		return nil
	end

	if type(GetWorldActorMgr) == "function" then
		local actorMgr = GetWorldActorMgr(world)

		if actorMgr and type(actorMgr.findPlayerByUin) == "function" then
			local player = actorMgr:findPlayerByUin(uin)

			if player then
				return player
			end
		end
	end

	if type(world.GetPlayerByUin) == "function" then
		return world:GetPlayerByUin(uin)
	end

	if type(world.getPlayerByUin) == "function" then
		return world:getPlayerByUin(uin)
	end

	return nil
end

function Task.GetBlockPos(pos)
	if not pos or pos.x == nil or pos.y == nil or pos.z == nil then
		return nil
	end

	local x, y, z = CoordDivBlock(pos.x, pos.y, pos.z)

	return {
		x = x,
		y = y,
		z = z
	}
end

function Task.GetDistance(pos1, pos2)
	local blockPos1 = Task.GetBlockPos(pos1)
	local blockPos2 = Task.GetBlockPos(pos2)

	if not blockPos1 or not blockPos2 then
		return nil
	end

	local dx = blockPos1.x - blockPos2.x
	local dy = blockPos1.y - blockPos2.y
	local dz = blockPos1.z - blockPos2.z

	return math.sqrt(dx * dx + dy * dy + dz * dz)
end

function Task.SavePlayer(ctrl, bbkey, uin)
	if type(bbkey) == "table" then
		if type(bbkey.func) ~= "function" then
			return false
		end

		bbkey.func({
			value = uin,
			controller = ctrl
		})

		return true
	else
		if not ctrl or not ctrl.bb or type(ctrl.bb.set) ~= "function" then
			return false
		end

		ctrl.bb.set(bbkey, {
			uin = uin
		})

		return true
	end
end

function Task.onbeg()
end

function Task.onend()
end

function Task.decorator()
	return controller.success()
end

function Task.send_debug_data()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam then
		return
	end

	local lBTService = BTService
	local result = nil

	if lBTService:IsSubparamReuseEnabled() then
		result = lBTService:GetSubparamOutputBuffer(ctrl)

		lBTService:GetSubparamInto(ctrl, 3, result)
	else
		result = btget_subparam(ctrl, {
			1,
			2,
			3
		})
	end

	local itemEvent = result[1]
	local dist = tonumber(result[2])
	local bbkey = result[3]
	local taskpram = ctrl.taskparam
	taskpram.itemEvent = itemEvent
	taskpram.dist = dist
	taskpram.bbkey = bbkey

	if ctrl:isNeedSendDebug() then
		local senddata = {}

		table.insert(senddata, {
			valtype = "enum",
			val = itemEvent
		})
		table.insert(senddata, {
			valtype = "val",
			val = dist
		})

		local sendval = {}

		if taskpram.bbkey then
			sendval.valtype = "getName"
		end

		table.insert(senddata, sendval)
		ctrl.sendValToDebug(senddata)
	end
end

function Task.run()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target or type(ctrl.target.get) ~= "function" then
		return false
	end

	local taskpram = ctrl.taskparam

	if taskpram.bbkey == nil or not taskpram.dist or taskpram.dist <= 0 then
		return ctrl.fail()
	end

	local eventParam = taskpram.eventParam
	local eventobj = eventParam and eventParam.eventobjid

	if eventobj == nil then
		return ctrl.fail()
	end

	local selfActor = ctrl.target.get()
	local selfPos = Task.GetObjPosition(selfActor)

	if not selfPos then
		return ctrl.fail()
	end

	local player = Task.GetPlayerByUin(selfActor, eventobj)
	local playerPos = Task.GetObjPosition(player)

	if not playerPos then
		return ctrl.fail()
	end

	local distance = Task.GetDistance(playerPos, selfPos)

	if not distance or taskpram.dist < distance then
		return ctrl.fail()
	end

	if not Task.SavePlayer(ctrl, taskpram.bbkey, eventobj) then
		return ctrl.fail()
	end

	return ctrl.success()
end

return Task
