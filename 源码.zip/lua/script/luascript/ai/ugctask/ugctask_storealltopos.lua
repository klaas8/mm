return {
	onbeg = function ()
		local selfobj = controller.target.get()
		local targetPos = controller.taskparam.targetPos

		if type(targetPos) ~= "table" then
			local ret_, newpos = BTService:GetPositionData(targetPos)

			if ret_ == ErrorCode.OK then
				targetPos = newpos
			else
				return controller.fail()
			end
		end

		local speed = 1
		local posx = targetPos.x or 0
		local posy = targetPos.y or 0
		local posz = targetPos.z or 0
		local pos_x, pos_y, pos_z = BlockBottomCoord(posx, posy, posz)
		local path_range = btget_path_range()

		selfobj:getNavigator():tryMoveTo(pos_x, pos_y, pos_z, speed, path_range)

		controller.taskparam.newTargetPos = {
			x = pos_x,
			y = pos_y,
			z = pos_z
		}
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local newTargetPos = controller.taskparam.newTargetPos

		if not newTargetPos then
			return controller.fail()
		end

		local targetPos = controller.taskparam.targetPos
		local distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

		while not selfobj:getNavigator():noPath() or distance > BLOCK_SIZE * 100 do
			if distance <= BLOCK_SIZE or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

			controller.wait()
		end

		local posx = targetPos.x or 0
		local posy = targetPos.y or 0
		local posz = targetPos.z or 0
		local result = AIFunctionMgr:NewStoreAllItem(selfobj, posx, posy, posz)

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local position = result[1]
		lcontroller.taskparam.targetPos = position

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = position
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
