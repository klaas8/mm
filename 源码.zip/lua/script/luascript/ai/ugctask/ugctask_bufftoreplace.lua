return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local src_buff = controller.taskparam.src_buff
		local dst_buff = controller.taskparam.dst_buff

		if not src_buff or not dst_buff then
			return controller.fail()
		end

		local src_buffid, src_bufflv = BTService:getBuffData(src_buff)
		local dst_buffid, dst_bufflv = BTService:getBuffData(dst_buff)

		if not src_buffid or not dst_buffid then
			return controller.fail()
		end

		if src_buffid == dst_buffid and src_bufflv == dst_bufflv then
			return controller.success()
		end

		local BTBuff = BTService:GetSSObj("Buff")

		if not BTBuff then
			return controller.fail()
		end

		local objid = controller.taskparam.objid
		local ok = BTBuff:hasBuff(objid, src_buffid, src_bufflv)

		if ok ~= ErrorCode.OK then
			return controller.fail()
		end

		local ok, num = BTBuff:getBuffNumByBuffid(objid, src_buffid)

		if ok ~= ErrorCode.OK or num == 0 then
			return controller.fail()
		end

		if BTBuff:removeBuff(objid, src_buffid) ~= ErrorCode.OK then
			return controller.fail()
		end

		local keeps = controller.taskparam.keeps
		local repeat_ = controller.taskparam.repeat_

		if type(repeat_) == "nil" then
			return controller.fail()
		end

		keeps = tonumber(keeps) or -1

		if repeat_ then
			keeps = 0
		elseif keeps > 0 then
			keeps = keeps * 20
		end

		for i = 1, num do
			local ret = BTBuff:addBuff(objid, dst_buffid, dst_bufflv, keeps)

			if ret ~= ErrorCode.OK then
				return controller.fail()
			end
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 5, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4,
				5
			})
		end

		local objid = result[1]
		local src_buff = result[2]
		local dst_buff = result[3]
		local repeat_ = result[4]
		local keeps = result[5]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.src_buff = src_buff
		lcontroller.taskparam.dst_buff = dst_buff
		lcontroller.taskparam.repeat_ = lBTService:GetBoolVal(repeat_)
		lcontroller.taskparam.keeps = keeps

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid
				}
			}
			local data2 = {
				valtype = "effecttype",
				val = {
					effectid = src_buff
				}
			}
			local data3 = {
				valtype = "effecttype",
				val = {
					effectid = dst_buff
				}
			}
			local data4 = {
				valtype = "val",
				val = repeat_
			}
			local data5 = {
				valtype = "val",
				val = keeps
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4,
				data5
			})
		end
	end
}
