return {
	send_debug_data = function ()
		local lcontroller = controller
		local nums = #lcontroller.subparam
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, nums, result)
		else
			local gettable = {}

			for i = 1, nums do
				table.insert(gettable, i)
			end

			result = btget_subparam(lcontroller, gettable)
		end

		local obj = result[1]
		local comname = result[2]
		local propertyname = result[3]
		local values = {}

		for i = 4, nums do
			if type(result[i]) == "string" and (result[i] == "true" or result[i] == "false") then
				result[i] = result[i] == "true"
			end

			table.insert(values, result[i])
		end

		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.comname = comname
		lcontroller.taskparam.propertyname = propertyname
		lcontroller.taskparam.values = values

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "cmp",
				val = comname
			}
			local data3 = {
				valtype = "cmpFn",
				val = {
					cmp = comname,
					fnname = propertyname
				}
			}
			local data4 = {
				valtype = "val",
				val = values
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	onbeg = function ()
	end,
	run = function ()
		if not controller.taskparam.obj or not controller.taskparam.comname or not controller.taskparam.propertyname then
			return controller.fail()
		end

		local obj, componentReady = BTService:ResolveAndEnsureComponent(controller.taskparam.obj, controller.taskparam.comname)

		if obj and componentReady then
			local result = false

			if #controller.taskparam.values > 0 then
				result = Service.Trigger.Component:CallComponentFunction(obj, controller.taskparam.comname, controller.taskparam.propertyname, unpack(controller.taskparam.values))
			else
				result = Service.Trigger.Component:CallComponentFunction(obj, controller.taskparam.comname, controller.taskparam.propertyname)
			end

			if result then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	onend = function ()
	end
}
