return {
	run = function ()
		local bbkey = controller.taskparam.bbkey
		local bbvalue = controller.taskparam.bbvalue

		if not bbkey then
			return controller.fail()
		end

		if bbvalue == nil then
			bbvalue = -1
		end

		if type(bbkey) == "table" then
			if bbkey.func and type(bbkey.func) == "function" then
				bbkey.func({
					value = bbvalue,
					controller = controller
				})
			end
		else
			controller.bb.set(bbkey, {
				objid = bbvalue
			})
		end

		return controller.success()
	end,
	onend = function ()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local bbkey = result[1]
		local bbvalue = result[2]
		lcontroller.taskparam.bbkey = bbkey
		lcontroller.taskparam.bbvalue = bbvalue

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "getName"
			}
			local data2 = {
				valtype = "actor",
				val = {
					actor = bbvalue or 0
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
