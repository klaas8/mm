local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local p1, p2, p3, p4, p5, p6, p7 = nil

		if TEST_TEST_TEST then
			p6 = 8
			p5 = 1
			p4 = 1
			p3 = CurMainPlayer:getObjId()
			p2 = 12051
			p1 = 12050
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 7, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4,
					5,
					6,
					7
				})
			end

			p7 = result[7]
			p6 = result[6]
			p5 = result[5]
			p4 = result[4]
			p3 = result[3]
			p2 = result[2]
			p1 = result[1]
		end

		if p7 == nil then
			p7 = 1
		end

		lcontroller.taskparam.ugc_weaponId = p1
		lcontroller.taskparam.ugc_projectileId = p2
		lcontroller.taskparam.ugc_targetObjId = p3

		if p4 < 0.1 then
			p4 = 0.1
		end

		lcontroller.taskparam.ugc_chargedTime = p4

		if p5 < 0 then
			p5 = 0
		end

		lcontroller.taskparam.ugc_frequency = p5
		lcontroller.taskparam.ugc_distance = p6
		lcontroller.taskparam.ugc_speed = p7

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = p1 or 0
				}
			}
			local data2 = {
				valtype = "itemtype",
				val = {
					itemid = p2 or 0
				}
			}
			local data3 = {
				valtype = "actor",
				val = {
					actor = p3 or 0
				}
			}
			local data4 = {
				valtype = "val",
				val = p4
			}
			local data5 = {
				valtype = "val",
				val = p5
			}
			local data6 = {
				valtype = "val",
				val = p6
			}
			local data7 = {
				valtype = "val",
				val = p7
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4,
				data5,
				data6,
				data7
			})
		end
	end,
	will = function ()
		local selfActor = controller.target.get("mob")

		if not selfActor or not selfActor:alive() then
			return false
		end

		if not GameplayTagUtils:IsNormalAttackEnabled(selfActor) then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		controller.taskparam.cache_targetActor = targetActor

		if not controller.taskparam.cache_weaponDef then
			local toolDef = DefMgr:getToolDef(controller.taskparam.ugc_weaponId)

			if not toolDef then
				return false
			end

			controller.taskparam.cache_weaponDef = toolDef
		end

		local dis_min = selfActor:getLocoMotion().m_BoundSize + targetActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local dis_max = selfActor:getViewDist()
		local attack_dis = math.clamp(controller.taskparam.ugc_distance * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.cache_atkDistance = attack_dis
		local t_pos = targetActor:getPosition()

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.cache_targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, btget_path_range())

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.cache_targetPos = nil
			controller.taskparam.path = nil

			return true
		end
	end,
	onbeg = function ()
		local selfActor = controller.target.get("mob")
		local handItemId = controller.taskparam.ugc_weaponId

		if AIFunctionMgr:getBagItemCount(selfActor, handItemId, false) <= 0 then
			AIFunctionMgr:addItemToBags(selfActor, handItemId, 1)
		end

		AIFunctionMgr:equipWeapon(selfActor, handItemId, 1)

		if controller.taskparam.path then
			local targetActor = controller.taskparam.cache_targetActor
			local speed = controller.taskparam.ugc_speed

			selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, btget_path_range())

			controller.taskparam.path = nil

			selfActor:keepLookAt(targetActor, 10, 10)
		end
	end,
	run = function ()
		local selfActor = controller.target.get("mob")
		local targetActor = controller.taskparam.cache_targetActor
		local attack_dis = controller.taskparam.cache_atkDistance

		if controller.taskparam.cache_targetPos then
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), controller.taskparam.cache_targetPos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					if controller.taskparam.cache_targetPos then
						return Pos3SquareDistToPos3(selfActor:getPosition(), controller.taskparam.cache_targetPos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
					else
						return true
					end
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		controller.taskparam.cache_targetPos = nil
		targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		if not selfActor:isUnsighted() and not ActorComponentCallModule(selfActor, "ActorVision", "canSeeInAICache", targetActor) then
			return controller.fail()
		end

		local weaponId = AIFunctionMgr:GetHoldItemId(selfActor)

		if weaponId ~= controller.taskparam.ugc_weaponId then
			return controller.fail()
		end

		selfActor:setDirectSwitchAni(true)
		AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_SHOOT, true, false)

		local targetObjId = controller.taskparam.ugc_targetObjId
		local projectileId = controller.taskparam.ugc_projectileId
		local power = controller.taskparam.ugc_chargedTime / controller.taskparam.cache_weaponDef.AccumulatorTime
		controller.taskparam.cache_onwaitForcharge = true

		controller.wait(controller.taskparam.ugc_chargedTime)

		controller.taskparam.cache_onwaitForcharge = false

		if controller.taskparam.cache_onwaitCheckFail then
			AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_SHOOT, false, false)

			return controller.fail()
		end

		targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		power = math.clamp(power, 0, 1)

		selfActor:doProjectileAttack(targetActor, projectileId, power, 0, 1, 1)
		AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_SHOOT, false, false)
		controller.wait(controller.taskparam.ugc_frequency)

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get("mob")
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		selfActor:keepLookAt(targetActor, 10, 10)

		local speed = controller.taskparam.ugc_speed

		if controller.taskparam.cache_targetPos then
			local t_pos = controller.taskparam.cache_targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
				t_pos = targetActor:getPosition()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, speed, btget_path_range()) then
					controller.taskparam.cache_targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}
				else
					return false
				end
			end
		end

		if controller.taskparam.cache_onwaitForcharge then
			AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

			if math.pow(controller.taskparam.cache_atkDistance, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) then
				controller.taskparam.cache_onwaitCheckFail = true

				return false
			end

			if not selfActor:isUnsighted() and not ActorComponentCallModule(selfActor, "ActorVision", "canSeeInAICache", targetActor) then
				controller.taskparam.cache_onwaitCheckFail = true

				return false
			end

			controller.taskparam.cache_onwaitCheckFail = false
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get("mob")

		selfActor:getNavigator():clearPathEntity()
		selfActor:stopLookAt()
		selfActor:setDirectSwitchAni(false)

		controller.taskparam.cache_targetActor = nil
		controller.taskparam.cache_atkDistance = nil
		controller.taskparam.cache_targetPos = nil
		controller.taskparam.cache_onwaitForcharge = nil
		controller.taskparam.cache_onwaitCheckFail = nil
	end
}
