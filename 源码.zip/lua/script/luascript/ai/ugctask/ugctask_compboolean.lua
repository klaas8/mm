return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local param_left = controller.taskparam.param_left
		local cmpEnumType = controller.taskparam.cmpEnumType
		local param_right = controller.taskparam.param_right

		if type(cmpEnumType) ~= "string" then
			return controller.fail()
		end

		if cmpEnumType == "==" then
			if param_left == nil and param_right == nil then
				return controller.success()
			elseif param_left ~= nil and param_right ~= nil and type(param_left) == "boolean" and type(param_right) == "boolean" and param_left == param_right then
				return controller.success()
			end
		elseif cmpEnumType == "~=" then
			if param_left == nil and param_right ~= nil or param_left ~= nil and param_right == nil then
				return controller.success()
			elseif param_left ~= nil and param_right ~= nil and type(param_left) == "boolean" and type(param_right) == "boolean" and param_left ~= param_right then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"param_left",
			"compareType",
			"param_right"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local param_left = result[1]
		local cmpEnumType = result[2]
		local param_right = result[3]
		lcontroller.taskparam.param_left = lBTService:GetBoolVal(param_left)
		lcontroller.taskparam.cmpEnumType = cmpEnumType
		lcontroller.taskparam.param_right = lBTService:GetBoolVal(param_right)

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = param_left
			}
			local data2 = {
				valtype = "val",
				val = cmpEnumType
			}
			local data3 = {
				valtype = "val",
				val = param_right
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
