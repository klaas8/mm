local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local targetObjId, actorId, hpPercent = nil

		if TEST_TEST_TEST then
			hpPercent = lcontroller.subparam.hpPercent
			actorId = lcontroller.subparam.actorId
			targetObjId = lcontroller.target.get():getObjId()
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 3, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3
				})
			end

			hpPercent = result[3]
			actorId = result[2]
			targetObjId = result[1]
			hpPercent = hpPercent == "==" and true or false
		end

		if type(actorId) == "string" then
			actorId = lBTService:ResidToId(actorId)
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId
		lcontroller.taskparam.ugc_actorId = actorId
		lcontroller.taskparam.ugc_hpPercent = hpPercent

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "actortype",
				val = {
					actorid = actorId or 0
				}
			}
			local data3 = {
				valtype = "enum",
				val = hpPercent or false
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		controller.taskparam.cache_targetActor = targetActor

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local targetActor = controller.taskparam.cache_targetActor
		local x, y, z = targetActor:getPosition(0, 0, 0)
		local locoMotion = targetActor:getLocoMotion()

		if not locoMotion then
			return controller.fail()
		end

		local newActor = AIFunctionMgr:spawnActorEx(selfActor, controller.taskparam.ugc_actorId, x, y, z, locoMotion:getRotateYaw(), locoMotion:getRotatePitch())

		if not newActor then
			return controller.fail()
		end

		AIFunctionMgr:giveAllEquipment(targetActor, newActor)
		AIFunctionMgr:giveAllItem(targetActor, newActor)

		if controller.taskparam.ugc_hpPercent then
			if targetActor:getLivingAttrib() and newActor:getLivingAttrib() then
				local oldHpCur = targetActor:getLivingAttrib():getHP()
				local oldHpMax = targetActor:getLivingAttrib():getMaxHP()
				local newHpMax = newActor:getLivingAttrib():getMaxHP()

				newActor:getLivingAttrib():initHP(newHpMax * oldHpCur / oldHpMax)
			else
				return controller.fail()
			end
		end

		threadpool:work(function ()
			threadpool:wait(0)
			AIFunctionMgr:removeActor(selfActor, targetActor:getObjId())
		end)

		return controller.success()
	end,
	onend = function ()
		controller.taskparam.cache_targetActor = nil
	end
}
