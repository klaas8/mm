return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if selfActor == nil or not selfActor:alive() then
			return controller.fail()
		end

		local targetPlayerObjId = controller.taskparam.targetPlayerObjId

		if type(targetPlayerObjId) == "string" then
			targetPlayerObjId = tonumber(targetPlayerObjId)
		end

		if targetPlayerObjId == nil or targetPlayerObjId <= 0 then
			return controller.fail()
		end

		if AIFunctionMgr:IsPlayerFirstEnterVillage(selfActor, targetPlayerObjId) then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local targetPlayerObjId = result[1]

		if type(targetPlayerObjId) == "string" then
			targetPlayerObjId = tonumber(targetPlayerObjId)
		end

		lcontroller.taskparam.targetPlayerObjId = targetPlayerObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetPlayerObjId or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
