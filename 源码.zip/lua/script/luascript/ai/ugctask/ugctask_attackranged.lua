local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local targetObjId, frequency, distance, itemId, speed = nil

		if TEST_TEST_TEST then
			itemId = 12002
			distance = 10
			frequency = 1
			targetObjId = CurMainPlayer:getObjId()
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 5, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4,
					5
				})
			end

			speed = result[5]
			itemId = result[4]
			distance = result[3]
			frequency = result[2]
			targetObjId = result[1]
		end

		if speed == nil then
			speed = 1
		end

		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.frequency = frequency
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.speed = speed

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = frequency
			}
			local data3 = {
				valtype = "val",
				val = distance
			}
			local data4 = {
				valtype = "itemtype",
				val = {
					itemid = itemId or 0
				}
			}
			local data5 = {
				valtype = "val",
				val = speed
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4,
				data5
			})
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		if not GameplayTagUtils:IsNormalAttackEnabled(selfActor) then
			return false
		end

		local targetObjId = controller.taskparam.targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		local dis_min = selfActor:getLocoMotion().m_BoundSize + targetActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local dis_max = selfActor:getViewDist()
		local distance = controller.taskparam.distance
		local attack_dis = math.clamp(distance * BLOCK_SIZE, dis_min, dis_max)
		local t_pos = targetActor:getPosition()
		controller.taskparam.targetActor = targetActor
		controller.taskparam.attackDis = attack_dis

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.targetPos = nil
			controller.taskparam.path = nil

			return true
		end
	end,
	onbeg = function ()
		local selfActor = controller.target.get()
		local handItemId = controller.taskparam.itemId

		if AIFunctionMgr:getBagItemCount(selfActor, handItemId, false) <= 0 then
			AIFunctionMgr:addItemToBags(selfActor, handItemId, 1)
		end

		AIFunctionMgr:equipWeapon(selfActor, handItemId, 1)

		if controller.taskparam.path then
			local targetObjId = controller.taskparam.targetObjId
			local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
			local path_range = btget_path_range()
			local speed = controller.taskparam.speed

			selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil

			if targetActor then
				selfActor:keepLookAt(targetActor, 30, 30)
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local attack_dis = controller.taskparam.attackDis

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

					if not targetActor or not targetActor:alive() then
						return true
					end

					return Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return true
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) then
			return controller.fail()
		end

		if not selfActor:isUnsighted() and not ActorComponentCallModule(selfActor, "ActorVision", "canSeeInAICache", targetActor) then
			return controller.fail()
		end

		local itemId = AIFunctionMgr:GetHoldItemId(selfActor)

		if itemId == 0 then
			itemId = controller.taskparam.itemId
		end

		if itemId == 12050 or itemId == 12281 then
			if selfActor:getDefID() == 3236 then
				selfActor:playAnim(SEQ_HUNT_ATTACK, false, 127, 2)
			else
				AIFunctionMgr:setFlagBit(selfActor, ACTOR_ANIM_FLAG_SHOOT, true, false)
			end
		else
			selfActor:playAttackSound()
			selfActor:playAnim(SEQ_ATTACK)
		end

		local projectileId = itemId

		controller.wait(selfActor:getAttackAnimTicks(ATTACK_RANGE) * 0.05)

		targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		selfActor:doProjectileAttack(targetActor, projectileId, 1, 0, 1, 1)

		local frequency = controller.taskparam.frequency

		controller.wait(frequency)

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
		local speed = controller.taskparam.speed

		if not targetActor or not targetActor:alive() then
			return false
		end

		selfActor:keepLookAt(targetActor, 30, 30)

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
				t_pos = targetActor:getPosition()
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, speed, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()
		selfActor:stopLookAt()

		local itemId = AIFunctionMgr:GetHoldItemId(selfActor)

		if itemId > 0 then
			AIFunctionMgr:putHandItemInBags(selfActor)
		end
	end
}
