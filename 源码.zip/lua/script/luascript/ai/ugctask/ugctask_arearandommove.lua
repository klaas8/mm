return {
	will = function ()
		local actor = controller.target.get()

		if not actor or actor:isDead() or actor:needClear() then
			return false
		end

		if not controller.taskparam.speed or not controller.taskparam.bbareaId or controller.taskparam.changeToward == nil then
			return false
		end

		if actor:getNavigator():noPath() then
			local movpos = nil
			local t_has = false
			local t_pos = {
				x = 0,
				z = 0,
				y = 0
			}
			local posbeg, posend = BTService:GetAreaRectRange(controller.taskparam.bbareaId)

			if posbeg and posend then
				t_has, t_pos.x, t_pos.y, t_pos.z = AIFunctionMgr:GetAreaRangePosForAdditionalWater(actor, WCoord(posbeg.x, posbeg.y, posbeg.z), WCoord(posend.x, posend.y, posend.z), t_pos.x, t_pos.y, t_pos.z)
			end

			if t_has then
				movpos = t_pos
			else
				movpos = BTService:GetRandomPos(controller.taskparam.bbareaId)
			end

			if movpos then
				controller.taskparam.Pos = movpos
				local x, y, z = BlockBottomCoord(movpos.x, movpos.y, movpos.z)
				local path_range = btget_path_range()
				controller.taskparam.path = actor:getNavigator():newCanMoveTo(x, y, z, path_range)

				if controller.taskparam.path then
					return true
				else
					return false
				end
			else
				return false
			end
		else
			return true
		end
	end,
	onbeg = function ()
		local actor = controller.target.get()
		local changeToward = controller.taskparam.changeToward
		controller.taskparam.lastYaw = nil

		if not changeToward then
			local locoMotion = actor:getLocoMotion()

			if locoMotion then
				controller.taskparam.lastYaw = locoMotion:getRotateYaw()
			end
		end

		if actor.IsStopBodyRotation == changeToward then
			actor.IsStopBodyRotation = not changeToward
		end

		local speed = controller.taskparam.speed
		local path_range = btget_path_range()

		if controller.taskparam.path and actor:getNavigator():noPath() then
			actor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
		end
	end,
	run = function ()
		local actor = controller.target.get()

		if not actor:getNavigator():noPath() then
			controller.wait_until(function ()
				return actor:getNavigator():noPath()
			end)
		end

		return controller.success()
	end,
	onend = function ()
		local actor = controller.target.get()

		actor:getNavigator():clearPathEntity()
		BTService:RestoreSavedYaw(actor, controller.taskparam)

		actor.IsStopBodyRotation = false
	end,
	release = function ()
		local actor = controller.target.get()
		local shouldRestoreRotation = actor and controller.taskparam.lastYaw ~= nil

		BTService:RestoreSavedYaw(actor, controller.taskparam)

		if shouldRestoreRotation then
			actor.IsStopBodyRotation = false
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local areaId = result[1]
		local speed = result[2]
		local changeToward = result[3]
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.bbareaId = areaId

		if changeToward == "==" then
			lcontroller.taskparam.changeToward = true
		else
			lcontroller.taskparam.changeToward = false
		end

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "area",
				val = lBTService:GetAreaDebugData(areaId)
			}
			local data2 = {
				valtype = "val",
				val = speed
			}
			local data3 = {
				valtype = "enum"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
