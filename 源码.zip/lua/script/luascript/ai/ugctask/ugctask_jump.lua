return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local obj = result[1]
		local height = result[2]
		local dist = result[3]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.height = height
		lcontroller.taskparam.dist = dist

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = height
			}
			local data3 = {
				valtype = "val",
				val = dist
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end,
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.obj

		if not objid then
			return controller.fail()
		end

		local height = controller.taskparam.height
		local dist = controller.taskparam.dist
		local obj = controller.target.get()
		local actor = AIFunctionMgr:getActorByObjId(obj, objid)

		if actor then
			if height == nil or dist == nil then
				local jump = AIFunctionMgr:tryJump(actor)

				if jump then
					return controller.success()
				end
			else
				local jump = AIFunctionMgr:tryJumpByParam(actor, height, dist)

				if jump then
					return controller.success()
				end
			end
		end

		return controller.fail()
	end
}
