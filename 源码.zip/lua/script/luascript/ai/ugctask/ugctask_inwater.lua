return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor then
			return controller.fail()
		end

		local setobj = controller.taskparam.setobj

		if not setobj then
			return controller.fail()
		end

		local setobjActor = AIFunctionMgr:getActorByObjId(selfActor, setobj)

		if not setobjActor then
			return controller.fail()
		end

		local ret = AIFunctionMgr:InWater(setobjActor)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local setobj = result[1]
		lcontroller.taskparam.setobj = setobj

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = setobj or 0
				}
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
