local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId, frequency, distance, speed = nil

		if TEST_TEST_TEST then
			distance = 0
			frequency = 1
			targetObjId = CurMainPlayer:getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 4, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4
				})
			end

			speed = result[4]
			distance = result[3]
			frequency = result[2]
			targetObjId = result[1]
		end

		if speed == nil then
			speed = 1
		end

		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.frequency = frequency
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.speed = speed

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = frequency
			}
			local data3 = {
				valtype = "val",
				val = distance
			}
			local data4 = {
				valtype = "val",
				val = speed
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)

		if not GameplayTagUtils:IsNormalAttackEnabled(selfActor) then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noAttackTag"
				}

				controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
			end

			return false
		end

		local targetObjId = controller.taskparam.targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "targetNoExit",
					targetObjId = targetObjId
				}

				controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
			end

			return false
		end

		local dis_min = selfActor:getLocoMotion().m_BoundSize + targetActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local dis_max = selfActor:getViewDist()
		local distance = controller.taskparam.distance
		local attack_dis = math.clamp(distance * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.attackDis = attack_dis
		local t_pos = targetActor:getPosition()

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				if controller.taskparam.needErrInfo then
					local errinfo = {
						info = "targetNotReachable",
						targetObjId = targetObjId,
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
				end

				return false
			end
		else
			controller.taskparam.targetPos = nil

			return true
		end
	end,
	onbeg = function ()
		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(controller.target.get())

		if controller.taskparam.targetPos then
			local selfActor = controller.target.get()
			local targetObjId = controller.taskparam.targetObjId
			local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
			local path_range = btget_path_range()
			local speed = controller.taskparam.speed

			if targetActor and controller.taskparam.path then
				selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

				controller.taskparam.path = nil

				selfActor:keepLookAt(targetActor, 10, 10)
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local attack_dis = controller.taskparam.attackDis

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

					if not targetActor or not targetActor:alive() then
						return true
					end

					return Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if not targetActor or not targetActor:alive() then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "targetNoExit",
					targetObjId = targetObjId
				}

				controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
			end

			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "distanceTooFar",
					targetObjId = targetObjId,
					currentdistance = Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()),
					attackdistance = attack_dis
				}

				controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
			end

			return controller.fail()
		end

		if not selfActor:isUnsighted() and not ActorComponentCallModule(selfActor, "ActorVision", "canSeeInAICache", targetActor) then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "targetNotVisible"
				}

				controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
			end

			return controller.fail()
		end

		if not selfActor:isAttacking() then
			selfActor:playAttackSound()
			selfActor:attackActor(targetActor)

			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "attackMeleeSuccess",
					targetObjId = targetObjId
				}

				controller.sendMsgToAi(selfActor, "UGCTask_AttackMelee", errinfo)
			end
		end

		if selfActor:getDefID() == 3915 then
			local itemId = selfActor:getEquipItem(EQUIP_WEAPON)

			if itemId == 0 then
				ActorComponentCallModule(selfActor, "SoundComponent", "playSound", "ent.3915.attack1", selfActor:getSoundVolume(), selfActor:getSoundPitch())
			elseif itemId == 12069 then
				ActorComponentCallModule(selfActor, "SoundComponent", "playSound", "ent.3915.attack2", selfActor:getSoundVolume(), selfActor:getSoundPitch())
			elseif itemId == 12316 then
				ActorComponentCallModule(selfActor, "SoundComponent", "playSound", "ent.3915.attack3", selfActor:getSoundVolume(), selfActor:getSoundPitch())
			end
		end

		local frequency = controller.taskparam.frequency

		controller.wait(frequency)

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()
		local targetObjId = controller.taskparam.targetObjId
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)
		local speed = controller.taskparam.speed

		if not targetActor or tolua.isnull(targetActor) or not targetActor:alive() then
			return false
		end

		selfActor:keepLookAt(targetActor, 30, 30)

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
				t_pos = targetActor:getPosition()
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, speed, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()
		selfActor:stopLookAt()

		controller.taskparam.targetPos = nil
		controller.taskparam.attackDis = nil
	end
}
