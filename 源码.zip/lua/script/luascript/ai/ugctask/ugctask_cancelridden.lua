return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local targetObjId = controller.taskparam.targetObjId

		if targetObjId == nil then
			return controller.fail()
		end

		local selfActor = controller.target.get()

		if selfActor == nil or not selfActor:alive() then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

		if targetActor == nil or not targetActor:alive() then
			return controller.fail()
		end

		local ridecom = targetActor:getRideComponent()

		if not ridecom then
			return controller.fail()
		end

		if ridecom:DisMount(nil) then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local targetObjId = result[1]
		lcontroller.taskparam.targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
