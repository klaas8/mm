return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local buffid = controller.taskparam.buffid
		local comptype = controller.taskparam.comptype

		if not objid or not buffid or not comptype then
			return controller.fail()
		end

		local buffid_, bufflv_ = BTService:getBuffData(buffid)

		if not buffid_ then
			return controller.fail()
		end

		local ssBuff = BTService:GetSSObj("Buff")
		local newret = ssBuff:hasBuff(objid, buffid_, bufflv_)

		if comptype == "==" then
			if newret == ErrorCode.OK then
				return controller.success()
			end
		elseif comptype == "~=" and newret ~= ErrorCode.OK then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid",
			"buffid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objid = result[1]
		local comptype = result[2]
		local buffid = result[3]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.comptype = comptype
		lcontroller.taskparam.buffid = buffid

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				comptype,
				valtype = "enum"
			}
			local data3 = {
				valtype = "def",
				val = {
					defid = buffid or 0
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
