local Task = {
	TICKS_PER_SECOND = 20
}

function Task.IsActorValid(actor)
	return actor and actor:alive() and not actor:isDead() and not actor:needClear()
end

function Task.ResolveTargetActor(ctrl, selfActor)
	if not ctrl or not ctrl.taskparam or not Task.IsActorValid(selfActor) then
		return nil
	end

	local targetObjId = ctrl.taskparam.targetObjId

	if targetObjId == nil then
		return nil
	end

	local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObjId)

	if targetActor == selfActor then
		return nil
	end

	if Task.IsActorValid(targetActor) then
		return targetActor
	end

	return nil
end

function Task.RotateActorToTarget(actor, targetActor)
	if not Task.IsActorValid(actor) or not Task.IsActorValid(targetActor) then
		return false
	end

	local locoMotion = actor:getLocoMotion()
	local actorPos = actor:getPosition()
	local targetPos = targetActor:getPosition()

	if not locoMotion or not actorPos or not targetPos then
		return false
	end

	local dirX = targetPos.x - actorPos.x
	local dirZ = targetPos.z - actorPos.z

	if math.abs(dirX) < 0.001 and math.abs(dirZ) < 0.001 then
		return true
	end

	local yaw = Direction2PitchYaw(dirX, 0, dirZ)

	locoMotion:setRotateYaw(WrapAngleTo180(yaw))

	return true
end

function Task.UpdateFacing(ctrl)
	if not ctrl or not ctrl.taskparam or not ctrl.target or not ctrl.target.get then
		return false
	end

	local selfActor = ctrl.target.get("living")

	if not Task.IsActorValid(selfActor) then
		return false
	end

	local targetActor = Task.ResolveTargetActor(ctrl, selfActor)

	if not targetActor then
		return false
	end

	return Task.RotateActorToTarget(selfActor, targetActor)
end

function Task.IsDurationReached(ctrl)
	if not ctrl or not ctrl.taskparam then
		return true
	end

	local startTick = tonumber(ctrl.taskparam.startTick)
	local duration = tonumber(ctrl.taskparam.duration)
	local curTick = WorldMgr:getWorldTime()

	if not startTick or not duration or not curTick then
		ctrl.taskparam.rotateFailed = true

		return true
	end

	return duration <= (curTick - startTick) / Task.TICKS_PER_SECOND
end

function Task.ClearRuntimeState(ctrl)
	if not ctrl or not ctrl.taskparam then
		return
	end

	ctrl.taskparam.rotateStarted = nil
	ctrl.taskparam.rotateFailed = nil
	ctrl.taskparam.startTick = nil
end

function Task.run()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.target then
		return false
	end

	Task.ClearRuntimeState(ctrl)

	local duration = tonumber(ctrl.taskparam.duration)

	if not duration or duration <= 0 then
		return ctrl.fail()
	end

	local startTick = WorldMgr:getWorldTime()

	if not startTick then
		return ctrl.fail()
	end

	ctrl.taskparam.duration = duration
	ctrl.taskparam.startTick = startTick
	ctrl.taskparam.rotateStarted = true

	if not Task.UpdateFacing(ctrl) then
		Task.ClearRuntimeState(ctrl)

		return ctrl.fail()
	end

	ctrl.wait_until(function ()
		if not ctrl.taskparam or ctrl.taskparam.rotateFailed then
			return true
		end

		if not Task.UpdateFacing(ctrl) then
			ctrl.taskparam.rotateFailed = true

			return true
		end

		return Task.IsDurationReached(ctrl)
	end)

	if ctrl.taskparam and ctrl.taskparam.rotateFailed then
		Task.ClearRuntimeState(ctrl)

		return ctrl.fail()
	end

	Task.ClearRuntimeState(ctrl)

	return ctrl.success()
end

function Task.onwait()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam or not ctrl.taskparam.rotateStarted then
		return
	end

	if not Task.UpdateFacing(ctrl) then
		ctrl.taskparam.rotateFailed = true
	end
end

function Task.onend()
	local ctrl = controller

	Task.ClearRuntimeState(ctrl)
end

function Task.send_debug_data()
	local ctrl = controller

	if not ctrl or not ctrl.taskparam then
		return
	end

	local lBTService = BTService
	local result = nil

	if lBTService:IsSubparamReuseEnabled() then
		result = lBTService:GetSubparamOutputBuffer(ctrl)

		lBTService:GetSubparamInto(ctrl, 2, result)
	else
		result = btget_subparam(ctrl, {
			1,
			2
		})
	end

	local targetObjId = result[1]
	local duration = result[2]
	ctrl.taskparam.targetObjId = targetObjId
	ctrl.taskparam.duration = tonumber(duration)

	if ctrl:isNeedSendDebug() then
		local data1 = {
			valtype = "actor",
			val = {
				actor = targetObjId or 0
			}
		}
		local data2 = {
			valtype = "val",
			val = ctrl.taskparam.duration
		}

		ctrl.sendValToDebug({
			data1,
			data2
		})
	end
end

return Task
