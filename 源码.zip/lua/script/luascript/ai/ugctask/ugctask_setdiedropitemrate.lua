return {
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local dropRate = controller.taskparam.dropRate
		local itemId = controller.taskparam.itemId
		local itemNum = controller.taskparam.itemNum
		local objtype = selfobj:getObjType()
		local bigtype = GameActorTypeToObjType[objtype]

		if bigtype == OBJ_TYPE.OBJTYPE_CREATURE then
			if not CheckItemScriptUse(itemId) then
				return controller.fail()
			end

			local selfMob = tolua.cast(selfobj, "ClientMob")

			if selfMob and selfMob.getMobAttrib then
				local attrib = selfMob:getMobAttrib()

				attrib:setDropItem(dropRate, itemId, itemNum)

				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local dropRate = result[1]
		local itemNum = result[2]
		local itemId = result[3]
		dropRate = math.ceil(dropRate)
		itemNum = math.ceil(itemNum)
		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.dropRate = dropRate
		lcontroller.taskparam.itemId = itemId
		lcontroller.taskparam.itemNum = itemNum

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = dropRate
			}
			local data2 = {
				valtype = "itemtype",
				itemid = itemId
			}
			local data3 = {
				valtype = "val",
				val = itemNum
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end
}
