return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local item = controller.taskparam.item

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		local ret = AIFunctionMgr:HasEnoughMaterials(selfActor, item, 1)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local item = result[1]
		lcontroller.taskparam.item = item

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
