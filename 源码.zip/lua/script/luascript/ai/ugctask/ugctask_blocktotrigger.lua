return {
	will = function ()
		local pos = controller.taskparam.position

		if type(pos) ~= "table" then
			return false
		end

		if not pos.x or not pos.y or not pos.z then
			return false
		end

		local selfMob = controller.target.get("living")

		if not selfMob or not selfMob:alive() then
			return false
		end

		if not GameplayTagUtils:IsInteractEnabled(selfMob) then
			return false
		end

		return true
	end,
	decorator = function ()
		return controller.success()
	end,
	onbeg = function ()
		local actor = controller.target.get()
		local pos = controller.taskparam.position

		if not pos or not actor then
			return controller.fail()
		end

		local path_range = btget_path_range()
		local x, y, z = BlockBottomCoord(pos.x, pos.y, pos.z)

		actor:getNavigator():tryMoveTo(x, y, z, 1.2, path_range)

		controller.taskparam.targetPos = {
			x = x,
			y = y,
			z = z
		}
	end,
	run = function ()
		local selfobj = controller.target.get()
		local targetPos = controller.taskparam.targetPos
		local maxdistance = math.pow(BLOCK_SIZE * 2, 2)
		local distance = PosSquareDistanceToPos(selfobj:getPosition(), targetPos)

		while not selfobj:getNavigator():noPath() or maxdistance < distance do
			if distance <= maxdistance or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), targetPos)

			controller.wait()
		end

		local selfMob = tolua.cast(selfobj, "ClientMob")

		if not selfMob then
			return controller.fail()
		end

		local pos = controller.taskparam.position
		local blockPos = WCoord()
		blockPos.x = pos.x or 0
		blockPos.y = pos.y or 0
		blockPos.z = pos.z or 0
		local ret = selfMob:interactBlock(blockPos)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local position = result[1]
		lcontroller.taskparam.position = position

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = position
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
