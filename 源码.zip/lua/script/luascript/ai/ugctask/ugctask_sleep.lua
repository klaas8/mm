return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local obj = result[1]
		local time = result[2]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.time = time

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = time
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() or not controller.taskparam.obj or not controller.taskparam.time then
			return false
		end

		local objid = controller.taskparam.obj
		local targetObj = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetObj then
			return false
		end

		if AIFunctionMgr:isActorSleep(targetObj) then
			return false
		end

		controller.taskparam.sleeptime = -1

		return true
	end,
	onwait = function ()
		if WorldMgr and WorldMgr.getWorldTime and controller.taskparam.sleeptime > 0 then
			local tick = WorldMgr:getWorldTime() - controller.taskparam.sleeptime
			local time = tick / 20
			local len = controller.taskparam.time

			if len <= time then
				local selfActor = controller.target.get()

				if selfActor and selfActor:alive() then
					local objid = controller.taskparam.obj
					local targetObj = AIFunctionMgr:getActorByObjId(selfActor, objid)

					AIFunctionMgr:ActorWakeUp(targetObj)
				end

				controller.taskparam.sleeptime = -1
			end
		end
	end,
	run = function ()
		if WorldMgr and WorldMgr.getWorldTime then
			controller.taskparam.sleeptime = WorldMgr:getWorldTime()
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() or not controller.taskparam.obj or not controller.taskparam.time then
			return controller.fail()
		end

		local objid = controller.taskparam.obj
		local targetObj = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not AIFunctionMgr:ActorSleep(targetObj) then
			return controller.fail()
		end

		controller.wait_until(function ()
			if controller.taskparam.sleeptime < 0 then
				return true
			end

			return false
		end)

		return controller.success()
	end,
	onend = function ()
		local selfActor = controller.target.get()

		if selfActor and selfActor:alive() then
			local objid = controller.taskparam.obj
			local targetObj = AIFunctionMgr:getActorByObjId(selfActor, objid)

			AIFunctionMgr:ActorWakeUp(targetObj)
		end

		controller.taskparam.sleeptime = -1
	end
}
