local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local seqId, time, playtype = nil

		if TEST_TEST_TEST then
			playtype = 700001
			time = 2
			seqId = 600130
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 4, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4
				})
			end

			isStop = result[4]
			playtype = result[3]
			time = result[2]
			seqId = result[1]
		end

		if type(isStop) == "string" then
			isStop = isStop == "==" and true or false
		elseif isStop == nil then
			isStop = true
		end

		lcontroller.taskparam.ugc_seqId = seqId
		lcontroller.taskparam.time = time
		lcontroller.taskparam.playtype = lBTService:GetEnumValue(playtype)
		lcontroller.taskparam.isStop = isStop

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = seqId
			}
			local data2 = {
				valtype = "val",
				val = time
			}
			local data3 = {
				valtype = "enum",
				val = playtype
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()
		local seq = controller.taskparam.ugc_seqId
		local time = controller.taskparam.time

		if seq == nil or time == nil or not selfActor or not selfActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local seq = controller.taskparam.ugc_seqId
		local time = controller.taskparam.time
		local playtype = controller.taskparam.playtype
		local isStop = controller.taskparam.isStop

		if seq == nil or time == nil or not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local result = selfActor:skillPlayAnim(seq, 0, playtype, -1)

		if not result then
			return controller.fail()
		else
			if seq == 110172 or seq == 110173 or seq == 110177 then
				AIFunctionMgr:ReportActEvent(selfActor, seq)
			end

			controller.wait(time)

			if not selfActor or not selfActor:alive() then
				return controller.success()
			end

			if isStop then
				selfActor:skillStopAnim(seq, 0, false)
			end

			return controller.success()
		end
	end,
	onend = function ()
		local selfActor = controller.target.get()
		local seq = controller.taskparam.ugc_seqId
		local time = controller.taskparam.time
		local playtype = controller.taskparam.playtype
		local isStop = controller.taskparam.isStop

		if selfActor and selfActor:alive() and isStop then
			selfActor:skillStopAnim(seq, 0, false)
		end
	end
}
