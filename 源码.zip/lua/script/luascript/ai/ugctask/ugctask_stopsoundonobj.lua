return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local soundId = controller.taskparam.soundId
		local obj = controller.taskparam.obj

		if not soundId or not obj then
			return controller.fail()
		end

		local ret = ErrorCode.FAILED

		if Service and Service.Actor then
			ret = Service.Actor:StopSoundEffectById(obj, soundId)
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local obj = result[1]
		local soundId = result[2]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.soundId = soundId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "sound",
				val = {
					effectid = soundId
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
