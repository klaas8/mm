local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId = nil

		if TEST_TEST_TEST then
			targetObjId = lcontroller.target.get():getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 1, result)
			else
				result = btget_subparam(lcontroller, {
					1
				})
			end

			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		if controller.taskparam.ugc_targetObjId == controller.target.get():getObjId() then
			threadpool:work(function ()
				threadpool:wait(0)

				if Service and Service.World then
					Service.World:DespawnActor(controller.taskparam.ugc_targetObjId)
				end
			end)
		elseif Service and Service.World then
			Service.World:DespawnActor(controller.taskparam.ugc_targetObjId)
		end

		return controller.success()
	end,
	onend = function ()
	end
}
