local AUTO_MOVEMENT_MODE = 128

return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local move_param = controller.taskparam.movetype

		if not objid or not move_param then
			return controller.fail()
		end

		local obj = controller.target.get()
		local actor = AIFunctionMgr:getActorByObjId(obj, objid)

		if actor then
			local movemode = 0

			if move_param == "Climbing" then
				movemode = 4
			elseif move_param == "Fly" then
				movemode = 1
			elseif move_param == "Swing" then
				movemode = 2
			elseif move_param == "AutoMoveMode" then
				movemode = AUTO_MOVEMENT_MODE
			end

			local ret = AIFunctionMgr:SetMovementModeOrAuto(actor, movemode)

			if ret then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objid = result[1]
		local move_param = result[2]
		local isOpen = result[3]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.movetype = move_param

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "enum"
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
