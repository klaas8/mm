return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local range = result[1]
		local actorType = result[2]
		local bbkey = result[3]
		local taskParam = lcontroller.taskparam
		taskParam.bbkey = bbkey
		taskParam.range = range
		taskParam.actorType = lBTService:ResidToId(actorType)

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = range
			}
			local data2 = {
				valtype = "actortype",
				val = {
					actorid = lBTService:ResidToId(actorType)
				}
			}
			local data3 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3
			})
		end
	end,
	run = function ()
		local taskParam = controller.taskparam

		if not taskParam.range or not taskParam.actorType or not taskParam.bbkey then
			return controller.fail()
		end

		local range = taskParam.range
		local actorType = taskParam.actorType
		local bbkey = taskParam.bbkey
		local eventParam = taskParam.eventParam

		if not eventParam or not eventParam.toobjid or not eventParam.itemid or eventParam.itemid ~= actorType or range < eventParam.itemnum then
			return controller.fail()
		end

		if type(bbkey) == "table" then
			if type(bbkey.func) == "function" then
				bbkey.func({
					value = eventParam.toobjid,
					controller = controller
				})
			end
		else
			controller.bb.set(bbkey, {
				actor = eventParam.toobjid
			})
		end

		return controller.success()
	end
}
