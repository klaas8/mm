return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local areaId = result[1]
		local frequency = result[2]
		local canDrop = result[3]
		local newCanDrop = lBTService:GetBoolVal(canDrop)
		lcontroller.taskparam.ugc_areaId = areaId
		lcontroller.taskparam.ugc_frequency = frequency
		lcontroller.taskparam.ugc_canDrop = newCanDrop

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "area",
				val = lBTService:GetAreaDebugData(areaId)
			}
			local data2 = {
				valtype = "val",
				val = frequency
			}
			local data3 = {
				valtype = "val",
				val = newCanDrop
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() or not SSMgrArea then
			return false
		end

		local world = selfActor:getWorld()

		if not world then
			return false
		end

		local isOK, bx, by, bz, ex, ey, ez = SSMgrArea:GetAreaRectRange(controller.taskparam.ugc_areaId, 0, 0, 0, 0, 0, 0)

		if not isOK then
			return false
		end

		local digBlockPos, digBlockId = nil

		for _x = bx, ex do
			for _y = by, ey do
				for _z = bz, ez do
					digBlockId = world:getBlockID(_x, _y, _z)

					if digBlockId ~= BLOCK_AIR then
						digBlockPos = {
							x = _x,
							y = _y,
							z = _z
						}

						break
					end
				end

				if digBlockPos then
					break
				end
			end

			if digBlockPos then
				break
			end
		end

		if not digBlockPos then
			return false
		end

		controller.taskparam.cache_digBlockId = digBlockId
		controller.taskparam.cache_digBlockPos = digBlockPos

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local digBlockPos = controller.taskparam.cache_digBlockPos
		local world = CurWorld
		local actor = controller.target.get()

		if actor then
			world = actor:getWorld()
		end

		world:destroyBlock(digBlockPos.x, digBlockPos.y, digBlockPos.z, controller.taskparam.ugc_canDrop)

		if controller.taskparam.ugc_frequency > 0 then
			controller.wait(controller.taskparam.ugc_frequency)
		end

		return controller.success()
	end,
	onend = function ()
		controller.taskparam.cache_digBlockPos = nil
	end
}
