local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local tp = lcontroller.taskparam
		tp.attractTime = 2.5
		tp.threatDistance = 5
		tp.attractDistance = 5
		tp.attractVal = 15
		tp.animAttract = SEQ_ATTTACT_POWER
		tp.soundAttract = 10175
		tp.effectAttract = 3069
		tp.animBomb = SEQ_ATTTACT_BOMB
		tp.soundBomb = "misc.pollution"
		tp.effectBomb = "particles/nengliang_baozha.ent"
		local targetObjId = nil

		if TEST_TEST_TEST then
			targetObjId = CurMainPlayer:getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 1, result)
			else
				result = btget_subparam(lcontroller, {
					1
				})
			end

			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local tp = controller.taskparam
		local selfActor = controller.target.get("mob")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		if math.pow(BLOCK_SIZE * tp.threatDistance, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) then
			return false
		end

		controller.taskparam.cache_targetActor = targetActor

		return true
	end,
	onbeg = function ()
		local selfActor = controller.target.get("mob")
		local selfActorPos = selfActor:getPosition()
		controller.taskparam.cache_selfActorPos = {
			x = selfActorPos.x,
			y = selfActorPos.y,
			z = selfActorPos.z
		}
	end,
	run = function ()
		local tp = controller.taskparam
		local selfActor = controller.target.get("mob")
		local targetActor = controller.taskparam.cache_targetActor
		local itemsVector = AIFunctionMgr:SelectNearItems(selfActor, targetActor:getPosition(), BLOCK_SIZE * tp.attractDistance)
		local itemsArray = {}

		for i = 0, itemsVector:size() - 1 do
			local actorItem = itemsVector[i]

			table.insert(itemsArray, actorItem:getObjId())
		end

		controller.taskparam.cache_itemsArray = itemsArray
		local livingsVertor = AIFunctionMgr:SelectNearLivings(selfActor, targetActor:getPosition(), BLOCK_SIZE * tp.attractDistance)
		local livingArray = {}

		for i = 0, livingsVertor:size() - 1 do
			local actorLiving = livingsVertor[i]

			if actorLiving ~= selfActor then
				table.insert(livingArray, actorLiving:getObjId())
			end
		end

		controller.taskparam.cache_livingArray = livingArray
		local selfActorObjId = selfActor:getObjId()

		if Service and Service.Actor then
			Service.Actor:PlayBodyEffectById(selfActorObjId, tp.effectAttract)
			Service.Actor:PlaySoundEffectById(selfActorObjId, tp.soundAttract, selfActor:getSoundVolume() * 100, selfActor:getSoundPitch(), true)
		end

		selfActor:playAnim(tp.animAttract, false, 127, 0)

		controller.taskparam.cache_attractSuccess = true

		controller.wait(tp.attractTime)

		if Service and Service.Actor then
			Service.Actor:StopBodyEffectById(selfActorObjId, tp.effectAttract)
			Service.Actor:StopSoundEffectById(selfActorObjId, tp.soundAttract)
		end

		selfActor:stopAnim(tp.animAttract)

		targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		if controller.taskparam.cache_attractSuccess then
			selfActor:playAnim(tp.animBomb, false, 127, 1)
			controller.wait(0.4)

			targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

			if not targetActor or not targetActor:alive() then
				return controller.fail()
			end

			local selfActorPos = selfActor:getPosition()
			local atkDistance = selfActor:getLivingAttrib():getAttackPoint(ATTACK_EXPLODE, 2)
			local world = CurWorld

			if selfActor then
				world = selfActor:getWorld()
			end

			world:createExplosionWithPath(selfActor, WCoord(selfActorPos.x, selfActorPos.y + BLOCK_SIZE * 0.5, selfActorPos.z), atkDistance, false, true, 0, 0, tp.soundBomb, tp.effectBomb)
			selfActor:setNeedClear()

			return controller.success()
		else
			return controller.fail()
		end
	end,
	onwait = function ()
		local tp = controller.taskparam

		local function funcMotionChange(actorFrome, actorTo, power)
			local fromePos = actorFrome:getPosition():toVector3()
			local toPos = actorTo:getPosition():toVector3()
			local motion = Rainbow.Vector3f(toPos.x - fromePos.x, toPos.y - fromePos.y, toPos.z - fromePos.z)
			motion = motion:GetNormalizedSafe()
			motion.x = motion.x * power
			motion.y = motion.y * power
			motion.z = motion.z * power

			actorFrome:setMotionChange(motion)
		end

		local selfActor = controller.target.get("mob")
		local selfActorPos = selfActor:getPosition()
		controller.taskparam.cache_selfActorPos = {
			x = selfActorPos.x,
			y = selfActorPos.y,
			z = selfActorPos.z
		}
		local selfLocoMotion = selfActor:getLocoMotion()
		local selfBoundSize = selfLocoMotion.m_BoundSize
		local selfBoundHeight = selfLocoMotion.m_BoundHeight
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			controller.taskparam.cache_attractSuccess = false

			return false
		end

		if math.pow(BLOCK_SIZE * tp.threatDistance, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), targetActor:getPosition()) then
			controller.taskparam.cache_attractSuccess = false

			return false
		else
			if type(controller.taskparam.cache_itemsArray) == "table" then
				local itemsArray = controller.taskparam.cache_itemsArray
				local itemsPendingRemove = {}

				for i, v in ipairs(itemsArray) do
					local actorItem = AIFunctionMgr:getActorByObjId(selfActor, v)
					local actorItemReal = nil

					if actorItem and actorItem:alive() then
						actorItemReal = tolua.cast(actorItem, "ClientItem")
					end

					if actorItemReal then
						local dist = actorItemReal:getLocoMotion().m_BoundSize + selfBoundSize + BLOCK_SIZE * 0.1

						if math.pow(dist, 2) < Pos3SquareDistToPos3(actorItemReal:getPosition(), selfActor:getPosition()) then
							funcMotionChange(actorItemReal, selfActor, tp.attractVal)
						else
							actorItemReal:setMotionChange(0, 0, 0)

							local realNum = AIFunctionMgr:addItemToBags(selfActor, actorItemReal:getItemID(), actorItemReal:getItemNum())

							if realNum > 0 then
								table.insert(itemsPendingRemove, i)

								if not controller.taskparam.cache_dropItems then
									controller.taskparam.cache_dropItems = {}
								end

								table.insert(controller.taskparam.cache_dropItems, {
									actorItemReal:getItemID(),
									realNum
								})
							end
						end
					else
						table.insert(itemsPendingRemove, i)
					end
				end

				for i = #itemsPendingRemove, 1, -1 do
					local objid = itemsArray[itemsPendingRemove[i]]

					AIFunctionMgr:removeActor(selfActor, objid)
					table.remove(itemsArray, itemsPendingRemove[i])
				end
			end

			if type(controller.taskparam.cache_livingArray) == "table" then
				local livingArray = controller.taskparam.cache_livingArray

				for _, v in ipairs(livingArray) do
					local actorLiving = AIFunctionMgr:getActorByObjId(selfActor, v)

					if actorLiving and actorLiving:alive() then
						local dist = actorLiving:getLocoMotion().m_BoundSize + selfBoundSize + BLOCK_SIZE * 0.2

						if math.pow(dist, 2) < Pos3SquareDistToPos3(actorLiving:getPosition(), selfActor:getPosition()) then
							funcMotionChange(actorLiving, selfActor, tp.attractVal * 0.5)
						else
							actorLiving:setMotionChange(0, 0, 0)
						end
					end
				end
			end
		end

		return true
	end,
	onend = function ()
		controller.taskparam.cache_targetActor = nil
		controller.taskparam.cache_itemsArray = nil
		controller.taskparam.cache_livingArray = nil
		controller.taskparam.cache_attractSuccess = nil
	end,
	release = function ()
		if WorldMgr and not WorldMgr:isGodMode() and controller and controller.taskparam and controller.taskparam.cache_dropItems and controller.taskparam.cache_selfActorPos then
			local itemPos = controller.taskparam.cache_selfActorPos

			for _, v in ipairs(controller.taskparam.cache_dropItems) do
				itemPos.y = itemPos.y + BLOCK_SIZE * 0.5
				itemPos.x = itemPos.x + BlockUtil:GenRandomInt(BLOCK_SIZE)
				itemPos.z = itemPos.z + BlockUtil:GenRandomInt(BLOCK_SIZE)

				GetCurWorldActorMgr():spawnItem(WCoord(itemPos.x, itemPos.y, itemPos.z), v[1], v[2])
			end

			controller.taskparam.cache_dropItems = nil
			controller.taskparam.cache_selfActorPos = nil
		end
	end
}
