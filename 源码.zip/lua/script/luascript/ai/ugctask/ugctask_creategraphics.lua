return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local info = controller.taskparam.info
		local xoffest = controller.taskparam.xoffest
		local yoffest = controller.taskparam.yoffest

		if not objid or not info or not xoffest or not yoffest then
			return controller.fail()
		end

		local x = xoffest
		local y = yoffest
		local ret = -1
		local itype = info.itype
		local dx = 1
		local dy = 1
		local dz = 1

		if info.Type == GRAPHICS.GRAPHICS_PROGRESS then
			local curval = info.curvalue
			local maxval = info.maxvalue
			local color = info.color or 16711680
			local world = CurWorld
			local actor = controller.target.get()

			if actor then
				world = actor:getWorld()
			end

			if GraphicsManager and GraphicsManager.createGraphicsProgressByObjId then
				local id = GraphicsManager:createGraphicsProgressByObjId(objid, curval, maxval, color, itype, dx, dy, dz, 1, x, y)

				if id > 0 then
					ret = ErrorCode.OK
				end
			elseif world and world.createGraphicsProgressByObjId then
				local id = world:createGraphicsProgressByObjId(objid, curval, maxval, color, itype, dx, dy, dz, 1, x, y)

				if id > 0 then
					ret = ErrorCode.OK
				end
			end
		elseif info.Type == GRAPHICS.GRAPHICS_SUSPENDBOOK then
			local title = info.title

			if not title then
				return controller.fail()
			end

			local fontsize = info.fontsize > 80 and 80 or info.fontsize

			if get_game_env() < 10 then
				title = DefMgr:filterString(title)
			end

			if GraphicsManager and GraphicsManager.createFloatingTextByObj and title then
				local objid = GraphicsManager:createFloatingTextByObj(objid, title, fontsize, itype, dx, dy, dz, 1, x, y)

				if objid and objid > 0 then
					ret = ErrorCode.OK
				end
			elseif world and world.createFloatingTextByObj and title then
				local objid = world:createFloatingTextByObj(objid, title, fontsize, itype, dx, dy, dz, 1, x, y)

				if objid and objid > 0 then
					ret = ErrorCode.OK
				end
			end
		elseif info.Type == GRAPHICS.GRAPHICS_HORNBOOK then
			local title = info.title

			if not title then
				return controller.fail()
			end

			local fontsize = info.fontsize > 80 and 80 or info.fontsize
			local apha = info.apha or 100

			if apha > 100 then
				apha = 100
			end

			if get_game_env() < 10 then
				title = DefMgr:filterString(title)
			end

			if GraphicsManager and GraphicsManager.createGraphicsTextByObjId and title then
				local objid = GraphicsManager:createGraphicsTextByObjId(objid, title, fontsize, itype, apha, dx, dy, dz, 1, x, y, 0)

				if objid and objid > 0 then
					ret = ErrorCode.OK
				end
			elseif world and world.createGraphicsTextByObjId and title then
				local objid = world:createGraphicsTextByObjId(objid, title, fontsize, itype, apha, dx, dy, dz, 1, x, y)

				if objid and objid > 0 then
					ret = ErrorCode.OK
				end
			end
		elseif info.Type == GRAPHICS.GRAPHICS_IMAGE then
			local imgid = info.imgid

			if not imgid then
				return ErrorCode.FAILED
			end

			local itype = info.id
			local apha = info.apha or 100

			if apha > 100 then
				apha = 100
			end

			local scale = info.scale or 1

			if GraphicsManager and GraphicsManager.createGraphicsImageByActor then
				local objid = GraphicsManager:createGraphicsImageByActor(objid, imgid, scale, apha, itype, dx, dy, dz, 1, x, y, true, -1)

				if objid and objid > 0 then
					ret = ErrorCode.OK
				end
			end
		elseif info.Type == GRAPHICS.GRAPHICS_BUBBLE then
			if info.title ~= nil then
				GetInst("BubbleChatManager"):ShowTextBubble(objid, info.title)

				ret = ErrorCode.OK
			elseif info.id ~= nil then
				GetInst("BubbleChatManager"):ShowBubble(objid, info.id, {
					immediate = true
				})

				ret = ErrorCode.OK
			elseif info.grupid ~= nil then
				GetInst("BubbleChatManager"):ShowRandomBubbleByGroup(objid, tostring(info.grupid), {
					immediate = true
				})

				ret = ErrorCode.OK
			end
		end

		if ret == ErrorCode.OK then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local objid = result[1]
		local info = result[2]
		local xoffest = result[3]
		local yoffest = result[4]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.info = info
		lcontroller.taskparam.xoffest = xoffest
		lcontroller.taskparam.yoffest = yoffest

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "getName"
			}
			local data3 = {
				valtype = "val",
				val = xoffest
			}
			local data4 = {
				valtype = "val",
				val = yoffest
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
