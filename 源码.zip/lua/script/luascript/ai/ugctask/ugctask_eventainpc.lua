return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 5, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4,
				5
			})
		end

		local msgkey = result[1]
		local bbkey1 = result[2]
		local bbkey2 = result[3]
		local bbkey3 = result[4]
		local bbkey4 = result[5]
		local taskpram = lcontroller.taskparam
		taskpram.bbkey1 = bbkey1
		taskpram.bbkey2 = bbkey2
		taskpram.bbkey3 = bbkey3
		taskpram.bbkey4 = bbkey4
		taskpram.msgkey = msgkey
		local eventparm = taskpram.eventParam

		if lcontroller:isNeedSendDebug() and eventparm and eventparm.cmd and eventparm.cmd == msgkey then
			local data1 = {
				valtype = "val",
				val = msgkey
			}
			local send_data = {
				data1
			}

			for i = 1, 4 do
				local key2 = "param" .. i

				if eventparm.param[key2] ~= nil then
					local data = {
						valtype = "val",
						val = eventparm.param[key2]
					}

					table.insert(send_data, data)
				else
					table.insert(send_data, {
						val = "nil",
						valtype = "val"
					})
				end
			end

			lcontroller.sendValToDebug(send_data)
		end
	end,
	run = function ()
		local targetObj = controller.target.get()
		local taskpram = controller.taskparam
		local msgkey = taskpram.msgkey
		local eventparm = taskpram.eventParam

		if eventparm and eventparm.cmd and eventparm.cmd == msgkey and eventparm.param then
			for i = 1, 4 do
				local key1 = "bbkey" .. i
				local key2 = "param" .. i

				if eventparm.param[key2] == nil then
					break
				elseif type(taskpram[key1]) == "table" then
					if taskpram[key1].func and type(taskpram[key1].func) == "function" then
						taskpram[key1].func({
							value = tostring(eventparm.param[key2]),
							controller = controller
						})
					end
				else
					local settype = controller.bb.set(taskpram[key1], tostring(eventparm.param[key2]))
				end
			end

			return controller.success()
		end

		return controller.fail()
	end
}
