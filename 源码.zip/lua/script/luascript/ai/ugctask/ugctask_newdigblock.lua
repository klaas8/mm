return {
	onbeg = function ()
		local selfobj = controller.target.get()
		local param_keys = {
			"blockpos"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(controller)

			lBTService:GetSubparamInto(controller, 1, result)
		else
			result = btget_subparam(controller, {
				1
			})
		end

		local blockpos = result[1]

		if type(blockpos) ~= "table" then
			return controller.fail()
		end

		local ret, blockid = nil
		local posx = 0
		local posy = 0
		local posz = 0
		controller.taskparam.blockpos = blockpos
		local world = CurWorld
		local actor = controller.target.get()

		if actor then
			world = actor:getWorld()
		end

		if Service and Service.Block then
			posz = blockpos.z
			posy = blockpos.y
			posx = blockpos.x
			ret, blockid = Service.Block:GetBlockID(posx, posy, posz, world:getCurMapID())
			controller.bb.digtask_blockid = blockid
		end

		if ret == ErrorCode.FAILED or not blockid then
			return controller.fail()
		end

		if not controller.bb.digtask_digticks then
			controller.bb.digtask_digticks = 0
		end

		if not controller.bb.digtask_totaldigs then
			controller.bb.digtask_totaldigs = 0
		end

		local speed = 1
		local pos_x, pos_y, pos_z = BlockBottomCoord(posx, posy, posz)
		local path_range = btget_path_range()

		selfobj:getNavigator():tryMoveTo(pos_x, pos_y, pos_z, speed, path_range)

		controller.bb.digtask_blockpos = {
			x = pos_x,
			y = pos_y,
			z = pos_z
		}
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local param_keys = {
			"blockpos"
		}
		local targetPos = controller.taskparam.blockpos
		local sobj_pos = selfobj:getPosition()
		local newTargetPos = controller.bb.digtask_blockpos
		local distance = PosSquareDistanceToPos(sobj_pos, newTargetPos)

		while not selfobj:getNavigator():noPath() or BLOCK_SIZE < distance do
			if distance <= BLOCK_SIZE or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), newTargetPos)

			controller.wait()
		end

		if selfobj:getNavigator():noPath() then
			selfobj:getNavigator():clearPathEntity()
		end

		controller.bb.digtask_digticks = controller.bb.digtask_digticks + 1
	end
}
