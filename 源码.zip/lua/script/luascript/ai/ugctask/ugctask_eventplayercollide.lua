return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local bbkey = result[1]
		local taskpram = lcontroller.taskparam
		taskpram.bbkey = bbkey

		if lcontroller:isNeedSendDebug() then
			local senddata = {}
			local sendval = {}

			if taskpram.bbkey then
				sendval.valtype = "getName"
			end

			table.insert(senddata, sendval)
			lcontroller.sendValToDebug(senddata)
		end
	end,
	run = function ()
		local taskpram = controller.taskparam

		if not taskpram.bbkey then
			return controller.fail()
		end

		local eventobj = taskpram.eventParam.toobjid

		if not eventobj then
			return controller.fail()
		end

		local targetActor = {
			uin = eventobj
		}

		if type(taskpram.bbkey) == "table" then
			if taskpram.bbkey.func and type(taskpram.bbkey.func) == "function" then
				taskpram.bbkey.func({
					value = eventobj,
					controller = controller
				})
			end
		else
			controller.bb.set(taskpram.bbkey, targetActor)
		end

		return controller.success()
	end
}
