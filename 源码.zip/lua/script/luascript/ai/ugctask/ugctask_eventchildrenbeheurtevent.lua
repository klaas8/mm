return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local dist = result[1]
		local bbkey = result[2]
		local taskpram = lcontroller.taskparam
		taskpram.bbkey = bbkey
		taskpram.dist = dist

		if lcontroller:isNeedSendDebug() then
			local senddata = {}
			local sendval = {}

			table.insert(senddata, {
				valtype = "val",
				val = dist
			})

			if taskpram.bbkey then
				sendval.valtype = "getName"
			end

			table.insert(senddata, sendval)
			lcontroller.sendValToDebug(senddata)
		end
	end,
	run = function ()
		local taskpram = controller.taskparam

		if taskpram.bbkey == nil or taskpram.dist == nil then
			return controller.fail()
		end

		local eventobj = taskpram.eventParam.toobjid
		local dist = taskpram.dist
		local selfActor = controller.target.get()

		if not selfActor then
			return controller.fail()
		end

		local targetObj = AIFunctionMgr:getActorByObjId(selfActor, eventobj)

		if not selfActor then
			return controller.fail()
		end

		local t_pos = targetObj:getPosition()
		local t_x, t_y, t_z = CoordDivBlock(t_pos.x, t_pos.y, t_pos.z)
		local s_pos = selfActor:getPosition()
		local s_x, s_y, s_z = CoordDivBlock(s_pos.x, s_pos.y, s_pos.z)
		local rdist = math.sqrt((t_x - s_x)^2 + (t_y - s_y)^2 + (t_z - s_z)^2)

		if rdist <= dist then
			local targetActor = {
				actor = eventobj
			}

			if type(taskpram.bbkey) == "table" then
				if taskpram.bbkey.func and type(taskpram.bbkey.func) == "function" then
					taskpram.bbkey.func({
						value = eventobj,
						controller = controller
					})
				end
			else
				controller.bb.set(taskpram.bbkey, targetActor)
			end

			return controller.success()
		end

		return controller.fail()
	end
}
