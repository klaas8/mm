local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local weaponId, comboIndex, targetObjId, distance, isReset = nil

		if TEST_TEST_TEST then
			isReset = false
			distance = 0
			targetObjId = CurMainPlayer:getObjId()
			comboIndex = 5
			weaponId = 12005
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 5, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4,
					5
				})
			end

			isReset = result[5]
			distance = result[4]
			targetObjId = result[3]
			comboIndex = result[2]
			weaponId = result[1]
			isReset = isReset == "==" and true or false
		end

		local taskparam = lcontroller.taskparam
		taskparam.ugc_weaponId = weaponId or 0
		taskparam.ugc_comboIndex = comboIndex or 1
		taskparam.ugc_targetObjId = targetObjId or 0
		taskparam.ugc_distance = distance or 0
		taskparam.ugc_isReset = isReset

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = weaponId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = comboIndex
			}
			local data3 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data4 = {
				valtype = "val",
				val = distance
			}
			local data5 = {
				valtype = "val",
				val = isReset
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4,
				data5
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get("mob")

		if not selfActor or not selfActor:alive() then
			return false
		end

		if not GameplayTagUtils:IsNormalAttackEnabled(selfActor) then
			return false
		end

		local taskparam = controller.taskparam
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		local toolDef = DefMgr:getToolDef(taskparam.ugc_weaponId)

		if not toolDef then
			return false
		end

		taskparam.cache_weaponDef = toolDef
		local attackDefStrArr = {}

		for i = 0, MAX_ATTACK_CONFIG - 1 do
			if toolDef.AtkComboSeq[i] then
				table.insert(attackDefStrArr, toolDef.AtkComboSeq[i])
			else
				break
			end
		end

		if next(attackDefStrArr) == nil then
			table.insert(attackDefStrArr, "General_NAtk_01")
		end

		taskparam.cache_attackDefNum = 0
		taskparam.cache_attackDefArr = {}

		for _, v in ipairs(attackDefStrArr) do
			local luaTable = BTService:getAttackDef(v)

			if luaTable then
				taskparam.cache_attackDefNum = taskparam.cache_attackDefNum + 1

				table.insert(taskparam.cache_attackDefArr, luaTable)
			end
		end

		if taskparam.cache_attackDefNum == 0 then
			return false
		end

		taskparam.cache_comboIndex = math.clamp(taskparam.ugc_comboIndex, 1, taskparam.cache_attackDefNum)
		local dis_min = selfActor:getLocoMotion().m_BoundSize + targetActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local attack_dis = taskparam.ugc_distance * BLOCK_SIZE

		if dis_min > attack_dis then
			attack_dis = dis_min
		end

		taskparam.cache_attackDis = attack_dis
		local t_pos = targetActor:getPosition()

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			taskparam.cache_targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, btget_path_range())

			if taskparam.path then
				return true
			else
				return false
			end
		else
			taskparam.cache_targetPos = nil
			taskparam.path = nil

			return true
		end
	end,
	onbeg = function ()
		local selfActor = controller.target.get("mob")
		local taskparam = controller.taskparam
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, taskparam.ugc_targetObjId)
		local weaponId = taskparam.ugc_weaponId
		local selfObjId = selfActor:getObjId()
		local actormgr = selfActor:getActorMgr()
		taskparam.cache_eventHandler = SubscribeGameEvent(nil, "Animation_FrameKey", function (context)
			if not actormgr then
				return
			end

			selfActor = actormgr:findActorByWID(selfObjId)
			targetActor = actormgr:findActorByWID(taskparam.ugc_targetObjId)

			if not selfActor or not selfActor:alive() or not targetActor or not targetActor:alive() then
				return
			end

			if not taskparam.cache_attackDefArr or not taskparam.cache_comboIndex then
				return
			end

			local defArr = taskparam.cache_attackDefArr
			local curDefIdx = taskparam.cache_comboIndex
			local param = context:GetParamData()
			local defName = StringSplit(param.eventName, "__")

			if param.objId == selfActor:getObjId() and defArr and defArr[curDefIdx] and defArr[curDefIdx].property.actid_3rd == param.seqId and defName and defName[1] == defArr[curDefIdx].property.name then
				local atkComboData = defArr[curDefIdx].property

				for _, v in ipairs(atkComboData.eventlist) do
					if v.event_name == param.eventName then
						for _, vv in ipairs(v.execution) do
							if vv == "atk_sound_play" then
								if atkComboData.soundlist[vv] then
									ActorComponentCallModule(selfActor, "SoundComponent", "playSound", atkComboData.soundlist[vv].filename, 1, 1)
								end
							elseif vv == "atk_effect_play" then
								if atkComboData.effectlist[vv] then
									local playEffName, playEffName_dft = nil

									for _, eff in ipairs(atkComboData.effectlist[vv]) do
										if eff.toolid == weaponId then
											playEffName = eff.filename

											break
										elseif eff.toolid == 0 then
											playEffName_dft = eff.filename
										end
									end

									playEffName = playEffName or playEffName_dft

									if playEffName then
										if taskparam.cache_effect then
											ActorComponentCallModule(selfActor, "EffectComponent", "stopBodyEffect", taskparam.cache_effect)
										end

										ActorComponentCallModule(selfActor, "EffectComponent", "playBodyEffect", playEffName)

										taskparam.cache_effect = playEffName
									end
								end
							elseif vv == "atk_decide_do" then
								local atkEnemyVertor = AIFunctionMgr:CollectAttackableActors(selfActor, atkComboData.name, false)

								for i = 0, atkEnemyVertor:size() - 1 do
									AIFunctionMgr:attackActor(selfActor, atkEnemyVertor[i], atkComboData.name)
								end
							elseif vv == "atk_decide_end" then
								local atkEnemyVertor = AIFunctionMgr:CollectAttackableActors(selfActor, atkComboData.name, false)

								for i = 0, atkEnemyVertor:size() - 1 do
									AIFunctionMgr:attackActor(selfActor, atkEnemyVertor[i], atkComboData.name)
								end
							end
						end

						break
					end
				end

				if taskparam.cache_eventAtkLastName == param.eventName then
					taskparam.cache_eventAtkDo = true
				end
			end
		end)

		if AIFunctionMgr:getBagItemCount(selfActor, weaponId, false) <= 0 then
			AIFunctionMgr:addItemToBags(selfActor, weaponId, 1)
		end

		AIFunctionMgr:equipWeapon(selfActor, weaponId, 1)

		if taskparam.path then
			selfActor:getNavigator():newTryMoveTo(taskparam.path, 1, btget_path_range())

			taskparam.path = nil

			selfActor:keepLookAt(targetActor, 10, 10)
		end

		if AccountManager and AccountManager:getMultiPlayer() ~= 0 then
			selfActor:getBody():SetModelAnimPlayerCullingMode(0)
		end

		selfActor:SetModelAnimPlrIsPlayer(true)
	end,
	run = function ()
		local selfActor = controller.target.get("mob")
		local taskparam = controller.taskparam
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, taskparam.ugc_targetObjId)
		local attack_dis = taskparam.cache_attackDis

		if taskparam.cache_targetPos then
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), taskparam.cache_targetPos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfActor:getPosition(), taskparam.cache_targetPos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		targetActor = AIFunctionMgr:getActorByObjId(selfActor, taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local comboIdx = taskparam.cache_comboIndex
		local attackDef = taskparam.cache_attackDefArr[comboIdx]

		if type(attackDef) ~= "table" then
			return controller.fail()
		end

		local playSeqId = attackDef.property.actid_3rd
		local selfBody = selfActor:getBody()

		if not selfBody:hasAnimSeq(playSeqId) then
			MiniLog("[lyx] [UGCTask_AttackMeleeCombo] mobID:", selfActor:getMonsterDef().ID, ", not has aniSeqId:", playSeqId)

			return controller.fail()
		end

		if GetGameInfo():GetRoomHostType() == ROOM_SERVER_RENT then
			selfActor:ClearTLAnimFrameEvent()
		else
			selfBody:clearAnimFrameEvent(selfActor:getObjId())
		end

		local maxEventFrame = 0

		for _, v in ipairs(attackDef.property.eventlist) do
			if GetGameInfo():GetRoomHostType() == ROOM_SERVER_RENT then
				selfActor:RegisterTLAnimFrameEvent(playSeqId, v.event_frame, v.event_name)
			else
				selfBody:addAnimFrameEvent(playSeqId, v.event_frame, v.event_name, selfActor:getObjId())
			end

			if maxEventFrame < v.event_frame then
				taskparam.cache_eventAtkLastName = v.event_name
				maxEventFrame = v.event_frame
			end
		end

		selfBody:resetAnim(playSeqId)

		local toolDef_speedVal = taskparam.cache_weaponDef.AtkSpeed or 1
		toolDef_speedVal = toolDef_speedVal > 0 and toolDef_speedVal or 1
		local atkData_speedVal = attackDef.property.atk_speed or 1
		atkData_speedVal = atkData_speedVal > 0 and atkData_speedVal or 1
		local loopMode = taskparam.ugc_isReset and 1 or 2
		taskparam.cache_eventAtkDo = false

		if GetGameInfo():GetRoomHostType() == ROOM_SERVER_RENT then
			selfActor:ActiveTLAnimFrameEvent()
		end

		selfBody:playAnimCheck(playSeqId, loopMode, toolDef_speedVal * atkData_speedVal, attackDef.property.act_level)
		controller.wait_until(function ()
			local playing = selfBody:hasAnimPlayingById(playSeqId)
			local playEnd = selfBody:hasAnimPlayEnd(playSeqId)
			local playOK = not playing or playing and playEnd

			return playOK and taskparam.cache_eventAtkDo
		end)

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get("mob")
		local taskparam = controller.taskparam
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		selfActor:keepLookAt(targetActor, 10, 10)

		if taskparam.cache_targetPos then
			local t_pos = taskparam.cache_targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
				t_pos = targetActor:getPosition()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, btget_path_range()) then
					taskparam.cache_targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get("mob")

		selfActor:getNavigator():clearPathEntity()
		selfActor:getBody():clearPendingAnimEvents()
		selfActor:stopLookAt()

		local taskparam = controller.taskparam
		taskparam.cache_weaponDef = nil
		taskparam.cache_targetActor = nil
		taskparam.cache_attackDis = nil
		taskparam.cache_attackDefNum = nil
		taskparam.cache_attackDefArr = nil
		taskparam.cache_comboIndex = nil
		taskparam.cache_targetPos = nil
		taskparam.cache_eventAtkLastName = nil
		taskparam.cache_eventAtkDo = false

		if taskparam.cache_effect then
			ActorComponentCallModule(selfActor, "EffectComponent", "stopBodyEffect", taskparam.cache_effect)

			taskparam.cache_effect = nil
		end

		if taskparam.cache_eventHandler then
			UnsubscribeGameEvent(nil, "Animation_FrameKey", taskparam.cache_eventHandler)

			taskparam.cache_eventHandler = nil
		end
	end,
	release = function ()
		if controller and controller.taskparam and controller.taskparam.cache_eventHandler then
			UnsubscribeGameEvent(nil, "Animation_FrameKey", controller.taskparam.cache_eventHandler)

			controller.taskparam.cache_eventHandler = nil
		end
	end
}
