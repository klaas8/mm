local function extractParamValue(param)
	if type(param) == "function" then
		return param.get()
	else
		return param
	end
end

return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local msgid = result[1]
		local eventParam = lcontroller.taskparam.eventParam
		local customparams = eventParam.customdata.CustomEventParams
		local num = customparams and #customparams or 0
		lcontroller.taskparam.msgid = msgid
		lcontroller.taskparam.num = num
		lcontroller.taskparam.customparams = customparams
		local paramids = nil

		if num > 0 then
			paramids = {}

			for i = 1, num do
				table.insert(paramids, i)
			end
		end

		lcontroller.taskparam.paramids = paramids

		if lcontroller:isNeedSendDebug() then
			local data = {}

			table.insert(data, {
				valtype = "msg"
			})

			if customparams and num > 0 then
				for i = 1, num do
					local value = extractParamValue(customparams[i])

					table.insert(data, {
						valtype = "val",
						val = value
					})
				end
			end

			lcontroller.sendValToDebug(data)
		end
	end,
	run = function ()
		local taskparam = controller.taskparam

		if not taskparam.msgid then
			return controller.fail()
		end

		local vals = {}

		for i = 1, taskparam.num do
			local value = extractParamValue(taskparam.customparams[i])

			table.insert(vals, value)
		end

		for index, value in ipairs(vals) do
			GetInst("BTEventManager"):AddEventParam(taskparam.msgid, index, value, controller.treeid)
		end

		return controller.success()
	end
}
