local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId, modelName = nil

		if TEST_TEST_TEST then
			modelName = lcontroller.subparam.modelName
			targetObjId = lcontroller.target.get():getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 2, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2
				})
			end

			modelName = result[2]
			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId
		lcontroller.taskparam.ugc_modelName = modelName

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = modelName or ""
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local ret = BTService:ChangeCustomModel(controller.taskparam.ugc_targetObjId, controller.taskparam.ugc_modelName)

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
