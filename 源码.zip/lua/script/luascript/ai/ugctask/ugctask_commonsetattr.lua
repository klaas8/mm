return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local targetObjId = controller.taskparam.targetObjId
		local cmpName = controller.taskparam.cmpName
		local property = controller.taskparam.property
		local value = controller.taskparam.value

		if targetObjId == -1 then
			return controller.fail()
		end

		local obj = Service.GameObject:FindObject(targetObjId)

		if obj then
			Service.Trigger.Component:SetComponentProperty(obj, cmpName, property, value)

			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local targetObjId = result[1]
		local cmpName = result[2]
		local property = result[3]
		local value = result[4]
		lcontroller.taskparam.targetObjId = targetObjId
		lcontroller.taskparam.cmpName = cmpName
		lcontroller.taskparam.property = property
		lcontroller.taskparam.value = value

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = cmpName
			}
			local data3 = {
				valtype = "val",
				val = property
			}
			local data4 = {
				valtype = "val",
				val = value
			}
			local send_data = {
				data1,
				data2,
				data3,
				data4
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
