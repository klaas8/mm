return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local objid = controller.taskparam.obj

		if objid == nil then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetActor or targetActor:isDead() or targetActor:needClear() then
			return controller.fail()
		end

		local result = AIFunctionMgr:SetOpenDoor(targetActor, true, controller.taskparam.closedoor)

		if not result then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local obj = result[1]
		local bCloseDoor = false

		if type(result[2]) == "string" then
			bCloseDoor = result[2] == "=="
		end

		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.closedoor = bCloseDoor

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = bCloseDoor
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
