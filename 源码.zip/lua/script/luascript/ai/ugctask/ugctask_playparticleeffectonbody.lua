local TEST_TEST_TEST = false
local once = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId, particleId, scale, offset = nil

		if TEST_TEST_TEST then
			scale = 1
			particleId = 1232
			targetObjId = CurMainPlayer:getObjId()
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 5, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3,
					4,
					5
				})
			end

			time = result[5]
			offset = result[4]
			scale = result[3]
			particleId = result[2]
			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId
		lcontroller.taskparam.ugc_particleId = particleId
		lcontroller.taskparam.ugc_scale = scale
		lcontroller.taskparam.ugc_offset = offset
		lcontroller.taskparam.ugc_time = time

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "effecttype",
				val = {
					effectid = particleId
				}
			}
			local data3 = {
				valtype = "val",
				val = scale
			}
			local data4 = {
				valtype = "pos",
				val = offset
			}
			local data5 = {
				valtype = "val",
				val = time
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4,
				data5
			})
		end
	end,
	will = function ()
		if TEST_TEST_TEST then
			if once then
				return false
			end

			once = true
		end

		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local particleId = controller.taskparam.ugc_particleId
		local scale = controller.taskparam.ugc_scale or 1
		local offset = controller.taskparam.ugc_offset
		local targetObjId = controller.taskparam.ugc_targetObjId
		local time = controller.taskparam.ugc_time
		local ret = false

		if Service and Service.Actor then
			ret = Service.Actor:PlayBodyParticleById(targetObjId, particleId, time, offset, nil, {
				x = scale,
				y = scale,
				z = scale
			})
		end

		if ret then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
