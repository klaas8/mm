return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfobj = controller.target.get()
		local itemId = controller.taskparam.itemId
		local weaponId = selfobj:getEquipItem(EQUIP_WEAPON)

		if weaponId == itemId then
			return controller.success()
		end

		if not CheckItemScriptUse(itemId) then
			return controller.fail()
		end

		local result = AIFunctionMgr:equipWeapon(selfobj, itemId, 1)

		if result then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"itemId"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local itemId = result[1]
		local itemNum = result[2]
		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.itemId = itemId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "itemtype",
				val = {
					itemid = itemId
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
