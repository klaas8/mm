return {
	send_debug_data = function ()
	end,
	will = function ()
		local selfActor = controller.target.get("mob")

		if not selfActor or not selfActor:alive() then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get("mob")

		if selfActor:IsInDefanceState() then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
