return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local obj = result[1]
		local comname = result[2]
		local propertyname = result[3]
		local value = result[4]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.comname = comname
		lcontroller.taskparam.propertyname = propertyname
		lcontroller.taskparam.value = value

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = obj or 0
				}
			}
			local data2 = {
				valtype = "cmp",
				val = comname
			}
			local data3 = {
				valtype = "cmpParam",
				val = {
					cmp = comname,
					paramname = propertyname
				}
			}
			local data4 = {
				valtype = "val",
				val = value
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end,
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		if not controller.taskparam.obj or not controller.taskparam.comname or not controller.taskparam.propertyname or not controller.taskparam.value then
			return controller.fail()
		end

		local obj, componentReady = BTService:ResolveAndEnsureComponent(controller.taskparam.obj, controller.taskparam.comname)

		if obj and componentReady then
			local result = Service.Trigger.Component:SetComponentProperty(obj, controller.taskparam.comname, controller.taskparam.propertyname, controller.taskparam.value)

			if result then
				return controller.success()
			end
		end

		return controller.fail()
	end
}
