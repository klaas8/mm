return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local pos = controller.taskparam.pos

		if controller.taskparam.targetPos then
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), controller.taskparam.targetPos) <= math.pow(controller.taskparam.attackDis, 2)

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfActor:getPosition(), controller.taskparam.targetPos) <= math.pow(controller.taskparam.attackDis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local num = controller.taskparam.num
		local tag = controller.taskparam.tag

		if pos == nil or num == nil or tag == nil then
			return controller.fail()
		end

		local searchType = controller.taskparam.searchType
		searchType = searchType or 2
		local t_pos = {
			x = pos.x * BLOCK_SIZE,
			y = pos.y * BLOCK_SIZE,
			z = pos.z * BLOCK_SIZE
		}

		if t_pos then
			AIFunctionMgr:rotateBodyToPos(selfActor, t_pos.x, t_pos.y, t_pos.z)
		end

		local ret = AIFunctionMgr:TakeItemByTag(selfActor, pos.x, pos.y, pos.z, tag, num, searchType)

		if ret == 0 then
			return controller.fail()
		end

		return controller.success()
	end,
	onbeg = function ()
		if controller.taskparam.targetPos then
			local selfActor = controller.target.get()
			local path_range = btget_path_range()

			if controller.taskparam.path then
				selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, 1, path_range)

				controller.taskparam.path = nil
			end
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local tag = controller.taskparam.tag
		local num = controller.taskparam.num

		if not tag or not num then
			return false
		end

		if not BTService:IsXYZ(controller.taskparam.pos) then
			local ret_, newpos = BTService:GetPositionData(controller.taskparam.pos)

			if ret_ == ErrorCode.OK then
				controller.taskparam.pos = newpos
			else
				return false
			end
		end

		local dis_min = selfActor:getLocoMotion().m_BoundSize + 0.2 * BLOCK_SIZE
		local dis_max = selfActor:getViewDist()
		local attack_dis = math.clamp(1 * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.attackDis = attack_dis
		controller.taskparam.targetPos = {
			x = controller.taskparam.pos.x * BLOCK_SIZE,
			y = controller.taskparam.pos.y * BLOCK_SIZE,
			z = controller.taskparam.pos.z * BLOCK_SIZE
		}
		local t_pos = controller.taskparam.targetPos

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.targetPos = nil

			return true
		end
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) and selfActor:getNavigator():noPath() then
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local pos = result[1]
		local num = result[2]
		local tag = result[3]
		local searchType = result[4]
		lcontroller.taskparam.searchType = searchType
		local debugtag = ""
		lcontroller.taskparam.pos = pos
		lcontroller.taskparam.num = num
		local needSendDebug = lcontroller:isNeedSendDebug()
		lcontroller.taskparam.tag, debugtag = lBTService:DealTagToArrayData(tag, needSendDebug, lcontroller.taskparam.tag)
		lcontroller.taskparam.searchType = searchType

		if needSendDebug then
			local data1 = {
				valtype = "pos",
				val = lcontroller.taskparam.pos
			}
			local data2 = {
				valtype = "val",
				val = lcontroller.taskparam.num
			}
			local data3 = {
				valtype = "enum"
			}
			local data4 = {
				valtype = "val",
				val = debugtag
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
