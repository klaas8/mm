return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local isNo = controller.taskparam.isNo

		if not objid or not isNo then
			return controller.fail()
		end

		local obj = controller.target.get()
		local actor = AIFunctionMgr:getActorByObjId(obj, objid)
		local visible = false
		visible = isNo ~= "false"

		if actor then
			local ret = AIFunctionMgr:setHPVisible(actor, visible)

			if ret then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local isNo = result[2]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.isNo = isNo

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "enum"
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
