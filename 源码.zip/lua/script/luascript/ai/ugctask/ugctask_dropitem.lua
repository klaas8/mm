return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)
		local num = controller.taskparam.num
		local item = controller.taskparam.item
		local isCreate = controller.taskparam.isCreate
		local distance = controller.taskparam.distance

		if item == nil or num == nil or isCreate == nil or distance == nil then
			if controller.taskparam.needErrInfo then
				local errinfo = {}

				if item == nil then
					errinfo.info = "itemnil"
				elseif num == nil then
					errinfo.info = "numnil"
				elseif isCreate == nil then
					errinfo.info = "isCreatenil"
				elseif distance == nil then
					errinfo.info = "distancenil"
				end

				controller.sendMsgToAi(selfActor, "UGCTask_DropItem", errinfo)
			end

			return controller.fail()
		end

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		if not CheckItemScriptUse(item) then
			isCreate = false
		end

		local ret, errinfo = AIFunctionMgr:DiscardItem(selfActor, item, num, distance, isCreate, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfActor, "UGCTask_DropItem", errinfo)
		end

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local num = result[1]
		local item = result[2]
		local distance = result[3]
		local isCreate = result[4]

		if type(isCreate) == "string" then
			if isCreate == "==" then
				isCreate = true
			else
				isCreate = false
			end
		end

		lcontroller.taskparam.item = item
		lcontroller.taskparam.num = num
		lcontroller.taskparam.distance = distance
		lcontroller.taskparam.isCreate = isCreate

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = num
			}
			local data2 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}
			local data3 = {
				valtype = "val",
				val = distance
			}
			local data4 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
