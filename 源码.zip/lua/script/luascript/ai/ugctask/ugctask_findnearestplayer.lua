return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local obj = controller.target.get()
		local param_keys = {
			"range"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(controller)

			lBTService:GetSubparamInto(controller, 1, result)
		else
			result = btget_subparam(controller, {
				1
			})
		end

		local findRange = result[1]
		local ret = false
		local targetObjID = 0
		local posX = 0
		local posY = 0
		local posZ = 0
		ret, targetObjID, posX, posY, posZ = AIFunctionMgr:GetNearestPlayerPos(obj, targetObjID, findRange, 0, 0, 0)

		if ret then
			controller.bb.set(controller.subparam.bbret_targetpos, {
				x = posX,
				y = posY,
				z = posZ
			})
			controller.bb.set(controller.subparam.bbret_targetobj, {
				actor = targetObjID
			})

			return controller.success()
		else
			return controller.fail()
		end
	end
}
