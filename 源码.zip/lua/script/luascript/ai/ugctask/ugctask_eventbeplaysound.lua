return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local obj = result[1]
		local dist = result[2]
		local soundid = result[3]
		local bbkey = result[4]
		lcontroller.taskparam.obj = obj
		lcontroller.taskparam.dist = dist
		lcontroller.taskparam.soundid = soundid
		lcontroller.taskparam.bbkey = bbkey

		if lcontroller:isNeedSendDebug() then
			local bbval = lcontroller.bb.get(bbkey)
			local data = {
				{
					valtype = "actor",
					val = {
						actor = obj or 0
					}
				},
				{
					valtype = "val",
					val = dist or 0
				},
				{
					valtype = "sound",
					val = {
						effectid = soundid or 0
					}
				},
				{
					valtype = "getName"
				}
			}

			lcontroller.sendValToDebug(data)
		end
	end,
	run = function ()
		if not controller.taskparam.obj or not controller.taskparam.dist or not controller.taskparam.soundid or not controller.taskparam.bbkey or type(controller.taskparam.bbkey) == "number" then
			return controller.fail()
		end

		local eventparm = controller.taskparam.eventParam

		if not eventparm then
			return controller.fail()
		end

		local x = eventparm.x
		local y = eventparm.y
		local z = eventparm.z
		local selfActor = controller.target.get()
		local posx, posy, posz = selfActor:getPosition(0, 0, 0)
		posx = posx / BLOCK_SIZE
		posy = posy / BLOCK_SIZE
		posz = posz / BLOCK_SIZE
		x = x / BLOCK_SIZE
		y = y / BLOCK_SIZE
		z = z / BLOCK_SIZE
		local dist = math.sqrt((posx - x) * (posx - x) + (posy - y) * (posy - y) + (posz - z) * (posz - z))

		if dist <= controller.taskparam.dist then
			if type(bbkey) == "table" then
				if bbkey.func and type(bbkey.func) == "function" then
					bbkey.func({
						value = {
							x = x,
							y = y,
							z = z
						},
						controller = controller
					})
				end
			else
				local settype = controller.bb.set(controller.taskparam.bbkey, {
					x = x,
					y = y,
					z = z
				})
			end

			return controller.success()
		end

		return controller.fail()
	end
}
