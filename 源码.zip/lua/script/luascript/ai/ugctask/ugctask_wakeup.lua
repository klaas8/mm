return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)
		local ret, errinfo = AIFunctionMgr:wakeUp(selfActor, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfActor, "UGCTask_WakeUp", errinfo)
		end

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
	end
}
