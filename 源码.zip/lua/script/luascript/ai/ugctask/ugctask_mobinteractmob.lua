return {
	send_debug_data = function ()
		local lcontroller = controller
		local object, targetObj = nil
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		object = result[2]
		targetObj = result[1]
		lcontroller.taskparam.object = object
		lcontroller.taskparam.targetObj = targetObj
		lcontroller.taskparam.distance = 1.5

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObj or 0
				}
			}
			local data2 = {
				valtype = "actor",
				val = {
					actor = object or 0
				}
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local object = controller.taskparam.object
		local targetObj = controller.taskparam.targetObj

		if not object or not targetObj then
			return false
		end

		local objectActor = AIFunctionMgr:getActorByObjId(selfActor, object)

		if not objectActor or not objectActor:alive() then
			return false
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)

		if not targetActor or not targetActor:alive() then
			return false
		end

		local dis_min = targetActor:getLocoMotion().m_BoundSize + objectActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local dis_max = targetActor:getViewDist()
		local distance = controller.taskparam.distance
		local attack_dis = math.clamp(distance * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.attackDis = attack_dis
		local t_pos = objectActor:getPosition()

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = targetActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.targetPos = nil

			return true
		end
	end,
	onbeg = function ()
		if controller.taskparam.targetPos then
			local selfActor = controller.target.get()
			local targetObj = controller.taskparam.targetObj
			local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)
			local object = controller.taskparam.object
			local objectActor = AIFunctionMgr:getActorByObjId(selfActor, object)
			local path_range = btget_path_range()

			if objectActor and controller.taskparam.path then
				targetActor:getNavigator():newTryMoveTo(controller.taskparam.path, 1, path_range)

				controller.taskparam.path = nil

				targetActor:keepLookAt(objectActor, 10, 10)
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()
		local targetObj = controller.taskparam.targetObj
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)
		local attack_dis = controller.taskparam.attackDis
		local object = controller.taskparam.object
		local objectActor = AIFunctionMgr:getActorByObjId(selfActor, object)

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local checkTag = Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or targetActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)
					local objectActor = AIFunctionMgr:getActorByObjId(selfActor, object)

					if not targetActor or not targetActor:alive() or not objectActor or not objectActor:alive() then
						return true
					end

					return Pos3SquareDistToPos3(targetActor:getPosition(), objectActor:getPosition()) <= math.pow(attack_dis, 2) or targetActor:getNavigator():noPath()
				end)
			end
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)

		if targetActor and targetActor:alive() then
			targetActor:getNavigator():clearPathEntity()
		end

		local objectActor = AIFunctionMgr:getActorByObjId(selfActor, object)

		if not objectActor or not objectActor:alive() then
			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(targetActor, objectActor)

		if math.pow(attack_dis * 3, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), objectActor:getPosition()) then
			return controller.fail()
		end

		local ret = AIFunctionMgr:MobInteractMob(targetActor, objectActor)

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get()
		local targetObj = controller.taskparam.targetObj
		local object = controller.taskparam.object
		local objectActor = AIFunctionMgr:getActorByObjId(selfActor, object)
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)

		if not targetActor or tolua.isnull(targetActor) or not targetActor:alive() or not objectActor or tolua.isnull(objectActor) or not objectActor:alive() then
			return false
		end

		targetActor:keepLookAt(objectActor, 30, 30)

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(objectActor:getPosition(), t_pos) then
				t_pos = objectActor:getPosition()
				local path_range = btget_path_range()

				if targetActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()
		local targetObj = controller.taskparam.targetObj
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, targetObj)

		if targetActor and targetActor:alive() then
			targetActor:getNavigator():clearPathEntity()
			targetActor:stopLookAt()
		end

		controller.taskparam.targetPos = nil
		controller.taskparam.attackDis = nil
	end
}
