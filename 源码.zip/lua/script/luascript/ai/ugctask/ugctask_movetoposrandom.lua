return {
	will = function ()
		local actor = controller.target.get()

		if not actor or actor:isDead() or actor:needClear() then
			return false
		end

		local centerPos = controller.taskparam.centerPos
		local rangeWidth = controller.taskparam.range or 0
		local rangeHeight = controller.taskparam.range or 0

		if not BTService:IsXYZ(centerPos) or rangeWidth == nil or rangeHeight == nil then
			return false
		end

		local t_pos = {
			z = 0,
			x = 0,
			y = 0
		}
		t_pos.x, t_pos.y, t_pos.z = AIFunctionMgr:GetRandStrollCenterPos(actor, t_pos.x, t_pos.y, t_pos.z, centerPos.x, centerPos.y, centerPos.z, rangeWidth, rangeHeight)
		local x, y, z = BlockBottomCoord(t_pos.x, t_pos.y, t_pos.z)
		local path_range = btget_path_range()
		controller.taskparam.path = actor:getNavigator():landCanMoveTo(x, y, z, path_range)

		if controller.taskparam.path then
			controller.taskparam.targetPos = {
				x = x,
				y = y,
				z = z
			}

			return true
		else
			return false
		end
	end,
	onbeg = function ()
		local actor = controller.target.get()
		controller.taskparam.lastStopState = actor.IsStopBodyRotation
		controller.taskparam.lastYaw = nil
		local changeToward = controller.taskparam.changeToward

		if not changeToward then
			local locoMotion = actor:getLocoMotion()

			if locoMotion then
				controller.taskparam.lastYaw = locoMotion:getRotateYaw()
			end
		end

		actor.IsStopBodyRotation = not changeToward
		local speed = controller.taskparam.speed
		local path_range = btget_path_range()

		if controller.taskparam.path then
			actor:getNavigator():newTryMoveTo(controller.taskparam.path, speed, path_range)

			controller.taskparam.path = nil
		end
	end,
	run = function ()
		local actor = controller.target.get()

		if actor:IsInNavigating() then
			controller.wait_until(function ()
				return not actor:IsInNavigating()
			end)
		end

		return controller.success()
	end,
	onend = function ()
		local actor = controller.target.get()

		actor:getNavigator():clearPathEntity()

		local lastStopState = controller.taskparam.lastStopState

		BTService:RestoreSavedYaw(actor, controller.taskparam)

		if lastStopState ~= nil then
			actor.IsStopBodyRotation = lastStopState
		end

		controller.taskparam.lastStopState = nil
	end,
	release = function ()
		local actor = controller.target.get()
		local lastStopState = controller.taskparam.lastStopState
		controller.taskparam.lastStopState = nil

		BTService:RestoreSavedYaw(actor, controller.taskparam)

		if actor and lastStopState ~= nil then
			actor.IsStopBodyRotation = lastStopState
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local realpos = result[1]
		local range = result[2]
		local speed = result[3]
		local changeToward = result[4]
		changeToward = changeToward == "==" and true or false
		lcontroller.taskparam.centerPos = realpos
		lcontroller.taskparam.range = range
		lcontroller.taskparam.speed = speed
		lcontroller.taskparam.changeToward = changeToward

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = realpos
			}
			local data2 = {
				valtype = "val",
				val = range
			}
			local data3 = {
				valtype = "val",
				val = speed
			}
			local data4 = {
				valtype = "val",
				val = changeToward
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
