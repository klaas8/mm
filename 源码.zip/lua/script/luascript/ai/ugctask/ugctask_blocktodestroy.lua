return {
	will = function ()
		local pos = controller.taskparam.position

		if type(pos) ~= "table" then
			return false
		end

		if not pos.x or not pos.y or not pos.z then
			return false
		end

		local mobActor = controller.target.get("living")

		if not mobActor or not mobActor:alive() then
			return false
		end

		if not GameplayTagUtils:IsDestroyBlockEnabled(mobActor) then
			return false
		end

		return true
	end,
	decorator = function ()
		return controller.success()
	end,
	onbeg = function ()
		local actor = controller.target.get()
		local pos = controller.taskparam.position

		if not pos or not actor then
			return controller.fail()
		end

		local path_range = btget_path_range()
		local x, y, z = BlockBottomCoord(pos.x, pos.y, pos.z)

		actor:getNavigator():tryMoveTo(x, y, z, 1.2, path_range)

		controller.taskparam.targetPos = {
			x = x,
			y = y,
			z = z
		}
	end,
	run = function ()
		local selfobj = controller.target.get()
		local targetPos = controller.taskparam.targetPos
		local maxdistance = math.pow(BLOCK_SIZE * 2, 2)
		local distance = PosSquareDistanceToPos(selfobj:getPosition(), targetPos)

		while not selfobj:getNavigator():noPath() or maxdistance < distance do
			if distance <= maxdistance or selfobj:getNavigator():noPath() then
				break
			end

			distance = PosSquareDistanceToPos(selfobj:getPosition(), targetPos)

			controller.wait()
		end

		local pos = controller.taskparam.position
		local blockPos = WCoord()
		blockPos.x = pos.x or 0
		blockPos.y = pos.y or 0
		blockPos.z = pos.z or 0
		local ret = false
		local objtype = selfobj:getObjType()
		local bigtype = GameActorTypeToObjType[objtype]
		local candropItem = controller.taskparam.candrop or false

		if bigtype == OBJ_TYPE.OBJTYPE_CREATURE then
			local selfMob = tolua.cast(selfobj, "ClientMob")

			if selfMob and selfMob.destroyBlock then
				selfMob:destroyBlock(blockPos, true, BLOCK_MINE_NOTOOL, candropItem)

				return controller.success()
			end
		else
			local world = CurWorld

			if selfobj then
				world = selfobj:getWorld()
			end

			local result = Service.Block:DestroyBlock(pos.x, pos.y, pos.z, true, world:getCurMapID())

			if result then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	onend = function ()
		local selfobj = controller.target.get()

		selfobj:getNavigator():clearPathEntity()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local position = result[1]
		local candrop = result[2]
		local newCanDrop = lBTService:GetBoolVal(candrop)
		lcontroller.taskparam.position = position
		lcontroller.taskparam.candrop = newCanDrop

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = position
			}
			local data2 = {
				valtype = "val",
				val = newCanDrop
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
