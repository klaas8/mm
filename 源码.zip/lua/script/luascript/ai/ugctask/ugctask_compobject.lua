return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local param_left = controller.taskparam.param_left
		local cmpEnumType = controller.taskparam.cmpEnumType
		local param_right = controller.taskparam.param_right

		if type(cmpEnumType) ~= "string" then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local lefActor = nil

		if param_left then
			lefActor = AIFunctionMgr:getActorByObjId(selfActor, param_left)
		end

		local rightActor = nil

		if param_right then
			rightActor = AIFunctionMgr:getActorByObjId(selfActor, param_right)
		end

		if cmpEnumType == "==" then
			if param_left == param_right then
				if lefActor == nil and rightActor == nil or lefActor ~= nil and rightActor ~= nil then
					return controller.success()
				else
					return controller.fail()
				end
			elseif lefActor == nil and rightActor == nil then
				return controller.success()
			end
		elseif cmpEnumType == "~=" then
			if param_left ~= param_right then
				if lefActor == nil and rightActor == nil then
					return controller.fail()
				else
					return controller.success()
				end
			elseif lefActor == nil and rightActor ~= nil or rightActor == nil and lefActor ~= nil then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"param_left",
			"compareType",
			"param_right"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local param_left = result[1]
		local cmpEnumType = result[2]
		local param_right = result[3]
		lcontroller.taskparam.param_left = param_left
		lcontroller.taskparam.cmpEnumType = cmpEnumType
		lcontroller.taskparam.param_right = param_right

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = param_left or 0
				}
			}
			local data2 = {
				valtype = "enum",
				val = cmpEnumType
			}
			local data3 = {
				valtype = "actor",
				val = {
					actor = param_right or 0
				}
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
