local TEST_TEST_TEST = false
local once = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local targetPos, actorId = nil

		if TEST_TEST_TEST then
			actorId = 3409
			targetPos = {
				y = 0,
				z = 0,
				x = 0
			}
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 2, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2
				})
			end

			actorId = result[2]
			targetPos = result[1]
		end

		actorId = lBTService:ResidToId(actorId)
		lcontroller.taskparam.ugc_position = targetPos
		lcontroller.taskparam.ugc_actorId = actorId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = targetPos
			}
			local data2 = {
				valtype = "val",
				val = actorId or 0
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	will = function ()
		if TEST_TEST_TEST then
			if once then
				return false
			end

			once = true
		end

		local selfActor = controller.target.get()
		local world = CurWorld

		if selfActor then
			world = selfActor:getWorld()
		end

		if not selfActor or not selfActor:alive() then
			return false
		end

		if type(controller.taskparam.ugc_actorId) ~= "number" or type(controller.taskparam.ugc_position) ~= "table" then
			return false
		end

		if not world then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local position = controller.taskparam.ugc_position
		local blockPosX = position.x
		local blockPosY = position.y
		local blockPosZ = position.z
		local world = CurWorld

		if selfActor then
			world = selfActor:getWorld()
		end

		if not world then
			return controller.fail()
		end

		while world:getBlockID(blockPosX, blockPosY, blockPosZ) ~= BLOCK_AIR do
			blockPosY = blockPosY + 1
		end

		local actorid = controller.taskparam.ugc_actorId

		if controller.taskparam.ugc_actorId < 1 then
			return controller.fail()
		end

		local x, y, z = BlockCenterCoord(blockPosX, blockPosY, blockPosZ)
		local newActor = AIFunctionMgr:spawnActorEx(selfActor, controller.taskparam.ugc_actorId, x, y, z)

		if newActor then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
