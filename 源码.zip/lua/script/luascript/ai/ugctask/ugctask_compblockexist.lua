return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local selfActor = controller.target.get()
		local dist = controller.taskparam.dist

		if not selfActor or dist == nil then
			return controller.fail()
		end

		if controller.taskparam.worldobj == nil then
			controller.taskparam.worldobj = UGCGetInst("GameObjectMgr"):GetWorld()

			if controller.taskparam.worldobj then
				local cmp = controller.taskparam.worldobj:GetComponent("ZombieFacilityMgr")

				if cmp then
					controller.taskparam.ZombieFacilityMgr = cmp

					if cmp.GetNearestFacility then
						controller.taskparam.GetNearestFacility = cmp.GetNearestFacility
					end
				end
			end
		end

		if controller.taskparam.GetNearestFacility and controller.taskparam.ZombieFacilityMgr then
			local pos = selfActor:getPosition()
			local rpos = {
				x = pos.x,
				y = pos.y,
				z = pos.z
			}
			rpos.x, rpos.y, rpos.z = CoordDivBlock(rpos.x, rpos.y, rpos.z)
			local ret, result = controller.taskparam.GetNearestFacility(controller.taskparam.ZombieFacilityMgr, rpos, dist)

			if type(ret) == "table" then
				if not ret or not ret[1] then
					return controller.fail()
				end
			elseif not ret or not result then
				return controller.fail()
			end
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local dist = result[1]
		lcontroller.taskparam.dist = dist

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "var",
				val = dist
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
