return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)
		local item = controller.taskparam.item

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		if item == nil then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "itemnil"
				}

				controller.sendMsgToAi(selfActor, "UGCTask_EquipItem", errinfo)
			end

			return controller.fail()
		end

		local ret, errinfo = AIFunctionMgr:EquipItem(selfActor, item, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfActor, "UGCTask_EquipItem", errinfo)
		end

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local item = result[1]
		lcontroller.taskparam.item = item

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end
}
