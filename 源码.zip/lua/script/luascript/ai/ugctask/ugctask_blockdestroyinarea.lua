local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local areaId, frequency, canDrop = nil

		if TEST_TEST_TEST then
			frequency = 0.5
			areaId = 0
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 3, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3
				})
			end

			canDrop = result[3]
			frequency = result[2]
			areaId = result[1]
		end

		local newCanDrop = lBTService:GetBoolVal(canDrop)
		lcontroller.taskparam.ugc_areaId = areaId
		lcontroller.taskparam.ugc_frequency = frequency
		lcontroller.taskparam.ugc_canDrop = newCanDrop

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "area",
				val = lBTService:GetAreaDebugData(areaId)
			}
			local data2 = {
				valtype = "val",
				val = frequency
			}
			local data3 = {
				valtype = "val",
				val = newCanDrop
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		if not GameplayTagUtils:IsDestroyBlockEnabled(selfActor) then
			return false
		end

		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local realAreadId = controller.taskparam.ugc_areaId
		local ss_area = BTService:GetSSObj("Area")
		local ret = ErrorCode.FAILED

		if controller.taskparam.ugc_frequency > 0 then
			ret = ss_area:DestroyAllBlock(realAreadId, 0, 1, controller.taskparam.ugc_canDrop)
		else
			ret = ss_area:DestroyAllBlock(realAreadId, 0, 0, controller.taskparam.ugc_canDrop)
		end

		if ret == ErrorCode.OK then
			controller.target.get():getBody():playAnimCheck(100105)

			if controller.taskparam.ugc_frequency > 0 then
				controller.wait(controller.taskparam.ugc_frequency)
			end

			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
