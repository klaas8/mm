local function LocalXZSqDist(p1, p2)
	if not p1 or not p2 then
		return 999999
	end

	local dx = (p1.x or 0) - (p2.x or 0)
	local dz = (p1.z or 0) - (p2.z or 0)

	return dx * dx + dz * dz
end

local function PickSingleNestApproachPos(pet, nestpos, path_range)
	if not pet or not nestpos then
		return nil
	end

	local nav = pet:getNavigator()

	if not nav then
		return nil
	end

	local bestPos, bestPath = nil
	local bestDist = 999999999
	local ppos = pet:getPosition()

	for dx = -1, 1 do
		for dz = -1, 1 do
			if dx ~= 0 or dz ~= 0 then
				local bx = nestpos.x + dx
				local by = nestpos.y
				local bz = nestpos.z + dz
				local px, py, pz = BlockBottomCoord(bx, by, bz)
				local path = nav:landCanMoveTo(px, py, pz, path_range)

				if path then
					local dis = LocalXZSqDist(ppos, {
						x = px,
						y = py,
						z = pz
					})

					if dis < bestDist then
						bestDist = dis
						bestPos = {
							x = px,
							y = py,
							z = pz
						}
						bestPath = path
					end
				end
			end
		end
	end

	return bestPos, bestPath
end

local sNestExtendPos = {
	{
		{
			0,
			0
		},
		{
			1,
			0
		},
		{
			0,
			-1
		},
		{
			1,
			-1
		}
	},
	{
		{
			0,
			0
		},
		{
			-1,
			0
		},
		{
			0,
			1
		},
		{
			-1,
			1
		}
	},
	{
		{
			0,
			0
		},
		{
			1,
			0
		},
		{
			0,
			1
		},
		{
			1,
			1
		}
	},
	{
		{
			0,
			0
		},
		{
			-1,
			0
		},
		{
			0,
			-1
		},
		{
			-1,
			-1
		}
	}
}

local function FindMultiNestCorePos(world, nestpos)
	if not world or not nestpos then
		return nil
	end

	local bx = nestpos.x
	local by = nestpos.y
	local bz = nestpos.z
	local data = world:getBlockData(bx, by, bz) or 0
	local dir = bit.band(data, 3)

	for y = 0, 1 do
		for i = 1, 4 do
			local ox = sNestExtendPos[dir + 1][i][1]
			local oz = sNestExtendPos[dir + 1][i][2]
			local cx = bx - ox
			local cy = by - y
			local cz = bz - oz

			if world:getBlockID(cx, cy, cz) == BLOCK_MULTI_PET_NEST then
				local cdata = world:getBlockData(cx, cy, cz) or 0

				if bit.band(cdata, 4) == 0 then
					return {
						x = cx,
						y = cy,
						z = cz
					}, bit.band(cdata, 3)
				end
			end
		end
	end

	return nil
end

local sNestStandPos = {
	{
		{
			-1,
			0
		},
		{
			-1,
			-1
		},
		{
			-1,
			1
		},
		{
			-1,
			-2
		},
		{
			0,
			1
		},
		{
			0,
			-2
		},
		{
			1,
			1
		},
		{
			1,
			-2
		},
		{
			2,
			1
		},
		{
			2,
			-2
		},
		{
			2,
			0
		},
		{
			2,
			-1
		}
	},
	{
		{
			1,
			0
		},
		{
			1,
			1
		},
		{
			1,
			-1
		},
		{
			1,
			2
		},
		{
			0,
			-1
		},
		{
			0,
			2
		},
		{
			1,
			-1
		},
		{
			1,
			2
		},
		{
			2,
			-1
		},
		{
			2,
			0
		},
		{
			2,
			1
		},
		{
			2,
			2
		}
	},
	{
		{
			0,
			-1
		},
		{
			1,
			-1
		},
		{
			-1,
			-1
		},
		{
			2,
			-1
		},
		{
			-1,
			0
		},
		{
			2,
			0
		},
		{
			-1,
			1
		},
		{
			2,
			1
		},
		{
			-1,
			2
		},
		{
			0,
			2
		},
		{
			1,
			2
		},
		{
			2,
			2
		}
	},
	{
		{
			0,
			1
		},
		{
			-1,
			1
		},
		{
			1,
			1
		},
		{
			-2,
			1
		},
		{
			1,
			0
		},
		{
			-2,
			0
		},
		{
			1,
			-1
		},
		{
			-2,
			-1
		},
		{
			1,
			-2
		},
		{
			0,
			-2
		},
		{
			-1,
			-2
		},
		{
			-2,
			-2
		}
	}
}

local function PickMultiNestDoorPos(pet, corePos, dir, path_range)
	if not pet or not corePos then
		return nil
	end

	local nav = pet:getNavigator()

	if not nav then
		return nil
	end

	local d = (dir or 0) + 1
	local y = corePos.y

	for i = 1, 12 do
		local off = sNestStandPos[d][i]
		local x = corePos.x + off[1]
		local z = corePos.z + off[2]
		local px, py, pz = BlockBottomCoord(x, y, z)
		local path = nav:newCanMoveTo(px, py, pz, path_range)

		if path then
			return {
				x = px,
				y = py,
				z = pz
			}, path
		end
	end

	return nil
end

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local petobjid = result[1]
		local nestpos = result[2]
		lcontroller.taskparam.petobjid = petobjid
		lcontroller.taskparam.nestpos = nestpos

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = petobjid or 0
				}
			}
			local data2 = {
				valtype = "pos",
				val = nestpos
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local objid = controller.taskparam.petobjid

		if not objid or objid <= 0 then
			return false
		end

		local nestpos = controller.taskparam.nestpos

		if not nestpos or type(nestpos) ~= "table" then
			return false
		end

		if nestpos.x == nil or nestpos.y == nil or nestpos.z == nil then
			return false
		end

		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or not pet:alive() then
			return false
		end

		if AIFunctionMgr:IsPetInNest(pet) then
			return false
		end

		local world = pet:getWorld()
		local nestblockId = world:getBlockID(nestpos.x, nestpos.y, nestpos.z)

		if nestblockId and nestblockId == BLOCK_MULTI_PET_NEST then
			local path_range = btget_path_range()
			local corePos, dir = FindMultiNestCorePos(world, nestpos)

			if not corePos then
				return false
			end

			controller.taskparam.nestCorePos = corePos
			local doorPos, doorPath = PickMultiNestDoorPos(pet, corePos, dir, path_range)

			if not doorPos then
				return false
			end

			controller.taskparam.targetPos = doorPos
			controller.taskparam.path = doorPath
			controller.taskparam.isMultiNest = true
			local d = (dir or 0) + 1
			local sumOx = 0
			local sumOz = 0

			for i = 1, 4 do
				sumOx = sumOx + sNestExtendPos[d][i][1]
				sumOz = sumOz + sNestExtendPos[d][i][2]
			end

			local offX = sumOx / 4
			local offZ = sumOz / 4
			local cx, cy, cz = BlockCenterCoord(corePos.x + offX, corePos.y + 0.1, corePos.z + offZ)
			controller.taskparam.nestCenterPos = {
				x = cx,
				y = cy,
				z = cz
			}
		else
			controller.taskparam.isMultiNest = false
			local path_range = btget_path_range()
			local approachPos, approachPath = PickSingleNestApproachPos(pet, nestpos, path_range)

			if not approachPos then
				return false
			end

			controller.taskparam.targetPos = approachPos
			controller.taskparam.path = approachPath
			controller.taskparam.isSingleNest = true
			local cx, cy, cz = BlockBottomCoord(nestpos.x, nestpos.y, nestpos.z)
			controller.taskparam.nestCenterPos = {
				x = cx,
				y = cy + 50,
				z = cz
			}
		end

		local dis_min = 0.5 * BLOCK_SIZE
		local dis_max = pet:getViewDist()
		controller.taskparam.approachDis = math.clamp(0.5 * BLOCK_SIZE, dis_min, dis_max)

		if nestblockId and nestblockId == BLOCK_MULTI_PET_NEST then
			controller.taskparam.approachDis = math.clamp(BLOCK_SIZE, dis_min, dis_max)
		end

		local targetPos = controller.taskparam.targetPos

		if math.pow(controller.taskparam.approachDis, 2) < Pos3SquareDistToPos3(pet:getPosition(), targetPos) then
			local path_range = btget_path_range()
			controller.taskparam.path = controller.taskparam.path or pet:getNavigator():landCanMoveTo(targetPos.x, targetPos.y, targetPos.z, path_range)

			if not controller.taskparam.path then
				return false
			end
		else
			controller.taskparam.path = nil
		end

		return true
	end,
	onbeg = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return
		end

		local objid = controller.taskparam.petobjid
		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or not pet:alive() then
			return
		end

		if controller.taskparam.path then
			local path_range = btget_path_range()

			pet:getNavigator():newTryMoveTo(controller.taskparam.path, 1, path_range)

			controller.taskparam.path = nil
		end
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local objid = controller.taskparam.petobjid
		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or not pet:alive() then
			return controller.fail()
		end

		local nestpos = controller.taskparam.nestpos

		if not nestpos or type(nestpos) ~= "table" then
			return controller.fail()
		end

		local targetPos = controller.taskparam.targetPos

		if not targetPos then
			return controller.fail()
		end

		local approachDis = controller.taskparam.approachDis or 0.5 * BLOCK_SIZE
		local checkTag = LocalXZSqDist(pet:getPosition(), targetPos) <= math.pow(approachDis, 2) or pet:getNavigator():noPath()

		if not checkTag then
			controller.wait_until(function ()
				if not pet or tolua.isnull(pet) or not pet:alive() then
					return true
				end

				return LocalXZSqDist(pet:getPosition(), targetPos) <= math.pow(approachDis, 2) or pet:getNavigator():noPath()
			end)
			pet:getNavigator():clearPathEntity()
		end

		if math.pow(approachDis, 2) < LocalXZSqDist(pet:getPosition(), targetPos) then
			return controller.fail()
		end

		local tempPet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not tempPet or not tempPet:alive() then
			return controller.fail()
		end

		local result = AIFunctionMgr:BindToPetNest(tempPet, nestpos.x, nestpos.y, nestpos.z)

		if result then
			if (controller.taskparam.isMultiNest or controller.taskparam.isSingleNest) and controller.taskparam.nestCenterPos then
				local nestCenter = controller.taskparam.nestCenterPos

				tempPet:setPosition(nestCenter.x, nestCenter.y, nestCenter.z)

				local doorPos = controller.taskparam.targetPos

				if doorPos ~= nil then
					AIFunctionMgr:faceWorldPos(tempPet, doorPos.x * BLOCK_SIZE, doorPos.y * BLOCK_SIZE, doorPos.z * BLOCK_SIZE, 180, 180)
				end
			end

			return controller.success()
		end

		return controller.fail()
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local objid = controller.taskparam.petobjid
		local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not pet or tolua.isnull(pet) or not pet:alive() then
			return false
		end

		local targetPos = controller.taskparam.targetPos
		local approachDis = controller.taskparam.approachDis or 1 * BLOCK_SIZE

		if targetPos and math.pow(approachDis, 2) < LocalXZSqDist(pet:getPosition(), targetPos) and not pet:getNavigator():noPath() then
			local path_range = btget_path_range()

			if pet:getNavigator():tryMoveTo(targetPos.x, targetPos.y, targetPos.z, 1, path_range) then
				return true
			else
				return false
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		if selfActor and selfActor:alive() then
			local objid = controller.taskparam.petobjid
			local pet = AIFunctionMgr:getActorByObjId(selfActor, objid)

			if pet and pet:alive() then
				pet:getNavigator():clearPathEntity()
			end
		end

		controller.taskparam.targetPos = nil
		controller.taskparam.path = nil
		controller.taskparam.approachDis = nil
		controller.taskparam.isMultiNest = nil
		controller.taskparam.isSingleNest = nil
		controller.taskparam.nestCorePos = nil
		controller.taskparam.nestCenterPos = nil
	end
}
