return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local buff = controller.taskparam.buff

		if not objid or not buff then
			return controller.fail()
		end

		local buffid, bufflv = BTService:getBuffData(buff)

		if not buffid then
			return controller.fail()
		end

		local ret = BTService:GetSSObj("Buff"):removeBuff(objid, buffid)

		if ret == ErrorCode.OK then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local buff = result[2]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.buff = buff

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid
				}
			}
			local data2 = {
				valtype = "effecttype",
				val = {
					effectid = buff
				}
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
