return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local reuseSubparamOutput = lBTService:IsSubparamReuseEnabled()
		local num = math.max(#lcontroller.subparam - 1, 0)
		local result = nil

		if reuseSubparamOutput then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, num + 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local msgid = result[1]
		local param = {}
		local data = {}

		table.insert(data, {
			valtype = "msg"
		})

		for i = 1, num do
			local val = nil

			if reuseSubparamOutput then
				val = result[i + 1]
			else
				result = btget_subparam(lcontroller, {
					i + 1
				})
				val = result[1]
			end

			table.insert(param, val)
			table.insert(data, {
				valtype = "val",
				val = val
			})
		end

		lcontroller.taskparam.msgid = msgid
		lcontroller.taskparam.param = param

		if lcontroller:isNeedSendDebug() then
			lcontroller.sendValToDebug(data)
		end
	end,
	run = function ()
		if not controller.taskparam.msgid or not controller.taskparam.param then
			return controller.fail()
		end

		local customdata = {
			CustomEventParams = controller.taskparam.param
		}
		local data = {
			customdata = _G.table2json(customdata)
		}
		local ss_Game = BTService:GetSSObj("Game")
		local result = ss_Game:dispatchEvent(controller.taskparam.msgid, data)

		if result == ErrorCode.OK then
			return controller.success()
		end

		return controller.fail()
	end
}
