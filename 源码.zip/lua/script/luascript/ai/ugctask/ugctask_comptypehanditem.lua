local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local targetObjId, compareType, itemId = nil

		if TEST_TEST_TEST then
			itemId = 12005
			compareType = true
			targetObjId = CurMainPlayer:getObjId()
		else
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 3, result)
			else
				result = btget_subparam(lcontroller, {
					1,
					2,
					3
				})
			end

			itemId = result[3]
			compareType = result[2]
			targetObjId = result[1]
			compareType = compareType == "==" and true or false
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId
		lcontroller.taskparam.ugc_compareType = compareType
		itemId = lBTService:ResidToId(itemId)
		lcontroller.taskparam.ugc_itemId = itemId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local data2 = {
				valtype = "enum",
				val = compareType
			}
			local data3 = {
				valtype = "itemtype",
				val = {
					itemid = itemId
				}
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		return true
	end,
	onbeg = function ()
	end,
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		local itemId = AIFunctionMgr:GetHoldItemId(targetActor)
		local compRet = false

		if controller.taskparam.ugc_compareType then
			compRet = itemId == controller.taskparam.ugc_itemId
		else
			compRet = itemId ~= controller.taskparam.ugc_itemId
		end

		if compRet then
			return controller.success()
		else
			return controller.fail()
		end
	end,
	onend = function ()
	end
}
