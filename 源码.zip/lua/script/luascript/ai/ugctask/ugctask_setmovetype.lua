return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local movetype = controller.taskparam.movetype

		if not objid or not movetype then
			return controller.fail()
		end

		local obj = controller.target.get()
		local actor = AIFunctionMgr:getActorByObjId(obj, objid)

		if actor then
			local move = 0

			if movetype == "Climbing" then
				move = 4
			elseif movetype == "Fly" then
				move = 1
			elseif movetype == "Swing" then
				move = 2
			elseif movetype == "Walk_Swim" then
				move = 5
			end

			local ret = true

			if move == 5 then
				AIFunctionMgr:SetMoveAbility(actor, 2, true)
				AIFunctionMgr:SetMoveAbility(actor, 0, true)

				ret = AIFunctionMgr:SetMovementModeOrAuto(actor, 128)
			else
				ret = AIFunctionMgr:SetLocoMotionType(actor, move, true)
			end

			if ret then
				return controller.success()
			end
		end

		return controller.fail()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local objid = result[1]
		local movetype = result[2]
		local isOpen = result[3]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.movetype = movetype

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				valtype = "enum"
			}
			local send_data = {
				data1,
				data2
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
