return {
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local num = result[1]
		local item = result[2]
		local range = result[3]
		lcontroller.taskparam.num = num
		lcontroller.taskparam.item = item
		lcontroller.taskparam.range = range
		lcontroller.taskparam.distance = distance

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = num
			}
			local data2 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}
			local data3 = {
				valtype = "val",
				val = range
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return false
		end

		local num = controller.taskparam.num or 0
		local item = controller.taskparam.item or 0
		local distance = controller.taskparam.range or 1

		if distance == nil then
			return false
		end

		local ret, movex, movey, movez, x, y, z = AIFunctionMgr:GetNearestItemFeedTrough(selfActor, distance, item, 0, 0, 0, 0, 0, 0)

		if not ret then
			return false
		end

		controller.taskparam.targetPos = {
			x = movex,
			y = movey,
			z = movez
		}
		controller.taskparam.addItemPos = {
			x = x,
			y = y,
			z = z
		}
		local path_range = btget_path_range()
		local dis_min = 10
		local dis_max = selfActor:getViewDist()
		local attack_dis = math.clamp(1 * BLOCK_SIZE, dis_min, dis_max)
		controller.taskparam.attackDis = attack_dis
		local t_pos = controller.taskparam.targetPos

		if math.pow(attack_dis, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			local path_range = btget_path_range()
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, path_range)

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.targetPos = nil

			return true
		end
	end,
	onbeg = function ()
		if controller.taskparam.targetPos then
			local selfActor = controller.target.get()
			local path_range = btget_path_range()

			if selfActor and controller.taskparam.path then
				selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, 1, path_range)

				controller.taskparam.path = nil
			end
		end
	end,
	run = function ()
		local selfActor = controller.target.get()
		local attack_dis = controller.taskparam.attackDis

		if controller.taskparam.targetPos then
			local t_pos = controller.taskparam.targetPos
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) <= math.pow(attack_dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		local addItemPos = controller.taskparam.addItemPos
		local num = controller.taskparam.num
		local item = controller.taskparam.item

		if not num or not item or not addItemPos then
			return controller.fail()
		end

		local ret = AIFunctionMgr:AddFeedToFeeder(selfActor, item, num, addItemPos.x, addItemPos.y, addItemPos.z)

		if ret then
			return controller.success()
		end

		return controller.fail()
	end,
	onwait = function ()
		local selfActor = controller.target.get()

		if controller.taskparam.targetPos then
			local addItemPos = controller.taskparam.addItemPos
			local t_pos = controller.taskparam.targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) and selfActor:getNavigator():noPath() then
				local path_range = btget_path_range()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, path_range) then
					controller.taskparam.targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}

					return true
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		local selfActor = controller.target.get()

		selfActor:getNavigator():clearPathEntity()

		controller.taskparam.targetPos = nil
		controller.taskparam.addItemPos = nil
		controller.taskparam.attackDis = nil
	end
}
