local TEST_TEST_TEST = false

return {
	send_debug_data = function ()
		local lcontroller = controller
		local targetObjId = nil

		if TEST_TEST_TEST then
			targetObjId = 0
		else
			local lBTService = BTService
			local result = nil

			if lBTService:IsSubparamReuseEnabled() then
				result = lBTService:GetSubparamOutputBuffer(lcontroller)

				lBTService:GetSubparamInto(lcontroller, 1, result)
			else
				result = btget_subparam(lcontroller, {
					1
				})
			end

			targetObjId = result[1]
		end

		lcontroller.taskparam.ugc_targetObjId = targetObjId

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = targetObjId or 0
				}
			}
			local send_data = {
				data1
			}

			lcontroller.sendValToDebug(send_data)
		end
	end,
	will = function ()
		local selfActor = controller.target.get("living")

		if not selfActor or not selfActor:alive() then
			return false
		end

		local slefobjid = selfActor:getObjId()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		controller.taskparam.cache_targetActor = targetActor

		if ActorComponentCallModule(selfActor, "RiddenComponent", "isRidden") or ActorComponentCallModule(targetActor, "RiddenComponent", "isRidden") then
			return true
		end

		if ActorComponentCallModule(targetActor, "RiddenComponent", "isRiding") or ActorComponentCallModule(selfActor, "RiddenComponent", "isRiding") then
			return false
		end

		controller.taskparam.cache_distance = selfActor:getLocoMotion().m_BoundSize + targetActor:getLocoMotion().m_BoundSize + BLOCK_SIZE * 0.2
		local t_pos = targetActor:getPosition()

		if math.pow(controller.taskparam.cache_distance, 2) < Pos3SquareDistToPos3(selfActor:getPosition(), t_pos) then
			controller.taskparam.cache_targetPos = {
				x = t_pos.x,
				y = t_pos.y,
				z = t_pos.z
			}
			controller.taskparam.path = selfActor:getNavigator():newCanMoveTo(t_pos.x, t_pos.y, t_pos.z, btget_path_range())

			if controller.taskparam.path then
				return true
			else
				return false
			end
		else
			controller.taskparam.cache_targetPos = nil
			controller.taskparam.path = nil

			return true
		end
	end,
	onbeg = function ()
		local selfActor = controller.target.get("living")
		local targetActor = controller.taskparam.cache_targetActor

		if controller.taskparam.path then
			selfActor:getNavigator():newTryMoveTo(controller.taskparam.path, 1, btget_path_range())

			controller.taskparam.path = nil

			selfActor:keepLookAt(targetActor, 10, 10)
		end
	end,
	run = function ()
		local selfActor = controller.target.get("living")
		local targetActor = controller.taskparam.cache_targetActor

		if ActorComponentCallModule(selfActor, "RiddenComponent", "isRidden") then
			return controller.success()
		end

		if controller.taskparam.cache_targetPos then
			local dis = controller.taskparam.cache_distance
			local checkTag = Pos3SquareDistToPos3(selfActor:getPosition(), controller.taskparam.cache_targetPos) <= math.pow(dis, 2) or selfActor:getNavigator():noPath()

			if not checkTag then
				controller.wait_until(function ()
					return Pos3SquareDistToPos3(selfActor:getPosition(), controller.taskparam.cache_targetPos) <= math.pow(dis, 2) or selfActor:getNavigator():noPath()
				end)
				selfActor:getNavigator():clearPathEntity()
			end
		end

		targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		if ActorComponentCallModule(selfActor, "RiddenComponent", "isRidden") or ActorComponentCallModule(targetActor, "RiddenComponent", "isRidden") then
			return controller.success()
		end

		if ActorComponentCallModule(targetActor, "RiddenComponent", "isRiding") or ActorComponentCallModule(selfActor, "RiddenComponent", "isRiding") then
			return controller.fail()
		end

		targetActor:mountActor_mob(selfActor)
		AIFunctionMgr:setFlagBit(selfActor, ACTORFLAG_AI_HOLD, true)

		return controller.success()
	end,
	onwait = function ()
		local selfActor = controller.target.get("living")
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, controller.taskparam.ugc_targetObjId)

		if not targetActor or not targetActor:alive() then
			return false
		end

		selfActor:keepLookAt(targetActor, 10, 10)

		if controller.taskparam.cache_targetPos then
			local t_pos = controller.taskparam.cache_targetPos

			if math.pow(BLOCK_SIZE, 2) < Pos3SquareDistToPos3(targetActor:getPosition(), t_pos) then
				t_pos = targetActor:getPosition()

				if selfActor:getNavigator():tryMoveTo(t_pos.x, t_pos.y, t_pos.z, 1, btget_path_range()) then
					controller.taskparam.cache_targetPos = {
						x = t_pos.x,
						y = t_pos.y,
						z = t_pos.z
					}
				else
					return false
				end
			end
		end

		return true
	end,
	onend = function ()
		controller.taskparam.cache_targetActor = nil
		controller.taskparam.cache_targetPos = nil
		controller.taskparam.cache_distance = nil
	end
}
