return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 1, result)
		else
			result = btget_subparam(lcontroller, {
				1
			})
		end

		local msginfo = result[1]
		lcontroller.taskparam.msginfo = msginfo

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "val",
				val = msginfo
			}

			lcontroller.sendValToDebug({
				data1
			})
		end
	end,
	run = function ()
		if not controller.taskparam.msginfo then
			return controller.fail()
		end

		local selfobj = controller.target.get()

		if not selfobj or not selfobj:alive() then
			return controller.fail()
		end

		if AIFunctionMgr:SendToAi(selfobj, controller.taskparam.msginfo) then
			return controller.success()
		end

		return controller.fail()
	end
}
