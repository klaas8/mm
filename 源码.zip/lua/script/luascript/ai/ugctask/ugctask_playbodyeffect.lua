return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	run = function ()
		local objid = controller.taskparam.objid
		local actid = controller.taskparam.actid

		if not objid or not actid then
			return controller.fail()
		end

		local selfActor = controller.target.get()
		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, objid)

		if not targetActor or not targetActor:alive() then
			return controller.fail()
		end

		if targetActor and targetActor.playActForTrigger and targetActor:playActForTrigger(actid) then
			return controller.success()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local param_keys = {
			"objid",
			"actid"
		}
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 2, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2
			})
		end

		local objid = result[1]
		local actid = result[2]
		lcontroller.taskparam.objid = objid
		lcontroller.taskparam.actid = actid

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = objid or 0
				}
			}
			local data2 = {
				actid,
				valtype = "def"
			}

			lcontroller.sendValToDebug({
				data1,
				data2
			})
		end
	end
}
