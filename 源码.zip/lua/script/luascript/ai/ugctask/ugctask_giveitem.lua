return {
	run = function ()
		local selfActor = controller.target.get()

		if not selfActor or not selfActor:alive() then
			return controller.fail()
		end

		controller.taskparam.needErrInfo = AIFunctionMgr:NeedErrInfo(selfActor)
		local toObjId = controller.taskparam.toObjId
		local num = controller.taskparam.num
		local item = controller.taskparam.item
		local isCreate = controller.taskparam.isCreate

		if type(item) == "string" then
			item = Service.Mod:GetCfgIdByAssetId(item)
		end

		if not CheckItemScriptUse(item) then
			return controller.fail()
		end

		if toObjId == nil or num == nil or item == nil or isCreate == nil then
			if controller.taskparam.needErrInfo then
				local errinfo = {}

				if toObjId == nil then
					errinfo.info = "toObjIdnil"
				elseif num == nil then
					errinfo.info = "numnil"
				elseif item == nil then
					errinfo.info = "itemnil"
				elseif isCreate == nil then
					errinfo.info = "isCreatenil"
				end

				controller.sendMsgToAi(selfActor, "UGCTask_GiveItem", errinfo)
			end

			return controller.fail()
		end

		local targetActor = AIFunctionMgr:getActorByObjId(selfActor, toObjId)

		if not targetActor or not targetActor:alive() then
			if controller.taskparam.needErrInfo then
				local errinfo = {
					info = "noTarget",
					toobjid = toObjId
				}

				controller.sendMsgToAi(selfActor, "UGCTask_GiveItem", errinfo)
			end

			return controller.fail()
		end

		AIFunctionMgr:rotateBodyToActor(selfActor, targetActor)

		local ret, errinfo = AIFunctionMgr:GiveActorItem(selfActor, toObjId, item, num, isCreate, "")

		if controller.taskparam.needErrInfo then
			controller.sendMsgToAi(selfActor, "UGCTask_GiveItem", errinfo)
		end

		if not ret then
			return controller.fail()
		end

		return controller.success()
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 4, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3,
				4
			})
		end

		local toObjId = result[1]
		local num = result[2]
		local item = result[3]
		local isCreate = result[4]

		if type(isCreate) == "string" then
			if isCreate == "==" then
				isCreate = true
			else
				isCreate = false
			end
		end

		lcontroller.taskparam.toObjId = toObjId
		lcontroller.taskparam.num = num
		lcontroller.taskparam.item = item
		lcontroller.taskparam.isCreate = isCreate

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "actor",
				val = {
					actor = toObjId or 0
				}
			}
			local data2 = {
				valtype = "val",
				val = num
			}
			local data3 = {
				valtype = "item",
				val = {
					itemid = item or 0,
					num = num or 0
				}
			}
			local data4 = {
				valtype = "getName"
			}

			lcontroller.sendValToDebug({
				data1,
				data2,
				data3,
				data4
			})
		end
	end
}
