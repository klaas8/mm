return {
	onbeg = function ()
	end,
	onend = function ()
	end,
	decorator = function ()
		return controller.success()
	end,
	onwait = function ()
		if not controller.taskparam.playskil then
			local actor = controller.target.get()

			if not actor or actor:isDead() or actor:needClear() then
				return false
			end

			if actor and actor:getNavigator():noPath() then
				local id = controller.taskparam.id
				local pos = controller.taskparam.pos
				local x, y, z = BlockBottomCoord(pos.x, pos.y, pos.z)
				local targetPos = WCoord:new_local()
				targetPos.x = x
				targetPos.y = y
				targetPos.z = z

				if controller.taskparam.isrote then
					AIFunctionMgr:ActorRotatePos(actor, targetPos)
				end

				local ret = true

				if not AIFunctionMgr:SkillIsPlaying(actor, id) then
					ret = AIFunctionMgr:PlaySkillByPos(actor, id, targetPos)
				end

				controller.taskparam.playskil = true

				if ret then
					return true
				else
					return false
				end
			end
		end

		return true
	end,
	run = function ()
		local pos = controller.taskparam.pos
		local x, y, z = BlockBottomCoord(pos.x, pos.y, pos.z)
		local targetPos = WCoord:new_local()
		targetPos.x = x
		targetPos.y = y
		targetPos.z = z
		local id = controller.taskparam.id

		if not pos or pos.x == 0 and pos.y == 0 and pos.z == 0 or not id or string.len(id) <= 0 then
			return controller.fail()
		end

		local obj = controller.target.get()
		local ret = AIFunctionMgr:CheckPosAndSkillDist(obj, id, targetPos)

		if ret then
			if controller.taskparam.isrote then
				AIFunctionMgr:ActorRotatePos(obj, targetPos)
			end

			local ret = true

			if not AIFunctionMgr:SkillIsPlaying(obj, id) then
				ret = AIFunctionMgr:PlaySkillByPos(obj, id, targetPos)
			end

			if ret then
				controller.taskparam.playskil = true

				controller.wait_until(function ()
					local tobj = controller.target.get()

					if tobj:isDead() or tobj:needClear() then
						return true
					end

					local id = controller.taskparam.id
					local isplaying = AIFunctionMgr:SkillIsPlaying(tobj, id)

					return not isplaying
				end)

				return controller.success()
			end

			return controller.fail()
		else
			local path_range = btget_path_range()
			local path = obj:getNavigator():newCanMoveTo(x, y, z, path_range)

			if path then
				controller.taskparam.playskil = false

				obj:getNavigator():newTryMoveTo(path, 1, path_range)
				controller.wait_until(function ()
					return controller.taskparam.playskil
				end)

				if controller.taskparam.playskil then
					controller.wait_until(function ()
						local tobj = controller.target.get()

						if tobj:isDead() or tobj:needClear() then
							return true
						end

						local id = controller.taskparam.id
						local isplaying = AIFunctionMgr:SkillIsPlaying(tobj, id)

						return not isplaying
					end)

					return controller.success()
				end
			else
				return controller.fail()
			end
		end
	end,
	onend = function ()
		local obj = controller.target.get()
		local id = controller.taskparam.id

		if obj and id then
			AIFunctionMgr:StopSkill(obj, id)
		end

		controller.taskparam.playskil = false
	end,
	send_debug_data = function ()
		local lcontroller = controller
		local lBTService = BTService
		local result = nil

		if lBTService:IsSubparamReuseEnabled() then
			result = lBTService:GetSubparamOutputBuffer(lcontroller)

			lBTService:GetSubparamInto(lcontroller, 3, result)
		else
			result = btget_subparam(lcontroller, {
				1,
				2,
				3
			})
		end

		local pos = result[1]
		local id = result[2]
		local isrote = result[3]
		lcontroller.taskparam.pos = pos
		lcontroller.taskparam.id = id
		lcontroller.taskparam.isrote = isrote == nil and true or isrote == "true" and true or false

		if lcontroller:isNeedSendDebug() then
			local data1 = {
				valtype = "pos",
				val = pos
			}
			local data2 = {
				valtype = "val",
				val = id
			}
			local data3 = {
				valtype = "val",
				val = lcontroller.taskparam.isrote
			}
			local send_data = {
				data1,
				data2,
				data3
			}

			lcontroller.sendValToDebug(send_data)
		end
	end
}
