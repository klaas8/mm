local BTGetValueManage = ClassEx("BTGetValueManage")
local instance = nil

function BTGetValueManage:GetInst()
	if not instance then
		instance = ClassList.BTGetValueManage.instance()
	end

	return instance
end

function BTGetValueManage:Init()
	self.IdToFun = {}
	self.funid = {}
end

function BTGetValueManage:Regfun(treeID, fun)
	if not self.IdToFun[treeID] then
		self.IdToFun[treeID] = {}
		self.funid[treeID] = 0
	end

	self.funid[treeID] = self.funid[treeID] + 1
	local newId = self.funid[treeID]
	self.IdToFun[treeID][newId] = fun

	return newId
end

function BTGetValueManage:GetFun(treeID, funid)
	local treeFuns = self.IdToFun[treeID]

	if not treeFuns then
		return nil
	end

	return treeFuns[funid]
end

local function createWrapperFunc(fieldName)
	return function (val)
		if type(val) == "table" and val[fieldName] then
			return val
		end

		return {
			[fieldName] = val
		}
	end
end

local function valfun(val)
	return val
end

local objfun = createWrapperFunc("actor")
local itemfun = createWrapperFunc("itemid")
local playerfun = createWrapperFunc("uin")
local areafun = createWrapperFunc("areaid")
local actortypefun = createWrapperFunc("actorid")
local blocktypefun = createWrapperFunc("blockid")
local itemtypefun = createWrapperFunc("itemid")
local effecttypefun = createWrapperFunc("effectid")
local timerfun = createWrapperFunc("timerid")
local typetofun = {
	[AIDefine.ValueType.String] = valfun,
	[AIDefine.ValueType.Number] = valfun,
	[AIDefine.ValueType.Boolean] = valfun,
	[AIDefine.ValueType.Vector3] = valfun,
	[AIDefine.ValueType.Object] = objfun,
	[AIDefine.ValueType.Item] = itemfun,
	[AIDefine.ValueType.Player] = playerfun,
	[AIDefine.ValueType.Area] = areafun,
	[AIDefine.ValueType.ActorType] = actortypefun,
	[AIDefine.ValueType.BlockType] = blocktypefun,
	[AIDefine.ValueType.ItemType] = itemtypefun,
	[AIDefine.ValueType.EffectType] = effecttypefun,
	[AIDefine.ValueType.Timer] = timerfun
}

function BTGetValueManage:DealReesul(valtype, result)
	local fun = typetofun[valtype]

	if fun then
		return fun(result)
	end

	return result
end

function BTGetValueManage:ReleaseFun(treeID)
	self.IdToFun[treeID] = nil
	self.funid[treeID] = nil
end
