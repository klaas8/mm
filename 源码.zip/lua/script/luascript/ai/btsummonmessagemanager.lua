local BTSummonMessageManager = ClassEx("BTSummonMessageManager")
local instance = nil
local MAX_PENDING_EVENTS = 512
local DISPATCH_PER_TICK = 16
local EMPTY_SEND_THROTTLE_SEC = 0.5
local WORLD_TICK_PER_SEC = 20

function BTSummonMessageManager:GetInst()
	if instance == nil then
		instance = ClassList.BTSummonMessageManager.instance()
	end

	return instance
end

function BTSummonMessageManager:GetInstIfExists()
	return instance
end

function BTSummonMessageManager:ReleaseInst()
	local oldInstance = instance
	instance = nil

	if oldInstance then
		oldInstance:Clear()

		if oldInstance.delete then
			oldInstance:delete()
		end
	end
end

function BTSummonMessageManager:Init()
	self:Clear()
end

function BTSummonMessageManager:Clear()
	self.sendCooldown = {}
	self.targetSendCooldown = {}
	self.emptySendThrottle = {}
	self.receiveCooldown = {}
	self.receiverEvents = {}
	self.msgReceivers = {}
	self.treeReceivers = {}
	self.pendingReceivers = {}
	self.dynamicReceivers = {}
	self.pendingEvents = {}
	self.dispatching = false
end

local function IsActorValid(actor)
	if not actor then
		return false
	end

	if actor.alive and not actor:alive() then
		return false
	end

	if actor.isDead and actor:isDead() then
		return false
	end

	if actor.needClear and actor:needClear() then
		return false
	end

	return true
end

local function GetNowSec()
	if WorldMgr and WorldMgr.getWorldTime then
		return WorldMgr:getWorldTime() / WORLD_TICK_PER_SEC
	end

	if type(g_curtime) == "number" then
		return g_curtime
	end

	return os.time()
end

local function GetObjId(actor)
	if actor and actor.getObjId then
		return actor:getObjId()
	end

	return nil
end

local function GetActorByObjId(anchorActor, objId)
	if not anchorActor or not objId or objId <= 0 then
		return nil
	end

	if AIFunctionMgr and AIFunctionMgr.getActorByObjId then
		return AIFunctionMgr:getActorByObjId(anchorActor, objId)
	end

	if anchorActor.getActorMgr then
		local actorMgr = anchorActor:getActorMgr()

		if actorMgr and actorMgr.findActorByWID then
			return actorMgr:findActorByWID(objId)
		end
	end

	return nil
end

local function IsInRange(senderActor, receiverActor, rangeBlock)
	local senderPos = senderActor and senderActor.getPosition and senderActor:getPosition()
	local receiverPos = receiverActor and receiverActor.getPosition and receiverActor:getPosition()

	if not senderPos or not receiverPos then
		return false
	end

	local rangeWorld = rangeBlock * BLOCK_SIZE
	local dx = senderPos.x - receiverPos.x
	local dy = senderPos.y - receiverPos.y
	local dz = senderPos.z - receiverPos.z

	return dx * dx + dy * dy + dz * dz <= rangeWorld * rangeWorld
end

local function IsCooldownReady(cooldownTable, objId, msgId, nowSec, cooldownSec)
	if cooldownSec <= 0 then
		return true
	end

	local objCooldown = cooldownTable[objId]
	local lastTime = objCooldown and objCooldown[msgId]

	return not lastTime or cooldownSec <= nowSec - lastTime
end

local function SetCooldown(cooldownTable, objId, msgId, nowSec)
	cooldownTable[objId] = cooldownTable[objId] or {}
	cooldownTable[objId][msgId] = nowSec
end

local function ClearEmptySendThrottleForMsg(self, msgId)
	msgId = tonumber(msgId)

	if not msgId or not self.emptySendThrottle then
		return
	end

	local emptySenderIds = {}

	for senderObjId, objCooldown in pairs(self.emptySendThrottle) do
		if objCooldown[msgId] then
			objCooldown[msgId] = nil

			if not next(objCooldown) then
				table.insert(emptySenderIds, senderObjId)
			end
		end
	end

	for i = 1, #emptySenderIds do
		self.emptySendThrottle[emptySenderIds[i]] = nil
	end
end

local function IsTargetCooldownReady(cooldownTable, senderObjId, targetObjId, msgId, nowSec, cooldownSec)
	if cooldownSec <= 0 then
		return true
	end

	local senderCooldown = cooldownTable[senderObjId]
	local targetCooldown = senderCooldown and senderCooldown[targetObjId]
	local lastTime = targetCooldown and targetCooldown[msgId]

	return not lastTime or cooldownSec <= nowSec - lastTime
end

local function SetTargetCooldown(cooldownTable, senderObjId, targetObjId, msgId, nowSec)
	cooldownTable[senderObjId] = cooldownTable[senderObjId] or {}
	cooldownTable[senderObjId][targetObjId] = cooldownTable[senderObjId][targetObjId] or {}
	cooldownTable[senderObjId][targetObjId][msgId] = nowSec
end

local function ClearTargetCooldownByActor(self, actorObjId)
	if not self.targetSendCooldown then
		return
	end

	self.targetSendCooldown[actorObjId] = nil
	local emptySenderIds = {}

	for senderObjId, targetMap in pairs(self.targetSendCooldown) do
		targetMap[actorObjId] = nil

		if not next(targetMap) then
			table.insert(emptySenderIds, senderObjId)
		end
	end

	for i = 1, #emptySenderIds do
		self.targetSendCooldown[emptySenderIds[i]] = nil
	end
end

local function ResolveEmptySendThrottleSec(sendCooldownSec)
	return math.max(EMPTY_SEND_THROTTLE_SEC, tonumber(sendCooldownSec) or 0)
end

local function CopyEventParam(eventParam, copiedTables)
	if type(eventParam) ~= "table" then
		return eventParam
	end

	copiedTables = copiedTables or {}

	if copiedTables[eventParam] then
		return copiedTables[eventParam]
	end

	local copy = {}
	copiedTables[eventParam] = copy

	for key, value in pairs(eventParam) do
		copy[CopyEventParam(key, copiedTables)] = CopyEventParam(value, copiedTables)
	end

	return copy
end

local function TraceError(errorInfo)
	if debug and debug.traceback then
		return debug.traceback(tostring(errorInfo))
	end

	return tostring(errorInfo)
end

local function LogDispatchError(errorInfo)
	local message = "[BTSummonMessageManager] dispatch failed: " .. tostring(errorInfo)

	if MiniLog then
		MiniLog(message)
	elseif print then
		print(message)
	end
end

local function ClearReceiverEventsIfEmpty(self, receiverObjId)
	local receiverMap = self.receiverEvents[receiverObjId]

	if receiverMap and not next(receiverMap) then
		self.receiverEvents[receiverObjId] = nil
	end
end

local function GetSummonMsgIdParamValue(param)
	local btreeParamType = AIDefine and AIDefine.BtreeParamType

	if type(param) == "table" and btreeParamType and param.paramtype == btreeParamType.Val then
		return param.val
	end

	if type(param) == "table" then
		return param.val
	end

	return param
end

local function IsSummonMsgIdDynamic(param)
	if type(param) == "string" then
		return true
	end

	if type(param) ~= "table" then
		return false
	end

	if param.bb then
		return true
	end

	local btreeParamType = AIDefine and AIDefine.BtreeParamType

	return btreeParamType and param.paramtype == btreeParamType.GetValueFun
end

local function RemoveIndexedReceiver(self, receiverObjId, msgId, treeId, nodeId)
	local msgEvents = self.receiverEvents[receiverObjId] and self.receiverEvents[receiverObjId][msgId]

	if msgEvents then
		for i = #msgEvents, 1, -1 do
			local eventInfo = msgEvents[i]

			if eventInfo.treeId == treeId and eventInfo.nodeId == nodeId then
				table.remove(msgEvents, i)
			end
		end

		if #msgEvents == 0 then
			self.receiverEvents[receiverObjId][msgId] = nil

			if self.msgReceivers[msgId] then
				self.msgReceivers[msgId][receiverObjId] = nil

				if not next(self.msgReceivers[msgId]) then
					self.msgReceivers[msgId] = nil
				end
			end

			ClearReceiverEventsIfEmpty(self, receiverObjId)
		end
	end
end

local function RemoveTreeReceiverIndex(self, receiverObjId, treeId, nodeId)
	local treeList = self.treeReceivers[treeId]

	if not treeList then
		return
	end

	for i = #treeList, 1, -1 do
		local info = treeList[i]

		if info.receiverObjId == receiverObjId and info.nodeId == nodeId then
			table.remove(treeList, i)
		end
	end

	if #treeList == 0 then
		self.treeReceivers[treeId] = nil
	end
end

local function AddIndexedReceiver(self, receiverObjId, msgId, nodeId, treeId, node)
	self.receiverEvents[receiverObjId] = self.receiverEvents[receiverObjId] or {}
	self.receiverEvents[receiverObjId][msgId] = self.receiverEvents[receiverObjId][msgId] or {}

	table.insert(self.receiverEvents[receiverObjId][msgId], {
		nodeId = nodeId,
		treeId = treeId,
		node = node
	})

	self.msgReceivers[msgId] = self.msgReceivers[msgId] or {}
	self.msgReceivers[msgId][receiverObjId] = true
	self.treeReceivers[treeId] = self.treeReceivers[treeId] or {}

	table.insert(self.treeReceivers[treeId], {
		receiverObjId = receiverObjId,
		msgId = msgId,
		nodeId = nodeId
	})
	ClearEmptySendThrottleForMsg(self, msgId)
end

local function RemoveIndexedReceiverForNode(self, receiverObjId, msgId, treeId, nodeId)
	RemoveIndexedReceiver(self, receiverObjId, msgId, treeId, nodeId)
	RemoveTreeReceiverIndex(self, receiverObjId, treeId, nodeId)
end

local function RemoveIndexedReceiverForTreeNode(self, treeId, nodeId)
	local treeList = self.treeReceivers[treeId]

	if not treeList then
		return
	end

	local entries = {}

	for i = 1, #treeList do
		local info = treeList[i]

		if info.nodeId == nodeId then
			table.insert(entries, {
				receiverObjId = info.receiverObjId,
				msgId = info.msgId
			})
		end
	end

	for i = 1, #entries do
		RemoveIndexedReceiverForNode(self, entries[i].receiverObjId, entries[i].msgId, treeId, nodeId)
	end
end

local function RemoveDynamicReceiver(self, treeId, nodeId)
	local dynamicTree = self.dynamicReceivers and self.dynamicReceivers[treeId]

	if not dynamicTree then
		return
	end

	local info = dynamicTree[nodeId]

	if info and info.lastReceiverObjId and info.lastMsgId then
		RemoveIndexedReceiverForNode(self, info.lastReceiverObjId, info.lastMsgId, treeId, nodeId)
	end

	dynamicTree[nodeId] = nil

	if not next(dynamicTree) then
		self.dynamicReceivers[treeId] = nil
	end
end

local function ClearReceiverRegistrationForTreeNode(self, treeId, nodeId)
	self:UnregisterPendingNode(treeId, nodeId)
	RemoveIndexedReceiverForTreeNode(self, treeId, nodeId)
	RemoveDynamicReceiver(self, treeId, nodeId)
end

function BTSummonMessageManager:UnregisterNode(receiverObjId, treeId, nodeId)
	if not receiverObjId or not treeId or not nodeId then
		return
	end

	local receiverMap = self.receiverEvents[receiverObjId]

	if receiverMap then
		local msgIds = {}

		for msgId in pairs(receiverMap) do
			table.insert(msgIds, msgId)
		end

		for i = 1, #msgIds do
			local msgId = msgIds[i]

			RemoveIndexedReceiver(self, receiverObjId, msgId, treeId, nodeId)
		end
	end

	local treeList = self.treeReceivers[treeId]

	if treeList then
		for i = #treeList, 1, -1 do
			local info = treeList[i]

			if info.receiverObjId == receiverObjId and info.nodeId == nodeId then
				table.remove(treeList, i)
			end
		end

		if #treeList == 0 then
			self.treeReceivers[treeId] = nil
		end
	end

	RemoveDynamicReceiver(self, treeId, nodeId)
end

function BTSummonMessageManager:RegisterReceiver(receiverObjId, msgId, nodeId, treeId, node)
	receiverObjId = tonumber(receiverObjId)
	msgId = tonumber(msgId)
	nodeId = tonumber(nodeId)

	if not receiverObjId or receiverObjId <= 0 or not msgId or msgId <= 0 or not nodeId or not treeId or not node then
		return false
	end

	self:UnregisterNode(receiverObjId, treeId, nodeId)
	AddIndexedReceiver(self, receiverObjId, msgId, nodeId, treeId, node)

	return true
end

function BTSummonMessageManager:UnregisterPendingNode(treeId, nodeId)
	if not treeId or not nodeId then
		return
	end

	local pendingList = self.pendingReceivers and self.pendingReceivers[treeId]

	if not pendingList then
		return
	end

	for i = #pendingList, 1, -1 do
		if pendingList[i].nodeId == nodeId then
			table.remove(pendingList, i)
		end
	end

	if #pendingList == 0 then
		self.pendingReceivers[treeId] = nil
	end
end

function BTSummonMessageManager:RegisterPendingReceiver(msgId, nodeId, treeId, node, objIdResolver)
	msgId = tonumber(msgId)
	nodeId = tonumber(nodeId)

	if not msgId or msgId <= 0 or not nodeId or not treeId or not node or type(objIdResolver) ~= "function" then
		return false
	end

	self.pendingReceivers = self.pendingReceivers or {}

	self:UnregisterPendingNode(treeId, nodeId)

	self.pendingReceivers[treeId] = self.pendingReceivers[treeId] or {}

	table.insert(self.pendingReceivers[treeId], {
		msgId = msgId,
		nodeId = nodeId,
		treeId = treeId,
		node = node,
		objIdResolver = objIdResolver
	})

	return true
end

function BTSummonMessageManager:RegisterSummonMessageReceiver(treeId, nodeId, node, msgIdParam, objIdResolver)
	nodeId = tonumber(nodeId)

	if not treeId or not nodeId or not node or type(objIdResolver) ~= "function" then
		return false
	end

	if IsSummonMsgIdDynamic(msgIdParam) then
		return self:RegisterDynamicReceiver(treeId, nodeId, node, msgIdParam, objIdResolver)
	end

	ClearReceiverRegistrationForTreeNode(self, treeId, nodeId)

	local msgId = self:ResolveSummonMsgIdParam(treeId, msgIdParam)

	if not msgId or msgId <= 0 then
		return false
	end

	local ok, receiverObjId = pcall(objIdResolver)
	receiverObjId = ok and tonumber(receiverObjId) or nil

	if receiverObjId and receiverObjId > 0 then
		return self:RegisterReceiver(receiverObjId, msgId, nodeId, treeId, node)
	end

	return self:RegisterPendingReceiver(msgId, nodeId, treeId, node, objIdResolver)
end

function BTSummonMessageManager:RegisterDynamicReceiver(treeId, nodeId, node, msgIdParam, objIdResolver)
	nodeId = tonumber(nodeId)

	if not treeId or not nodeId or not node or type(objIdResolver) ~= "function" then
		return false
	end

	ClearReceiverRegistrationForTreeNode(self, treeId, nodeId)

	self.dynamicReceivers[treeId] = self.dynamicReceivers[treeId] or {}
	self.dynamicReceivers[treeId][nodeId] = {
		treeId = treeId,
		nodeId = nodeId,
		node = node,
		msgIdParam = msgIdParam,
		objIdResolver = objIdResolver
	}

	return true
end

function BTSummonMessageManager:ResolveSummonMsgIdParam(treeId, msgIdParam)
	local paramType = type(msgIdParam)

	if (paramType == "table" or paramType == "string") and BTExecGetController and btget_param_value then
		local btManager = _G and _G.BTManager
		local btree = btManager and btManager:GetInstance(treeId)

		if btree then
			local okController, controller = pcall(BTExecGetController, btree, treeId)
			controller = okController and controller or nil

			if controller then
				local ok, value = pcall(btget_param_value, controller, msgIdParam)

				if ok then
					local msgId = tonumber(value)

					if msgId then
						return msgId
					end
				end
			end
		end
	end

	return tonumber(GetSummonMsgIdParamValue(msgIdParam))
end

function BTSummonMessageManager:ResolveDynamicMsgId(info)
	if not info then
		return nil
	end

	return self:ResolveSummonMsgIdParam(info.treeId, info.msgIdParam)
end

function BTSummonMessageManager:RefreshDynamicReceiver(info)
	if not info then
		return false
	end

	local ok, receiverObjId = pcall(info.objIdResolver)
	receiverObjId = ok and tonumber(receiverObjId) or nil
	local msgId = self:ResolveDynamicMsgId(info)

	if not receiverObjId or receiverObjId <= 0 or not msgId or msgId <= 0 then
		if info.lastReceiverObjId and info.lastMsgId then
			RemoveIndexedReceiverForNode(self, info.lastReceiverObjId, info.lastMsgId, info.treeId, info.nodeId)
		end

		info.lastReceiverObjId = nil
		info.lastMsgId = nil

		return false
	end

	if info.lastReceiverObjId == receiverObjId and info.lastMsgId == msgId then
		return true
	end

	if info.lastReceiverObjId and info.lastMsgId then
		RemoveIndexedReceiverForNode(self, info.lastReceiverObjId, info.lastMsgId, info.treeId, info.nodeId)
	end

	AddIndexedReceiver(self, receiverObjId, msgId, info.nodeId, info.treeId, info.node)

	info.lastReceiverObjId = receiverObjId
	info.lastMsgId = msgId

	return true
end

function BTSummonMessageManager:RefreshDynamicReceiversForSend()
	if not self.dynamicReceivers then
		return
	end

	local infos = {}

	for _, treeReceivers in pairs(self.dynamicReceivers) do
		for _, info in pairs(treeReceivers) do
			table.insert(infos, info)
		end
	end

	for i = 1, #infos do
		local info = infos[i]
		local treeReceivers = self.dynamicReceivers[info.treeId]

		if treeReceivers and treeReceivers[info.nodeId] == info then
			self:RefreshDynamicReceiver(info)
		end
	end
end

function BTSummonMessageManager:ResolvePendingReceivers()
	if not self.pendingReceivers then
		return
	end

	local emptyTreeIds = {}

	for treeId, pendingList in pairs(self.pendingReceivers) do
		for i = #pendingList, 1, -1 do
			local pendingInfo = pendingList[i]
			local ok, receiverObjId = pcall(pendingInfo.objIdResolver)

			if not ok then
				table.remove(pendingList, i)

				receiverObjId = nil
			else
				receiverObjId = tonumber(receiverObjId)
			end

			if receiverObjId and receiverObjId > 0 and self:RegisterReceiver(receiverObjId, pendingInfo.msgId, pendingInfo.nodeId, pendingInfo.treeId, pendingInfo.node) then
				table.remove(pendingList, i)
			end
		end

		if #pendingList == 0 then
			table.insert(emptyTreeIds, treeId)
		end
	end

	for i = 1, #emptyTreeIds do
		self.pendingReceivers[emptyTreeIds[i]] = nil
	end
end

local function BuildEventSnapshot(events)
	local snapshot = {}

	for i = 1, #events do
		local eventInfo = events[i]

		if eventInfo.nodeId and eventInfo.treeId and eventInfo.node then
			table.insert(snapshot, {
				nodeId = eventInfo.nodeId,
				treeId = eventInfo.treeId,
				node = eventInfo.node
			})
		end
	end

	return snapshot
end

function BTSummonMessageManager:QueueReceiverEvents(receiverObjId, snapshot, eventParam, receiverActor)
	if #snapshot == 0 then
		return false
	end

	if MAX_PENDING_EVENTS < #self.pendingEvents + #snapshot then
		return false
	end

	for i = 1, #snapshot do
		local info = snapshot[i]

		table.insert(self.pendingEvents, {
			receiverObjId = receiverObjId,
			receiverActor = receiverActor,
			nodeId = info.nodeId,
			treeId = info.treeId,
			node = info.node,
			eventParam = CopyEventParam(eventParam)
		})
	end

	return true
end

function BTSummonMessageManager:SendAround(senderActor, rangeBlock, msgId, sendCooldownSec, receiveCooldownSec)
	if not IsActorValid(senderActor) then
		return 0
	end

	self:ResolvePendingReceivers()

	local senderObjId = GetObjId(senderActor)
	rangeBlock = tonumber(rangeBlock)
	msgId = tonumber(msgId)
	sendCooldownSec = tonumber(sendCooldownSec)
	receiveCooldownSec = tonumber(receiveCooldownSec)

	if not senderObjId or senderObjId <= 0 or not rangeBlock or rangeBlock <= 0 or not msgId or msgId <= 0 or not sendCooldownSec or sendCooldownSec < 0 or not receiveCooldownSec or receiveCooldownSec < 0 then
		return 0
	end

	local nowSec = GetNowSec()

	if not IsCooldownReady(self.sendCooldown, senderObjId, msgId, nowSec, sendCooldownSec) then
		return 0
	end

	self:RefreshDynamicReceiversForSend()

	local emptyThrottleSec = ResolveEmptySendThrottleSec(sendCooldownSec)

	if not IsCooldownReady(self.emptySendThrottle, senderObjId, msgId, nowSec, emptyThrottleSec) then
		return 0
	end

	local receivers = self.msgReceivers[msgId]

	if not receivers or not next(receivers) then
		SetCooldown(self.emptySendThrottle, senderObjId, msgId, nowSec)

		return 0
	end

	local receiverIds = {}

	for receiverObjId in pairs(receivers) do
		table.insert(receiverIds, receiverObjId)
	end

	local queuedReceiverCount = 0

	for i = 1, #receiverIds do
		local receiverObjId = receiverIds[i]

		if receiverObjId == senderObjId then
			-- Nothing
		elseif IsCooldownReady(self.receiveCooldown, receiverObjId, msgId, nowSec, receiveCooldownSec) then
			local receiverActor = GetActorByObjId(senderActor, receiverObjId)

			if not IsActorValid(receiverActor) then
				self:ClearActor(receiverObjId)
			elseif IsInRange(senderActor, receiverActor, rangeBlock) then
				local events = self.receiverEvents[receiverObjId] and self.receiverEvents[receiverObjId][msgId]
				local snapshot = events and BuildEventSnapshot(events) or {}
				local eventParam = {
					msgId = msgId,
					receiverMsgIdSnapshot = msgId,
					senderObjId = senderObjId,
					receiverObjId = receiverObjId,
					time = nowSec
				}

				if self:QueueReceiverEvents(receiverObjId, snapshot, eventParam, receiverActor) then
					SetCooldown(self.receiveCooldown, receiverObjId, msgId, nowSec)

					queuedReceiverCount = queuedReceiverCount + 1
				end
			end
		end
	end

	if queuedReceiverCount > 0 then
		SetCooldown(self.sendCooldown, senderObjId, msgId, nowSec)
	else
		SetCooldown(self.emptySendThrottle, senderObjId, msgId, nowSec)
	end

	return queuedReceiverCount
end

function BTSummonMessageManager:SendToActor(senderActor, targetObjId, msgId, sendCooldownSec, receiveCooldownSec)
	if not IsActorValid(senderActor) then
		return 0
	end

	self:ResolvePendingReceivers()

	local senderObjId = GetObjId(senderActor)
	targetObjId = tonumber(targetObjId)
	msgId = tonumber(msgId)
	sendCooldownSec = tonumber(sendCooldownSec)
	receiveCooldownSec = tonumber(receiveCooldownSec)

	if not senderObjId or senderObjId <= 0 or not targetObjId or targetObjId <= 0 or not msgId or msgId <= 0 or not sendCooldownSec or sendCooldownSec < 0 or not receiveCooldownSec or receiveCooldownSec < 0 then
		return 0
	end

	local targetActor = GetActorByObjId(senderActor, targetObjId)

	if not IsActorValid(targetActor) then
		self:ClearActor(targetObjId)

		return 0
	end

	local nowSec = GetNowSec()

	if not IsTargetCooldownReady(self.targetSendCooldown, senderObjId, targetObjId, msgId, nowSec, sendCooldownSec) then
		return 0
	end

	if not IsCooldownReady(self.receiveCooldown, targetObjId, msgId, nowSec, receiveCooldownSec) then
		return 0
	end

	self:RefreshDynamicReceiversForSend()

	local events = self.receiverEvents[targetObjId] and self.receiverEvents[targetObjId][msgId]

	if not events or #events == 0 then
		return 0
	end

	local snapshot = BuildEventSnapshot(events)
	local eventParam = {
		msgId = msgId,
		receiverMsgIdSnapshot = msgId,
		senderObjId = senderObjId,
		receiverObjId = targetObjId,
		time = nowSec
	}

	if self:QueueReceiverEvents(targetObjId, snapshot, eventParam, targetActor) then
		SetCooldown(self.receiveCooldown, targetObjId, msgId, nowSec)
		SetTargetCooldown(self.targetSendCooldown, senderObjId, targetObjId, msgId, nowSec)

		return 1
	end

	return 0
end

function BTSummonMessageManager:DispatchPending(maxCount)
	if self.dispatching or not self.pendingEvents or #self.pendingEvents == 0 then
		return
	end

	self.dispatching = true
	local ok, errorInfo = xpcall(function ()
		local dispatchCount = math.min(tonumber(maxCount) or DISPATCH_PER_TICK, #self.pendingEvents)

		for _ = 1, dispatchCount do
			local eventInfo = table.remove(self.pendingEvents, 1)

			if eventInfo then
				local receiverActor = eventInfo.receiverActor

				if not IsActorValid(receiverActor) and eventInfo.receiverObjId and eventInfo.receiverObjId > 0 and CurMainPlayer then
					receiverActor = GetActorByObjId(CurMainPlayer, eventInfo.receiverObjId)
				end

				if not IsActorValid(receiverActor) and GetCurWorldActorMgr and eventInfo.receiverObjId then
					local actorMgr = GetCurWorldActorMgr()
					receiverActor = actorMgr and actorMgr.findActorByWID and actorMgr:findActorByWID(eventInfo.receiverObjId)
				end

				if IsActorValid(receiverActor) then
					local eventOk, eventError = xpcall(function ()
						BehaviorTreeLuaOneEventRun(eventInfo.nodeId, eventInfo.treeId, eventInfo.node, eventInfo.eventParam)
					end, TraceError)

					if not eventOk then
						LogDispatchError(eventError)
					end
				else
					self:ClearActor(eventInfo.receiverObjId)
				end
			end
		end
	end, TraceError)
	self.dispatching = false

	if not ok then
		LogDispatchError(errorInfo)
	end
end

function BTSummonMessageManager:OnTick(sec)
	self:ResolvePendingReceivers()
	self:DispatchPending(DISPATCH_PER_TICK)
end

function BTSummonMessageManager:ClearTree(treeId, actorObjId)
	if not treeId then
		return
	end

	if self.pendingReceivers then
		self.pendingReceivers[treeId] = nil
	end

	local treeList = self.treeReceivers[treeId]

	if treeList then
		for i = #treeList, 1, -1 do
			local info = treeList[i]

			RemoveIndexedReceiver(self, info.receiverObjId, info.msgId, treeId, info.nodeId)
		end

		self.treeReceivers[treeId] = nil
	end

	local dynamicTree = self.dynamicReceivers and self.dynamicReceivers[treeId]

	if dynamicTree then
		local nodeIds = {}

		for nodeId in pairs(dynamicTree) do
			table.insert(nodeIds, nodeId)
		end

		for i = 1, #nodeIds do
			RemoveDynamicReceiver(self, treeId, nodeIds[i])
		end
	end

	if actorObjId and actorObjId > 0 then
		self.sendCooldown[actorObjId] = nil

		ClearTargetCooldownByActor(self, actorObjId)

		self.emptySendThrottle[actorObjId] = nil
		self.receiveCooldown[actorObjId] = nil
	end

	for i = #self.pendingEvents, 1, -1 do
		local eventInfo = self.pendingEvents[i]

		if eventInfo.treeId == treeId or actorObjId and eventInfo.receiverObjId == actorObjId then
			table.remove(self.pendingEvents, i)
		end
	end
end

function BTSummonMessageManager:ClearActor(actorObjId)
	actorObjId = tonumber(actorObjId)

	if not actorObjId or actorObjId <= 0 then
		return
	end

	local receiverMap = self.receiverEvents[actorObjId]

	if receiverMap then
		for msgId in pairs(receiverMap) do
			if self.msgReceivers[msgId] then
				self.msgReceivers[msgId][actorObjId] = nil

				if not next(self.msgReceivers[msgId]) then
					self.msgReceivers[msgId] = nil
				end
			end
		end

		self.receiverEvents[actorObjId] = nil
	end

	local emptyTreeIds = {}

	for treeId, treeList in pairs(self.treeReceivers) do
		for i = #treeList, 1, -1 do
			if treeList[i].receiverObjId == actorObjId then
				table.remove(treeList, i)
			end
		end

		if #treeList == 0 then
			table.insert(emptyTreeIds, treeId)
		end
	end

	for i = 1, #emptyTreeIds do
		self.treeReceivers[emptyTreeIds[i]] = nil
	end

	self.sendCooldown[actorObjId] = nil

	ClearTargetCooldownByActor(self, actorObjId)

	self.emptySendThrottle[actorObjId] = nil
	self.receiveCooldown[actorObjId] = nil

	for i = #self.pendingEvents, 1, -1 do
		if self.pendingEvents[i].receiverObjId == actorObjId then
			table.remove(self.pendingEvents, i)
		end
	end

	if self.dynamicReceivers then
		for _, dynamicTree in pairs(self.dynamicReceivers) do
			for _, info in pairs(dynamicTree) do
				if info.lastReceiverObjId == actorObjId then
					info.lastReceiverObjId = nil
					info.lastMsgId = nil
				end
			end
		end
	end
end
