if not BTClass then
	assert(false)

	return
end

require("sandboxengine.common.CoroutinePool")

local BTTaskClass = BTClass:Class("BTTask")
BTTaskClass.result_successed = 10000
BTTaskClass.result_failed = 10001
BTTaskClass.taskStep = 3
local type = _G.type
local setfenv = _G.setfenv
local setmetatable = _G.setmetatable
local coroutine = _G.coroutine
local tonumber = _G.tonumber
local tostring = _G.tostring
local pcall = _G.pcall

local function IsUGCTask(taskname)
	return type(taskname) == "string" and string.sub(taskname, 1, 7) == "UGCTask"
end

function BTTaskClass:constructor(id, defid, cfg, taskname, nodeptr)
	self.id = id
	self.cfg = cfg or {}
	self.taskname = taskname
	self.this = nodeptr
	self.subparam = {}
	self.BTEnum = _G.BTEnum

	self:ResetStatus()

	self.val = {}
	self.begain = 0
	self.AIEditorInterface = GetInst("AIEditorInterface")
	self.BTGetValueManage = GetInst("BTGetValueManage")
	self.BTDebugDataManage = GetInst("BTDebugDataManage")
	self.BTSendMsgToAi = GetInst("BTSendMsgToAi")
	self.gCoroutinePool = _G.gCoroutinePool
	self.isOneRun = nil
	self.closeIsOneCoroutine = true
end

function BTTaskClass:destructor()
	if type(self.release) == "function" then
		local ok, msg = pcall(self.release)

		assert(ok, "BTTaskClass:destructor() => self.release() => Call failed. msg: " .. tostring(msg))
	end

	self:ResetStatus()

	self.id = nil
	self.cfg = nil
	self.taskname = nil
	self.subparam = nil
	self.fenv = nil
	self.func = nil
	self.run = nil
	self.on_beg = nil
	self.on_end = nil
	self.co = nil
	self.will = nil
	self.onwait = nil
	self.isAiTree = nil
	self.senddebugdata = nil
	self.val = {}
	self.blackboard = nil
end

function BTTaskClass:SetSubparam(subparam)
	if type(subparam) == "table" then
		for k, v in pairs(subparam) do
			if type(v) == "table" then
				self.subparam[k] = copy_table(v)
			else
				self.subparam[k] = v
			end

			self:BuildUGCSubparamResolvePlan(k)
		end
	elseif subparam then
		MiniLog("BT ERROR : task load subparam failed! subparam = ", subparam)
	end
end

function BTTaskClass:BuildUGCSubparamResolvePlan(index)
	if not IsUGCTask(self.taskname) or not BTService or not BTService:IsSubparamReuseEnabled() then
		return nil
	end

	local plan = self._ugcSubparamResolvePlan

	if not plan then
		plan = {}
		self._ugcSubparamResolvePlan = plan
	end

	local function updatePlanItem(key)
		local param = self.subparam[key]

		if type(param) == "table" then
			plan[key] = {
				param = param,
				paramtype = param.paramtype
			}
		else
			plan[key] = {
				param = param
			}
		end
	end

	if index ~= nil then
		updatePlanItem(index)
	else
		for key in pairs(self.subparam) do
			updatePlanItem(key)
		end
	end

	return plan
end

function BTTaskClass:Begin(...)
	if not self.cfg then
		return
	end

	self:ResetStatus()

	if not self.func then
		local onbeg = self.cfg and type(self.cfg.onbeg) == "function" and self.cfg.onbeg or function ()
		end
		local onend = self.cfg and type(self.cfg.onend) == "function" and self.cfg.onend or function ()
		end
		local decorator = self.cfg and type(self.cfg.decorator) == "function" and self.cfg.decorator or function ()
			return controller.success()
		end
		local run = self.cfg and type(self.cfg.run) == "function" and self.cfg.run or function ()
			return controller.fail()
		end
		local controller = self:MakeController(decorator, ...)
		self.controller = controller
		local taskname = self.taskname
		local senddebugdata = self.cfg and type(self.cfg.send_debug_data) == "function" and self.cfg.send_debug_data or function ()
			controller.sendValToDebug({})
		end
		local fenv = {
			controller = controller,
			coroutine = setmetatable({}, {
				__index = function ()
					MiniLog("BT ERROR : coroutine has been limited in btree task!")
				end
			})
		}

		setmetatable(fenv, {
			__index = _G
		})

		local release = self.cfg and type(self.cfg.release) == "function" and self.cfg.release or function ()
		end

		function self.release()
			setfenv(release, fenv)
			release()
		end

		local wile = self.cfg and type(self.cfg.will) == "function" and self.cfg.will or function ()
			return true
		end

		function self.will()
			setfenv(wile, fenv)

			return wile()
		end

		function self.senddebugdata()
			setfenv(senddebugdata, fenv)
			senddebugdata()
		end

		pcall(self.senddebugdata)

		local ok, msg = pcall(self.will)

		if ok then
			if not msg then
				return
			end
		else
			MiniLog("BT ERROR : bttask [will] failed! taskname=" .. tostring(self.taskname) .. ", errorlog = " .. tostring(msg))
		end

		local onwait = self.cfg and type(self.cfg.onwait) == "function" and self.cfg.onwait or function ()
			return true
		end

		function self.onwait()
			setfenv(onwait, fenv)

			return onwait()
		end

		self.run = run

		function self.on_beg()
			setfenv(onbeg, fenv)
			onbeg()
		end

		function self.on_end()
			setfenv(onend, fenv)
			onend()
		end

		function self.func()
			setfenv(decorator, fenv)
			setfenv(run, fenv)

			local ok, msg, ret = pcall(function ()
				if self.val.needtime then
					self.val.currenttime = self.this:GetCurentTime()
				end

				local msg, result = decorator()

				if result == BTTaskClass.result_failed then
					return controller.fail()
				end

				return run()
			end)

			if not ok then
				if not string.find(msg, "over", string.len(msg) - 4 + 1) then
					MiniLog("BT ERROR : bttask instance [run] failed! taskname = " .. tostring(taskname) .. ", errorlog = " .. tostring(msg))
				end

				return controller.fail()
			end

			if ret ~= BTTaskClass.result_failed then
				return controller.success()
			else
				return controller.fail()
			end
		end
	else
		pcall(self.senddebugdata)

		local ok, msg = pcall(self.will)

		if ok then
			if not msg then
				return
			end
		else
			MiniLog("BT ERROR : bttask [will] failed! taskname=" .. tostring(self.taskname) .. ", errorlog = " .. tostring(msg))
		end
	end

	local ok, error = pcall(self.on_beg)

	if not ok then
		MiniLog("BT ERROR : bttask [onbeg] failed! taskname=" .. tostring(self.taskname) .. ", errorlog = " .. tostring(error))
	end

	self.call_beg_end = true

	if not self:IsOne() then
		self.co = self.gCoroutinePool:Create(self.func)
	end

	if self.blackboard then
		self.blackboard:TaskSaveBBData()
	end
end

function BTTaskClass:ClearState()
	if not self:IsOne() and self.co then
		local costatus = coroutine.status(self.co)

		if costatus == "suspended" and self.runstatus ~= "over" then
			coroutine.resume(self.co, "over")
		end
	end

	if type(self.release) == "function" then
		local ok, msg = pcall(self.release)

		if not ok then
			MiniLog("BT ERROR : bttask [release] failed! taskname=" .. tostring(self.taskname) .. ", errorlog = " .. tostring(msg))
		end
	end

	self:ResetStatus()

	self.co = nil
	self.val = {}

	if self.controller then
		self.controller.taskparam = self.val

		self:MakeSafeController(self.controller)
	end
end

function BTTaskClass:End()
	if not self:IsOne() and self.co then
		local costatus = coroutine.status(self.co)

		if costatus == "suspended" and self.runstatus ~= "over" then
			coroutine.resume(self.co, "over")
		end
	end

	self:ResetStatus()

	if self.on_end and self.call_beg_end then
		local ok, error = pcall(self.on_end)

		if not ok then
			MiniLog("BT ERROR : bttask [onend] failed! taskname=" .. tostring(self.taskname) .. ", errorlog = " .. tostring(error))
		end

		self.call_beg_end = false
	end

	self.co = nil
end

function BTTaskClass:Run()
	if not self:IsOne() then
		if not self.co then
			return self.BTEnum.BTNODERESULT.FAIL
		end

		local rt = self:RunByStatus()

		if rt == self.BTEnum.BTNODERESULT.WAIT and self.onwait then
			local ok, msg = pcall(self.onwait)

			if ok then
				if msg == false then
					self:ResetStatus()
				end
			else
				MiniLog("BT ERROR : bttask [onwait] failed! taskname=" .. tostring(self.taskname) .. ", errorlog = " .. tostring(msg))
			end
		end

		if rt then
			return rt
		end

		local ok, msg, param = coroutine.resume(self.co, "run", self)

		if not ok then
			self.co = nil

			return self.BTEnum.BTNODERESULT.FAIL
		end

		if not self.co then
			msg = "over"
		else
			local costatus = coroutine.status(self.co)

			if costatus == "dead" then
				msg = "over"
			end
		end

		self:SetStatus(msg, param)

		if self.runstatus == "over" then
			return self.result
		end

		return self.BTEnum.BTNODERESULT.WAIT
	else
		if not self.func then
			return self.BTEnum.BTNODERESULT.FAIL
		end

		local msg, param = self:func()

		self:SetStatus(msg, param)

		return self.result
	end
end

function BTTaskClass:ResetStatus()
	self.runstatus = "idle"
	self.waittime = 0
	self.begain = 0
	self.wait_predicate = nil
	self.result = self.BTEnum.BTNODERESULT.SUCCESS
end

function BTTaskClass:SetStatus(msg, param)
	self.runstatus = msg

	if msg == "wait" then
		self.waittime = param or 0
		self.begain = self.this:GetCurentTime()
	elseif msg == "wait_until" then
		self.wait_predicate = param or function ()
			return true
		end
	elseif msg == "over" then
		self.result = param ~= BTTaskClass.result_failed and self.BTEnum.BTNODERESULT.SUCCESS or self.BTEnum.BTNODERESULT.FAIL
	else
		self:ResetStatus()
	end
end

function BTTaskClass:isAiEdit()
	if self.isAiTree == nil then
		local treeins = self.this:GetBehaviorTreeInstance()

		if treeins.isLoadAiEditNode then
			self.isAiTree = treeins:isLoadAiEditNode()
		else
			self.isAiTree = false
		end
	end

	return self.isAiTree
end

function BTTaskClass:RunByStatus()
	if self.runstatus == "wait" then
		local currentlent = self.this:GetCurentTime() - self.begain

		if self.waittime <= currentlent then
			self:ResetStatus()

			return
		end

		return self.BTEnum.BTNODERESULT.WAIT
	elseif self.runstatus == "wait_until" then
		if self.wait_predicate() then
			self:ResetStatus()

			return
		end

		return self.BTEnum.BTNODERESULT.WAIT
	elseif self.runstatus == "over" then
		return self.result
	end
end

function BTTaskClass:SendDataToDebug()
	local treeins = self.this:GetBehaviorTreeInstance()
	local treeid = treeins:GetInstanceID()
	local nodeid = self.this:GetNodeId() or 0

	if self.sendData and self.AIEditorInterface:GetDebugModeState() then
		local senddata = self.BTDebugDataManage:DealSendToDebugData(self.sendData)

		self.AIEditorInterface:BTreePassRuntimeParam(treeid, nodeid, senddata)
	end
end

function BTTaskClass:SendMsgToAi(actor, NodeName, msg)
end

function BTTaskClass:ControllerWait(time, decorator)
	time = tonumber(time) or 0.001
	local status, task = coroutine.yield("wait", time)

	if status == "run" then
		return task
	end

	if status == "over" then
		error("over")

		return
	end

	local msg, result = decorator()

	if result == BTTaskClass.result_failed then
		error("over")

		return
	end
end

function BTTaskClass:ControllerWaituntil(predicate, decorator)
	if type(predicate) == "function" then
		local status, task = coroutine.yield("wait_until", predicate)

		if status == "run" then
			return task
		end

		if status == "over" then
			error("over")

			return
		end
	end

	local msg, result = decorator()

	if result == BTTaskClass.result_failed then
		error("over")

		return
	end
end

function BTTaskClass:SetEventData(param)
	self.val.eventParam = param
end

function BTTaskClass:IsOne()
	if self.isOneRun == nil then
		self.isOneRun = self.this:isOneRun()
	end

	if self.isOneRun and self.closeIsOneCoroutine then
		return true
	end
end

function BTTaskClass:MakeSafeController(controller)
	if type(BTEnsureSafeController) == "function" then
		return BTEnsureSafeController(controller)
	end

	return nil
end

function BTTaskClass:MakeController(decorator, btree)
	local coroutine = coroutine
	local blackboard = btree and btree:GetBlackboard()
	self.blackboard = blackboard
	local targetf = btree and btree:GetTargetF()
	local result_successed = BTTaskClass.result_successed
	local result_failed = BTTaskClass.result_failed
	local subparam = self.subparam
	local isUGCTask = IsUGCTask(self.taskname)
	local subparamResolvePlan = self:BuildUGCSubparamResolvePlan()
	local luabb = btree:GetLuaBB()
	local treeid = btree:GetTreeId()
	local taskparam = self.val
	local controller = nil
	controller = {
		_blackboard = blackboard,
		_targetf = targetf,
		wait = function (time)
			return self:ControllerWait(time, decorator)
		end,
		wait_until = function (predicate)
			return self:ControllerWaituntil(predicate, decorator)
		end,
		success = function ()
			return "over", result_successed
		end,
		fail = function ()
			return "over", result_failed
		end,
		treeid = treeid,
		bb = {
			set = function (key, data)
				if controller._blackboard then
					return controller._blackboard and key and controller._blackboard:SetData(key, data)
				end

				return false
			end,
			get = function (key)
				if type(key) ~= "string" then
					return key
				end

				if controller._blackboard then
					return controller._blackboard and controller._blackboard:GetData(key)
				end

				return false
			end,
			setGroupData = function (key, index, data)
				if controller._blackboard then
					return controller._blackboard and key and controller._blackboard:SetGroupDataByIndex(key, index, data)
				end

				return false
			end,
			getName = function (key)
				if type(key) ~= "string" then
					return ""
				end

				if controller._blackboard then
					return controller._blackboard and controller._blackboard:GetName(key)
				end

				return false
			end,
			getGroupRandomValue = function (key)
				if controller._blackboard then
					return controller._blackboard and controller._blackboard:GetGroupRandomValue(key)
				end

				return false
			end,
			getGroupData = function (key, index)
				if controller._blackboard then
					return controller._blackboard and controller._blackboard:GetGroupDataByIndex(key, index)
				end

				return false
			end
		},
		luabb = luabb,
		taskparam = taskparam,
		target = {
			get = function (type)
				return controller._targetf and controller._targetf(type)
			end,
			getobjid = function (type)
				if controller._targetf then
					local obj = controller._targetf(type)

					if obj then
						return obj:getObjId()
					end
				end

				return 0
			end
		},
		subparam = subparam,
		_isUGCTask = isUGCTask,
		_ugcSubparamResolvePlan = subparamResolvePlan,
		isNeedSendDebug = function ()
			if self.AIEditorInterface and self.AIEditorInterface:GetDebugModeState() then
				return true
			end

			return false
		end,
		sendValToDebug = function (val)
			self.sendData = val

			self:SendDataToDebug()
		end,
		sendMsgToAi = function (actor, NodeName, msg)
			self.BTSendMsgToAi:SendMsgToAi(actor, NodeName, msg)
		end
	}

	self:MakeSafeController(controller)

	return controller
end
