if not BTClass then
	assert(false)

	return
end

if not BTClass.BTBlackboard then
	assert(false)

	return
end

local BTreeClass = BTClass:Class("BTree")

function BTreeClass:constructor(id, defid, cfg, btname, btreeptr)
	self.id = id

	if type(btname) == "table" then
		self.btname = tostring(btname)
	elseif type(btname) == "string" then
		self.btname = tostring(btname)
	end

	self.GetBtreeDirByUUID = GetBtreeDirByUUID
	self.BehaviorTreeTaskSetSubparam = BehaviorTreeTaskSetSubparam
	self.BehaviorTree_AddChildBBFile = BehaviorTree_AddChildBBFile
	self.BehaviorTreeCreateTask = BehaviorTreeCreateTask
	self.BTTaskMgr = _G.BTTaskMgr
	self.BehaviorTree_AddTempNode = BehaviorTree_AddTempNode
	self.BTCreator = BTCreator
	self.BTAddMsg = BTAddMsg
	self.BBManager = _G.BBManager
	self.this = btreeptr

	if cfg and cfg.iscfgs then
		local pnode = self:CreateNodeTreeByCfgs(defid, cfg)
	else
		local treeid = nil

		if cfg and cfg.treeid then
			treeid = cfg.treeid
		end

		local pnode = self:CreateNodeTree(defid, cfg, nil, cfg.treeid)

		if pnode then
			local ok = self:SetBTreeNode(pnode, cfg.treeid)

			if not ok then
				self:DestroyNodeTree(pnode)
			end
		end
	end

	self.m_luabb = {}
	self.GetBtreeDirByUUID = nil
	self.BehaviorTreeTaskSetSubparam = nil
	self.BehaviorTree_AddChildBBFile = nil
	self.BehaviorTreeCreateTask = nil
	self.BTTaskMgr = nil
	self.BehaviorTree_AddTempNode = nil
end

function BTreeClass:destructor()
	if GetInst("BTEventManager") then
		GetInst("BTEventManager"):RemoveCustomEvent(self.id)
	end

	local summonMsgClass = ClassList and ClassList.BTSummonMessageManager
	local summonMsgMgr = summonMsgClass and summonMsgClass.GetInstIfExists and summonMsgClass:GetInstIfExists()

	if summonMsgMgr then
		summonMsgMgr:ClearTree(self.id, self.objid)
	end

	self.id = nil
	self.btname = nil
	self.this = nil
	self.m_luabb = nil
end

function BTreeClass:CreateNodeTreeByCfgs(defid, cfgs, parent)
	local param = {
		{
			paramtype = 4,
			val = 2030001
		}
	}
	local pnode = self:CreateNode(defid, "BTNodeSelector", parent, param, nil, "root")
	local num = #cfgs.data
	local value = nil

	for i = 1, num do
		value = cfgs.data[i]

		self:CreateNodeTree(defid, value, pnode, value.treeid)
	end

	local ok = self:SetBTreeNode(pnode)

	if not ok then
		self:DestroyNodeTree(pnode)
	end

	return pnode
end

function BTreeClass:GetTreeId()
	return self.id
end

function BTreeClass:CreateNodeTree(defid, cfg, parent, treeid)
	parent = parent or nil

	if type(cfg) ~= "table" then
		return nil
	end

	local nodetype = cfg.node
	local param = cfg.param
	local children = cfg.children
	local nodeid = cfg.nodeid

	if param and param.script == "BTTask_commonTips" and (not IsOpenBtTreeDebug or not IsOpenBtTreeDebug()) then
		nodetype = "BTNodeSuccess"
		param = {
			tip = "BTTask_commonTips"
		}
	end

	if not nodetype then
		print("BT-ERROR : create node : nodetype is error! cfg=", cfg)

		return nil
	end

	local subparam = param and param.subparam

	if nodetype == "UGCUseTree" then
		if param[1] and param[1].val then
			local uuid = param[1].val
			local dir = self.GetBtreeDirByUUID(uuid)

			if string.len(dir) > 0 then
				local treepath = dir .. "/btree.lua"
				local bbpath = dir .. "/blackboard.lua"

				return self:CreateNodeChildrenTree(defid, treepath, bbpath, parent, nodeid, uuid)
			end
		end
	else
		local pnode = self:CreateNode(defid, nodetype, parent, param, subparam, nodeid, treeid)

		if not pnode then
			print("BT ERROR : create node failed! nodetype=" .. tostring(nodetype) .. ", parentid=" .. tostring(parent and parent:GetInstanceID()) .. ", param=", param)

			return nil
		end

		if (nodetype == "BTNodeTaskLua" or nodetype == "BTNodeConditionLua" or nodetype == "BTNodeEvent") and type(cfg.param.__USE_LOCAL_TABLE_) == "table" then
			if not self.BTTaskMgr:CreateInstanceByCfg(pnode:GetInstanceID(), nil, "__USE_LOCAL_TABLE_", cfg.param.__USE_LOCAL_TABLE_, pnode) then
				return nil
			end

			if subparam then
				self.BehaviorTreeTaskSetSubparam(pnode:GetInstanceID(), subparam)
			end
		end

		if children then
			if not children[1] and next(children) then
				children = {
					children
				}
			end

			local num = #children

			for i = 1, num do
				local childnode = self:CreateNodeTree(defid, children[i], pnode, treeid)

				if not childnode then
					print("BT ERROR : create node tree failed! childcfg=", children[i])
					print("BT ERROR : create node tree failed! parentcfg=", cfg)
				end
			end
		end

		return pnode
	end

	return nil
end

function BTreeClass:CreateNodeChildrenTree(defid, childreeTreefile, childreeBloadfile, parent, nodeid, uuid)
	local cfg = self.BTTaskMgr:LoadAIEditConfig(childreeTreefile)

	self.BehaviorTree_AddChildBBFile(defid, uuid, childreeBloadfile)

	local pnode = self:CreateNode(defid, "BTNodeSingle", parent, nil, nil, nodeid, uuid)

	return self:CreateNodeTree(defid, cfg, pnode, uuid)
end

function BTreeClass:DestroyNodeTree(pnode)
	self:DestroyNode(pnode)
end

function BTreeClass:SetBTreeNode(pnode, treeid)
	if self.BTCreator and self.BTCreator.SetBTreeNode then
		return self.BTCreator:SetBTreeNode(self.this, pnode)
	end

	return false
end

function BTreeClass:FillParam(param, callback)
	if not param then
		return
	end

	for key, val in pairs(param) do
		local nodedata = self.BTCreator:LockNodeData()

		if not nodedata then
			print("BT ERROR! fill param failed! lock node data failed!")

			break
		end

		local ok, ret = pcall(function ()
			if key == "subparam" then
				return false
			end

			nodedata:Clear()

			local ok = false
			local tempval = val

			if type(val) == "table" and val.paramtype then
				if val.paramtype == AIDefine.BtreeParamType.Val then
					tempval = val.val
				elseif val.paramtype == AIDefine.BtreeParamType.Enum then
					local str = VisualCodeApiProxy:GetEnumInfo(val.val)

					if str then
						tempval = str
						local num = tonumber(str)

						if num then
							tempval = num
						elseif str == "true" or str == "false" then
							tempval = BTService:GetBoolVal(str)
						end
					end
				elseif val.paramtype == AIDefine.BtreeParamType.GetValueFun then
					return true
				else
					MiniLog("BT ERROR! fill param failed! node param valtype error! ", key, val.paramtype)

					return false
				end
			end

			local typeval = type(tempval)

			if type(key) == "number" and typeval == "table" and next(tempval) == nil then
				return false
			end

			if typeval == "boolean" then
				nodedata:SetValue_Bool(tempval)

				ok = true
			elseif typeval == "number" then
				nodedata:SetValue_Number(tempval)

				ok = true
			elseif typeval == "string" then
				nodedata:SetValue_String(tempval)

				ok = true
			elseif typeval == "table" then
				local size = #tempval

				if size > 0 then
					local typevaldata = type(tempval[1])

					if typevaldata == "number" then
						nodedata:SetValue_ArrayNumber(size)

						for i = 1, size do
							nodedata:SetValue_ArrayNumber_ByIndex(i - 1, tempval[i])
						end

						ok = true
					else
						print("BT ERROR! fill node param failed! param is array, but data type is invalid! type(val[1])=" .. tostring(typevaldata))
					end
				elseif tempval.x and tempval.y and tempval.z then
					local x = tonumber(tempval.x)
					local y = tonumber(tempval.y)
					local z = tonumber(tempval.z)

					if x and y and z then
						nodedata:SetValue_Vector3(x, y, z)

						ok = true
					end
				elseif next(tempval) then
					print("BT ERROR! fill node param failed! param is table, but data is invalid! val=", tempval)
				end
			else
				print("BT ERROR! fill node param failed! param type is invalid! type(val)=" .. tostring(typeval))
			end

			return ok
		end)

		if ok and ret then
			if type(val) == "table" and val.paramtype and val.paramtype == AIDefine.BtreeParamType.GetValueFun then
				callback(key, val, true)
			else
				callback(key, nodedata)
			end
		elseif not ok then
			print("BT ERROR! fill node param failed! lua_pcall error! errorlog=" .. tostring(ret))
		end

		self.BTCreator:UnlockNodeData()
	end
end

local needOneRun = {
	BTNodeConditionLua = true
}
local TriggerEvent = TriggerEvent or {
	PlayerPickUpItem = "Player.PickUpItem",
	PlayerConsumeItem = "Player.ConsumeItem",
	PlayerDiscardItem = "Player.DiscardItem",
	PlayerChargeItemBegin = "Player.ChargeItem.Begin",
	PlayerChargeItemEnd = "Player.ChargeItem.End",
	PlayerUseItem = "Player.UseItem",
	PlayerAddItem = "Player.AddItem"
}
local PlayerItemEventNameByEnum = {
	[3270001] = TriggerEvent.PlayerAddItem,
	[3270002] = TriggerEvent.PlayerUseItem,
	[3270003] = TriggerEvent.PlayerChargeItemBegin,
	[3270004] = TriggerEvent.PlayerConsumeItem,
	[3270005] = TriggerEvent.PlayerPickUpItem,
	[3270006] = TriggerEvent.PlayerDiscardItem,
	[3270007] = TriggerEvent.PlayerChargeItemEnd
}

local function ResolvePlayerItemEventName(param)
	local subparam = param and param.subparam
	local eventParam = subparam and subparam[1]
	local eventEnum = eventParam and tonumber(eventParam.val)

	if not eventEnum then
		return nil
	end

	return PlayerItemEventNameByEnum[eventEnum]
end

local realNodeType = {
	UGCTask_EvntTeamActorBeHeurt = "BTNodeTeamActorBeHeurtEvent",
	UGCTask_EventBePlayerInteract = "BTNodeEvent",
	UGCTask_EventPlayerPlayAction = "BTNodeGlobelEvent",
	UGCTask_EventPlayerCollide = "BTNodePlayerCollideEvent",
	UGCTask_EventOnLanded = "BTNodeEvent",
	UGCTask_EventRangeCreatureTypeGroupAttacked = "BTNodeEvent",
	UGCTask_EventRangeCreatureTypeAttacked = "BTNodeEvent",
	UGCTask_EvntBeClick = "BTNodeEvent",
	UGCTask_EventPlayerInputString = "BTNodeGlobelEvent",
	UGCTask_EventChildrenBeHeurtEvent = "BTNodeChildrenBeHeurtEvent",
	UGCTask_EventAiNPC = "BTNodeAiNPCEvent",
	UGCTask_EventActorCollideFilterPlayer = "BTNodeLivingCollideFilterPlayerEvent",
	UGCTask_EventHostBeHurt = "BTNodeHostBeHeurtEvent",
	UGCTask_EventPlayerItem = "BTNodeGlobelEvent",
	UGCTask_EventBeInteract = "BTNodeEvent",
	UGCTask_EventActorDie = "BTNodeGlobelEvent",
	UGCTask_EventReceiveSummonMsg = "BTNodeEvent",
	UGCTask_EventBeMsg = "BTNodeEvent",
	UGCTask_EvntClickActor = "BTNodeEvent",
	UGCTask_EventActorCollide = "BTNodeLivingCollideEvent",
	UGCTask_EventBeHurt = "BTNodeBeHeurtEvent",
	UGCTask_EventBePlaySound = "BTNodePlaySoundEvent"
}

function BTreeClass:GetRealNodetype(oldnodetype, param)
	if param and param.script and realNodeType[param.script] then
		return realNodeType[param.script]
	end

	return oldnodetype
end

local cjson = require("cjson")

function BTreeClass:CreateNode(defid, nodetype, parent, param, subparam, nodeid, treeid)
	if not self.BTCreator or not self.BTCreator.CreateNode then
		print("BT ERROR! create node failed! cpp function can not found!")

		return nil
	end

	local pnode = nil
	local tempnode = BehaviorTree_GetTempNode(treeid, nodeid)
	local needadd = false
	local lnodetype = self:GetRealNodetype(nodetype, param)

	if nodeid == nil or type(nodeid) ~= "string" then
		pnode = self.BTCreator:CreateNode(lnodetype, parent)
	elseif type(nodeid) == "string" and treeid and type(treeid) == "string" then
		pnode = self.BTCreator:AIEditCreateNodeByTreeid(lnodetype, nodeid, treeid, parent)
		needadd = true
	else
		needadd = true
		pnode = self.BTCreator:AIEditCreateNode(lnodetype, nodeid, parent)
	end

	if tempnode and tempnode.node then
		local id = pnode:InitValue(tempnode.node)

		if next(tempnode.getvals) ~= nil then
			for key, value in pairs(tempnode.getvals) do
				local nodeinfo = {}
				local id = GetInst("BTGetValueManage"):Regfun(self.id, value.func)
				nodeinfo.funid = id
				nodeinfo.paramtype = value.paramtype
				nodeinfo.valtype = value.valtype

				pnode:addGetValueNode(key, cjson.encode(nodeinfo))
			end
		end

		if tempnode and tempnode.script then
			local sctr = tempnode.script

			if sctr then
				if self:CheckSplite(sctr) then
					self.this:SetNeedSplit(false)
				end

				if sctr ~= "__USE_LOCAL_TABLE_" then
					local ressult = self:IsNoSetParamNode(sctr) or self.BehaviorTreeCreateTask(id, sctr, pnode)
				end
			end

			self:regTriginfo(tempnode.script, pnode, tempnode)
		end

		if tempnode.subparam and not self:IsNoSetParamNode(tempnode.script) then
			if tempnode.script == "UGCTask_EventBeMsg" and tempnode.subparam[1] and type(tempnode.subparam[1].val) == "string" and tempnode.subparam[1].val ~= "" then
				self:RegCustomEvent(subparam[1].val, pnode)
			end

			if tempnode.script == "UGCTask_EventReceiveSummonMsg" then
				local param1 = type(tempnode.subparam) == "table" and tempnode.subparam[1]

				if param1 then
					self:RegSummonMessageEvent(param1, pnode)
				end
			end

			self.BehaviorTreeTaskSetSubparam(id, tempnode.subparam)

			local count = #tempnode.subparam

			if count > 0 and needOneRun[lnodetype] then
				local enums = std.vector_int_()
				local bbs = std.vector_std__string_()

				for i = 1, count do
					local param = tempnode.subparam[i]

					if param.bb or param.paramtype == AIDefine.BtreeParamType.Enum then
						if param.bb then
							bbs:push_back(param.bb)
						end

						if param.paramtype == AIDefine.BtreeParamType.Enum then
							enums:push_back(param.val)
						end
					else
						bbs:clear()
						enums:clear()

						break
					end
				end

				if enums:size() > 0 or bbs:size() > 0 then
					self.this:regNode(bbs, enums, param.script, nodeid)
				end
			end
		end
	else
		if not pnode then
			print("BT ERROR! create node failed! nodetype=" .. tostring(lnodetype) .. ", parentid=" .. tostring(parent and parent:GetInstanceID()))

			return nil
		end

		local getvals = {}

		if param and not self:IsNoSetParamNode(param.script) then
			self:FillParam(param, function (key, nodedata, iscreatGetValfun)
				if iscreatGetValfun then
					local nodeinfo = {}
					local id = GetInst("BTGetValueManage"):Regfun(self.id, nodedata.func)
					nodeinfo.funid = id
					nodeinfo.paramtype = nodedata.paramtype
					nodeinfo.valtype = nodedata.valtype

					pnode:addGetValueNode(key, cjson.encode(nodeinfo))

					nodeinfo.func = nodedata.func

					if needadd then
						getvals[key] = nodeinfo
					end
				else
					pnode:SetParam(key, nodedata)
				end
			end)
		end

		pnode:Init()

		local id = pnode:GetInstanceID()
		local onerun = false

		if param and param.script then
			local sctr = param.script

			if sctr and id then
				if self:CheckSplite(sctr) then
					self.this:SetNeedSplit(false)
				end

				if sctr ~= "__USE_LOCAL_TABLE_" then
					local ressult = self:IsNoSetParamNode(sctr) or self.BehaviorTreeCreateTask(id, sctr, pnode)
				end
			end

			if AITaskProxy.OneRunLuaTask[param.script] then
				onerun = true
			end

			self:regTriginfo(param.script, pnode, param)
		end

		if subparam and not self:IsNoSetParamNode(param.script) then
			if param and param.script == "UGCTask_EventBeMsg" and subparam[1] and type(subparam[1].val) == "string" and subparam[1].val ~= "" then
				self:RegCustomEvent(subparam[1].val, pnode)
			end

			if param and param.script == "UGCTask_EventReceiveSummonMsg" then
				local param1 = type(subparam) == "table" and subparam[1]

				if param1 then
					self:RegSummonMessageEvent(param1, pnode)
				end
			end

			if param and param.script == "UGCTask_EventBePlaySound" then
				if subparam[3] and type(subparam[3].val) == "string" then
					local nodedata = self.BTCreator:LockNodeData()

					if nodedata then
						nodedata:Clear()
						nodedata:SetValue_String(subparam[3].val)
						pnode:SetParam(4, nodedata)
					end

					self.BTCreator:UnlockNodeData()
				elseif subparam[3] and type(subparam[3].val) == "number" then
					local ss_actor = BTService:GetSSObj("Actor")

					if ss_actor then
						local type, name = ss_actor:getSoundEffectById(subparam[3].val)
						local nodedata = self.BTCreator:LockNodeData()

						if nodedata then
							nodedata:Clear()
							nodedata:SetValue_String(name)
							pnode:SetParam(4, nodedata)
						end

						self.BTCreator:UnlockNodeData()
					end
				end
			end

			self.BehaviorTreeTaskSetSubparam(id, subparam)

			local count = #subparam

			if count > 0 and needOneRun[lnodetype] then
				local enums = std.vector_int_()
				local bbs = std.vector_std__string_()

				for i = 1, count do
					local param = subparam[i]

					if param.bb or param.paramtype == AIDefine.BtreeParamType.Enum then
						if param.bb then
							bbs:push_back(param.bb)
						end

						if param.paramtype == AIDefine.BtreeParamType.Enum then
							enums:push_back(param.val)
						end
					else
						bbs:clear()
						enums:clear()

						break
					end
				end

				if enums:size() > 0 or bbs:size() > 0 then
					self.this:regNode(bbs, enums, param.script, nodeid)
				end
			end
		end

		if onerun and pnode and pnode.setOneRun then
			pnode:setOneRun(true)
		end

		if needadd then
			local nodeinfos = {}

			if nodeid and type(nodeid) == "string" then
				nodeinfos.node = self.BTCreator:CreateNode(lnodetype, nil)

				if nodeinfos.node then
					nodeinfos.node:InitValue(pnode)

					nodeinfos.subparam = subparam
					nodeinfos.script = param.script
					nodeinfos.getvals = getvals

					self.BehaviorTree_AddTempNode(treeid, nodeid, nodeinfos)
				end
			end
		end
	end

	return pnode
end

local NoSpliteNode = {
	UGCTask_AttackMeleeCombo = true
}

function BTreeClass:CheckSplite(sctr)
	return NoSpliteNode[sctr]
end

function BTreeClass:RegCustomEvent(msg, node)
	local lmsg = msg
	local nodeid = node:GetInstanceID()
	local treeid = self.this:GetInstanceID()
	local lnode = node

	if GetInst("BTEventManager") then
		GetInst("BTEventManager"):RegCustomEvent(lmsg, nodeid, treeid, lnode)
	end
end

function BTreeClass:RegSummonMessageEvent(msgIdParam, node)
	if not node or not self.id then
		return
	end

	local summonMsgMgr = GetInst("BTSummonMessageManager")

	if not summonMsgMgr or not summonMsgMgr.RegisterSummonMessageReceiver then
		return
	end

	summonMsgMgr:RegisterSummonMessageReceiver(self.id, node:GetInstanceID(), node, msgIdParam, function ()
		return self:GetObjId()
	end)
end

function BTreeClass:DestroyNode(pnode)
	if not pnode then
		return
	end

	pnode:Release()

	if self.BTCreator and self.BTCreator.DestroyNode then
		self.BTCreator:DestroyNode(pnode)
	end
end

function BTreeClass:GetBlackboard()
	local bbid = self.this:GetBlackboardID()

	if bbid > 0 then
		local bb = bbid and self.BBManager:GetInstance(bbid)

		return bb
	else
		return nil
	end
end

function BTreeClass:GetTargetF()
	local type2Function = {
		player = "GetTargetPlayer",
		living = "GetTargetLiving",
		mob = "GetTargetMob"
	}

	return function (type)
		local fname = type and type2Function[type] or "GetTarget"
		local this = self.this

		return this and this[fname](this)
	end
end

function BTreeClass:GetNodeByKey(key)
	return self.this:GetNodeByKey(key)
end

function BTreeClass:GetLuaBB()
	return self.m_luabb
end

function BTreeClass:InitSendDebugdata()
	if self.this then
		self.this:initSendDebugdata()
	end
end

local noSetParamNode = {
	UGCTask_EvntCollide = true,
	UGCTask_EventDamage = true,
	UGCTask_EventAttackHit = true,
	UGCTask_EventAttack = true,
	UGCTask_EventBeat = true
}
local regtrigerEveent = {
	UGCTask_EventBeat = {
		triggeridnamme = TriggerEvent.ActorBeat
	},
	UGCTask_EventAddBuff = {
		playerTriggeridename = "Player.AddBuff",
		triggeridnamme = TriggerEvent.ActorAddBuff
	},
	UGCTask_EventAttack = {
		playerTriggeridename = "Player.AddBuff",
		triggeridnamme = TriggerEvent.MobAttack
	},
	UGCTask_EventAttackHit = {
		playerTriggeridename = "Player.AttackHit",
		triggeridnamme = TriggerEvent.MobAttackHit
	},
	UGCTask_EventChangeAttr = {
		playerTriggeridename = "Player.ChangeAttr",
		triggeridnamme = TriggerEvent.MobChangeAttr
	},
	UGCTask_EventRemoveBuff = {
		playerTriggeridename = "Player.RemoveBuff",
		triggeridnamme = TriggerEvent.ActorRemoveBuff
	},
	UGCTask_EventDamage = {
		triggeridnamme = TriggerEvent.ActorDamage
	},
	UGCTask_EventAreaIn = {
		playerTriggeridename = "Player.AreaIn",
		triggeridnamme = TriggerEvent.MobAreaIn
	},
	UGCTask_EventAreaOut = {
		playerTriggeridename = "Player.AreaOut",
		triggeridnamme = TriggerEvent.MobAreaOut
	},
	UGCTask_EvntCollide = {
		playerTriggeridename = "Player.Collide",
		triggeridnamme = "Actor.Collide"
	},
	UGCTask_EventBeHurt = {
		playerTriggeridename = "Player.BeHurt",
		triggeridnamme = "Actor.BeHurt"
	},
	UGCTask_EvntClickActor = {
		playerTriggeridename = "Player.ClickActor",
		triggeridnamme = TriggerEvent.ActorClickActor
	},
	UGCTask_EvntTeamActorBeHeurt = {
		triggeridnamme = "TeamActorBeHeurt"
	},
	UGCTask_EventBeInteract = {
		triggeridnamme = "ClientMob_Interact"
	},
	UGCTask_EventBePlayerInteract = {
		triggeridnamme = "ClientMob_Interact"
	},
	UGCTask_EventBePlaySound = {
		triggeridnamme = "PlaySound"
	},
	UGCTask_EventActorCollide = {
		playerTriggeridename = "Player.Collide",
		triggeridnamme = "Actor.Collide"
	},
	UGCTask_EventPlayerCollide = {
		playerTriggeridename = "Player.Collide",
		triggeridnamme = "Actor.Collide"
	},
	UGCTask_EventActorCollideFilterPlayer = {
		triggeridnamme = "Actor.Collide"
	},
	UGCTask_EventOnLanded = {
		triggeridnamme = "ActorReachShore"
	},
	UGCTask_EventRangeCreatureTypeAttacked = {
		triggeridnamme = "RangeActorBeHeurt"
	},
	UGCTask_EventRangeCreatureTypeGroupAttacked = {
		triggeridnamme = "RangeActorBeHeurt"
	},
	UGCTask_EvntBeClick = {
		needRegisterEvent = "Player.TouchObj",
		triggeridnamme = "Obj.BeTouched"
	}
}
local regGTrigerEveent = {
	UGCTask_EventHostBeHurt = {
		triggeridnamme = "Player.BeHurt"
	},
	UGCTask_EventChildrenBeHeurtEvent = {
		triggeridnamme = "Actor.NewBeHurt"
	},
	UGCTask_EventPlayerInputString = {
		triggeridnamme = "Player.NewInputContent"
	},
	UGCTask_EventActorDie = {
		playerTriggeridename = "Player.Die",
		triggeridnamme = "Actor.Die"
	},
	UGCTask_EventPlayerPlayAction = {
		triggeridnamme = "Player.PlayAction"
	}
}
local regAINPCEveent = {
	UGCTask_EventAiNPC = true
}

function BTreeClass:GetObjId()
	if self.objid then
		return self.objid
	end

	if self.this and self.this.GetTargetMob then
		local mob = self.this:GetTargetMob()

		if mob then
			self.objid = mob:getObjId()
		end
	end

	return self.objid
end

function BTreeClass:regTriginfo(name, node, param)
	local lname = name

	if regtrigerEveent[lname] then
		if regtrigerEveent[lname].playerTriggeridename then
			self.this:RegEvent(regtrigerEveent[lname].triggeridnamme, node, regtrigerEveent[lname].playerTriggeridename)
		else
			self.this:RegEvent(regtrigerEveent[lname].triggeridnamme, node)
		end

		if regtrigerEveent[lname].needRegisterEvent then
			GetInst("BTEventManager"):RegisterEvent(regtrigerEveent[lname].needRegisterEvent)
		end
	end

	self:regGTriginfo(name, node, param)
	self:regAINPCEveent(name, node)
end

function BTreeClass:regGTriginfo(name, node, param)
	local lname = name
	local dynamicEventName = nil

	if lname == "UGCTask_EventPlayerItem" then
		dynamicEventName = ResolvePlayerItemEventName(param)

		if not dynamicEventName then
			return
		end

		self.this:RegGEvent(dynamicEventName, node)
	elseif regGTrigerEveent[lname] then
		if regGTrigerEveent[lname].playerTriggeridename then
			self.this:RegGEvent(regGTrigerEveent[lname].triggeridnamme, node, regGTrigerEveent[lname].playerTriggeridename)
		else
			self.this:RegGEvent(regGTrigerEveent[lname].triggeridnamme, node)
		end
	end

	local eventname = dynamicEventName

	if not eventname and regGTrigerEveent[lname] then
		eventname = regGTrigerEveent[lname].triggeridnamme
	elseif regtrigerEveent[lname] then
		eventname = regtrigerEveent[lname].triggeridnamme
	end

	local info = VisualCodeDef:GetFilterEventInfo(eventname)

	if info then
		local filterparam = nil

		if param.subparam and param.subparam[1] then
			local paramtype = param.subparam[1].paramtype

			if paramtype == AIDefine.BtreeParamType.Enum then
				local str = VisualCodeApiProxy:GetEnumInfo(param.subparam[1].val)

				if str then
					filterparam = str

					if type(str) == "string" then
						local tb = utils.split(str, ".")
						local val = nil

						for i = 1, #tb do
							if i == 1 and val == nil then
								val = _G[tb[i]] or CmpEnvEnum[tb[i]]
							elseif type(val) == "table" then
								val = val[tb[i]]
							end
						end

						if val then
							filterparam = val
						end
					end
				end
			elseif paramtype == AIDefine.BtreeParamType.GetValueFun and param.subparam[1].filterfunc then
				local ret, msg = pcall(param.subparam[1].filterfunc)

				if ret then
					filterparam = msg
				end
			end
		end

		if not filterparam then
			filterparam = ""
		else
			local num = tonumber(filterparam)

			if num then
				filterparam = num
			end
		end

		GameVM.ScriptSupportEvent:WaitNotifyClient(eventname, filterparam)
	end
end

function BTreeClass:regAINPCEveent(name, node)
	local lname = name

	if regAINPCEveent[lname] then
		self.this:RegAiNPCEvent(node)
	end
end

function BTreeClass:IsNoSetParamNode(name)
	return noSetParamNode[name]
end
