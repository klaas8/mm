local enum_comm = {
	Developer = {
		ShopNormalGroupID = 7,
		PassPortItemID = 10113,
		TagType = {
			Hot = 2,
			None = 1,
			Discount = 7,
			Timelimit = 6,
			Popular = 5,
			Recommend = 4,
			New = 3
		},
		CurrencyType = {
			Coin = 2,
			Money = 1,
			MiniPointAndMiniCoin = 4,
			MiniPoint = 3
		}
	},
	homechest = {
		GolderFruitUIIndex = 100
	},
	smscodetype = {
		write_off = 9,
		lookdevice = 8,
		getbackuin = 7,
		uploadmap = 6,
		passwd = 5,
		setsafestate = 4,
		safelogin = 3,
		unbindphone = 2,
		bindphone = 1
	},
	smsTemplateid = {
		write_off = 1740027,
		lookdevice = 1405543,
		uploadmap = 604458,
		passwd = 489165,
		setsafestate = 478582,
		safelogin = 461053,
		unbindphone = 892451,
		bindphone = 607797,
		phonereg = 1107761,
		phonelogin = 1107762
	},
	emailcodetype = {
		write_off = 9,
		lookdevice = 8,
		getbackuin = 7,
		uploadmap = 6,
		passwd = 5,
		setsafestate = 4,
		safelogin = 3,
		unbindemail = 2,
		bindemail = 1
	},
	identityauth = {
		idtype = {
			other = 5,
			passport = 4,
			hkmopermit = 3,
			armyman = 2,
			idcard = 1
		}
	},
	email_comm_type = {
		sendItem = 22,
		demandItem = 21,
		workSpace = 20,
		feedback = 15,
		weeklyreport = 14,
		XQlabelresult = 13,
		vipcard_demand = 12,
		vipcard_present = 11,
		weaponskin = 10,
		newComment = 9,
		atPush = 8,
		attentionCommentMap = 7,
		giveLikePush = 6,
		InvitationToEvaluate = 5,
		sharewantgift = 4,
		wantgift = 3,
		renameresult = 2,
		sendpresent = 1,
		normal = 0,
		sendThankBack = 27,
		sendRedPocket = 26,
		sendFriendGift = 25,
		mapReportResult = 24,
		demandItemReplay = 23
	},
	Present = {
		Limit = {
			TARGET_MAX_TIMES = 5,
			DAY_MAX_TIMES = 20,
			CHESTTREE_LEVEL_LIMIT = 0
		}
	},
	FriendGiftType = {
		SKIN = 1,
		NULL = 0,
		ACTION = 9,
		ITEM_SPEC = 8,
		SPRAY_PAINT = 7,
		VIPCARD = 6,
		WEAPON_SKIN = 5,
		LOTTERT_GIFT = 4,
		ITEM_SHOP = 3,
		CUSTOM_SKIN = 2
	},
	ResCenter = {
		ResType = {
			EFFECT_TYPE = 6,
			TEXTURE_TYPE = 5,
			MECHANICAL_TYPE = 4,
			BLUE_PRINT_TYPE = 3,
			ANIMATION_TYPE = 2,
			CUSTOM_MODEL_TYPE = 1,
			PROGRAM_TYPE = 8,
			SOUND_TYPE = 7
		},
		MotionFrom = {
			AR_CAPTURE = 1,
			OFFICIAL = 3,
			CUSTOM_MODEL = 2
		}
	},
	MotionType = {
		VICTORY = 14,
		STRETCH_ONESELF = 13,
		GET_ANGRY = 12,
		WEEP = 11,
		THINK_DOWN = 10,
		SAY_HELLO = 9,
		BEAR_ATTACK = 8,
		DIE = 7,
		ATTACK = 6,
		SWIMMING = 5,
		LIE_DOWN = 4,
		SIT_DOWN = 3,
		RUN = 2,
		STAND = 1,
		CUSTOM = 0,
		TRANSFER = 19,
		POSE = 18,
		FALL_GROUND = 17,
		LEISURE_ACTION = 16,
		THANKS = 15
	},
	Rename = {
		FAILED = 2,
		NULL = 0,
		SUCCESS = 1,
		REVIEWING = 3
	},
	Business = {
		SUBSCRIBE_MINIB = 1,
		NULL = 0
	},
	shop_standby_type1 = {
		from4 = 4,
		from3 = 3,
		from2 = 2,
		from1 = 1,
		from8 = 8,
		from7 = 7,
		from6 = 6,
		from5 = 5
	},
	shop_standby_type2 = {
		from4 = 4,
		from3 = 3,
		from2 = 2,
		from1 = 1,
		from8 = 8,
		from7 = 7,
		from6 = 6,
		from5 = 5
	},
	SensitiveWords_Replace = {
		mapcomment = "mapcomment",
		dynamicscomment = "dynamicscomment",
		mood = "mood",
		maprecommendation = "maprecommendation",
		driftbottle = "driftbottle",
		dynamics = "dynamics"
	}
}
local vk = nil

function vk(t)
	if type(t) == "table" then
		local tt = {}

		for k, v in pairs(t) do
			if type(v) == "table" then
				tt[k] = vk(v)
			else
				tt[v] = k
			end
		end

		return tt
	else
		return t
	end
end

if table.merge then
	table.merge(enum_comm, vk(enum_comm))
end

_G.g_enum_comm = enum_comm

return enum_comm
