return {
	command = true,
	col = true,
	br = true,
	base = true,
	area = true,
	input = true,
	link = true,
	wbr = true,
	track = true,
	source = true,
	param = true,
	meta = true,
	keygen = true,
	img = true,
	hr = true,
	embed = true
}
