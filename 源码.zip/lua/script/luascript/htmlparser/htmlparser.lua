local function noop(...)
end

local str = tostring
local char = string.char
local ElementNode = require("luascript.htmlparser.ElementNode")
local voidelements = require("luascript.htmlparser.voidelements")
local HtmlParser = {}

local function parse(text, limit, opts)
	opts = opts or {}
	opts.looplimit = opts.looplimit or 1000
	opts.allowed_tags = opts.allowed_tags or nil
	opts.collect_data = opts.collect_data or nil
	text = str(text)
	limit = limit or opts.looplimit or 1000
	local log = opts.log
	local prn = log and function (l, f, ...)
		local t = ("[%s] "):format(l:upper())

		log(t .. f:format(...))
	end or noop
	local err = opts.noerr and noop or function (f, ...)
		prn("e", f, ...)
	end
	local line = debug and function (lvl)
		return debug.getinfo(lvl or 2).currentline
	end or noop
	local dbg = opts.debug and function (f, ...)
		prn("d", f:gsub("#LINE#", str(line(3))), ...)
	end or noop
	local collected_data = {}

	local function set_error(msg, detailed_msg)
		detailed_msg = detailed_msg or msg

		err(detailed_msg)

		return nil, msg
	end

	local function validate_tag_and_attrs(tag_name, attrs)
		if not opts.allowed_tags then
			return true
		end

		local allowed_attrs = opts.allowed_tags[tag_name:lower()]

		if not allowed_attrs then
			return false, string.format("Tag '%s' is not allowed", tag_name)
		end

		if type(allowed_attrs) == "table" then
			for attr_name, _ in pairs(attrs) do
				if not allowed_attrs[attr_name:lower()] then
					return false, string.format("Attribute '%s' is not allowed for tag '%s'", attr_name, tag_name)
				end
			end
		end

		return true
	end

	local tpl = false

	if not opts.keep_comments then
		text = text:gsub("<!%-%-.-%-%->", "")
	end

	local tpr = {}

	if not opts.keep_danger_placeholders then
		local busy = {}
		local i = 0

		repeat
			local cc = char(i)

			if not text:match(cc) then
				if not tpr["<"] or not tpr[">"] then
					if not busy[i] then
						if not tpr["<"] then
							tpr["<"] = cc
						elseif not tpr[">"] then
							tpr[">"] = cc
						end

						busy[i] = true

						dbg("c:{%s}||cc:{%d}||tpr[c]:{%s}", str(c), cc:byte(), str(tpr[c]))
						dbg("busy[i]:{%s},i:{%d}", str(busy[i]), i)
						dbg("[FindPH]:#LINE# Success! || i=%d", i)
					else
						dbg("[FindPH]:#LINE# Busy! || i=%d", i)
					end

					dbg("c:{%s}||cc:{%d}||tpr[c]:{%s}", c, cc:byte(), str(tpr[c]))
					dbg("%s", str(busy[i]))
				else
					dbg("[FindPH]:#LINE# Done!", i)

					break
				end
			else
				dbg("[FindPH]:#LINE# Text contains this byte! || i=%d", i)
			end

			local skip = 1

			if i == 31 then
				skip = 96
			end

			i = i + skip
		until i == 255

		i = nil

		if not tpr["<"] or not tpr[">"] then
			err("Impossible to find at least two unused byte codes in this HTML-code. We need it to escape bracket-contained placeholders inside tags.")
			err("Consider enabling 'keep_danger_placeholders' option (to silence this error, if parser wasn't failed with current HTML-code) or manually replace few random bytes, to free up the codes.")
		else
			dbg("[FindPH]:#LINE# Found! || '<'=%d, '>'=%d", tpr["<"]:byte(), tpr[">"]:byte())
		end

		local function g(id, ...)
			local arg = {
				...
			}
			local orig = arg[id]
			arg[id] = arg[id]:gsub("(.)", tpr)

			if arg[id] ~= orig then
				tpl = true

				dbg("[g]:#LINE# orig: %s", str(orig))
				dbg("[g]:#LINE# replaced: %s", str(arg[id]))
			end

			dbg("[g]:#LINE# called, id: %s, arg[id]: %s, args { " .. ("{%s}, "):rep(#arg):gsub(", $", "") .. " }", id, arg[id], ...)
			dbg("[g]:#LINE# concat(arg): %s", table.concat(arg))

			return table.concat(arg)
		end

		text = text:gsub("(=[%s]-)" .. "(%b'')", function (...)
			return g(2, ...)
		end):gsub("(=[%s]-)" .. "(%b\"\")", function (...)
			return g(2, ...)
		end):gsub("(<" .. (opts.tpl_skip_pattern or "[^!]") .. ")([^>]+)" .. "(>)", function (...)
			return g(2, ...)
		end):gsub("(" .. (tpr["<"] or "__FAILED__") .. ")(" .. (opts.tpl_marker_pattern or "[^%w%s]") .. ")([%g%s]-)" .. "(%2)(>)" .. "([^>]*>)", function (...)
			return g(5, ...)
		end)
	end

	local index = 0
	local root = ElementNode:new(index, str(text))
	local node = root
	local descend = true
	local tpos = 1
	local opentags = {}
	local tag_stack = {}

	while true do
		if index == limit then
			return set_error("HTML parse limit reached", string.format("Main loop reached loop limit (%d). Consider either increasing it or checking HTML-code for syntax errors", limit))
		end

		local openstart, name = nil
		openstart, tpos, name = root._text:find("<" .. "([%w-]+)" .. "[^>]*>", tpos)

		dbg("[MainLoop]:#LINE# openstart=%s || tpos=%s || name=%s", str(openstart), str(tpos), str(name))

		if not name then
			break
		end

		if opts.allowed_tags then
			local is_valid = opts.allowed_tags[name:lower()] ~= nil

			if not is_valid then
				return set_error("Invalid tag", string.format("Tag '%s' is not allowed", name))
			end
		end

		index = index + 1
		local tag = ElementNode:new(index, str(name), node or {}, descend, openstart, tpos)
		node = tag
		local tagloop = nil
		local tagst = tag:gettext()
		local apos = 1
		local collected_attrs = {}

		while true do
			dbg("[TagLoop]:#LINE# tag.name=%s, tagloop=%s", str(tag.name), str(tagloop))

			if tagloop == limit then
				return set_error("HTML parse limit reached", string.format("Tag parsing loop reached loop limit (%d)", limit))
			end

			local start, k, eq, quote, v, zsp = nil
			start, apos, k, zsp, eq, zsp, quote = tagst:find("%s+" .. "([^%s=/>]+)" .. "([%s]-)" .. "(=?)" .. "([%s]-)" .. "(['\"]?)", apos)

			dbg("[TagLoop]:#LINE# start=%s || apos=%s || k=%s || zsp='%s' || eq='%s', quote=[%s]", str(start), str(apos), str(k), str(zsp), str(eq), str(quote))

			if not k or k == "/>" or k == ">" then
				break
			end

			if eq == "=" then
				local pattern = "=([^%s>]*)"

				if quote ~= "" then
					pattern = quote .. "([^" .. quote .. "]*)" .. quote
				end

				start, apos, v = tagst:find(pattern, apos)

				dbg("[TagLoop]:#LINE# start=%s || apos=%s || v=%s || pattern=%s", str(start), str(apos), str(v), str(pattern))
			end

			v = v or ""

			if tpl then
				for rk, rv in pairs(tpr) do
					v = v:gsub(rv, rk)

					dbg("[TagLoop]:#LINE# rv=%s || rk=%s", str(rv), str(rk))
				end
			end

			collected_attrs[k:lower()] = v

			dbg("[TagLoop]:#LINE# k=%s || v=%s", str(k), str(v))
		end

		if opts.allowed_tags then
			local is_valid, err_msg = validate_tag_and_attrs(tag.name, collected_attrs)

			if not is_valid then
				return set_error("Invalid attribute", err_msg)
			end
		end

		for k, v in pairs(collected_attrs) do
			tag:addattribute(k, v)

			tagloop = (tagloop or 0) + 1
		end

		if opts.collect_data and opts.collect_data[tag.name:lower()] then
			local data = {
				_type = tag.name:lower()
			}
			local should_collect = false

			for attr_name, should_collect_attr in pairs(opts.collect_data[tag.name:lower()]) do
				if should_collect_attr and collected_attrs[attr_name:lower()] then
					data[attr_name] = collected_attrs[attr_name:lower()]
					should_collect = true
				end
			end

			if should_collect then
				table.insert(collected_data, data)
			end
		end

		local is_self_closing = false
		local self_closing_match = tagst:match("/>[%s]*$")

		if self_closing_match then
			if not voidelements[tag.name:lower()] then
				return set_error("Invalid self-closing tag", string.format("Tag '%s' cannot be self-closed. Only void elements can use self-closing syntax.", tag.name))
			end

			is_self_closing = true
		end

		if voidelements[tag.name:lower()] or is_self_closing then
			descend = false

			tag:close()
		else
			descend = true

			table.insert(tag_stack, tag)

			opentags[tag.name] = opentags[tag.name] or {}

			table.insert(opentags[tag.name], tag)
		end

		local closeend = tpos
		local closingloop = nil

		while true do
			if closingloop == limit then
				return set_error("HTML parse limit reached", string.format("Tag closing loop reached loop limit (%d)", limit))
			end

			local closestart, closing, closename = nil
			closestart, closeend, closing, closename = root._text:find("[^<]*<(/?)([%w-]+)", closeend)

			dbg("[TagCloseLoop]:#LINE# closestart=%s || closeend=%s || closing=%s || closename=%s", str(closestart), str(closeend), str(closing), str(closename))

			if not closing or closing == "" then
				break
			end

			if closing == "/" then
				if #tag_stack == 0 then
					return set_error("Unexpected closing tag", string.format("Unexpected closing tag '%s'", closename))
				end

				local last_tag = tag_stack[#tag_stack]

				if last_tag.name ~= closename then
					return set_error("Tag mismatch", string.format("Tag mismatch: expected closing tag '%s', got '%s'", last_tag.name, closename))
				end

				table.remove(tag_stack)
			end

			tag = table.remove(opentags[closename] or {}) or tag
			closestart = root._text:find("<", closestart)

			dbg("[TagCloseLoop]:#LINE# closestart=%s", str(closestart))
			tag:close(closestart, closeend + 1)

			node = tag.parent
			descend = true
			closingloop = (closingloop or 0) + 1
		end
	end

	if #tag_stack > 0 then
		local unclosed_tags = {}

		for _, tag in ipairs(tag_stack) do
			table.insert(unclosed_tags, tag.name)
		end

		return set_error("Unclosed tags", string.format("Unclosed tags: %s", table.concat(unclosed_tags, ", ")))
	end

	if tpl then
		dbg("tpl")

		for k, v in pairs(tpr) do
			root._text = root._text:gsub(v, k)
		end
	end

	return root, nil, collected_data
end

HtmlParser.parse = parse

return HtmlParser
