function PlayCameraAnimAndWait(anim_id)
	CutScenesMgr:playCameraAnim(anim_id)

	while CutScenesMgr:isPlayingCameraAnim(anim_id) do
		coroutine.yield()
	end
end

s_cutscene_0 = coroutine.create(function ()
	local kaka = GetWorldActorMgr(CurWorld):spawnMonster(3400, 9100, 2800, 3839, 290)

	kaka:getBody():setCurAnim(SEQ_LAYDOWN, 0)
	PlayCameraAnimAndWait(0)
	PopMsgBoxAndWait("aaaa")
	PlayCameraAnimAndWait(1)
end)

function cutscene_resume(id)
	local co = getglobal("s_cutscene_" .. id)
	local ret = coroutine.resume(co)

	return ret
end
