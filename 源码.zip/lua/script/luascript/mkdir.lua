if not LuaInterface or not LuaInterface.os_mkdir or not LuaInterface.io_dir_exsit then
	return
end

local function mkdir(path)
	if not LuaInterface:io_dir_exsit(path) then
		LuaInterface:os_mkdir(path)
	end
end

local path = "./data/mods/userdefault_0.1_667f325c-1ff1-11e7-93ae-92361f002671/behavior/actor/"

mkdir(path)

return "ok " .. path
