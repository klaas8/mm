function MiniWorksReqPrizeMap(uin, fn_wid, comment_uin, CommentObj)
	if uin and fn_wid and comment_uin then
		local url = mapservice.getserver() .. "/miniw/map/?act=prize_map_comment"
		url = url .. "&fn=" .. fn_wid
		url = url .. "&comment_uin=" .. comment_uin
		url = UrlAddAuth(url)

		Log("(LLTODO:MiniWorksReqPrizeMap, url = )" .. url)

		local userdata = {
			wid = fn_wid,
			comment_uin = comment_uin,
			_CommentObj = CommentObj
		}

		ns_http.func.rpc(url, MiniWorksRespPrizeMap, userdata)
	end
end
